# Sun Life Jenkins Pipeline Parameters

By default the pipeline will use the tools from the same environment.  For example, if running the pipeline in Stage Jenkins it will use Stage SonarQube and Artifactory, in Prod it will use Prod. See [default configuration module](vars/getConfiguration.groovy).

## Common Parameters

| Parameter Name | Default | Description |
| -------------- | ------- | ----------- |
| agentLabel     | linux-java8-liberty17 | Label of the Jenkins agent type required to run the job/pipeline.  Valid values: see [Jenkins Agent Labels][JenkinsAgentLabels] |
| deployment    | false | Trigger deployment to first environment on successful pipeline completion.  Valid values: true, false |
| artifactoryDeployer | Artifactory {env} | Jenkins Artifactory instance name to be used when pushing build artifacts.<br />For example: Artifactory Prod |
| artifactoryResolver | Artifactory Prod | Jenkins Artifactory instance name to be used when pushing build artifacts.<br />For example: Artifactory Prod |
| sonarQubeInstance | SonarQube {env} | Jenkins SonarQube instance name to be used when scanning code.<br />For example: SonarQube Stage |
| snapshotRepo | libs-snapshot-local | Repository in artifactory  to push build artifacts of snapshot builds. |
| stagingRepo | libs-staging-local | Repository in artifactory  to push build artifacts of staging builds(Release candidate).|
| releaseRepo | libs-release-local |  Repository in artifactory  to promote build artifacts of release builds. |
| releaseArtifactsResolver | maven-release-all |  Repository in artifactory  to resolve dependencies for release builds. |
| snapshotArtifactsResolver | maven-snapshot-all |  Repository in artifactory  to resolve dependencies for snapshot builds. |
| deploymentBranch | ^(develop\|release) | Regular expression of git branches to be used for pipeline. |
| sonarqubeScan | true | Toggle SonarQube scanning on or off.  Valid values: true, false |
| stepPublishToCodeDx | false | Turn on/off publishing to CodeDX. |
| successChannel   | {env}JenkinsPipelineSuccess webhook URL | MS Teams channel webhook URL to be notified of pipeline success.<br />For example: `https://sunlifefinancial.webhook...` |
| failureChannel   | {env}JenkinsPipelineFailure webhook URL | MS Teams channel webhook URL to be notified of pipeline errors. |
| unstableChannel  | {env}JenkinsPipelineUnstable (or Failure) webhook URL | MS Teams channel webhook URL to be notified of an unstable pipeline. |

## Maven Specific Parameters

| Parameter Name | Default | Description |
| -------------- | ------- | ----------- |
| mavenVersion   | Maven 3.3.9 | Required Maven version. |
| mavenGoal      | clean install | Maven command-line goals required to build (no tests will be run). |
| mavenProfile  | CI | Maven profile |
| mavenOption    | -Xmx1024m | Any Maven options to be added such as Java heap space requirements. |

## Gradle Specific Parameters

| Parameter Name | Default | Description |
| -------------- | ------- | ----------- |
| gradleTask      | clean build | Gradle command-line goals required to build (no tests will be run). |
| gradleTestGoal  | test | Maven command-line goals required to run tests. |
| gradleProperty  |  |  |
| gradleOptions   | -Xmx1024m | Any Maven options to be added such as Java heap space requirements. |

[JenkinsAgentLabels]: https://bitbucket.sunlifecorp.com/projects/DEVOPS/repos/devops-appdev/browse/Tools/Jenkins/JenkinsAgentLabels.md