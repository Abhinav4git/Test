# Sun Life Shared Jenkins Pipeline Library

## Pipelines

Main pipelines to be invoked via a simple Jenkinsfile stored with the application code.

### Sample Jenkinsfile

``` groovy
@@Library('jenkins-pipeline') _ // Remove extra @ character (workaround for rendering problem in Bitbucket)

buildMavenPipeline {

    deploymentApplicationName = 'web-apps-helloworld'
    artifactoryDeployer = 'Artifactory Stage'
    sonarQubeInstance = 'SonarQube Stage'
 }
```

You can customize the behaviour of your pipeline by adding other [pipeline parameters](PipelineParameters.md) into the `buildMavenPipeline` code block.

|||
| --- | --- |
| [buildMavenPipeline](vars/buildMavenPipeline.groovy) | For building Java applications with Maven. |
| [buildGradlePipeline](vars/buildGradlePipeline.groovy) | For building Java or Node.js applications with Gradle. |

## Pipeline Steps

| Pipeline Step             | Maven Module        | Gradle Module        | Variable for Toggling Step |
| -------------             | ------------        | -------------        | -------------------------- |
| Pipeline initialization   | [mavenInitializePipeline](vars/mavenInitializePipeline.groovy) | [gradleInitializePipeline](vars/gradleInitializePipeline.groovy) | |
| Release Creation  | [mavenRelease](vars/mavenRelease.groovy) | [gradleRelease](vars/gradleRelease.groovy) | |
| Checkout Release Tag  |  |  | |
| Artifactory configuration | [mavenConfigureArtifactory](vars/mavenConfigureArtifactory.groovy) | [gradleConfigureArtifactory](vars/gradleConfigureArtifactory.groovy) | |
| Build And Test                     | [mavenBuild](vars/mavenBuild.groovy)      | [gradleBuild](vars/gradleBuild.groovy)<br />[gradleClearCacheAndBuild](vars/gradleClearCacheAndBuild.groovy) | |
| Sonar branch analysis     | [mavenRunSonarQubeScan](vars/mavenRunSonarQubeScan.groovy) | [gradleRunSonarQubeScan](vars/gradleRunSonarQubeScan.groovy) | sonarQubeScan |
| Sonar pull request analysis     | [mavenPullRequestAnalysis](vars/mavenPullRequestAnalysis.groovy) | [gradlePullRequestAnalysis](vars/gradlePullRequestAnalysis.groovy) | pullRequestId |
| Publish to Artifactory    | [mavenPushToArtifactory](vars/mavenPushToArtifactory.groovy) | [gradlePushToArtifactory](vars/gradlePushToArtifactory.groovy) | |
| Xray scan                 | [stepRunXrayScan](vars/stepRunXrayScan.groovy) | [stepRunXrayScan](vars/stepRunXrayScan.groovy) |                     | |
| Deploy                    | [stepDeployToFirstEnvironment](vars/stepDeployToFirstEnvironment.groovy) | [stepDeployToFirstEnvironment](vars/stepDeployToFirstEnvironment.groovy) | deployment (and deploymentBranch set)  |
| Add interactive promotion | [stepPromoteArtifacts](vars/stepPromoteArtifacts.groovy) | [stepPromoteArtifacts](vars/stepPromoteArtifacts.groovy) | Option available when creating a release |




## Changes to code to run a maven pipeline

* Add Jenkinsfile to the root of your repository.

* Ensure 'Jenkins User' has admin rights to your repository.

![SelectFolder](images/ProjectPermissions.png)

* Make the following changes to your pom.xml

Add the following after the **properties** section and update the {repository_url} to the url for your repository(ssh) :

``` xml
  	<scm>
		<developerConnection>scm:git:{repository_url}</developerConnection>
		<url>{repository_url}</url>
	  	<tag>@{project.version}</tag>
  	</scm>	
```

Here is an example:


![SelectFolder](images/ExampleFile.png)

   Add this under the **plugins** section :
``` xml
                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-release-plugin</artifactId>
                    <version>3.0.0-M1</version>
                </plugin> 
```
