//Generate Xray report for current build, extract report as JSON to Jenkins workspace
//This report can be uploaded to CodeDx to import vulnerabilities from Jfrog
def call(effectiveConfiguration = [:]){
  def connectionDetails = getEnvironmentDetails()
  def authValue = craftAuthorizationValue(connectionDetails)
  def reportId = generateReport(connectionDetails, authValue)
  exportReport(reportId, authValue,connectionDetails)
  deleteReport(reportId, authValue, connectionDetails)

}

//This will need to be changed to use CDX creds (currently using James')
//Store these creds in Jenkins environment may be a solution
//function to craft Authorization Header to allow for authenitcation to Jfrog env
def craftAuthorizationValue(connectionDetails){
  //converts API-Key String to base64 encoded string to required for Authentication header
  def credPair = "codedx:$connectionDetails.key" //replace with CDX creds after provisioned
  def encoded = credPair.getBytes().encodeBase64().toString()
  def authValue = "Basic $encoded"
  return authValue
}

//function to export Xray vulnerability report once status of report is 'completed'
def exportReport(reportId,authValue,connectionDetails){
  def status = checkReportStatus(reportId, authValue,connectionDetails)
  def count = 4
  //polling report status
  while(status == 'pending' || status == 'running' && count>0){
    sleep(15)
    status = checkReportStatus(reportId, authValue,connectionDetails)
    count--
  }
  if (status == 'failed'){
    echo "Report generation failure, skipping.."
    return 1
  }
  //request to export the report
  def response = httpRequest(
    acceptType: 'APPLICATION_JSON',
    contentType: 'APPLICATION_JSON',
    httpMode: 'GET',
    customHeaders: [[maskValue: true, name: 'Authorization',value: "${authValue}"]],
    ignoreSslErrors: true,
    url: "${connectionDetails.url}/xray/api/v1/reports/export/${reportId}?file_name=CodeDx_Report&format=json",
    outputFile: 'CodeDx_Report.zip',
    consoleLogResponseBody : false
    )
    count = 4
    while(fileExists('CodeDx_Report.zip')!=true || count==0){
      echo "Waiting for Xray report to export..."
      echo "sleeping for 5 seconds"
      sleep(5)
      echo "Attempts remaining: $count"
      count--
    }
    if(fileExists('CodeDx_Report.zip')!=true){
      echo "Report not exported \n exiting..."
      return 1
    }

    echo "CodeDx_Report.zip available in workspace"
    echo "unpacking CodeDx_Report.zip..."
    unzip(
      zipFile: "CodeDx_Report.zip",
      )
    return 0
}

//polling function for report Status
def checkReportStatus(reportId,authValue,connectionDetails){
  //checks report status
  def response = httpRequest(
    acceptType: 'APPLICATION_JSON',
    contentType: 'APPLICATION_JSON',
    httpMode: 'GET',
    customHeaders: [[maskValue: true, name: 'Authorization',value: "${authValue}"]],
    ignoreSslErrors: true,
    url: "${connectionDetails.url}/xray/api/v1/reports/${reportId}",
    consoleLogResponseBody : true
    ).getContent()

    jsonResponse = readJSON(
      text: response,
      returnPojo: true
      )

    def status = jsonResponse['status']
    return status
}

//sends request to generate report for the build that was just published,returns ID of the report
def generateReport(connectionDetails, authValue){
  def buildName = env.JOB_NAME.replaceAll('/', ' :: ')
  echo "Requesting report for Build --> $buildName"
  def response = httpRequest(
    acceptType: 'APPLICATION_JSON',
    contentType: 'APPLICATION_JSON',
    httpMode: 'POST',
    customHeaders: [[maskValue: true, name: 'Authorization',value: "${authValue}"]],
    ignoreSslErrors: true,
    //requestBody: "{\"name\":\"CodeDx_Report\",\"resources\":{\"repositories\":[{\"name\":\"ext-nuget-snapshot-local\"}]}}",
    //requestBody: "{\"name\":\"CodeDx_Report\",\"resources\":{\"builds\":{\"names\":[\"Web :: web-apps :: web-apps-gb_advisor\"],\"number_of_latest_versions\":1}}}",
    requestBody: "{\"name\":\"CodeDx_Report\",\"resources\":{\"builds\":{\"names\":[\"${buildName}\"],\"number_of_latest_versions\":1}}}",
    url: "${connectionDetails.url}/xray/api/v1/reports/vulnerabilities",
    consoleLogResponseBody : true
    ).getContent()

    jsonResponse = readJSON (
        text: response,
        returnPojo: true
    )
    def reportId = jsonResponse['report_id']
    return reportId
}

//sets base url/API key values to be used in http request of above functions
def getEnvironmentDetails(){
  def values = [:]
  //can update with dev details once dev-artifactory is back up
  if ("${SLF_JENKINS_ENVIRONMENT}" == "Dev"){
    values.put('url', "https://stage-artifactory.sunlifecorp.com")
    values.put ('key',"AKCp8jQHympgSwgovRddkMJ8UDxCasgLNWYCKXfqfWPUDUHj5zumFUwmMeNMmwhZvmsQwdaut" ) //invalid
  }
  else if ("${SLF_JENKINS_ENVIRONMENT}" == "Stage") {
    values.put('url',"https://stage-artifactory.sunlifecorp.com")
    values.put('key' , "AKCp8jQHympgSwgovRddkMJ8UDxCasgLNWYCKXfqfWPUDUHj5zumFUwmMeNMmwhZvmsQwdaut")
  }
  else {
    values.put('url',"https://artifactory.sunlifecorp.com")
    values.put('key' , "AKCp8jQHymq7oujh1HXasDykCDrYNjDWbn216BAxGjKqimTiiMtRtcFMTWc4dSW8MTGBCj44D")
  }

  return values
}

def deleteReport(reportId, authValue, connectionDetails){
  httpRequest(
    acceptType: 'APPLICATION_JSON',
    contentType: 'APPLICATION_JSON',
    httpMode: 'DELETE',
    customHeaders: [[maskValue: true, name: 'Authorization',value: "${authValue}"]],
    ignoreSslErrors: true,
    url: "${connectionDetails.url}/xray/api/v1/reports/${reportId}",
    consoleLogResponseBody : true
    )
}
