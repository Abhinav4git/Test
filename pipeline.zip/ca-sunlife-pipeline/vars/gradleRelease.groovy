def call(effectiveConfiguration =[:]){
    sshagent(['gitget-ssh']){
        withSonarQubeEnv("${effectiveConfiguration.sonarQubeInstance}") {
            rtGradleRun(
                    buildFile: 'build.gradle',
                    tasks: "final sonarqube artifactoryPublish -Prelease.scope=${params.releaseScope} -Dsonar.branch.name=${GIT_BRANCH.substring('origin/'.size())}  ${effectiveConfiguration.gradleProperty}",
                    deployerId: "GRADLE_DEPLOYER",
                    resolverId: "GRADLE_RESOLVER",
                    useWrapper: true,
                    usesPlugin: true
            )
        }
    }

    rtPublishBuildInfo(
        serverId:  "${effectiveConfiguration.artifactoryDeployer}"
    )
}