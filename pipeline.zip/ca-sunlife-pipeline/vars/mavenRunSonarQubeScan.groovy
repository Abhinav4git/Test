//Build step for Java Maven
def call(effectiveConfiguration = [:]) {
    try{
        withSonarQubeEnv("${effectiveConfiguration.sonarQubeInstance}") {
            rtMavenRun(
                pom: 'pom.xml',
                goals: "sonar:sonar -P ${effectiveConfiguration.mavenProfile} -Dsonar.branch.name=${GIT_BRANCH.substring('origin/'.size())}",
                opts: "${effectiveConfiguration.mavenOption}",
                deployerId: "MAVEN_DEPLOYER",
                resolverId: "MAVEN_RESOLVER"
            )
        } 
    }
    

    catch(Exception err){
        echo 'Test Failed'
        currentBuild.result = 'UNSTABLE'
    }
}
