def call(body) {
    def pipelineParams= [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()
    def effectiveConfiguration = mavenInitializePipeline(pipelineParams)
    pipeline {
        agent {
            label "${effectiveConfiguration.agentLabel}"
        }

          tools {
              maven "${effectiveConfiguration.mavenVersion}"
          }

        options {
            buildDiscarder(logRotator(daysToKeepStr: '30', numToKeepStr: '15', artifactNumToKeepStr: '10', artifactDaysToKeepStr: '60'))
            disableConcurrentBuilds()
        }

        parameters{
            gitParameter branchFilter: 'origin/(.*)', defaultValue: "none", name: 'BRANCH', type: 'PT_BRANCH'
            //string(name: 'branchName', description: 'Branch Name', defaultValue: "none")
            booleanParam(name: 'isRelease', description: 'Enable this parameter to create release artifact', defaultValue: false)
            choice(name: 'releaseScope', description: 'Bumping the semantic release major/minor/patch', choices: ['minor','patch','major'])
            string(name: 'pullRequestId', description: 'Pull request id', defaultValue: "-1")
            string(name: 'pullRequestSource', description: 'Pull request source branch', defaultValue: "none")
            string(name: 'pullRequestDestination', description: 'Pull request destination branch', defaultValue: "none")
        }

        environment {
            VERSION = readMavenPom().getVersion()
            //MAVEN_SETTINGS_FILE_ID = "196daf49-9ffd-4571-8f6a-027a91831766"    //Dev
            //MAVEN_SETTINGS_FILE_ID = "fb511e14-f7ad-4ea9-bc4e-be45dcd2265e"    //Stage
            MAVEN_SETTINGS_FILE_ID = "8d2a7047-31b1-47a8-8788-be4b89b71125" //Prod
            BUILD_NAME = "${JOB_NAME}".replace("/", " :: ")
            jvmBuildParams = "${effectiveConfiguration.jvmBuildParams}" + " -Dgit.commit=${GIT_COMMIT} -Dgit.url=${GIT_URL} -Dgit.branch=${GIT_BRANCH}"
           
        }

        stages {
            stage ('Initialize pipeline') {
                steps {
                   mavenConfigureArtifactory(effectiveConfiguration);
                }
            }

            stage('Create Release'){
                when {
                    expression {
                        params.isRelease
                    }
                }
                
                steps{
                        mavenRelease(effectiveConfiguration);
                }
            }

            stage('Checkout Release Tag') {
                when {
                    expression {
                        params.isRelease
                    }
                }
                steps{
                    script{
                        def latestTag = sh(returnStdout: true, script: "git describe --tags --abbrev=0").trim()
                        checkout([$class: 'GitSCM', branches: [[name: "${latestTag}"]], extensions: [], userRemoteConfigs: [[credentialsId: 'gitget-ssh', url: "${GIT_URL}"]]])
                    }

                }
            }

            stage('Build') {
               
                    steps {
                            mavenBuild(effectiveConfiguration);
                    }
            }
            stage('Test') {
                
                    steps {
                            script{
                                mavenTest(effectiveConfiguration);
                            }  
                            
                    }
            }
            stage('Sonar branch analysis') {

                when {
                    expression { effectiveConfiguration.sonarQubeScan.equalsIgnoreCase('true') }
                }
                steps {
                    script{
                        mavenRunSonarQubeScan(effectiveConfiguration);
                    }
                    
                }
            }

            // Must configure Bitbucket repository for pull request analysis
            stage('Sonar pull request analysis') {

                when {
                    expression {
                        params.pullRequestId ==~ /^[1-9]\d*/
                    }
                }
               
                steps {
   
                         mavenPullRequestAnalysis(effectiveConfiguration);
                 }
            }

            stage('Publish to Artifactory') {
                steps {
                    script{
                        if(!(params.isRelease) && !(VERSION.contains('SNAPSHOT'))){
                            echo "Skipping push to artifactory"
                        
                        }
                        else{
                            mavenPushToArtifactory(effectiveConfiguration);
                        }
                    }      
                }                
            }

            // TODO add stepRunXrayScan = true/false
            stage('Xray scan') {
                when {  
                    allOf{
                        expression { effectiveConfiguration.runXrayScan.equalsIgnoreCase('true')  }
                        expression { !(params.isRelease) && !(VERSION.contains('SNAPSHOT')) }
                    }
                }
                steps{
                    stepRunXrayScan(effectiveConfiguration);
                }
            }

            stage('Prepare CodeDx Analysis Files'){
              when{
                expression {effectiveConfiguration.stepPublishToCodeDx.equalsIgnoreCase('true')}
              }
              steps{
                stepExtractJFrogReport(effectiveConfiguration);
              }
            }

            stage('Publish to CodeDx'){
              when{
                expression {effectiveConfiguration.stepPublishToCodeDx.equalsIgnoreCase('true')}
              }
              steps{
                stepPublishToCodeDx(effectiveConfiguration);
              }
            }

            stage('Deploy') {
                when {
                    expression{
                        return GIT_BRANCH.substring('origin/'.size()) =~ /${effectiveConfiguration.deploymentBranch}/ && effectiveConfiguration.deployment =~ /(?i)(Y|YES|T|TRUE|ON|RUN|true|yes|y|t|on|run)/
                    }
                }

                steps {
                    stepDeployToFirstEnvironment(effectiveConfiguration);
                }
            }

            stage('Add interactive promotion'){
                when {
                    expression {
                        params.isRelease
                    }
                }
                steps {
                    stepPromoteArtifacts(effectiveConfiguration);
                }
            }

        }


        post {
            // TODO Commented because stepNotifyBitbucket plugin not in k8s/AWS Jenkins - get Paul V to add.
            always{
                stepNotifyBitbucket(effectiveConfiguration)
                cleanWs()
            }

            success{
                office365ConnectorSend webhookUrl: "${effectiveConfiguration.successChannel}"
            }

            failure{
                office365ConnectorSend webhookUrl: "${effectiveConfiguration.failureChannel}"
            }

            unstable{
                office365ConnectorSend webhookUrl: "${effectiveConfiguration.unstableChannel}"
            }
        }
    }
}
