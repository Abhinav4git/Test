//Download dependencies from artifactory step for maven 
def call(effectiveConfiguration = [:]) {
    rtGradleDeployer(
            id: "GRADLE_DEPLOYER",
            serverId: "${effectiveConfiguration.artifactoryDeployer}",
            snapshotRepo:"${effectiveConfiguration.snapshotRepo}",
            releaseRepo: "${effectiveConfiguration.stagingRepo}"
    )

    rtGradleResolver(
            id: "GRADLE_RESOLVER",
            serverId: "${effectiveConfiguration.artifactoryResolver}",
            releaseRepo: "${effectiveConfiguration.releaseArtifactsResolver}",
            snapshotRepo: "${effectiveConfiguration.snapshotArtifactsResolver}"
    )
}
