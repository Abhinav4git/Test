//Artifactory upload step for Java Maven
def call(effectiveConfiguration = [:]) {
    
        // Obtain an Artifactory server instance, defined in Jenkins --> Manage Jenkins --> Configure System:
        def server = Artifactory.server "${effectiveConfiguration.artifactoryDeployer}"
        def rtMaven = Artifactory.newMavenBuild()

        def mavenGoalWithProfile = "${effectiveConfiguration.mavenGoal} -DskipTests ${jvmBuildParams} -P ${effectiveConfiguration.mavenProfile}"
        rtMaven.tool = "${effectiveConfiguration.mavenVersion}"

        rtMaven.deployer releaseRepo: "${effectiveConfiguration.stagingRepo}".toString(), snapshotRepo: "${effectiveConfiguration.snapshotRepo}".toString(), server: server
        rtMaven.resolver releaseRepo: "${effectiveConfiguration.releaseArtifactsResolver}".toString(), snapshotRepo: "${effectiveConfiguration.snapshotArtifactsResolver}".toString(), server: server

        def buildInfo = Artifactory.newBuildInfo()
        rtMaven.run pom: 'pom.xml', goals: mavenGoalWithProfile.toString(), buildInfo: buildInfo
        server.publishBuildInfo buildInfo
    
}