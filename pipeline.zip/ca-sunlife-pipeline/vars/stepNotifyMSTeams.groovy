//Notify MSTeams for Java Maven
def call(effectiveConfiguration = [:]){
    success{
        office365ConnectorSend "${effectiveConfiguration.successChannel}"
    }

    failure{
        office365ConnectorSend "${effectiveConfiguration.failureChannel}"
    }

    unstable{
        office365ConnectorSend "${effectiveConfiguration.failureChannel}"
    }
}