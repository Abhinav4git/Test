//Build step for Java Maven
def call(effectiveConfiguration = [:]){
    withSonarQubeEnv("${effectiveConfiguration.sonarQubeInstance}") {
        rtGradleRun(
                buildFile: 'build.gradle',
                tasks: "sonarqube -Dsonar.branch.name=${GIT_BRANCH.substring('origin/'.size())}",
                //deployerId: "GRADLE_DEPLOYER",
                resolverId: "GRADLE_RESOLVER",
                useWrapper: true,
                usesPlugin: true
        )
    }                     
}

