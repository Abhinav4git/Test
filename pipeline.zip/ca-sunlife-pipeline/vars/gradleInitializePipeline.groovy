//Get effective configuration for a project by merging default confuguration and configuration from jenkins file
def call(pipelineParams = [:]){

    def defaultConfiguration = [
        'agentLabel' : 'linux-java8-liberty17',
        'jdkVersion' : 'JDK 1.8',
        'gradleTask' : 'clean build ',
        'gradleProperty' : '',
        'gradleOptions' : '-Xmx1024m',
        'sonarQubeScan' : 'true',
        'deployment' : 'false',
        'artifactoryDeployer' : "Artifactory ${SLF_JENKINS_ENVIRONMENT}",
        'artifactoryResolver' : "Artifactory ${SLF_JENKINS_ENVIRONMENT}",
        'sonarQubeInstance' : "SonarQube ${SLF_JENKINS_ENVIRONMENT}",
        'deploymentBranch' : '^(develop|release)',
        'successChannel' : '',
        'failureChannel' : '',
        'unstableChannel' : '',
        'snapshotRepo' : 'libs-snapshot-local',
        'stagingRepo' : 'libs-staging-local',
        'releaseRepo' : 'libs-release-local',
        'runXrayScan' : 'true',
        'releaseArtifactsResolver' : 'maven-release-all',
        'snapshotArtifactsResolver' : 'maven-snapshot-all',
        'stepPublishToCodeDx' : 'false'
     ]
    def defaultConfig = setEnvironmentSpecificValues(defaultConfiguration)
    def effectiveConfiguration = merge(defaultConfig, pipelineParams)
    printConfiguration(effectiveConfiguration)
    return effectiveConfiguration
}

// Print out the configuration settings to the console in Jenkins
def printConfiguration(Map effectiveConfig) {
    def printParams = ""
    effectiveConfig.each { key, value ->
        printParams += key + ": " + value + "\n"
    }
    echo "[SLF Pipeline] Configuration Settings START\n" + printParams + "[SLF Pipeline] Configuration Settings END\n"
}

def merge(Map lhs, Map rhs) {
    return rhs.inject(lhs.clone()) { map, entry ->
        if (map[entry.key] instanceof Map && entry.value instanceof Map) {
            map[entry.key] = merge(map[entry.key], entry.value)
        } else if (map[entry.key] instanceof Collection && entry.value instanceof Collection) {
            map[entry.key] += entry.value
        } else {
            map[entry.key] = entry.value
        }
        return map
    }
}



/**
 * Configure environment specific pipeline settings based on environment set in Jenkins
 * Jenkins pipeline in a given environment should talk to other tools in that environment.
 * For example: Dev Jenkins should talk to Dev Bitbucket, Dev Artifactory and Dev SonarQube
 * It is possible to pull from prod in lower environments but nothing should be pushed to
 * prod from lower environments.
 *
 * @param defaultConfig The map containing default pipeline parameter name and value pairs.
 * @return Default configuration map
 */
def setEnvironmentSpecificValues(Map defaultConfig) {
    def jenkinsEnvironment = "${SLF_JENKINS_ENVIRONMENT}"

    echo "[SLF Pipeline] SLF_JENKINS_ENVIRONMENT: " + jenkinsEnvironment

    // These same IDs should be configured in all Jenkins environments (cannot be editted, must delete and create new if changes are needed)
    // Prod Maven Config - MyGlobalSettings = '8d2a7047-31b1-47a8-8788-be4b89b71125'
    // Stage Maven Config - MyGlobalSettings-stg = 'fb511e14-f7ad-4ea9-bc4e-be45dcd2265e'
    // Dev Maven Config - MyGlobalSettings-dev = '196daf49-9ffd-4571-8f6a-027a91831766'
    if (jenkinsEnvironment == 'Prod') { // Prod
        defaultConfig.successChannel = 'https://sunlifefinancial.webhook.office.com/webhookb2/14bb908b-6904-4e25-bdb1-257f0741b578@415bb08f-1a20-4fbe-9b57-313be7050945/JenkinsCI/3e5adf6ed0ee4e269e568800e5a9c4fd/02e6c952-73f3-42c8-b70f-b7beacb8c6b4'
        defaultConfig.failureChannel = 'https://sunlifefinancial.webhook.office.com/webhookb2/14bb908b-6904-4e25-bdb1-257f0741b578@415bb08f-1a20-4fbe-9b57-313be7050945/JenkinsCI/af8edec92a5348fca525cf509fb64e0c/02e6c952-73f3-42c8-b70f-b7beacb8c6b4'
        defaultConfig.unstableChannel = 'https://sunlifefinancial.webhook.office.com/webhookb2/14bb908b-6904-4e25-bdb1-257f0741b578@415bb08f-1a20-4fbe-9b57-313be7050945/JenkinsCI/af8edec92a5348fca525cf509fb64e0c/02e6c952-73f3-42c8-b70f-b7beacb8c6b4'
    } else if (jenkinsEnvironment == 'Stage') {
        defaultConfig.successChannel = 'https://sunlifefinancial.webhook.office.com/webhookb2/14bb908b-6904-4e25-bdb1-257f0741b578@415bb08f-1a20-4fbe-9b57-313be7050945/JenkinsCI/36dded6bd08547e8a874110a413e3a23/02e6c952-73f3-42c8-b70f-b7beacb8c6b4'
        defaultConfig.failureChannel = 'https://sunlifefinancial.webhook.office.com/webhookb2/14bb908b-6904-4e25-bdb1-257f0741b578@415bb08f-1a20-4fbe-9b57-313be7050945/JenkinsCI/9e94d81566624fcfb58cefbc823b202d/02e6c952-73f3-42c8-b70f-b7beacb8c6b4'
        defaultConfig.unstableChannel = 'https://sunlifefinancial.webhook.office.com/webhookb2/14bb908b-6904-4e25-bdb1-257f0741b578@415bb08f-1a20-4fbe-9b57-313be7050945/JenkinsCI/9e94d81566624fcfb58cefbc823b202d/02e6c952-73f3-42c8-b70f-b7beacb8c6b4'
    } else if (jenkinsEnvironment == 'Dev') {
        // TODO Set back to Dev once Dev Artifactory is back
        defaultConfig.artifactoryDeployer = 'Artifactory Stage'
        defaultConfig.successChannel = 'https://sunlifefinancial.webhook.office.com/webhookb2/14bb908b-6904-4e25-bdb1-257f0741b578@415bb08f-1a20-4fbe-9b57-313be7050945/JenkinsCI/efb9a556f923466582c81de4c0b1bab9/02e6c952-73f3-42c8-b70f-b7beacb8c6b4'
        defaultConfig.failureChannel = 'https://sunlifefinancial.webhook.office.com/webhookb2/14bb908b-6904-4e25-bdb1-257f0741b578@415bb08f-1a20-4fbe-9b57-313be7050945/JenkinsCI/5d99c7ddb4294319ae587af63d9bee56/02e6c952-73f3-42c8-b70f-b7beacb8c6b4'
        defaultConfig.unstableChannel = 'https://sunlifefinancial.webhook.office.com/webhookb2/14bb908b-6904-4e25-bdb1-257f0741b578@415bb08f-1a20-4fbe-9b57-313be7050945/JenkinsCI/c8a1ec209cb441d191d1c3075caedd2e/02e6c952-73f3-42c8-b70f-b7beacb8c6b4'
    } else { // Unknown environment value
        error "Unrecognized SLF_JENKINS_ENVIRONMENT environment variable value (expected: Dev, Stage, Prod), but was: " + jenkinsEnvironment
    }
    return defaultConfig
}
