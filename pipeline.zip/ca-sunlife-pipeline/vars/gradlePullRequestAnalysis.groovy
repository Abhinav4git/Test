def call(effectiveConfiguration = [:]){
    withSonarQubeEnv("${effectiveConfiguration.sonarQubeInstance}"){
        rtGradleRun(
            buildFile: 'build.gradle',
            tasks: "sonarqube ${effectiveConfiguration.gradleProperty} -Dsonar.pullrequest.key=${effectiveConfiguration.pullRequestId} -Dsonar.pullrequest.branch=${effectiveConfiguration.pullRequestSource} -Dsonar.pullrequest.base=${effectiveConfiguration.pullRequestDestination}",
            resolverId: "GRADLE_RESOLVER",
            useWrapper: true,
            usesPlugin: true
        )
    }                     
}
