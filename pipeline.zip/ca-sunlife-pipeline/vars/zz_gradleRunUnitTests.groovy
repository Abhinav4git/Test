// Run unit tests step for Java Gradle
def call(effectiveConfiguration = [:]) {
    rtGradleRun(
            buildFile: 'build.gradle',
            tasks: "${effectiveConfiguration.gradleTestGoal}",
            deployerId: "GRADLE_DEPLOYER",
            resolverId: "GRADLE_RESOLVER",
            useWrapper: true,
            usesPlugin: true
    )
}

