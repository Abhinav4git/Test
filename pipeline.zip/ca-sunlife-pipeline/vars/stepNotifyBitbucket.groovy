//Step to call pot action to notify BitBucket
def call(effectiveConfiguration = [:]){
    notifyBitbucket (
        commitSha1: '',
        considerUnstableAsSuccess: false,
        credentialsId: 'gitget-userid-password',
        disableInprogressNotification: false,
        ignoreUnverifiedSSLPeer: false,
        includeBuildNumberInKey: false,
        prependParentProjectKey: false,
        projectKey: '',
        stashServerBaseUrl: 'https://bitbucket.sunlifecorp.com'
    )
}
