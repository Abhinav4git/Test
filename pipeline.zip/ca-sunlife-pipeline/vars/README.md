# Basic Pipelines

## Quick Start

- buildMavenPipeline
- buildGradlePipeline (handles NPM)

## Custom Pipelines

- Link