//Download dependencies from artifactory step for maven 
def call(effectiveConfiguration = [:]){
    rtMavenDeployer(
        id: "MAVEN_DEPLOYER",
        serverId: "${effectiveConfiguration.artifactoryDeployer}",
        snapshotRepo: "${effectiveConfiguration.snapshotRepo}",
        releaseRepo: "${effectiveConfiguration.stagingRepo}"
    ) 
    
    rtMavenResolver(
        id: "MAVEN_RESOLVER",
        serverId: "${effectiveConfiguration.artifactoryResolver}",
        snapshotRepo: "${effectiveConfiguration.snapshotArtifactsResolver}",
        releaseRepo: "${effectiveConfiguration.releaseArtifactsResolver}"
    )
}
