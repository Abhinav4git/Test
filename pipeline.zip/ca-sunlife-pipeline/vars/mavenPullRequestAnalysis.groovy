def call(effectiveConfiguration = [:]){
    withSonarQubeEnv("${effectiveConfiguration.sonarQubeInstance}"){
        
        rtMavenRun(
            pom: 'pom.xml',
            goals: "verify sonar:sonar -P ${effectiveConfiguration.mavenProfile} -Dsonar.pullrequest.key=${params.pullRequestId} -Dsonar.pullrequest.branch=${params.pullRequestSource} -Dsonar.pullrequest.base=${params.pullRequestDestination}",
            opts: "${effectiveConfiguration.mavenOption}",
            deployerId: "MAVEN_DEPLOYER",
            resolverId: "MAVEN_RESOLVER"
        )
    }
}
