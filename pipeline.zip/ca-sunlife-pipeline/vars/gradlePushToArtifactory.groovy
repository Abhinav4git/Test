//Artifactory upload step for Java Maven
def call(effectiveConfiguration = [:]) {
    rtGradleRun(
            buildFile: 'build.gradle',
            tasks: "artifactoryPublish",
            deployerId: "GRADLE_DEPLOYER",
            resolverId: "GRADLE_RESOLVER",
            useWrapper: true,
            usesPlugin: true
    )

    rtPublishBuildInfo(
            serverId: "${effectiveConfiguration.artifactoryDeployer}"
    )
}