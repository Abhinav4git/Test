def call(effectiveConfiguration =[:]){
    
    echo "${params.releaseScope}"
    echo "${VERSION}"
    git branch: "${params.BRANCH}",
        url: "${GIT_URL}",
        credentialsId: 'gitget-ssh'
    def nextDevelopmentVersion = getNextDevelopmentVersion(releaseScope, VERSION)
    def profileReleaseCandidate = "${effectiveConfiguration.mavenProfile}".equals("")? releaseCandidate : "${effectiveConfiguration.mavenProfile},releaseCandidate"
    sshagent(['gitget-ssh']){
        configFileProvider([configFile(fileId: "${MAVEN_SETTINGS_FILE_ID}", variable: 'MAVEN_SETTINGS_XML')]) {
            rtMavenRun(
                pom: 'pom.xml',
                goals: "-gs ${MAVEN_SETTINGS_XML} --batch-mode clean release:clean release:prepare -DdevelopmentVersion=${nextDevelopmentVersion} -P ${profileReleaseCandidate}",
                opts: "${effectiveConfiguration.mavenOption}",
                resolverId: "MAVEN_RESOLVER"
            )
            
        }
    }
}
@NonCPS
def getNextDevelopmentVersion(String releaseScope, String snapShotVersion){

    def version = snapShotVersion.split('-')[0]
    echo "Version : " +version
    def newVersion
    //String releaseScope = 'minor'
    def pattern = ~/(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/
    if(releaseScope == 'minor'){
        echo "Version : " +version
        newVersion = version.replaceFirst(pattern) { _, major, minor, patch -> "${major}.${(minor.toInteger()) + 1}.0"}
    }
    else if (releaseScope == 'major'){
        newVersion = version.replaceFirst(pattern) { _, major, minor, patch -> "${(major.toInteger()) + 1}.0.0"}
    }
    else if(releaseScope == 'patch'){
        newVersion = version.replaceFirst(pattern) { _, major, minor, patch -> "${major}.${minor}.${(patch.toInteger()) + 1}"}
    }

    echo "New Version : " +newVersion
    def nextVersion = newVersion + '-SNAPSHOT'
    echo "Next Version: " +nextVersion 
    return nextVersion
} 