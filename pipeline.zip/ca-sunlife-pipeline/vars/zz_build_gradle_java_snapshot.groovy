def call(body){
    def pipelineParams= [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    pipeline{
        agent {
            label "${pipelineParams.buildAgent}"
        }

        options{
            disableConcurrentBuilds()
        }

        parameters{
            string(name: 'pullRequestId', description: 'Pull request id', defaultValue: "-1")
            string(name: 'pullRequestSource', description: 'Pull request source branch', defaultValue: "none")
            string(name: 'pullRequestDestination', description: 'Pull request destination branch', defaultValue: "none")
        }

        tools{
            jdk "${pipelineParams.jdkVersion}"
        }

        stages{
            stage ('Artifactory configuration'){
                steps{
                    rtGradleDeployer(
                        id: "GRADLE_DEPLOYER",
                        serverId: "Artifactory Prod",
                        snapshotRepo: "libs-snapshot-local",
                        releaseRepo: "libs-staging-local"
                    )

                    rtGradleResolver(
                        id: "GRADLE_RESOLVER",
                        serverId: "Artifactory Prod",
                        repo: "libs-release"
                    )
                }
            }

            stage('Build'){
                steps{
                    rtGradleRun(
                        buildFile: 'build.gradle',
                        tasks: "${pipelineParams.gradleTask} ${pipelineParams.gradleProperty}",
                        deployerId: "GRADLE_DEPLOYER",
                        resolverId: "GRADLE_RESOLVER",
                        useWrapper: true,
                        usesPlugin: true
                    )
                }
            }

            stage('Sonar branch analysis'){
                when {
                    expression { params.pullRequestId ==~ /^-[1-9]\d*|0/ }
                }

                steps{
                    withSonarQubeEnv('SonarQube')
                    {
                        rtGradleRun(
                            buildFile: 'build.gradle',
                            tasks: "sonarqube ${pipelineParams.gradleProperty} -Dsonar.branch.name=${GIT_BRANCH.substring('origin/'.size())}",
                            deployerId: "GRADLE_DEPLOYER",
                            resolverId: "GRADLE_RESOLVER",
                            useWrapper: true,
                            usesPlugin: true
                        )
                    }
                }
            }

            stage('Sonar pull request analysis'){
                when {
                    expression { params.pullRequestId ==~ /^[1-9]\d*/ }
                }

                steps{
                    withSonarQubeEnv('SonarQube')
                    {
                        rtGradleRun(
                            buildFile: 'build.gradle',
                            tasks: "sonarqube ${pipelineParams.gradleProperty} -Dsonar.pullrequest.key=${params.pullRequestId} -Dsonar.pullrequest.branch=${params.pullRequestSource} -Dsonar.pullrequest.base=${params.pullRequestDestination}",
                            deployerId: "GRADLE_DEPLOYER",
                            resolverId: "GRADLE_RESOLVER",
                            useWrapper: true,
                            usesPlugin: true
                        )
                    }
                }
            }

            stage('Publish'){
                steps{
                    rtGradleRun(
                        buildFile: 'build.gradle',
                        tasks: "immutableSnapshot artifactoryPublish ${pipelineParams.gradleProperty}",
                        deployerId: "GRADLE_DEPLOYER",
                        resolverId: "GRADLE_RESOLVER",
                        useWrapper: true,
                        usesPlugin: true
                    )

                    rtPublishBuildInfo(
                        serverId: "Artifactory Prod"
                    )
                }
            }

            stage('Deploy'){
                when {
                    expression { return GIT_BRANCH.substring('origin/'.size()) =~ /${pipelineParams.branchToDeploy}/ && pipelineParams.CddAutoDeploy =~ /(?i)(Y|YES|T|TRUE|ON|RUN|true|yes|y|t|on|run)/ }
                }

                steps{
                    httpRequest (
                            url : 'https://cddirector.io:443/cdd/design/ec670cb9-5aa6-44d7-8139-06e964ed5dd7/v1/applications/application-versions/application-version-builds',
                            contentType : 'APPLICATION_JSON',
                            acceptType : 'APPLICATION_JSON',
                            customHeaders : [[name: 'Authorization', value:"Bearer ${env.CDD_API_TOKEN}"]],
                            requestBody: """{
                                "applicationName": "${pipelineParams.CddAppName}",
                                "applicationVersionName": "${pipelineParams.CddAppVersion}",
                                "applicationVersionBuildNumber": "${env.BUILD_NUMBER}"
                            }""",
                            consoleLogResponseBody : true,
                            httpProxy : "http://proxy-mwg-http.ca.sunlife:8443",
                            httpMode : "POST"

                        )
                }
            }
        }

         post {
            always{
                stepNotifyBitbucket (
                    commitSha1: '',
                    considerUnstableAsSuccess: false,
                    credentialsId: 'gitget_ID_Pass',
                    disableInprogressNotification: false,
                    ignoreUnverifiedSSLPeer: false,
                    includeBuildNumberInKey: false,
                    prependParentProjectKey: false,
                    projectKey: '',
                    stashServerBaseUrl: 'https://bitbucket.sunlifecorp.com'
                )


            }

            success{
                office365ConnectorSend "${pipelineParams.successChannel}"
            }

            failure{
                office365ConnectorSend "${pipelineParams.failureChannel}"
            }

            unstable{
                office365ConnectorSend "${pipelineParams.failureChannel}"
            }
        }
    }
}
