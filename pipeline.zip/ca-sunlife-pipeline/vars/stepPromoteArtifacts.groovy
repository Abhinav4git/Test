def call(effectiveConfiguration = [:]) {

    rtAddInteractivePromotion(
            //Mandatory parameter
            serverId: "${effectiveConfiguration.artifactoryDeployer}",
            buildName: "${BUILD_NAME}",
            buildNumber: "${BUILD_NUMBER}",
            //Optional parameters
            targetRepo: "${effectiveConfiguration.releaseRepo}",
            comment: 'this is the promotion comment',
            sourceRepo: "${effectiveConfiguration.stagingRepo}",
            status: 'Released',
            includeDependencies: false,
            failFast: true,
            copy: true
    )
}
