//Run xray scan 
def call(effectiveConfiguration = [:]){
    try{
        xrayScan (
        serverId: "${effectiveConfiguration.artifactoryDeployer}",
        failBuild: false
        )
    }
    catch(Exception err){
        echo 'Xray scan issues' +err
        currentBuild.result = 'UNSTABLE'
    }   
}