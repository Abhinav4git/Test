// Sends security issues to CodeDx from other security scanning tools such as SonarQube, Xray, etc.
def call(effectiveConfiguration = [:]) {
  def xrayFile = "CodeDx_Report.json"
  def webInspectFile = "WebInspect_Report.xml" //not used yet

  def connectionDetails = getEnvironmentDetails()
  def ProjectId = getProjectId(effectiveConfiguration.deploymentApplicationName, connectionDetails)
  if (ProjectId != null){
      def prepId = createAnalysisPrep(ProjectId,connectionDetails)
      uploadFile(prepId, connectionDetails, xrayFile)
      triggerPrepAnalysis(prepId, connectionDetails)
  }
  else{
    echo "Project not found in CodeDx, skipping analysis trigger"
  }
}

//function to upload JFrog/Xray report to the prepared analysis
def uploadFile(prepId,connectionDetails, fileName){
  if(checkFileContent(fileName) != true ){
    echo "File $fileName is empty and will not be uploaded"
    return
  }

  httpRequest (
    acceptType: 'APPLICATION_JSON',
    contentType: 'APPLICATION_JSON',
    httpMode: 'POST',
    customHeaders: [[maskValue: true, name: 'API-Key',
    value: "${connectionDetails.key}"]],
    ignoreSslErrors: true,
    url: "${connectionDetails.url}/api/analysis-prep/${prepId}/upload",
    consoleLogResponseBody : true,
    uploadFile: "${fileName}",
    wrapAsMultipart: true,
    multipartName: "${fileName}"
    )
}

//function to check for verification errors in the prepared analysis
def pollPrepAnalysis(prepId,connectionDetails){
  def response = httpRequest(
    acceptType: 'APPLICATION_JSON',
    contentType: 'APPLICATION_JSON',
    httpMode: 'GET',
    customHeaders: [[maskValue: true, name: 'API-Key',
    value: "${connectionDetails.key}"]],
    ignoreSslErrors: true,
    url: "${connectionDetails.url}/api/analysis-prep/${prepId}",
    consoleLogResponseBody : false
    ).getContent()

    jsonResponse = readJSON(
      text: response,
      returnPojo: true
      )
    def verificationErrors = jsonResponse['verificationErrors']
    return verificationErrors
}

//Sends request to create the prepared analysis
//returns the prepared analysis ID for use in further function
def createAnalysisPrep(ProjectId, connectionDetails){
  def response = httpRequest(
    acceptType: 'APPLICATION_JSON',
    contentType: 'APPLICATION_JSON',
    httpMode: 'POST',
    customHeaders: [[maskValue: true, name: 'API-Key',
    value: "${connectionDetails.key}"]],
    ignoreSslErrors: true,
    requestBody: "{\"projectId\" : $ProjectId }",
    url: "${connectionDetails.url}/api/analysis-prep",
    consoleLogResponseBody : true
    ).getContent()

    def jsonResponse = readJSON(
      text: response,
      returnPojo: true
      )

      def analysisId = jsonResponse['prepId']
      return analysisId
}

//function to return the CodeDx project ID given then deployment application name
def getProjectId(projectName, connectionDetails) {
  def response = httpRequest (
      acceptType: 'APPLICATION_JSON',
      contentType: 'APPLICATION_JSON',
      httpMode: 'GET',
      customHeaders: [[maskValue: true, name: 'API-Key',
      value: "${connectionDetails.key}"]],
      ignoreSslErrors: true,
      url: "${connectionDetails.url}/api/projects",
      consoleLogResponseBody : true
      ).getContent()

      jsonResponse = readJSON (
          text: response,
          returnPojo: true
      )
      def projectId
      Projects = jsonResponse['projects']
      Projects.each { entry ->
          if ("${entry.name}" == "${projectName}") {
              projectId = "${entry.id}"
          }
      }

      return projectId
}

//function to trigger the prepared analysis
//only fires if all verification errors were able to be resolved
//verification errors = uploaded files cannot be parsed (bad format)
def triggerPrepAnalysis(prepId, connectionDetails){
  def count = 4
  def verificationErrors = pollPrepAnalysis(prepId,connectionDetails)
  echo "$verificationErrors"
  while(verificationErrors != [] && count != 0){
    echo "Waiting for prepared ID verification errors to resolve.. "
    sleep(5)
    echo "attempts remaining: $count"
    count--
    verificationErrors = pollPrepAnalysis(prepId, connectionDetails)
    echo "$verificationErrors"
  }
  if (verificationErrors != []){
    echo "could not resolve verification errors, skipping Xray analysis"
    return
  }

  httpRequest(
    httpMode: 'POST',
    customHeaders: [[maskValue: true, name: 'API-Key',
    value: "${connectionDetails.key}"]],
    ignoreSslErrors: true,
    url: "${connectionDetails.url}/api/analysis-prep/${prepId}/analyze",
    consoleLogResponseBody : true
    )
}


def getEnvironmentDetails(){
  def values = [:]
  if ("${SLF_JENKINS_ENVIRONMENT}" == "Dev"){
    values.put('url', "https://dev-codedx.sunlifecorp.com")
    values.put ('key',"39b5a630-b26c-4ec9-911f-30c46a7b92f3" )
  }
  else if ("${SLF_JENKINS_ENVIRONMENT}" == "Stage") {
    values.put('url',"https://stage-codedx.sunlifecorp.com")
    values.put('key' , "2b5302f5-aa9f-415a-a105-4c74e4a35674")
  }
  else {
    values.put('url',"http://codedx.sunlifecorp.com")
    values.put('key' , "cfb9aeb6-750d-4cf4-a0a4-4e2aa35e2ce8")
  }
  return values
}

//returns false if file is empty (should not be uploaded)
//currently only works with the json report from xray, will be extended to support xml
//when webInspect is integrated
def checkFileContent(fileName){
  def result = readFile("$fileName")
  def contents = readJSON(
    text: result,
    returnPojo: true
    )

  if (contents['total_rows'] == 0){
    return false
  }
  else{
    return true
  }
}
