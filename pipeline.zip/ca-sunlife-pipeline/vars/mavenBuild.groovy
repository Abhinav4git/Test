//Build step for Java Maven
def call(effectiveConfiguration = [:]){
    
        rtMavenRun(
            pom: 'pom.xml',
            goals: " ${effectiveConfiguration.mavenGoal} ${jvmBuildParams} -P ${effectiveConfiguration.mavenProfile}",
            opts: "${effectiveConfiguration.mavenOption}",
            resolverId: "MAVEN_RESOLVER"
        )
}