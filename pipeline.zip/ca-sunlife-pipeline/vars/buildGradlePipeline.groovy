def call(body) {
    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()
    def effectiveConfiguration = gradleInitializePipeline(pipelineParams)

    pipeline {
        agent {
            label "${effectiveConfiguration.agentLabel}"
        }

        options {
            disableConcurrentBuilds()
        }

        parameters {
            booleanParam(name: 'refreshDependencies', description: 'Enable this parameter to refresh the dependencies/clear gradle cache', defaultValue: false)
            booleanParam(name: 'isRelease', description: 'Enable this parameter to create release artifact', defaultValue: false)
            gitParameter branchFilter: 'origin/(.*)', defaultValue: 'develop', name: 'BRANCH', type: 'PT_BRANCH'
            choice(name: 'releaseScope', description: 'Bumping the semantic release major/minor/patch', choices: ['minor', 'patch', 'major'])
            //string(name: 'releaseVersion', description: 'The current release version of the application. Use proper semantic versioning x.y.z', defaultValue: "1.0.0")
            //string(name: 'nextDevelopmentVersion', description: 'The next development version of the application', defaultValue: "1.1.0-SNAPSHOT")
        }

        tools {
            jdk 'JDK 1.8'
        }

        environment {
            BUILD_NAME = "${JOB_NAME}".replace("/", " :: ")
            scannerHome = tool 'Sonar_Scanner_No_Maven'
        }

        stages {

            stage('Initialize pipeline') {
                steps {
                    gradleConfigureArtifactory(effectiveConfiguration);
                }
            }

            stage('Clear Cache & Build') {
                when {
                    expression { params.refreshDependencies == true }
                }
                steps {
                    gradleClearCacheAndBuild(effectiveConfiguration);
                }
            }

            stage('Build') {
                when {
                    expression { params.refreshDependencies == false }
                }
                steps {
                    gradleBuild(effectiveConfiguration);
                }
            }

            stage('Sonar branch analysis') {
                when {
                    expression { effectiveConfiguration.sonarQubeScan.equalsIgnoreCase('true') }
                }
                steps {
                    gradleRunSonarQubeScan(effectiveConfiguration);
                }
            }

            // Must configure Bitbucket repository for pull request analysis
            stage('Sonar pull request analysis') {

                when {
                    expression {
                        params.pullRequestId ==~ /^[1-9]\d*/
                    }
                }
                steps {
                    gradlePullRequestAnalysis(effectiveConfiguration);
                }
            }

            stage('Publish to Artifactory') {
                steps {
                    script {
                        if ((params.isRelease)) {//} && !("${project.version}".contains('SNAPSHOT'))){
                            echo "Skipping push to artifactory"

                        } else {
                            gradlePushToArtifactory(effectiveConfiguration);
                        }
                    }
                }

            }

            stage('Xray scan') {
                when {
                    allOf {
                        expression { effectiveConfiguration.runXrayScan.equalsIgnoreCase('true') }
                        expression { !(params.isRelease) }// && !(VERSION.contains('SNAPSHOT')) }
                    }
                }
                steps {
                    stepRunXrayScan(effectiveConfiguration);
                }
            }

            stage('Create Release') {
                when {
                    expression { params.isRelease }
                }
                steps {
                    gradleRelease(effectiveConfiguration)
                }
            }

            // TODO add deploy step
            // stage('Deploy') {
            //     when{
            //         expression{
            //             return GIT_BRANCH.substring('origin/'.size()) =~ /${effectiveConfiguration.deploymentBranch}/ && effectiveConfiguration.deployment =~ /(?i)(Y|YES|T|TRUE|ON|RUN|true|yes|y|t|on|run)/
            //         }
            //     }

            //     steps {
            //         stepDeployToFirstEnvironment(effectiveConfiguration);
            //     }
            // }

            stage('Publish CodeDx') {
                when {
                    expression { effectiveConfiguration.stepPublishToCodeDx.equalsIgnoreCase('true') }
                }
                steps {
                    stepPublishToCodeDx(effectiveConfiguration);
                }
            }

            stage('Add interactive promotion') {
                when {
                    expression {
                        params.isRelease
                    }
                }
                steps {
                    stepPromoteArtifacts(effectiveConfiguration);
                }
            }
        }

        post {

            always {
                stepNotifyBitbucket(effectiveConfiguration)
                cleanWs deleteDirs: true, notFailBuild: true
            }

            success {
                office365ConnectorSend webhookUrl: "${effectiveConfiguration.successChannel}"
            }

            failure {
                office365ConnectorSend webhookUrl: "${effectiveConfiguration.failureChannel}"
            }

            unstable {
                office365ConnectorSend webhookUrl: "${effectiveConfiguration.unstableChannel}"
            }
        }
    }
}
