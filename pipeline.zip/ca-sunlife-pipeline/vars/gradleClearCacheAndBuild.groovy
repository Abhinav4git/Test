// Build step for Java Gradle
def call(effectiveConfiguration = [:]) {
    rtGradleRun(
            buildFile: 'build.gradle',
            tasks: "${effectiveConfiguration.gradleTask} --refresh-dependencies",
            deployerId: "GRADLE_DEPLOYER",
            resolverId: "GRADLE_RESOLVER",
            useWrapper: true,
            usesPlugin: true
    )
}
