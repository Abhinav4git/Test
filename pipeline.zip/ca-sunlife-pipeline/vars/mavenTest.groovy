def call(effectiveConfiguration = [:]){
    try{
        rtMavenRun(
            pom: 'pom.xml',
            goals: " ${effectiveConfiguration.mavenTestGoal} -P ${effectiveConfiguration.mavenProfile}",
            opts: "${effectiveConfiguration.mavenOption}",
            resolverId: "MAVEN_RESOLVER"
        )

    }

    catch(Exception err){
        echo 'Test Failed'
        currentBuild.result = 'UNSTABLE'
    }

    
        
}