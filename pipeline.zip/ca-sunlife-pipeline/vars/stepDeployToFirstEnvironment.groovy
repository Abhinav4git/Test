//Deploy to CDD step
def call(effectiveConfiguration = [:]){

     // May need to use API call (REST call)
     sendNotificationToCDD appName: "${effectiveConfiguration.deploymentApplicationName}", appVersion: "${VERSION}", releaseTokens: ''
}