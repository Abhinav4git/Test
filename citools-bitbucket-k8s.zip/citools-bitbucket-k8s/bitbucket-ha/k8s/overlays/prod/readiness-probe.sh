#!/bin/sh

getTimestamp() {
  local func_result=$(date +"%Y-%m-%d %H:%M:%S.%N%z")
  echo "$func_result"
}

getStatefulSetName() {
  echo "$HOSTNAME" | cut -d- -f-3
}

getReadyReplicas() {
  kubectl get statefulset -o=jsonpath='{$.status.readyReplicas}' $(getStatefulSetName)
}

getReadyPods() {
  kubectl get pods -o jsonpath='{range .items[?(.status.containerStatuses[0].ready==true)]}{.metadata.name}{ "\n"}{end}' | grep ^$(getStatefulSetName)-[0-9]*$
}

writeLog() {
  echo "$(getTimestamp) $1" | tee -a /readinessProbe-$(date +"%Y%m%d").log
}

writeLog "-----------------------"
writeLog "Starting readinessProbe"

# Check to ensure this container is healthy, and if not return an error so
# that it enters/stays in unready state
writeLog "Response from healthcheck: "
wget -q -O - http://localhost:7990
if [[ $? -ne 0 ]]; then
    writeLog "Accessing wget http://localhost:7990 returned a non-ok return code - this container is not healthy!" 
    exit 1
  else
    writeLog "Accessing wget http://localhost:7990 returned a 200 return code - this container is healthy (but the pod might be inactive)." 
  fi

# Note - if there are no ready replicas, READY_REPLICAS will be an empty string
# Otherwise, it will be the count of ready replicas
READY_REPLICAS=$(getReadyReplicas)
READY_PODS=$(getReadyPods)   
writeLog "Ready replicase: $READY_REPLICAS"
writeLog "Ready pods: $READY_PODS"

# If no replicas are currently ready then we can return success to become ready
if [ -z "$READY_REPLICAS" ] 
  then
    writeLog "This pod is becoming active"
    exit 0
  fi

# If this replica is the ready pod then return success to stay ready
if echo "$READY_PODS" | grep -q $HOSTNAME ;
  then
    writeLog "This pod is an active pod"
    exit 0
  else
    writeLog "This pod is inactive (and should stay inactive)"
    exit 1
  fi

writeLog "Reached end of script"
exit 0