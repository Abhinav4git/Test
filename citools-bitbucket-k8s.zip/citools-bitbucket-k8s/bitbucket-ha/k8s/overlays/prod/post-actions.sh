#!/bin/bash
if [ ! -f "/var/atlassian/application-data/bitbucket/shared/bitbucket.properties" ]; then
    cp -f /var/configmap/bitbucket.properties /var/atlassian/application-data/bitbucket/shared/bitbucket.properties;
    chown 777 /var/atlassian/application-data/bitbucket/shared/bitbucket.properties
fi
    
chown -R 1032:100 /opt/atlassian/bitbucket/
pod_ip=$(hostname -i)
while read -r line;
do
    if [[ $line =~ "hazelcast.network.tcpip.members=" ]]
    then
        if [[ $line =~ "5701" ]]
        then
             line+=","
        fi
        line+="$pod_ip"
        line+=":5701"
    fi
echo $line
done < /var/atlassian/application-data/bitbucket/shared/bitbucket.properties > /var/atlassian/application-data/bitbucket/shared/bitbucket.properties1
mv /var/atlassian/application-data/bitbucket/shared/bitbucket.properties1 /var/atlassian/application-data/bitbucket/shared/bitbucket.properties
chown 1032:100 /var/atlassian/application-data/bitbucket/shared/bitbucket.properties
