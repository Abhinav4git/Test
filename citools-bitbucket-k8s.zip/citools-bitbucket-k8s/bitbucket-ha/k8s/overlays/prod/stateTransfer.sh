#!/bin/sh
#By:Jack
getTimestamp() {
  func_result=$(date +"%Y-%m-%d %H:%M:%S.%N%z")
  echo "$func_result"
}

getStatefulSetName() {
  echo "$HOSTNAME" | cut -d- -f-3
}

getReadyPods() {
  kubectl get pods -o jsonpath='{range .items[?(.status.containerStatuses[0].ready==true)]}{.metadata.name}{ "\n"}{end}' | grep ^$(getStatefulSetName)-[0-9]*$
}

getNotReadyPods() {
  kubectl get pods -o jsonpath='{range .items[?(.status.containerStatuses[0].ready==false)]}{.metadata.name}{ "\n"}{end}' | grep ^$(getStatefulSetName)-[0-9]*$
}

writeLog() {
  echo "$(getTimestamp) $1" | tee -a /appstate/rsynclogs/stateTransfer-$(date +"%Y%m%d").log
}

writeLog "-----------------------"
writeLog "Starting state transfer"


READY_PODS=$(getReadyPods)
writeLog "Ready pods: $READY_PODS"

# If this replica is the ready pod then copy state to other pods
if echo "$READY_PODS" | grep $HOSTNAME ;
  then
  for p in $(getNotReadyPods); do
    writeLog "Copying state to pod: $p"
    POD_IP=$(kubectl get pod $p --template={{.status.podIP}})
    #tar cf - /appstate | kubectl exec -c sshd -i $p -- tar xf - -C /
    writeLog "Copying to the shared folder to IP: $POD_IP"
    sshpass -p 'C0mplexp@ssw0rd!' rsync -e "ssh -o StrictHostKeyChecking=no" -arv /appstate/ root@$POD_IP:/imports --delete --exclude 'rsynclogs' --log-file=/appstate/rsynclogs/stateTransfer-$(date +"%Y%m%d").log
    if [ "$?" -eq "0" ]
    then
      writeLog "Rsync Success"
      writeLog "Reached end of script"
      exit 0
    else
      writeLog "Rsync Failed"
      writeLog "Reached end of script"
      exit 1 
    fi
    #kubectl cp /appstate/* $p:/imports -c sshd
  done
  else
    writeLog "No Rsync Needed"
    writeLog "Reached end of script"
    exit 0
fi

# sleep 600; 
