#!/bin/sh
#By:Jack
FILE=/appstate/initContainer.txt

while true; do 

if [ -f "$FILE" ]; then
    exit
else
    sleep 30;
fi
done

writeLog "Reached end of script"