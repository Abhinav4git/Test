#!groovy
// vars/getMinuteOfDay.groovy
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit

def call() {
  ZoneId z = ZoneId.of( "America/Toronto" )
  ZonedDateTime zdt = ZonedDateTime.now( z )
  long minuteOfDay = ChronoUnit.MINUTES.between(zdt.toLocalDate().atStartOfDay( z ), zdt)
  return minuteOfDay;
}
