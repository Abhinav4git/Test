#!groovy
// vars/getTimestamp.groovy
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

// Return the current time as a String
def call() {
  ZoneId z = ZoneId.of( "America/Toronto" )
  ZonedDateTime zdt = ZonedDateTime.now( z )
  String timeString = zdt.format(DateTimeFormatter.RFC_1123_DATE_TIME)
  return timeString;
}
