#!groovy
// vars/getGitBranchName.groovy

// Returns the name of the current branch.
// Intended to be called by Jenkins Pipeline script.
def call() {
  return scm.branches[0].name
}
