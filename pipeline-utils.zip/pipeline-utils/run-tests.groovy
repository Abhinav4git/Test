//Run this via the run-tests bash script or via the Jenkinsfile.  Do not run directly.

println "Starting tests..."

//The following code block makes the @NonCPS attribute globally imported and available so that
//scripts under-test that have @NonCPS attributes don't fail to compile.
import org.codehaus.groovy.control.customizers.ImportCustomizer
import org.codehaus.groovy.control.CompilerConfiguration
ImportCustomizer importCustomizer = new ImportCustomizer();
importCustomizer.addImport('NonCPS', 'globals.NonCPS')
importCustomizer.addImport('Hudson', 'globals.Hudson')
importCustomizer.addImport('Jenkins', 'globals.Jenkins')
CompilerConfiguration.DEFAULT.addCompilationCustomizers(importCustomizer)

//Now load and run tests
import groovy.util.AllTestSuite
import junit.textui.TestRunner

System.setProperty(AllTestSuite.SYSPROP_TEST_DIR, "./tests")
System.setProperty(AllTestSuite.SYSPROP_TEST_PATTERN, "**/*Tests.groovy")

assert TestRunner.run(AllTestSuite.suite()).wasSuccessful() : 'TEST FAILURE'
