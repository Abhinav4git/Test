def call(String dockerImage, String command) {
    pipeline {
        options {
            ansiColor('xterm')
        }
        agent none
        stages {
            stage ('Display Job Info') {
                agent {
                    docker {
                        image 'alpine:3.7'
                    }
                }
                steps {
                    printEnvInfo()
                }
            }
            stage ('Build') {
                agent {
                    docker {
                        image dockerImage
                    }
                }
                steps {
                    sh command
                }
            }
        }
    }
}
