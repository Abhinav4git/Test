/**
 * validateConfig
 *
 * Validates a map of configuration parameters.
 * @param name name of the function that was called with the parameters. Used when logging errors
 * @param config parameters passed to the function
 * @param rules list of rules to validate the configuration. Each rule is either a String or a List.
 *   - String - Fail if this name is not a key in the configuration
 *   - List
 *     [0] String - Fail if this name is not a key in the configuration
 *     [1] Closure - Fail if the closure returns false. The closure is passed the value of the configuration parameter
 *     [2] String - Error message if the custom validation fails
 * Example,
 * <code>
 *  validateConfig('liquibase', config, [
 *     ['artifactIds', { !it.isEmpty() }, 'no artifacts specified'],
 *     ['environments', { !it.isEmpty() }, 'must provide at least one environment'],
 *     'groupId',
 *     'version'
 *   ])
 * </code>
 */
def call(String name, Map config, List rules) {
  def errors = []

  for (rule in rules) {
    def prop, check, message

    if (rule instanceof List) {
      prop = rule[0]
      check = rule[1]
      message = rule[2]
    } else if (rule instanceof String) {
      prop = rule
    } else {
      logErrorAndExit "${name}: unknown type for rule ${rule}"
    }

    if (!prop) {
      errors << "rule is missing parameter name as the first item in the list"
    } else if (!config.containsKey(prop)) {
      errors << "missing ${prop}"
    } else if (check && !check(config[prop])) {
      errors << "${prop} ${message}"
    }
  }

  if (!errors.isEmpty()) {
    errors.each { logError "${name}: ${it}" }
    error "${name}: invalid parameters"
  }
}
