#!/usr/bin/groovy

/**
 * Methods for dealing with ECS services
 */

import cvent.aws.AwsUtils

/**
 * deploy
 *
 * Deploys a docker service image to ECS.
 * @param ecrImageTag - ECR image tag to deploy
 * @param environments - One or more environments to deploy the image
 * @param hoganBranch - Branch used for deploy time configuration
 * @param logLevel - Log level of deploy-service-ecs
 * @param migrate - Migrate service through breaking pipeline or infrastructure change
 * @param serviceName - Name of the service to deploy
 * @param tagOverride - Tag of the deploy-service-ecs image
 */
def deploy(Map config) {
  validateConfig("ecs.deploy", config, [
    ["ecrImageTag", { !it.isEmpty() }, "Must provide an ECR image tag"],
    ["environments", { !it.isEmpty() }, "Must provide at least one environment"],
    "hoganBranch",
    "hoganGitSha",
    "logLevel",
    "migrate",
    ["serviceName", { !it.isEmpty() }, "Must provide a service name"],
    "tagOverride"
  ])

  // Deploys are not parallelizable because of various race conditions in the pipeline
  // For example, determining load balancer priority
  config.environments.each { environment ->
    logInfo("Deploy to ${environment}")

    // The build scripts perform various actions that are not compatible when running in parallel from the same
    // directory. This ensures each deploy gets its own copy of the deploy scripts
    string deployAwsDockerDir = "deploy-aws-docker-${config.serviceName}"

    sh(script: "rm -rf ${deployAwsDockerDir}")

    Map vars = [
      ECR_IMAGE_TAG: config.ecrImageTag,
      ENV          : environment,
      HOGAN_BRANCH : config.hoganBranch,
      HOGAN_GIT_SHA: config.hoganGitSha,
      LOG_LEVEL    : config.logLevel,
      METADATA_FILE: "metadata.json",
      SERVICE_NAME : config.serviceName,
    ]

    dir(deployAwsDockerDir) {
      withEnv(vars.collect { it.key + "=" + it.value }) {
        Closure body = {
          AwsUtils.withAwsProfiles {
            if(config.migrate) {
              sh(script: "cd /app && python -m deploy_service_ecs stages --stdout migrate-ecs-service")
            } else {
              sh(script: "cd /app && python -m deploy_service_ecs stages --stdout fetch-metadata")
              sh(script: "cd /app && python -m deploy_service_ecs stages --stdout create-networking")
              sh(script: "cd /app && python -m deploy_service_ecs stages --stdout create-ecs-service")
              sh(script: "cd /app && python -m deploy_service_ecs stages --stdout create-dns")
            }
          }
        }
        runDeployServiceEcsDockerImage(body, config.tagOverride as String)
      }
    }
  }
}

/**
 * scale
 *
 * Sets the desired count for an ECS service
 * @param artifactIds - List of artifact IDs for the services
 * @param delete - Delete the service and associated infra
 * @param desiredCount - Number of instances to run for the service
 * @param ecrImageTag - ECR image of the service to scale
 * @param environments - List of environments
 * @param logLevel - Log level of deploy-service-ecs
 * @param tagOverride - Tag of the deploy-service-ecs image
 */
def scale(Map config) {
  validateConfig("ecs.scale", config, [
    ["artifactIds", { !it.isEmpty() }, "No artifacts specified"],
    "delete",
    ["desiredCount", { it >= 0 }, "must be greater than or equal to 0"],
    ["ecrImageTag", { !it.isEmpty() }, "must provide ECR image tag"],
    ["environments", { !it.isEmpty() }, "must provide at least one environment"],
    "logLevel",
    "tagOverride"
  ])

  def artifactIds = config.artifactIds

  Closure outer = { Closure body ->
    runDeployServiceEcsDockerImage(body, config.tagOverride as String)
  }

  outer {
    artifactIds.each { artifactId ->
      config.environments.each { environment ->
        Map vars = [
          ECR_IMAGE_TAG: config.ecrImageTag,
          ENV          : environment,
          LOG_LEVEL    : config.logLevel,
          SERVICE_NAME : artifactId,
          DESIRED_COUNT: config.desiredCount,
        ]
        withEnv(vars.collect { it.key + "=" + it.value }) {
          AwsUtils.withAwsProfiles {
            if(config.delete) {
              sh(script: "cd /app && python -m deploy_service_ecs stages --stdout delete-ecs-service")
            } else {
              sh(script: "cd /app && python -m deploy_service_ecs stages --stdout scale-ecs-service")
            }
          }
        }
      }
    }
  }
}

private void runDeployServiceEcsDockerImage(Closure body, String tag) {
  if(!tag?.trim()) {
    string tag = "1.8"
  }
  string DOCKER_SERVICE_ECS_IMAGE = "docker.cvent.net/cvent/deploy-service-ecs:${tag}"
  sh(script: "docker pull ${DOCKER_SERVICE_ECS_IMAGE}")
  docker.image(DOCKER_SERVICE_ECS_IMAGE).inside("-u root --entrypoint='' --net=host", body)
}
