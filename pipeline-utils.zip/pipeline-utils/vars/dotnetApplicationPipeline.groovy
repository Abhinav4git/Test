import cvent.dotnet.NuGetBuilder
import cvent.dotnet.PackageType
// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// dotnetApplicationPipeline

// Arguments:
//  Many - see src/cvent/dotnet for more information
//
def call(def args = [:]) {
  pipeline {
    agent { label 'net46' }
    stages {
      stage('Build') {
        steps {
          script {
            NuGetBuilder.checkoutNugetBuild(args)
            NuGetBuilder.build(args)
          }
        }
      }
      stage('Pack') {
        steps {
          script {
            (args.packages ?: []).each { pkg ->
              PackageType packageType = pkg.type as PackageType
              pkg.type = packageType
              packageVersion = NuGetBuilder.getVersionForProject(args)
              NuGetBuilder.pack([package: pkg, version:packageVersion] + args)
            }
          }
        }
      }
      stage('Publish') {
        steps {
          script {
            NuGetBuilder.publish([feedApiKey: 'proget'] + args)
          }
        }
      }
      stage('Release the Octopus') {
        steps {
          script {
            NuGetBuilder.release(args)
          }
        }
      }
    }
  }
}