// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// dropwizardPipeline
import cvent.jenkins.GroovyUtils;
import cvent.slack.SlackUtils
import cvent.stash.Utils as StashUtils
import groovy.json.JsonOutput
import groovy.transform.Field

@Field def static final ECR_IMAGE_TAGS_FILENAME = 'ecr_image_tags.json'

@Field def PIPELINE_ERRORS = []
@Field def PIPELINE_WARNINGS = []

boolean isReleaseBranch(pipelineArgs) {
  def release = pipelineArgs.release
  def branch = release && release.branch ? release.branch : []
  return env.BRANCH_NAME ==~ branch
}

boolean isLastCommitMavenRelease() {
  return (env.PIPELINE_GIT_LAST_COMMIT_MSG ==~ /^(?s)\[maven-release-plugin\].*/)
}

// Returns true if this pipeline will build a release artifact
boolean isRelease(pipelineArgs) {
  // Never build release from a PR
  if (env.CHANGE_URL) {
    return false
  }

  // Let the user override building a release
  if (params.RELEASE) {
    return true
  }

  if (isReleaseBranch(pipelineArgs) && !StashUtils.changeSetContainsOnlyIgnoredFiles(pipelineArgs.ignoreFiles)
          && !isLastCommitMavenRelease()) {
    return true
  }
  return false
}

// Returns true if this pipeline will build a snapshot artifact
boolean isSnapshot(pipelineArgs) {
  return !isReleaseBranch(pipelineArgs) && !StashUtils.changeSetContainsOnlyIgnoredFiles(pipelineArgs.ignoreFiles)
}

// Returns true if this is a snapshot or release build
boolean isSnapshotOrRelease(pipelineArgs) {
  return isSnapshot(pipelineArgs) || isRelease(pipelineArgs)
}

/**
 * @return If building a PR then return the target branch otherwise return BRANCH_NAME
 */
def getTargetBranch() {
  return env.CHANGE_TARGET ?: env.BRANCH_NAME
}

// Returns the service modules to deploy. This is based on the value of "modules.to.deploy" property in the service's
// pom.xml file
def getModulesToDeploy() {
  return env.PIPELINE_MODULES_TO_DEPLOY.split(',')
    .collect { it.trim() }
    .findAll { !it.isEmpty() }
}

def getGitUrl() {
  // GIT_URL when building a branch, GIT_URL_1 when building a PR
  return env.GIT_URL ?: env.GIT_URL_1
}

/**
 * Returns the first matching build based on the build branch
 */
def getBuild(pipelineArgs, boolean ci = false) {
  def builds = ci ? pipelineArgs.ci.builds : pipelineArgs.builds

  // Do not build PRs in alpha/staging stage
  if (builds && (ci || !env.CHANGE_URL)) {
    for (build in builds) {
      if (getTargetBranch() ==~ build.branch) {
        return build
      }
    }
  }
  return []
}

def shouldDeployCloudformation(pipelineArgs) {
  if (params.DEPLOY_CLOUDFORMATION) {
    return params.DEPLOY_CLOUDFORMATION
  }

  if (pipelineArgs.cloudformation
        && pipelineArgs.cloudformation.branch
        && env.BRANCH_NAME ==~ pipelineArgs.cloudformation.branch) {
    return true;
  }

  return false;
}

/**
 * Returns the first matching environment based on the build branch
 */
def getEnvironments(pipelineArgs, boolean ci = false) {
  def build = getBuild(pipelineArgs, ci)
  if (build) {
    def envs = build.environments
    return envs instanceof String ? [envs] : envs
  }
  return []
}

def getTestEnvironments(pipelineArgs, boolean ci = false, testEnvironmentsKey) {
  def build = getBuild(pipelineArgs, ci)
  if (build) {
    def envs = build[testEnvironmentsKey]
    if (!envs) {
      return getEnvironments(pipelineArgs, ci)
    }
    return envs instanceof String ? [envs] : envs
  }
  return []
}

/**
 * Returns the first matching integration test environment based on the build branch
 */
def getIntegrationTestEnvironments(pipelineArgs, boolean ci = false) {
  return getTestEnvironments(pipelineArgs, ci, 'it_environments');
}

/**
 * Returns the first matching load test environment based on the build branch
 */
def getLoadTestEnvironments(pipelineArgs, boolean ci = false) {
  return getTestEnvironments(pipelineArgs, ci, 'load_environments');
}

/**
 * Run liquibase base on the builds configuration
 */
def runLiquibase(pipelineArgs, boolean ci = false) {
  def config = pipelineArgs.liquibase
  def modules = config ? config.get('artifacts', []) : getModulesToDeploy()

  liquibase(
    groupId: readMavenPom().getGroupId(),
    artifactIds: modules,
    version: env.PIPELINE_ARTIFACT_VERSION,
    environments: getEnvironments(pipelineArgs, ci))
}

/**
 * Deploy based on the builds configuration
 */
def runDeploy(pipelineArgs, boolean ci = false) {
  def ecrImageTags = readJSON file: ECR_IMAGE_TAGS_FILENAME
  def deploys = getModulesToDeploy().collectEntries() {
    [("deploy-" + it): { ->
      ecs.deploy(
        ecrImageTag: ecrImageTags[it],
        environments: getEnvironments(pipelineArgs, ci),
        hoganBranch: params.HOGAN_BRANCH,
        hoganGitSha: params.HOGAN_GIT_SHA,
        logLevel: "INFO",
        migrate: false,
        serviceName: it,
        tagOverride: params.DEPLOY_SERVICE_ECS_TAG
      )
    }]
  }
  parallel deploys
}

/**
 * Check to see if we should run tests in parallel based on args passed in from the pipeline and
 * default to true.
 */
def shouldRunTestsInParallel(pipelineArgs, ci) {
  def build = getBuild(pipelineArgs, ci)
  logInfo "shouldRunTestsInParallel: $build, $ci"
  return build.parallelTests != null ? build.parallelTests : true
}


def runTests(pipelineArgs, boolean ci = false) {
  // record the current stage for slack notification
  env.PIPELINE_STAGE = 'Tests'

  def environments = getEnvironments(pipelineArgs, ci)

  boolean parallelTests = shouldRunTestsInParallel(pipelineArgs, ci)

  // We run these in parallel, therefore use runTimed instead of runBlock. Using runBlock would cause a race
  // condition when setting env.PIPELINE_STAGE
  def steps = [
    'integration-tests': {
      runTimed 'integration-tests', {
        runMavenIntegrationTests environments: getIntegrationTestEnvironments(pipelineArgs, ci)
      }
    },
    'load-tests': {
      runTimed 'load-tests', {
        runMavenLoadTests environments: getLoadTestEnvironments(pipelineArgs, ci)
      }
    },
    'postman-tests'    : {
      runTimed 'postman-tests', {
        postmanNewmanServiceTests(
          environments: environments,
          artifactId: readMavenPom().getProperties().get('postman.service-test.module'),
          verbose: params.VERBOSE_LOGGING,
          parallel: parallelTests)
      }
    }
  ]

  def build = getBuild(pipelineArgs, ci)
  if (pipelineArgs.readyApi && build.readyApi) {
    def parameters = [
      executedBy: 'Dropwizard Pipeline'
    ] << pipelineArgs.readyApi << build.readyApi

    boolean syncMode = parameters.get('syncMode', true)

    // We don't want to pass 'syncMode' to the remote jenkins job
    parameters.remove('syncMode')

    steps['readyApi'] = {
      runTimed 'readyApi', {
        runRemoteJenkinsJob([
          username  : 'deployman',
          password  : 'deployman_token',
          url       : 'https://qe-jenkins.core.cvent.org',
          job       : 'runAPI',
          token     : 'Tru5tButVer1fy',
          syncMode  : syncMode,
          parameters: parameters
        ])
      }
    }
  }

  if (pipelineArgs.plannerTools && build.plannerTools) {
    def parameters = [
      cause: 'Dropwizard Pipeline'
    ] << pipelineArgs.plannerTools << build.plannerTools

    boolean syncMode = parameters.get('syncMode', true)

    // We don't want to pass 'syncMode' to the remote jenkins job
    parameters.remove('syncMode')

    // convert to pt-web-ui-automation-ci variable names
    parameters.put('ENVIRONMENT', parameters.remove('environment'))
    parameters.put('GIT_BRANCH', parameters.remove('branch'))
    parameters.put('THREAD_COUNT', parameters.remove('thread_count') ?: '1')
    parameters.put('TESTS', parameters.remove('tests'))

    steps['plannerTools'] = {
      runTimed 'plannerTools', {
        runRemoteJenkinsJob([
          username  : 'deployman',
          password  : 'deployman_password',
          url       : 'https://mobile-jenkins.core.cvent.org',
          job       : 'pt-web-ui-automation-ci',
          token     : 'mrsteve',
          syncMode  : syncMode,
          parameters: parameters
        ])
      }
    }
  }

  logInfo("Executing steps: parallel=$parallelTests")

  if (parallelTests) {
    parallel steps
  } else {
    steps.each { key, val ->
      logInfo("Running step $key")
      val()
    }
  }
}

/**
 * Return the first slack configuration which matches the build branch
 * @param pipelineArgs
 * @return
 */
def findSlackConfig(pipelineArgs) {
  def slack = pipelineArgs.slack ?: []
  for (config in slack) {
    // For SOURCE branch type, use BRANCH_NAME for config branch matching, otherwise use target branch
    // BRANCH_NAME = `PR-xxx` for PR builds or actual branch name for non-PR builds
    def slackBranch = (config.branch_type == 'SOURCE') ? env.BRANCH_NAME : getTargetBranch()
    if (slackBranch ==~ config.branch) {
      return config
    }
  }
}

String getEcrImageTag() {
  Map ecrImageTags = fileExists(ECR_IMAGE_TAGS_FILENAME) ? readJSON(file: ECR_IMAGE_TAGS_FILENAME) : null
  if (ecrImageTags) {
    return ecrImageTags.values().iterator().next();
  }
}

/**
 * @param result 'START' or currentBuild.currentResult
 */
def notifySlack(pipelineArgs, result) {
  if (!isSnapshotOrRelease(pipelineArgs)) {
    return
  }

  def config = findSlackConfig(pipelineArgs)
  if (!config || !config.events.contains(result)) {
    return
  }

  def channels = SlackUtils.transformSlackChannel(config.channel)
  if (!channels) {
    return
  }

  String style = (result == 'SUCCESS' || result == 'START') ? 'good' : 'danger'

  def fields = [
    [
      value: env.PIPELINE_GIT_LAST_COMMIT_MSG
    ],
    [
      title: "Branch",
      value: env.PIPELINE_SRC_BRANCH_NAME,
      short: true
    ],
    [
      title: "Author",
      value: env.PIPELINE_GIT_LAST_COMMITTER,
      short: true
    ],
    [
      title: "Version",
      value: env.PIPELINE_ARTIFACT_VERSION,
      short: true
    ],
    [
      title: "Commit",
      value: env.PIPELINE_GIT_COMMIT,
      short: true
    ]
  ]
  def actions = [
    [
      type : "button",
      text : "Jenkins Log",
      url  : env.BUILD_URL,
      style: style
    ]
  ]

  def environments = getEnvironments(pipelineArgs, !env.PIPELINE_ALPHA_BUILD)
  if (environments) {
    String tag = getEcrImageTag()
    if (tag) {
      fields.add([
        title: "ECR image tag",
        value: tag,
        short: false
      ])
    }
    getModulesToDeploy().each { module ->
      fields.add([
        value: "*${module}*",
        short: false
      ])
      environments.each { env ->
        fields.add([
          value: "${env} | <${link.aws(env, module)}|AWS> | <${link.datadog(env, module)}|Datadog APM> | <${link.splunk(env, module)}|Splunk>",
          short: false
        ])
      }
    }
  }

  if (result == 'ABORTED' || result == 'FAILURE') {
    fields.add([
      title: "Build failed at step",
      value: env.PIPELINE_STAGE,
      short: false
    ])
  }

  if (result != 'START') {
    actions.add([
      type : "button",
      text : "Test Results",
      url  : "${env.BUILD_URL}testReport/",
      style: style
    ])
  }

  if (env.CHANGE_URL) {
    actions.add([
      type : "button",
      text : "Pull Request",
      // slack will not show the action unless URL uses FQDN
      url  : env.CHANGE_URL.replace("/stash/", "/stash.cvent.net/"),
      style: style
    ])
  }

  def attachments = [
    [
      pretext  : "*${env.PIPELINE_REPO_ID}* - ${result}",
      color    : style,
      fallback : "${env.PIPELINE_REPO_ID} build",
      fields   : fields,
      mrkdwn_in: ['pretext', 'fields'],
      actions  : actions
    ]
  ]

  if (PIPELINE_WARNINGS) {
    attachments.add([
      color: "warning",
      text : PIPELINE_WARNINGS.join("\n")
    ])
  }

  SlackUtils.notifySlack(channels, [message: '', attachments: attachments])
}

def runBlock(String name, Closure body) {
  // record the current stage for slack notification
  env.PIPELINE_STAGE = name
  runTimed(name, body)
}

def runCheckout(String repo, String branch = 'master') {
  def tags = branch.startsWith('refs/tags/')

  checkout([
    $class                           : 'GitSCM',
    branches                         : [[name: branch]],
    doGenerateSubmoduleConfigurations: false,
    extensions                       : [
      [$class: 'CloneOption', depth: 0, noTags: !tags, reference: '', shallow: true],
      [$class: 'RelativeTargetDirectory', relativeTargetDir: repo]
    ],
    submoduleCfg                     : [],
    userRemoteConfigs                : [[url: "ssh://git@git.core.cvent.org:7999/stash/dep/${repo}.git"]]])
}

def runMaven(pipelineArgs, boolean snapshot) {
  env.PIPELINE_STAGE = 'Build'

  Closure buildMaven = {
    if (snapshot) {
      runTimed "Build snapshot: ${env.PIPELINE_ARTIFACT_VERSION}", {
        PIPELINE_WARNINGS += buildMavenSnapshot coverage: 'jacoco', deploy: true, runSonar: pipelineArgs.snapshot.sonar
      }
    } else {
      runTimed "Build release: ${env.PIPELINE_ARTIFACT_VERSION}", {
        PIPELINE_WARNINGS += buildMavenRelease coverage: 'jacoco', runSonar: pipelineArgs.release.sonar
      }
    }
  }

  boolean checkmarx = false
  if (pipelineArgs.checkmarx && pipelineArgs.checkmarx.branch) {
    checkmarx = (env.BRANCH_NAME ==~ pipelineArgs.checkmarx.branch)
  }

  String artifactId = getModulesToDeploy()[0]
  if (checkmarx && experiment.boolVariation(artifactId, 'pipeline-run-checkmarx')) {
    parallel(
      'build': buildMaven,
      'checkmarx': {
        runTimed 'checkmarx', {
          try {
            runCheckmarx(pipelineArgs.checkmarx)
          } catch (Exception e) {
            logError 'Checkmarx run failed: ' + e.getMessage()
            e.printStackTrace()
          }
        }
      }
    )
  } else {
    buildMaven()
  }
}

/*
  Picks the currently selected deploy AWS docker branch by using the following
  precedence:

  1. Jenkins job params
  2. dropwizardPipeline argument
  3. Feature flag

  If neither are set, return null.
*/
def getDeployAwsDockerBranch(pipelineArgs) {
  if (params.DEPLOY_AWS_DOCKER_BRANCH != null && !params.DEPLOY_AWS_DOCKER_BRANCH.allWhitespace) {
    return params.DEPLOY_AWS_DOCKER_BRANCH
  }

  if (pipelineArgs.deployAwsDockerBranch != null && !pipelineArgs.deployAwsDockerBranch.allWhitespace) {
    return pipelineArgs.deployAwsDockerBranch
  }

  String artifactId = getModulesToDeploy()[0]
  return experiment.stringVariation(artifactId, 'pipeline-deploy-aws-docker-branch', 'refs/tags/prod')
}

def call(pipelineArgs) {
  Map defaultConfig = [
    release: [
      sonar: true
    ],
    snapshot: [
      sonar: false
    ]
  ]
  pipelineArgs = GroovyUtils.mergeMaps(defaultConfig, pipelineArgs)

  if (!pipelineArgs.ci || !pipelineArgs.ci.builds) {
    pipelineArgs.ci = [
      builds: [
        [branch: '.*', environments: 'ci']
      ]
    ]
  }

  if (params.ENVIRONMENT) {
    pipelineArgs.builds = [
      [branch: '.*', environments: params.ENVIRONMENT]
    ]
  }

  pipeline {
    agent {
      label 'linux&&docker'
    }
    options {
      ansiColor('xterm')

      // Prepend all console output generated by the Pipeline run with the time at which the line was emitted.
      timestamps()

      buildDiscarder(logRotator(numToKeepStr: '15', daysToKeepStr: '30'))

      // https://jenkins.io/doc/book/pipeline/scaling-pipeline/
      durabilityHint('PERFORMANCE_OPTIMIZED')
    }
    parameters {
      booleanParam(
        name: 'RELEASE',
        defaultValue: false,
        description: 'Should maven release this build?'
      )
      string(
        name: 'HOGAN_CONFIGS_BRANCH',
        defaultValue: 'master',
        description: 'The branch to use for hogan-configs if your service config is going to be generated from hogan'
      )
      booleanParam(
        name: 'VERBOSE_LOGGING',
        defaultValue: false,
        description: 'Enable verbose logging'
      )
      string(
        name: 'DEPLOY_AWS_DOCKER_BRANCH',
        defaultValue: '',
        description: 'This is for testing for AWS pipeline developers only!! Otherwise leave this field blank!'
      )
      string(
        name: 'DEPLOY_SERVICE_ECS_TAG',
        defaultValue: '',
        description: 'This is for testing for AWS pipeline developers only!! Otherwise leave this field blank!'
      )
      string(
        name: 'HOGAN_BRANCH',
        defaultValue: 'master',
        description: 'Hogan branch to convert to git SHA for deploy time configuration'
      )
      string(
        name: 'HOGAN_GIT_SHA',
        defaultValue: '',
        description: 'Hogan git SHA for deploy time configuration. Takes priority over HOGAN_BRANCH'
      )
      string(
        name: 'ENVIRONMENT',
        defaultValue: '',
        description: 'Optional deployment environment to override the alpha/staging builds. Not recommended for general use. See the docs!'
      )
      booleanParam(
        name: 'DEPLOY_CLOUDFORMATION',
        defaultValue: false,
        description: 'Overrides the per-branch cloudformation flag, running cloudformation deployments on all stages. If not checked, has no effect.'
      )
    }
    environment {
      // Build branch (not PR branch name)
      PIPELINE_SRC_BRANCH_NAME = StashUtils.getBranch()
      // URL of GIT repository
      PIPELINE_GIT_URL = getGitUrl()
      // Unique identifier of repo
      PIPELINE_REPO_ID = StashUtils.getProjectSlashRepo(getGitUrl())
      // Get the last commit hash
      PIPELINE_GIT_COMMIT = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()
      // Get the last commit author so we can see if it's jenkins
      PIPELINE_GIT_LAST_COMMITTER = sh(returnStdout: true, script: "git log -1 --pretty=format:'%an'").trim()
      // Get the last commit message so we can see if it was a maven release "[maven-release-plugin]"
      PIPELINE_GIT_LAST_COMMIT_MSG = sh(returnStdout: true, script: "git log -1 --pretty=format:'%s'").trim()
      // Get the email address for the last committer; used to tag stacks if needed
      PIPELINE_GIT_LAST_COMMITTER_EMAIL = sh(returnStdout: true, script: "git log -1 --pretty=format:'%ae'").trim()
    }
    stages {
      stage('Setup') {
        steps {
          script {
            runBlock 'Setup', {
              def pom = readMavenPom()

              env.PIPELINE_ARTIFACT_VERSION = pom.getVersion()

              if (isSnapshotOrRelease(pipelineArgs)) {
                def index = pom.getVersion().lastIndexOf('-SNAPSHOT')
                if (index > 0) {
                  if (isRelease(pipelineArgs)) {
                    env.PIPELINE_ARTIFACT_VERSION = pom.getVersion().substring(0, index);
                  }
                } else {
                  PIPELINE_ERRORS.add("Unable to determine release version from snapshot version: ${pom.getVersion()}")
                  PIPELINE_ERRORS.add("Ensure your pom's version is a SNAPSHOT")
                }

                currentBuild.displayName = "#${env.BUILD_NUMBER} (${env.PIPELINE_ARTIFACT_VERSION})"
              } else if (isLastCommitMavenRelease()) {
                currentBuild.displayName = "#${env.BUILD_NUMBER} (No build: Maven release commit)"
              } else {
                currentBuild.displayName = "#${env.BUILD_NUMBER} (No build: Changeset contains only ignored files)"
              }

              env.PIPELINE_MODULES_TO_DEPLOY = pom.getProperties().getOrDefault('modules.to.deploy', '')

              def modules = getModulesToDeploy()
              if (modules) {
                modules.each {
                  if (!fileExists(it)) {
                    PIPELINE_ERRORS.add("Unable to find module '${it}'. Does the directory '${it}' exist? Is '${it}' a child module of your parent pom.xml?")
                  }
                }
              } else {
                PIPELINE_ERRORS.add('Root pom.xml file does not contain a "modules.to.deploy" property. This is a comma separated list of modules to deploy.')
              }

              if (env.CHANGE_URL && params.RELEASE) {
                PIPELINE_ERRORS.add('PR builds do not support building a RELEASE')
              }

              verifyPipelineArgs(pipelineArgs)

              notifySlack(pipelineArgs, 'START')

              printEnvInfo()

              if (!PIPELINE_ERRORS.isEmpty()) {
                error "Pipeline configuration has errors"
              }
            }
          }
        }
      }
      stage('Checkout') {
        when {
          beforeAgent true
          expression { isSnapshotOrRelease(pipelineArgs) }
        }
        steps {
          runBlock 'Checkout', {
            runCheckout('deploy-aws-docker', getDeployAwsDockerBranch(pipelineArgs))
            runCheckout('hogan-configs', params.HOGAN_CONFIGS_BRANCH ?: 'master')
            runCheckout('integration-tests-deploy')
            runCheckout('liquibase-deploy')
          }
        }
      }
      stage('Snapshot') {
        when {
          beforeAgent true
          expression { isSnapshot(pipelineArgs) }
        }

        steps {
          runMaven(pipelineArgs, true)
        }
      }
      stage('Release') {
        when {
          beforeAgent true
          expression { isRelease(pipelineArgs) }
        }
        steps {
          runMaven(pipelineArgs, false)
        }
      }
      // Invoke Nexus Lifecycle Scan which will scan 3rd party packages
      stage('Nexus Lifecycle Scan') {
        when {
          beforeAgent true
          expression { isSnapshotOrRelease(pipelineArgs) && !env.CHANGE_TARGET }
        }
        steps {
          build job: 'dropwizard-service-iq-scan', parameters:[
            string(name: 'GIT_REPO', value: env.PIPELINE_GIT_URL),
            string(name: 'GIT_BRANCH', value: env.PIPELINE_SRC_BRANCH_NAME),
            string(name: 'artifactId', value: env.PIPELINE_MODULES_TO_DEPLOY)
          ],
          wait: false
        }
      }
      stage('Docker Image') {
        when {
          beforeAgent true
          expression { isSnapshotOrRelease(pipelineArgs) }
        }
        steps {
          script {
            runBlock 'Build docker image', {
              def modules = getModulesToDeploy()
              def ecr_image_tags = buildDropwizardDocker(
                groupId: readMavenPom().getGroupId(),
                artifactIds: modules,
                platform: 'dropwizard',
                version: env.PIPELINE_ARTIFACT_VERSION,
                verbose: params.VERBOSE_LOGGING)

              // Save the output to let later steps determine the ecr image tags
              // writeJSON requires a JSON object, writeFile is easier
              writeFile file: ECR_IMAGE_TAGS_FILENAME, text: JsonOutput.toJson(ecr_image_tags)
            }
          }
        }
      }
      stage('CI') {
        when {
          beforeAgent true
          expression { isSnapshotOrRelease(pipelineArgs) }
        }
        steps {
          script {
            List environments = getEnvironments(pipelineArgs, true)
            if (environments) {
              lock("${env.PIPELINE_REPO_ID}-${environments.get(0)}") {
                  runBlock 'Migrate database: CI', {
                    runLiquibase(pipelineArgs, true)
                  }

                  runBlock 'Deploy: CI', {
                    runDeploy(pipelineArgs, true)
                  }

                  runBlock 'Deploy Cloudformation: CI', {
                    runCloudformationDeploy(
                      environments: environments,
                      verbose: params.VERBOSE_LOGGING,
                      commiter: env.PIPELINE_GIT_LAST_COMMITTER_EMAIL,
                      deploy: shouldDeployCloudformation(pipelineArgs)
                    )
                  }

                  runTests(pipelineArgs, true)

                  def build = getBuild(pipelineArgs, true)
                  if (build.get('shutdown', true)) {
                    runBlock 'Shutdown: CI', {
                      ecs.scale(
                        artifactIds: getModulesToDeploy(),
                        delete: false,
                        desiredCount: 0,
                        ecrImageTag: getEcrImageTag(),
                        environments: environments,
                        logLevel: "INFO",
                        tagOverride: params.DEPLOY_SERVICE_ECS_TAG
                      )
                    }
                  }
                }
            } else {
                PIPELINE_WARNINGS.add("""
                  Branch '${getTargetBranch()}' did not deploy to CI.
                  It is highly recommended to configure your Jenkinsfile to deploy every branch to a CI environment.""".stripIndent())
            }
          }
        }
      }
      stage('Alpha/Staging') {
        when {
          beforeAgent true
          expression { getEnvironments(pipelineArgs) && isSnapshotOrRelease(pipelineArgs) }
        }
        steps {
          script {
            env.PIPELINE_ALPHA_BUILD = true

            lock(env.PIPELINE_REPO_ID) {
              def environments = getEnvironments(pipelineArgs)

              runBlock "Migrate database: ${environments}", {
                runLiquibase(pipelineArgs)
              }

              runBlock "Deploy: ${environments}", {
                runDeploy(pipelineArgs)
              }

              runBlock "Deploy Cloudformation: ${environments}", {
                runCloudformationDeploy(
                  environments: environments,
                  verbose: params.VERBOSE_LOGGING,
                  commiter: env.PIPELINE_GIT_LAST_COMMITTER_EMAIL,
                  deploy: shouldDeployCloudformation(pipelineArgs)
                )
              }

              runTests(pipelineArgs)
            }
          }
        }
      }
    } // End Stages
    post {
      failure {
        script {
          // Print the errors near the end to help users find them
          PIPELINE_ERRORS.each({ logError it })


          logInfo "See https://stash.cvent.net/projects/JEN/repos/pipeline-utils/browse/doc/dropwizardPipeline.md#faq"
        }
      }
      always {
        script {
          PIPELINE_WARNINGS.each({ logWarn it })

          String tag = getEcrImageTag()
          if (tag) {
            logInfo "ECR image tag: ${tag}"

            // If we already have a description, append a new line. Otherwise
            // just make it an empty string
            currentDescr = currentBuild.description == null ?
              '' :
              currentBuild.description + '\n'

            // Append the image tags to the description
            currentBuild.description =
              "${currentDescr}ECR image tag: ${tag}"
          }
          notifySlack(pipelineArgs, currentBuild.currentResult)
        }
      }
    }
  }
}

def checkBuilds(builds) {
  checkProductionEnvironment(builds)

  builds.each { build ->
    if (build.readyApi && !build.readyApi.branch) {
      PIPELINE_ERRORS.add("Build specification contains readyApi but no readyApi branch: ${build}")
    }
  }
}

def checkProductionEnvironment(builds) {
  builds.each { build ->
    List envs = build.environments instanceof String ? [build.environments] : build.environments

    envs.each { env ->
      if (isProductionEnvironment(env)) {
        PIPELINE_ERRORS.add("Pipeline does not support deploying to production environment: ${env}")
      }
    }
  }
}

// Validates the arguments to the pipeline
def verifyPipelineArgs(pipelineArgs) {
  def release = pipelineArgs.release

  if (release) {
    if (!release.branch) {
      PIPELINE_ERRORS.add("Pipeline missing 'release.branch' property")
    }
  } else {
    PIPELINE_ERRORS.add("Pipeline missing 'release' property")
  }

  Set<String> pipelineKeys = [
    'builds',
    'checkmarx',
    'ci',
    'cloudformation',
    'liquibase',
    'ignoreFiles',
    'readyApi',
    'release',
    'slack',
    'snapshot',
    'deployAwsDockerBranch',
    'plannerTools'
  ]

  Set<String> ciKeys = ['builds']

  pipelineArgs.keySet().each { key ->
    if (!pipelineKeys.contains(key)) {
      PIPELINE_ERRORS.add("Pipeline contains unknown property '${key}'")
    }
  }

  pipelineArgs.ci.each { key, value ->
    if (!ciKeys.contains(key)) {
      PIPELINE_ERRORS.add("Pipeline contains unknown property 'ci.${key}'")
    }
  }

  checkBuilds(pipelineArgs.ci.builds)
  checkBuilds(pipelineArgs.builds)
}
