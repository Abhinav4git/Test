// Methods for notifying monitoring and metric services that a deploy has occured.

import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.transform.Field

// Sends user defined message to specified slack channe(s)l
def slackMessageSimple(silo,status,message,slackChannel="") {
  channel = slackChannel ?: consul.getEnvironmentData("silo/${silo}/deploy/slack_channel")
  switch (status) {
    case 'good':
      color='#43A047'
      break
    case 'bad':
      color='#E53935'
      break
    case 'neutral':
      color='#FDD835'
      break
  }
  slackSend(channel: channel,
    color: color,
    message: message
  )
}

// Sends user defined message to specified slack channe(s)l
def slackMessageDetail(silo,status,message,title,slackChannel="") {
  channel = slackChannel ?: consul.getEnvironmentData("silo/${silo}/deploy/slack_channel")
  switch (status) {
    case 'good':
      color='#43A047'
      break
    case 'bad':
      color='#E53935'
      break
    case 'neutral':
      color='#FDD835'
      break
  }
  attachments = [
    [
      pretext  : "${message}",
      color    : "${color}",
      title: "${title}",
      text: "(<${env.BUILD_URL}console|console>)",
      fallback : "${env.PIPELINE_REPO_ID} build ${env.BUILD_NUMBER}",
    ]
  ]
  slackSend(channel: channel,
    color: color,
    message: message,
    attachments: JsonOutput.toJson(attachments)
  )
}

// Sends a mark to NewRelic with the infomation about the deployed revision
def notifyNewRelic(type,environment,revision,changeLog,description,user) {
  println("Notifying NewRelic")
  withCredentials([string(credentialsId: 'NR_API_KEY', variable: 'NR_API_KEY')]) {
    def url = "https://api.newrelic.com"
    def uriPath = "/v2/applications.json"
    def connection =  new URL(url + uriPath).openConnection() as HttpURLConnection
    def requestBody = "filter[name]=${environment}: ${type}"

    //Gets the application id for the given app in an environment
    connection.setRequestProperty( 'X-Api-Key', NR_API_KEY)
    connection.setRequestProperty( 'Accept', 'application/json' )
    connection.setDoOutput(true)
    connection.getOutputStream().write(requestBody.getBytes("UTF-8"));
    if(connection.getResponseCode().equals(200)) {
      def response = new JsonSlurper().parseText(connection.inputStream.text)

      applicationID = response.applications[0].id
      requestBody = """\
        {
          "deployment": {
            "revision": "${revision}",
            "changelog": "${changeLog}",
            "description": "${description}",
            "user": "${user}"
          }
        }
        """

        //Then we send the deployment notification.
        uriPath = "/v2/applications/${applicationID}/deployments.json"
        connection = new URL(url + uriPath).openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.setRequestProperty( 'X-Api-Key', NR_API_KEY)
        connection.setRequestProperty( 'Content-Type', 'application/json' )
        connection.setRequestProperty( 'Accept', 'application/json' )
        connection.setDoOutput(true)
        connection.getOutputStream().write(requestBody.getBytes("UTF-8"))
        connection.disconnect();
        if (!connection.getResponseCode().equals(201)) {
          errorReporter(connection)
        }
    }
    else { //An error must have occured
      errorReporter(connection)
    }
  }
}

//Sends a event to datadog with the deployment information
def notifyDataDog(service,environment,revision,description,user) {
  println("Notifying DataDog")
  withCredentials([string(credentialsId: 'DD_API_KEY', variable: 'DD_API_KEY')]) {
    def url = "https://app.datadoghq.com"
    def uriPath = "/api/v1/events"
    def queryParams = "?api_key=${DD_API_KEY}"
    def fullPath = url + uriPath + queryParams

    def requestBody = """\
      {
        "title": "Deploying ${service}:${revision} to ${environment}",
        "text": "${description} by ${user}",
        "priority": "normal",
        "tags": ["application:${service}","account:crowdcompass","environment:${environment}", "artifact:${branch}"],
        "alert_type": "info"
      }
      """

      sh """curl --silent -X POST -H "Content-type: application/json" -d '${requestBody}' ${fullPath}"""
  }
}

def notifyRollBar(service,environment,revision,user) {
  println("Notifying RollBar")
  withCredentials([string(credentialsId: 'RB_API_KEY', variable: 'RB_API_KEY')]) {
    try {
      sh "curl -s https://api.rollbar.com/api/1/deploy/ \
        -F access_token=${apiKey} \
        -F environment=${environment} \
        -F revision=${revision} \
        -F local_username=${user} >>/dev/null"
    } catch (err) {
      println "RollBar Notification Failed"
    }
    return 0
  }
}


private def errorReporter(connection) {
  println "An error occured. Return code is ${connection.getResponseCode()}"
  println connection.inputStream.text
}
