// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// isProductionEnvironment

/**
 * @return true if environment is a production environment
 */
static boolean call(String environment) {
  environment = environment.toLowerCase()

  (environment.startsWith("ct")
    || environment.startsWith("pr")
    || environment == "p2"
    || environment == "p11"
    || environment.startsWith("ep"))
}
