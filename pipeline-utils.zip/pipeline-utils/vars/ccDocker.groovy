import groovy.transform.Field

@Field String registry = 'docker-registry.crwd.cc'
@Field String registryVersion = 'v2'
@Field String dockerPort = '2376'
@Field String cventDNS = '172.21.226.1'
@Field String vaultAddr = 'http://vault.crwd.cc'

//Checks to see if the tagged image already exists in the registry, if not builds using rbenv
def buildContainer(application,tag,composeTarget='rails',prefix='crowdcompass') {
  error("The function buildContainer is deprecated. Please use either dockerBuildLocal or dockerBuild")
}

//Updates docker service first via docker-compose and then force updates to cycle secrets
def updateService(application,tag,environment,domain,dockerHost,shortener,clickDomain,legacyClickDomain) {
  dockerCmdVars = "DOMAIN=${domain} ENVIRONMENT=${environment} TAG=${tag} SHORTENER_DOMAIN=${shortener} CLICK_DOMAIN=${clickDomain} LEGACY_CLICK_DOMAIN=${legacyClickDomain}"
  token = helpers.generateToken(environment)
  railsReplicas = consul.getEnvironmentData("silo/${environment}/config/services/${application}/replicas")
  println "Replicas: ${railsReplicas}"
  woodhouseReplicas = consul.getEnvironmentData("silo/${environment}/config/services/${application}/replicas_woodhouse")
  if (woodhouseReplicas?.trim()) {
    println "Woodhouse Replicas: ${woodhouseReplicas}"
  }
  println "Running docker stack deploy"
  sh '#!/bin/sh -e\n'+"${dockerCmdVars} DOCKER_HOST=\"${dockerHost}\":2376 VAULT_TOKEN=${token} RAILS_REPLICAS=${railsReplicas} WOODHOUSE_REPLICAS=${woodhouseReplicas} docker stack deploy --compose-file docker-compose.yml ${application}"
  //verifies stack deploy has completed
  println "Verifying ${application} service convergence in the swarm"
  sh '#!/bin/bash -e\n'+"""docker run --rm --mount type=bind,src=\$(pwd)/docker-compose.yml,dst=/home/opam/docker-compose.yml,readonly \
                                       -e VAULT_TOKEN=${token} \
                                       -e TAG=${tag} \
                                       -e DOMAIN=${domain} \
                                       -e ENVIRONMENT=${environment} \
                                       -e TAG=${tag} \
                                       -e SHORTENER_DOMAIN=${shortener} \
                                       -e CLICK_DOMAIN=${clickDomain} \
                                       -e LEGACY_CLICK_DOMAIN=${legacyClickDomain} \
                                       -e RAILS_REPLICAS=${railsReplicas} \
                                       -e WOODHOUSE_REPLICAS=${woodhouseReplicas} \
                                       issuu/sure-deploy:176 converge --host ${dockerHost} --port 2376 --verbose ${application}"""

}

//Updates docker service first via docker-compose and then force updates to cycle secrets
def restartService(application,environment,dockerHost) {
  dockerCmdVars = "ENVIRONMENT=${environment} DOCKER_HOST=${dockerHost}:2376"
  updateTargets = sh (returnStdout:true, script:
    "${dockerCmdVars} docker service ls --filter name=${application} --format '{{.Name}}'"
    ).split("\n")
  println "Output from service lookup ${updateTargets}"

  // We loop through every service associated with this application to cycle secrets
  for (int index = 0; index < updateTargets.size(); index++) {
    service = updateTargets[index]
    echo "Force updating ${service}"
    if (service.contains("woodhouse")) {
      dockerReplicas = consul.getEnvironmentData("silo/${environment}/config/services/${application}/replicas_woodhouse")
    }
    else {
      dockerReplicas = consul.getEnvironmentData("silo/${environment}/config/services/${application}/replicas")
    }
    if (!dockerReplicas) {
      println "No replica value found in consul for ${service}. Using default of 3."
      dockerReplicas = 3
    }
    try {
      sh returnStdout:true, script:("${dockerCmdVars} docker service update --stop-grace-period 15s --force --replicas ${dockerReplicas} ${service} --update-order start-first")
    } catch (err) {
      println "FAILED: Problem forcing ${service} update:\n ${err}"
    }
  }
}

//removes the service
def deleteContainer(application,tag,environment,domain,dockerHost,shortener) {
  println "deleting the service"
  dockerCmdVars = "DOMAIN=${domain} ENVIRONMENT=${environment} TAG=${tag} DOCKER_HOST=${dockerHost} SHORTENER_DOMAIN=${shortener}"
  updateTargets = sh (returnStdout:true, script:
    "${dockerCmdVars} docker service ls --filter name=${application} --format '{{.Name}}'"
    ).split("\n")
  println "Output from service lookup ${updateTargets}"
  if ("${updateTargets}" == "[]") {
    println "The service does not exist , so nothing to remove"
  } else {
      for (int index = 0; index < updateTargets.size(); index++) {
        service = updateTargets[index]
        echo "Removing Service ${service}"
        sh "${dockerCmdVars} docker service rm ${service}"
      }
   }
}

// Given the IP of a host in the swarm, runs a docker container with the entry point a script
def dockerRunScript(application,dockerTargetIP,environment,script,tag,network="overlay_v1",image_prefix='crowdcompass',envVars="",containerName="") {
  imageUrl = "${registry}/${image_prefix}/${application}:${tag}"
  try {
    withCredentials([string(credentialsId: 'VAULT_TOKEN', variable: 'VAULT_TOKEN')]) {
      now = new Date().format("yyyyMMddHHmmssSSS", TimeZone.getTimeZone('UTC'))
      containerName = "${application}_${environment}_script_${now}"
      echo "Docker Container: ${containerName}"
      sh "DOCKER_HOST=${dockerTargetIP}:${dockerPort} docker pull ${imageUrl}"
      sh "DOCKER_HOST=${dockerTargetIP}:${dockerPort} docker run --rm --name ${containerName} --network ${network} -e CC_ENVIRONMENT=${environment} -e SCRIPT='${script}' ${envVars} -e VAULT_TOKEN=${VAULT_TOKEN} ${imageUrl} /usr/local/bin/run_script.sh"
    }
  }
  catch(err) {
    currentBuild.result = 'FAILURE'
  }
  return containerName
}

// Given the IP of a host in the swarm, runs a docker container with the entry point a script
def dockerRunScriptv2(application,dockerTargetIP,environment,script,tag,network='overlay_v1',image_prefix='crowdcompass',envVars="") {
  imageUrl = "${registry}/${image_prefix}/${application}:${tag}"
  String result
  try {
    withCredentials([string(credentialsId: 'VAULT_TOKEN', variable: 'VAULT_TOKEN')]) {
      now = new Date().format("yyyyMMddHHmmssSSS", TimeZone.getTimeZone('UTC'))
      containerName = "${application}_${environment}_script_${now}"
      echo "Docker Container: ${containerName}"
      sh "DOCKER_HOST=${dockerTargetIP}:${dockerPort} docker pull ${imageUrl}"
      result = sh returnStdout:true, script: "DOCKER_HOST=${dockerTargetIP}:${dockerPort} docker run --rm --name ${containerName} --network ${network} -e CC_ENVIRONMENT=${environment} -e SCRIPT='${script}' ${envVars} -e VAULT_TOKEN=${VAULT_TOKEN} ${imageUrl} /usr/local/bin/run_script.sh"
      println("********SCRIPT OUTPUT*********\n\n${result}\n******************************")
    }
  }
  catch(err) {
      println(err)
    currentBuild.result = 'FAILURE'
  }
  return result
}

def dockerKillScript(dockerTargetIP,containerName) {
    echo "Killing docker container: ${containerName}"
    sh "DOCKER_HOST=${dockerTargetIP}:${dockerPort} docker kill ${containerName}"
}

//The buildScript functions work by using the projects FROM Docker image
//and running a command(ie. bundle install etc.) to prepare for building the image
def buildScriptv2(application,environment,command,gitBranch="",dockerfile="Dockerfile",envVars="") {
  from = dockerfileFromImage(dockerfile)
  echo "FROM: ${from}"
  withCredentials([string(credentialsId: 'VAULT_TOKEN', variable: 'VAULT_TOKEN')]) {
    sshagent(['80de4c91-460d-4e7e-9517-b99b826860a8']) {
      sh "docker run -i --dns=${cventDNS} --dns-search=cvent.net --user ccjenkinsman -e APP=${application} -e CC_ENVIRONMENT=${environment} -e GITBRANCH=${gitBranch} -e SCRIPT='${command}' -e VAULT_TOKEN=${VAULT_TOKEN} ${envVars} -e SSH_AUTH_SOCK=/ssh-agent -v /home/ccjenkinsman/.ssh:/home/ccjenkinsman/.ssh:ro -v \$SSH_AUTH_SOCK:/ssh-agent -v $WORKSPACE:/opt/apps/:rw ${from} /usr/local/bin/build_script.sh"
    }
  }
}

def buildScript(application,environment,command,gitBranch="",dockerfile="Dockerfile",envVars="") {
  error("The function buildScript is deprecated. Please update to use buildScriptv2 in your Jenkinsfile")
}


//Utilizes docker compose to build and push images
def dockerBuild(application,tag,composeTarget='rails') {
  println "docker building..."
  println "Application: ${application} Compose Target: ${composeTarget}"
  sh "TAG=${tag} RAILS_REPLICAS=1 WOODHOUSE_REPLICAS=1 docker-compose build --force-rm --pull ${composeTarget}"
  sh "docker push ${registry}/${image}:${tag}"
}

//TODO Remove the URL check here that should happen outside this function

def dockerBuildLocal(application,tag,prefix='crowdcompass') {
  image = "${prefix}/${application}"
  dockerRegUrl = "https://${registry}/${registryVersion}/${image}/manifests/${tag}"
  if (!urlHealth(dockerRegUrl.toString(),'200')) {
    println "docker building..."
    println "Application: ${application}"
    sh "docker build --pull -t ${registry}/${image}:${tag} ."
    sh "echo '${registry}/${image}:${tag} ${WORKSPACE}/Dockerfile' > anchore_files"
    sh "docker push ${registry}/${image}:${tag}"
  }
  else {
    println "This image already exists, skip the build."
  }
}

def dockerRunLocal(application,tag,silo,prefix,dockerVars,envVars) {
  imageURL = "${registry}/${prefix}/${application}:${tag}"
  withCredentials([string(credentialsId: 'VAULT_TOKEN', variable: 'VAULT_TOKEN')]) {
    now = new Date().format("yyyyMMddHHmmssSSS", TimeZone.getTimeZone('UTC'))
    containerName = "${application}-${now}"
    echo "Docker Container: ${containerName}"
    sh "docker pull ${imageURL}"
    sh "docker run --rm --name ${containerName} ${dockerVars} -e SILO=${silo} ${envVars} -e VAULT_TOKEN=${VAULT_TOKEN} -e VAULT_ADDR=${vaultAddr} ${imageURL}"
  }
}

def dockerRunSwarm(application,targetApplication,tag,silo,prefix,awsRegion,vpcId,awsId,dockerVars,envVars) {
  imageURL = "${registry}/${prefix}/${application}:${tag}"
  dockerTargetIP = consul.getDockerHost("docker-node",silo,awsRegion,vpcId,awsId)
  println "Retrieved Docker Node IP ${dockerTargetIP} from AWS Cloud Map\n"
  withCredentials([string(credentialsId: 'VAULT_TOKEN', variable: 'VAULT_TOKEN')]) {
    now = new Date().format("yyyyMMddHHmmssSSS", TimeZone.getTimeZone('UTC'))
    containerName = "${application}_${silo}_script_${now}"
    echo "Docker Container: ${containerName}"
    sh "DOCKER_HOST=${dockerTargetIP}:${dockerPort} docker pull ${imageURL}"
    sh "DOCKER_HOST=${dockerTargetIP}:${dockerPort} docker run --rm --name ${containerName} ${dockerVars} -e SILO=${silo} -e APP=${targetApplication} ${envVars} -e VAULT_TOKEN=${VAULT_TOKEN} -e VAULT_ADDR=${vaultAddr} ${imageURL}"
  }
}

// Helper method that curls a requested url for the expected response code
Boolean urlHealth(url,responseCode) {
  resp = sh returnStdout:true, script: "curl -I -s -k -o /dev/null -w '%{http_code}' ${url} || exit 0"
  if (resp == "${responseCode}"){
    return true
  }
  return false
}

Boolean imageExists(application,tag,prefix='crowdcompass'){
  image = "${prefix}/${application}"
  dockerRegUrl = "https://${registry}/${registryVersion}/${image}/manifests/${tag}"
  if (urlHealth(dockerRegUrl.toString(),'200')) {
    return true
  }
  else {
    return false
  }
}

// Returns the first FROM image of the named Dockerfile
String dockerfileFromImage(dockerfile='Dockerfile') {
  sh (script: "grep -m 1 FROM ${dockerfile} | awk '{print \$2}'", returnStdout: true).trim()
}
