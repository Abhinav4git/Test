// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// serviceBlacklists

static call(String environmentName) {
    Map blacklist = [:]

    blacklist["ct50"] = [
        "account-state-service",
        "aggregation-consumer", // Lead Scoring only has production
        "archive-couchbase-metadata-service", // Part of the data retention stack
        "archive-elasticsearch-metadata-service", // Part of the data retention stack
        "archive-executor-service", // Part of the data retention stack
        "auth-service-web", // Auth service in pr50 is used so this does not need to be deployed.
        "bkmbl", // Lead Scoring only has production
        "bi-account-manager-service",
        "bi-sink-service",
        "cdc-bulkloader-service",
        "cdc-datasync-service",
        "cdc-relay-consumer", // Not to be deployed https://cvent-tech.slack.com/archives/C87PLB2DB/p1547794936190200?thread_ts=1547742348.176100&cid=C87PLB2DB
        "checkEtlInbox", // Lead Scoring only has production
        "checkEtlSftp", // Lead Scoring only has production
        "conference-reporting-service",
        "conference-lead-score-bulk-update-service",
        "conference-marketing-person-data-consumer",
        "conference-marketing-lead-score-consumer",
        "conference-person-lead-score-service",
        "lead-score-activity-consumer",
        "marketing-integration-service",
        "marketo-lead-score-consumer",
        "conference-lead-scoring-service",
        "csn-dbk-booking-app-service",
        "csn-leadscore-sender", // Lead Scoring only has production
        "csn-microsite-consumer",
        "csn-microsite-service",
        "csn-rfp", // Lead Scoring only has production
        "Cvent.Buildpacks", // Internal tool not needed outside of PR50
        "Cvent.Payment.API", // no payment services in ct50
        "Cvent.Payment.ElasticSearchConsumer", // no payment services in ct50
        "Cvent.Payment.Report.API", // no payment services in ct50
        "Cvent.Payment.Service", // no payment services in ct50
        "Cvent.Payment.WebApp", // no payment services in ct50
        "daakiya-consumer", // Not to be deployed https://cvent-tech.slack.com/archives/C87PLB2DB/p1547818657217500?thread_ts=1547742348.176100&cid=C87PLB2DB
        "delphiFdcConnector", // Lead Scoring only has production
        "delphiFdcConsumer", // Lead Scoring only has production
        "drive", // Lead Scoring only has production
        "dumptruck", // Lead Scoring only has production
        "evaluate-worker", // Lead Scoring only has production
        "event-guestside-sitemap-service", // Not to be deployed - we don't want search engines to index ct50.
        "experiments-service", // ct50 uses production experiments API and etcd cluster
        "environments-service", // ct50 uses prod experiments which calls prod environments
        "importConsumer", // Lead Scoring only has production
        "obfuscation-metadata-service",
        "odometer", // Lead Scoring only has production
        "optimusPrime", // Lead Scoring only has production
        "optimusPrime-historicals", // Lead Scoring only has production
        "passkey-authentication-service",
        "passkey-delphifdc-service", // https://cvent-tech.slack.com/archives/C87NWE1MZ/p1550020642030600
        "passkey-event-service",
        "passkey-pbr-survey-service",
        "passkey-business-text-service",
        "passkey-create-hotel-service",
        "passkey-event-housing-service",
        "passkey-reglink-service",
        "passkey-reservation-service",
        "passkey-inventory-service",
        "passkey-inventory-consumer",
      	"passkey-autoblock-guestside-service",
        "passkey-room-type-data-service",
        "passkey-subblock-data-service",
        "payments-wallet-service", // no payment services in ct50
        "payments-proxy-service", // no payment services in ct50
        "postgres-data-archive-service", // Part of the data retention stack
        "rdbms-obfuscation-service", // Part of the data retention stack
        "s3-data-archive-service", // Part of the data retention stack
        "sql-server-data-archive-service", // Part of the data retention stack
        "starbirst-service",
      	"survey-analytics", // https://cvent.slack.com/archives/CGYBPCUSJ/p1576000005158800

        // Falcon related services - do not deploy until Falcon is ct50 ready
        "deep-link-service",
        "falcon-data-service",
        "falcon-planner-service",
        "falcon-service",
        "falcon-snapshot-service",
        "falcon-web-ui-service",
        "session-qa-service",
    ]

    blacklist["pr51"] = [
        "aggregation-consumer", // Lead Scoring only has production
        "archive-couchbase-metadata-service", // Part of the data retention stack
        "archive-elasticsearch-metadata-service", // Part of the data retention stack
        "archive-executor-service", // Part of the data retention stack
        "bkmbl", // Lead Scoring only has production
        "checkEtlInbox", // Lead Scoring only has production
        "checkEtlSftp", // Lead Scoring only has production
        "csn-leadscore-sender", // Lead Scoring only has production
        "csn-rfp", // Lead Scoring only has production
        "Cvent.Buildpacks", // Internal tool not needed outside of PR50
        "dba-admin-sql", // Not to be running in DR
        "delphiFdcConnector", // Lead Scoring only has production
        "delphiFdcConsumer", // Lead Scoring only has production
        "drive", // Lead Scoring only has production
        "dumptruck", // Lead Scoring only has production
        "evaluate-worker", // Lead Scoring only has production
        "importConsumer", // Lead Scoring only has production
        "odometer", // Lead Scoring only has production
        "optimusPrime", // Lead Scoring only has production
        "optimusPrime-historicals", // Lead Scoring only has production
        "postgres-data-archive-service", // Part of the data retention stack
        "rdbms-obfuscation-service", // Part of the data retention stack
        "s3-data-archive-service", // Part of the data retention stack
        "sql-deploy", // Not to be running in DR
        "sql-server-data-archive-service" // Part of the data retention stack
    ]

    blacklist["pr53"] = [
        "aggregation-consumer", // Lead Scoring only has production
        "API", // Lanyon is not in EU
        "archive-couchbase-metadata-service", // Part of the data retention stack
        "archive-elasticsearch-metadata-service", // Part of the data retention stack
        "archive-executor-service", // Part of the data retention stack
        "AWS", // Lanyon is not in EU
        "bi-account-manager-service",
        "bi-sink-service",
        "bkmbl", // Lead Scoring only has production
        "cdc-bulkloader-service", // Not to be deployed https://cvent-tech.slack.com/archives/C87PLB2DB/p1547789749183800?thread_ts=1547753933.182900&cid=C87PLB2DB
        "checkEtlInbox", // Lead Scoring only has production
        "checkEtlSftp", // Lead Scoring only has production
        "Commerce", // Lanyon is not in EU
        "conference-reporting-service", // not needed
        "conference-nomination-web", // Not needed in EU
        "conference-lead-score-bulk-update-service", // Not needed in EU
        "conference-marketing-person-data-consumer", // Not needed in EU
        "conference-marketing-lead-score-consumer", // Not needed in EU
        "conference-person-lead-score-service", // Not needed in EU
        "lead-score-activity-consumer", // Not needed in EU
        "marketing-integration-service", // Not needed in EU
        "marketo-lead-score-consumer", //  Lanyon is not in EU
        "conference-lead-scoring-service", //  Lanyon is not in EU
        "csn-leadscore-sender", // Lead Scoring only has production
        "csn-rfp", // Lead Scoring only has production
        "Cvent.Buildpacks", // Internal tool not needed outside of PR50
        "delphiFdcConnector", // Lead Scoring only has production
        "delphiFdcConsumer", // Lead Scoring only has production
        "directbook-postal-service", // As per Karen Tran in #csn-hypersonic
        "dortal-service",
        "dortal-scheduler-service",
        "drive", // Lead Scoring only has production
        "dumptruck", // Lead Scoring only has production
        "environments-service", // EU has it's environments and experiments managed in the US Pod
        "evaluate-worker", // Lead Scoring only has production
        "GDS Access - Gateway Services", // Lanyon is not in EU
        "GDS Access - Web Site", // Lanyon is not in EU
        "GL", // Lanyon is not in EU
        "HOD Publisher Connector Manager", // Lanyon is not in EU
        "HOD Publisher Publishing Manager", // Lanyon is not in EU
        "HOD Publisher Website", // Lanyon is not in EU
        "Hotel Directory - Web Site", // Lanyon is not in EU
        "Hotel-Directory-Service", // Lanyon is not in EU
        "id-service", // As per Siddharth Jain
        "importConsumer", // Lead Scoring only has production
        "odometer", // Lead Scoring only has production
        "optimusPrime", // Lead Scoring only has production
        "optimusPrime-historicals", // Lead Scoring only has production

        // Passkey API Services - see management section in wiki link below for script to generate this
        // https://wiki.cvent.com/x/VkESBw
        "passkey-acknowledgment-service",
        "passkey-addons-service",
        "passkey-authentication-service",
        "passkey-autoblock-data-service",
        "passkey-autoblock-guestside-service",
        "passkey-autoblock-site-editor-service",
        "passkey-bridge-service",
        "passkey-business-text-service",
        "passkey-compliance-consumer",
        "passkey-compliance-service",
        "passkey-create-event-service",
        "passkey-create-hotel-service",
        "passkey-create-planner-service",
        "passkey-create-subblock-group-service",
        "passkey-create-subblock-service",
        "passkey-delphifdc-service",
        "passkey-ecommerce-consumer",
        "passkey-ecommerce-service",
        "passkey-event-housing-service",
        "passkey-event-service",
        "passkey-gateway-service",
        "passkey-gdpr-service",
        "passkey-hotel-service",
        "passkey-inventory-consumer",
        "passkey-inventory-service",
        "passkey-payment-service",
        "passkey-pbr-survey",
        "passkey-pbr-survey-service",
        "passkey-planners-service",
        "passkey-reglink-service",
        "passkey-reporting-service",
        "passkey-resdesk-ui",
        "passkey-reservation-consumer",
        "passkey-reservation-service",
        "passkey-room-type-data-service",
        "passkey-smartcamp-cfg-data-service",
        "passkey-subblock-data-service",
        "passkey-create-subblock-service",
        "passkey-subblock-group-data-service",
        // Passkey API Services - END

        "passkey-callback-consumer", // https://cvent-tech.slack.com/archives/C4KF11GKZ/p1547828800081400
        "passkey-service", // https://cvent-tech.slack.com/archives/C4KF11GKZ/p1547828800081400
        "payments-proxy-bridge-service", // Used for directbook and not needed in pr53/pr53 as per Brian Szymanski
        "payments-proxy-service", // Used for directbook and not needed in pr53/pr53 as per Brian Szymanski
        "Planner", // Lanyon is not in EU
        "postgres-data-archive-service", // Part of the data retention stack
        "Rate Audit Processor", // Lanyon is not in EU
        "Rate Availability Processor", // Lanyon is not in EU
        "Rate Integrity", // Lanyon is not in EU
        "Reports", // Lanyon is not in EU
        "Resdesk", // Lanyon is not in EU
        "Reverse Audit Processor", // Lanyon is not in EU
        "RLM", // Lanyon is not in EU
        "rdbms-obfuscation-service", // Part of the data retention stack
        "s3-data-archive-service", // Part of the data retention stack
        "SBD", // Lanyon is not in EU
        "Smart", // Lanyon is not in EU
        "survey-analytics", //Legacy survey is not in EU
        "survey-event-consumer-service", //Legacy survey is not in EU,
        "surveys-report-service", //Legacy survey is not in EU
        "sql-server-data-archive-service", // Part of the data retention stack
        "starbirst-service",
        "Travel Portals - Web Site", // Lanyon is not in EU
    ]

    blacklist["pr54"] = [
        "aggregation-consumer", // Lead Scoring only has production
        "API", // Lanyon is not in EU
        "archive-couchbase-metadata-service", // Part of the data retention stack
        "archive-elasticsearch-metadata-service", // Part of the data retention stack
        "archive-executor-service", // Part of the data retention stack
        "AWS", // Lanyon is not in EU
        "bi-account-manager-service",
        "bi-sink-service",
        "bkmbl", // Lead Scoring only has production
        "cdc-bulkloader-service", // Not to be deployed https://cvent-tech.slack.com/archives/C87PLB2DB/p1547789749183800?thread_ts=1547753933.182900&cid=C87PLB2DB
        "checkEtlInbox", // Lead Scoring only has production
        "checkEtlSftp", // Lead Scoring only has production
        "conference-reporting-service", // not needed
        "conference-nomination-web", // Not needed in EU
        "conference-lead-score-bulk-update-service", // Not needed in EU
        "conference-marketing-person-data-consumer", // Not needed in EU
        "conference-marketing-lead-score-consumer", // Not needed in EU
        "conference-person-lead-score-service", // Not needed in EU
        "lead-score-activity-consumer", // Not needed in EU
        "marketing-integration-service", // Not needed in EU
        "marketo-lead-score-consumer", //  Lanyon is not in EU
        "conference-lead-scoring-service", //  Lanyon is not in EU
        "csn-leadscore-sender", // Lead Scoring only has production
        "csn-rfp", // Lead Scoring only has production
        "Cvent.Buildpacks", // Internal tool not needed outside of PR50
        "dba-admin-sql", // Not to be running in DR
        "delphiFdcConnector", // Lead Scoring only has production
        "delphiFdcConsumer", // Lead Scoring only has production
        "directbook-postal-service", // As per Karen Tran in #csn-hypersonic
        "dortal-service",
        "dortal-scheduler-service",
        "drive", // Lead Scoring only has production
        "dumptruck", // Lead Scoring only has production
        "environments-service", // EU has it's environments and experiments managed in the US Pod
        "evaluate-worker", // Lead Scoring only has production
        "GDS Access - Gateway Services", // Lanyon is not in EU
        "GDS Access - Web Site", // Lanyon is not in EU
        "GL", // Lanyon is not in EU
        "HOD Publisher Connector Manager", // Lanyon is not in EU
        "HOD Publisher Publishing Manager", // Lanyon is not in EU
        "HOD Publisher Website", // Lanyon is not in EU
        "Hotel Directory - Web Site", // Lanyon is not in EU
        "Hotel-Directory-Service", // Lanyon is not in EU
        "id-service", // As per Siddharth Jain
        "importConsumer", // Lead Scoring only has production
        "odometer", // Lead Scoring only has production
        "optimusPrime", // Lead Scoring only has production
        "optimusPrime-historicals", // Lead Scoring only has production

        // Passkey API Services - see management section in wiki link below for script to generate this
        // https://wiki.cvent.com/x/VkESBw
        "passkey-acknowledgment-service",
        "passkey-addons-service",
        "passkey-authentication-service",
        "passkey-autoblock-data-service",
        "passkey-autoblock-guestside-service",
        "passkey-autoblock-site-editor-service",
        "passkey-bridge-service",
        "passkey-business-text-service",
        "passkey-compliance-consumer",
        "passkey-compliance-service",
        "passkey-create-event-service",
        "passkey-create-hotel-service",
        "passkey-create-planner-service",
        "passkey-create-subblock-group-service",
        "passkey-create-subblock-service",
        "passkey-delphifdc-service",
        "passkey-ecommerce-consumer",
        "passkey-ecommerce-service",
        "passkey-event-housing-service",
        "passkey-event-service",
        "passkey-gateway-service",
        "passkey-gdpr-service",
        "passkey-hotel-service",
        "passkey-inventory-consumer",
        "passkey-inventory-service",
        "passkey-pbr-survey",
        "passkey-pbr-survey-service",
        "passkey-planners-service",
        "passkey-reglink-service",
        "passkey-reporting-service",
        "passkey-resdesk-ui",
        "passkey-reservation-consumer",
        "passkey-reservation-service",
        "passkey-room-type-data-service",
        "passkey-smartcamp-cfg-data-service",
        "passkey-subblock-data-service",
        "passkey-create-subblock-service",
        "passkey-subblock-group-data-service",
        // Passkey API Services - END

        "passkey-callback-consumer", // https://cvent-tech.slack.com/archives/C4KF11GKZ/p1547828800081400
        "passkey-service", // https://cvent-tech.slack.com/archives/C4KF11GKZ/p1547828800081400
        "payments-proxy-bridge-service", // Used for directbook and not needed in pr53/pr53 as per Brian Szymanski
        "payments-proxy-service", // Used for directbook and not needed in pr53/pr53 as per Brian Szymanski
        "Planner", // Lanyon is not in EU
        "postgres-data-archive-service", // Part of the data retention stack
        "Rate Audit Processor", // Lanyon is not in EU
        "Rate Availability Processor", // Lanyon is not in EU
        "Rate Integrity", // Lanyon is not in EU
        "Reports", // Lanyon is not in EU
        "Resdesk", // Lanyon is not in EU
        "Reverse Audit Processor", // Lanyon is not in EU
        "RLM", // Lanyon is not in EU
        "rdbms-obfuscation-service", // Part of the data retention stack
        "s3-data-archive-service", // Part of the data retention stack
        "SBD", // Lanyon is not in EU
        "Smart", // Lanyon is not in EU
        "survey-analytics", //Legacy survey is not in EU
        "survey-event-consumer-service", //Legacy survey is not in EU,
        "surveys-report-service", //Legacy survey is not in EU
        "sql-deploy", // Not to be running in DR
        "sql-server-data-archive-service", // Part of the data retention stack
        "starbirst-service",
        "Travel Portals - Web Site", // Lanyon is not in EU
    ]

    return blacklist[environmentName]
}
