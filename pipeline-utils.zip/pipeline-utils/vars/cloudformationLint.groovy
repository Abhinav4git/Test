import cvent.stash.Utils

/**
 * Should be run in a node that provides access to docker and linux.
 * E.g `label: 'linux && docker'`
 */
def call(pipelineArgs = [:]) {
  pipelineArgs = [
    template_glob: '**/template.yaml'
  ] + pipelineArgs

  def changes = Utils.getChanges()

  findFiles(glob: pipelineArgs['template_glob']).each {
    echo "Looking up ${it} in ${changes}"
    if (changes == null || changes.contains(it.path)) {
      lint_lines = docker.image('docker.cvent.net/cvent/cfn-lint').inside("--entrypoint=''") {
        return sh(returnStdout: true, script: "cfn-lint-cvent ${it.path} ||:")
      }.split("\n\n")

      def lint_errors = []

      lint_lines.each { lint_line ->
        def requirements = (lint_line =~ /requires? approval::(\w+)/).with { it.hasGroup() ? it.collect { it[1] } : [] }

        if (requirements.isEmpty()) {
          lint_errors += lint_line
        }

        requirements.each {
          if (env.CHANGE_TARGET && env.CHANGE_ID) {
            def approvalGroup = it
            if (approvalGroup == 'security') {
              approvalGroup = 'IT, Security Engineering'
            }

            echo "Adding comment to Pull Request for ${approvalGroup} because of:\n${lint_line}"
            Utils.commentOnPullRequest("require-approval::${approvalGroup}")
          }
        }
      }

      if (!lint_errors.isEmpty()) {
        echo lint_errors.join('\n')
        error "Lint Error"
      }
    }
  }
}
