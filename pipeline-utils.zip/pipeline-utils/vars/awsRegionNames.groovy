// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// awsRegionNames

static call() {
    List aws_region_names = [
        "us-east-1",
        "us-west-2",
        "eu-west-1",
        "eu-central-1"
    ]
    return aws_region_names
}