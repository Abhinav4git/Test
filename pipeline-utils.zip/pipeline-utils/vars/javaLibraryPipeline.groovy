// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// javaLibraryPipeline

import cvent.jenkins.GroovyUtils;
import cvent.slack.SlackUtils
import cvent.stash.Utils as StashUtils
import groovy.transform.Field

@Field def PIPELINE_WARNINGS = []

def runCheckout(String repo, String branch = 'master') {
  def tags = branch.startsWith('refs/tags/')

  checkout([
    $class                           : 'GitSCM',
    branches                         : [[name: branch]],
    doGenerateSubmoduleConfigurations: false,
    extensions                       : [
      [$class: 'CloneOption', depth: 0, noTags: !tags, reference: '', shallow: true],
      [$class: 'RelativeTargetDirectory', relativeTargetDir: repo]
    ],
    submoduleCfg                     : [],
    userRemoteConfigs                : [[url: "ssh://git@git.core.cvent.org:7999/stash/dep/${repo}.git"]]])
}

/**
 * Returns the first matching integration test environment based on the build branch
 */
def getIntegrationTestEnvironments(pipelineArgs, boolean build = true) {

  def envs = build ?
    pipelineArgs.integration_test.build.environments :
    pipelineArgs.integration_test.release.environments

  return envs instanceof String ? [ envs ] : envs
}

// Should integration tests be run for the build or release?
// (did someone defined the objects?)
boolean shouldRunIT(pipelineArgs, boolean build = true) {
  if (pipelineArgs.integration_test) {
    return build ?
      pipelineArgs.integration_test.build :
      pipelineArgs.integration_test.release
  }

  return false;
}

def runIntegrationTests(pipelineArgs, boolean build = true) {
  if (!shouldRunIT(pipelineArgs, build)) {
    return
  }

  runTimed 'integration-tests', {
    runMavenIntegrationTests environments: getIntegrationTestEnvironments(pipelineArgs, build)
  }
}

boolean isLastCommitMavenRelease() {
  return (env.git_last_commit_msg ==~ /^(?s)\[maven-release-plugin\].*/)
}

boolean isReleaseBranch(pipelineArgs) {
  def release = pipelineArgs.release
  def branches = release && release.branches ? release.branches : ['master']

  if (branches instanceof String) {
    branches = [branches]
  }

  // Always build release from master branches
  if (!branches.contains('master')) {
    branches.add('master')
  }

  return branches.any{env.BRANCH_NAME ==~ it}
}

// Is the release parameter set or is this the branch we run all releases off of?
boolean isReleaseExpected(pipelineArgs) {
  if (params.RELEASE) {
    return true
  }

  if (isReleaseBranch(pipelineArgs) && !StashUtils.changeSetContainsOnlyIgnoredFiles(pipelineArgs.ignoreFiles)
          && !isLastCommitMavenRelease()) {
    return true
  }

  return false
}

boolean isRelease(pipelineArgs) {
  return !isIncubating() && !isPR() && isReleaseExpected(pipelineArgs)
}

// Returns true if this pipeline will build a snapshot artifact
boolean isSnapshot(pipelineArgs) {
  return (!params.RELEASE && !isReleaseBranch(pipelineArgs) && !isLastCommitMavenRelease()
          && !StashUtils.changeSetContainsOnlyIgnoredFiles(pipelineArgs.ignoreFiles))
}

// Returns true if this is a snapshot or release build
boolean isSnapshotOrRelease(pipelineArgs) {
  return isSnapshot(pipelineArgs) || isRelease(pipelineArgs)
}

def isIncubating() {
  return sh(returnStdout: true, script: "git config --get remote.origin.url").trim().contains("/INCB/")
}

def isPR() {
  return env.BRANCH_NAME.startsWith('PR-')
}

def version(pipelineArgs) {
  // Snapshot version
  def snapshot_version = readMavenPom().getVersion()

  return isRelease(pipelineArgs) ? snapshot_version.split('-')[0] : snapshot_version
}

def notifySlack(channels) {
  branch = StashUtils.getBranch()
  git_url = sh(returnStdout: true, script: "git config --get remote.origin.url").trim()
  repo_id = StashUtils.getProjectSlashRepo(git_url)
  style = (currentBuild.currentResult == 'SUCCESS') ? '' : 'danger'

  fields = [
    [
      value: env.git_last_commit_msg
    ],
    [
      title: "Branch",
      value: branch,
      short: true
    ],
    [
      title: "Author",
      value: env.git_last_committer,
      short: true
    ],
    [
      title: "Version",
      value: "${env.artifact_version} (<${StashUtils.getChangelogUrl(git_url, branch)}|Changelog>)",
      short: true
    ],
    [
      title: "Commit",
      value: env.git_last_commit_short_hash,
      short: true
    ]
  ]

  actions = [
    [
      type : "button",
      text : "View Details",
      url  : env.BUILD_URL,
      style: style
    ],
    [
      type : "button",
      text : "Test Results",
      url  : "${env.BUILD_URL}testReport/",
      style: style
    ]
  ]

  if (env.CHANGE_URL) {
    actions.add([
      type : "button",
      text : "Pull Request",
      // slack will not show the action unless URL uses FQDN
      url  : env.CHANGE_URL.replace("/stash/", "/stash.cvent.net/"),
      style: style
    ])
  }

  attachments = [
    [
      pretext  : "*${repo_id}*",
      color    : (currentBuild.currentResult == 'SUCCESS') ? 'good' : 'danger',
      fallback : "${repo_id} build",
      fields   : fields,
      mrkdwn_in: ['pretext'],
      actions  : actions
    ]
  ]

  if (PIPELINE_WARNINGS) {
    attachments.add([
      color: "warning",
      text : PIPELINE_WARNINGS.join("\n")
    ])
  }

  SlackUtils.notifySlack(channels, [message: '', attachments: attachments])
}

def runMaven(pipelineArgs, boolean snapshot) {
  Closure buildMaven = {
    runTimed 'build', {
      if (snapshot) {
        PIPELINE_WARNINGS += buildMavenSnapshot coverage: pipelineArgs.coverage, runSonar: pipelineArgs.snapshot.sonar
      } else {
        PIPELINE_WARNINGS += buildMavenRelease coverage: pipelineArgs.coverage, runSonar: pipelineArgs.release.sonar
      }
    }
  }

  boolean checkmarx = false
  if (pipelineArgs.checkmarx && pipelineArgs.checkmarx.branch) {
    checkmarx = (env.BRANCH_NAME ==~ pipelineArgs.checkmarx.branch)
  }

  if (checkmarx) {
    parallel(
      'build': buildMaven,
      'checkmarx': {
        runTimed 'checkmarx', {
          try {
            runCheckmarx(pipelineArgs.checkmarx)
          } catch (Exception e) {
            logError 'Checkmarx run failed: ' + e.getMessage()
            e.printStackTrace()
          }
        }
      }
    )
  } else {
    buildMaven()
  }
}

def getGitUrl() {
  return env.GIT_URL ?: env.GIT_URL_1
}

// Arguments:
//  slack_channel - Slack channel which receives RELEASE build notifications. To disable notifications do not include
//    this option in the arguments map. You may also pass an array of channels
//  release.branches - Optional array which includes branch names or regular expressions to determine which branches
//    trigger release builds
//
def call(def pipelineArgs = [:]) {

  // This seems to happen when people leave the config block empty; if it was
  // left empty and groovy thought it was a collection, change it to a Map
  if (pipelineArgs instanceof Collection) {
    pipelineArgs = [:]
  }

  Map defaultConfig = [
    release: [
      sonar: true
    ],
    snapshot: [
      sonar: false
    ],
    coverage: 'clover'
  ]
  pipelineArgs = GroovyUtils.mergeMaps(defaultConfig, pipelineArgs)

  pipeline {
    agent { label 'linux && docker' }
    options {
      ansiColor('xterm')
      timestamps()
    }
    environment {
      // What artifact we are building
      artifact_id = readMavenPom().getArtifactId()

      // Get the last commit author so we can see if it's jenkins
      git_last_committer = sh(returnStdout: true, script: "git log -1 --pretty=format:'%an'").trim()
      // Get the last commit message so we can see if it was a maven release "[maven-release-plugin]"
      git_last_commit_msg = sh(returnStdout: true, script: "git log -1 --pretty=format:'%s'").trim()
      // Get the last commit sha so we can publish notifications with it
      git_last_commit_short_hash = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()

      // Store the artifact version from the start of the build
      // This allows us to publish notifications with the right version even after
      // the maven release prepare/perform has bumped to the next snapshot
      artifact_version = version(pipelineArgs)
      // Build branch (not PR branch name)
      PIPELINE_SRC_BRANCH_NAME = StashUtils.getBranch()
      // URL of GIT repository
      PIPELINE_GIT_URL = getGitUrl()
      // Get Module date
      PIPELINE_MODULES_TO_DEPLOY = readMavenPom().getModules().join(", ")
    }
    parameters {
      booleanParam(name: 'RELEASE',
        defaultValue: false,
        description: 'Should maven release this build?')

      string(name: 'HOGAN_CONFIGS_BRANCH',
        defaultValue: 'master',
        description: 'The branch to use for hogan-configs if your integration test config is going to be generated from hogan')
    }
    stages {
      stage('Print Environment') {
        steps {
          script {
            printEnvInfo()

            def displayName
            if (isSnapshotOrRelease(pipelineArgs)) {
              displayName = "${env.artifact_version}"
            } else if (isLastCommitMavenRelease()) {
              displayName = "No build: Maven release commit"
            } else if (isIncubating()) {
              displayName = "No build: repository is still incubating"
            } else if (isPR()) {
              displayName = "No build: PRs do not support releases"
            } else {
              displayName = "No build: Changeset contains only ignored files"
            }

            currentBuild.displayName = "#${env.BUILD_NUMBER} (${displayName})"
          }
        }
      }
      stage('Checkout') {
        when {
          beforeAgent true
          expression { isSnapshotOrRelease(pipelineArgs) && (shouldRunIT(pipelineArgs, true) || shouldRunIT(pipelineArgs, false)) }
        }
        steps {
          runTimed 'Checkout', {
            runCheckout('integration-tests-deploy')
            runCheckout('hogan-configs', params.HOGAN_CONFIGS_BRANCH ?: 'master')
          }
        }
      }
      stage('Build') {
        when {
          beforeAgent true
          expression { return isSnapshot(pipelineArgs) }
        }
        steps {
          script {
            runIntegrationTests(pipelineArgs, true)
            runMaven(pipelineArgs, true)
          }
        }
      }
      stage('Release') {
        when {
          beforeAgent true
          expression { return isRelease(pipelineArgs) }
        }
        steps {
          script {
            runIntegrationTests(pipelineArgs, false)
            runMaven(pipelineArgs, false)
          }
        }
        post {
          always {
            script {
              notifySlack(pipelineArgs['slack_channel'])
            }
          }
        }
      }
      stage('Nexus Lifecycle Scan'){
        when {
          beforeAgent true
          expression { isSnapshotOrRelease(pipelineArgs) && !env.CHANGE_TARGET }
        }
        steps {
          build job: 'dropwizard-service-iq-scan', parameters:[
            string(name: 'GIT_REPO', value: env.PIPELINE_GIT_URL),
            string(name: 'GIT_BRANCH', value: env.PIPELINE_SRC_BRANCH_NAME),
            string(name: 'artifactId', value: env.PIPELINE_MODULES_TO_DEPLOY)
          ],

          wait: false
        }
      }
    } // End stages
    post {
      always {
        script {
          PIPELINE_WARNINGS.each({ logWarn it })
        }
      }
    }
  }
}
