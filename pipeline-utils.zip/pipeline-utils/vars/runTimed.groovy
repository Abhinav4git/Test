#!/usr/bin/groovy

/**
 * runTimed
 *
 * Prints out a header with the specified name, runs the closure, and then prints out the number of seconds the
 * closure took to run.
 * @param name name to print
 * @param body closure to run
 */
def call(def name, Closure body) {
  def msg = [
    "",
    "**************************************************************************",
    "* ${name}",
    "**************************************************************************",
  ]
  logInfo msg.join("\n")

  long start = System.currentTimeMillis()
  try {
    body()
  } finally {
    def secs = (System.currentTimeMillis() - start) / 1000
    logInfo "${name} took ${secs} seconds"
  }
}
