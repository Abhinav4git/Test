// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// cventGuidesBuild
def call(String slackAlertChannel = '#guides-jenkins-alerts', String trunkBranch = 'pages') {
    pipeline {
        agent none
        options {
            ansiColor('xterm')
        }
        stages {
            stage ('Display Job Info') {
                agent {
                    docker {
                        image 'alpine:3.7'
                    }
                }
                steps {
                    printEnvInfo()
                }
            }
            stage ('Build') {
                agent {
                    docker {
                        image 'starefossen/ruby-node:2-8'
                        // UID is set automatically by the jenkins-pipeline
                        // Mount /etc/passwd so that we know it's the jenkins user
                        args '-v $HOME/.ssh:/home/jenkins/.ssh:ro -v /etc/passwd:/etc/passwd:ro'
                    }
                }
                steps {
                    sh './go setup'
                }
            }
            stage ('Release') {
                when {
                    branch trunkBranch
                }
                steps {
                    // https://guides.core.cvent.org/publish
                    // Docs on payload https://confluence.atlassian.com/bitbucketserver/post-service-webhook-for-bitbucket-server-776640367.html
                    // Endpoint source https://github.com/mbland/pages-server/blob/master/lib/webhooks/bitbucket.js
                    print 'TODO - hit the publish webhook'
                }
            }
        }
        post {
            failure {
                script {
                    if (env.BRANCH_NAME == trunkBranch) {
                        slackSend (channel: slackAlertChannel,
                                   color: 'danger',
                                   message: "FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' (${env.BUILD_URL})")
                    }
                }
            }
        }
    }
}
