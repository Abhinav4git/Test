// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// awsAccountNames

static call() {
    List aws_account_names = [
        "sandbox", // cvent-sandbox
        "development", // cvent-development
        "integration", // cvent-integration
        "production", // cvent-production
        "management", // cvent-management
        "core-app-prod", // core-app-prod
        "ecommerce-prod", //ecommerce-prod
        "ecommerce-dev", // ecommerce-dev
        "core-bt-dev", // core-bt-dev
        "core-passkey-dev", // core-passkey-dev
        "core-socialtables-prod", // core-socialtables-prod
        "core-socialtables-dev", // core-socialtables-dev
        "core-weddingspot-dev", // core-weddingspot-dev
        "core-weddingspot-prod", // core-weddingspot-prod
        "decision-street", //decision-street
        "conference-development" //conference-development
    ]
    return aws_account_names
}