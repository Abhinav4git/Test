import cvent.jenkins.BuildUtils;

/**
*  @param opts - A map consisting of:
*         account - The aws account to build in
*         region - Region where codebuild project is in
*         project - The name of the codebuild project to deploy
*         extra_args - A string containing any desired extra arguments to call
*           start-build with. Ref: https://docs.aws.amazon.com/cli/latest/reference/codebuild/start-build.html
*
*/
def call(opts = [:]) {
  pipeline {
    agent {
      docker {
        image 'cvent/aws-cli'
        reuseNode true
        args '--entrypoint=\'\''
      }
    }
    options {
      timestamps()
      ansiColor('xterm')
    }
    environment {
      JOB_NONCE = BuildUtils.getJobNonce()
    }
    stages {
      stage ('Update Job Execution') {
          when { changeRequest() }
          steps {
              script {
                  currentBuild.displayName += " (${JOB_NONCE})"
              }
          }
      }
      stage('Build'){
        stages {
          stage('CI') {
            when { changeRequest() }
            steps {
              script {
                account = opts['account'] ?: 'sandbox'
                region = opts['region'] ?: 'us-east-1'
                project = opts['project'][account]
                extra_args = opts['extra_args'] ?: ''

                withCredentials([[
                  $class: 'AmazonWebServicesCredentialsBinding',
                  credentialsId: "${account}-shared-jenkins"
                ]]) {
                  sh "aws --region ${region} codebuild start-build --project-name ${project} ${extra_args}"
                }
              }
            }
          }
          stage('PROD') {
            when { branch 'master' }
            steps {
              script {
                account = opts['account'] ?: 'cvent-management'
                region = opts['region'] ?: 'us-east-1'
                project = opts['project'][account]
                extra_args = opts['extra_args'] ?: ''

                withCredentials([[
                  $class: 'AmazonWebServicesCredentialsBinding',
                  credentialsId: "${account}-shared-jenkins"
                ]]) {
                  sh "aws --region ${region} codebuild start-build --project-name ${project} ${extra_args}"
                }
              }
            }
          }
        }
      }
    }
  }
}
