#!/usr/bin/groovy
import cvent.aws.CloudFormationUtils

/**
 * Runs the cloudformation deploy bash file for the list of stacks and parameter files passed.
 *
 * @param environments - one or more environments to run
 * @param verbose - if we are going to enable verbose logging
 *
 * Requires:
 * ssh://git@git.core.cvent.org:7999/stash/dep/deploy-aws-docker.git
 * ssh://git@git.core.cvent.org:7999/stash/dep/hogan-configs.git
 */
def call(Map config) {

    def cfTemplateFiles = CloudFormationUtils.getCloudformationStacksFromPom()
    // Save time for services which do not support cloudformation and ruturn
    if (!cfTemplateFiles) {
        return
    }

    validateConfig('runCloudformationDeploy', config, [
            ['environments', { !it.isEmpty() }, 'must provide at least one environment'],
            'verbose',
            'deploy'
    ])

    def verbose = config.get('verbose', false).toBoolean()
    def deploy = config.get('deploy', true).toBoolean()

    dir('deploy-aws-docker') {
        withSecrets {
            config.environments.each { environment ->
                def vars = [
                        BUILD_WORKSPACE             : "${env.WORKSPACE}",
                        AWS_ACCOUNT_NAME            : 'development',
                        AWS_REGION                  : 'us-east-1',
                        ENV                         : environment,
                        HOGAN_CONFIGS_DIR           : 'hogan-configs',
                        CF_PARAMETERS_DIR           : 'cloudformation/stacks/parameters',
                        CF_TEMPLATE_FILES           : cfTemplateFiles,
                        CF_ARTIFACT_ID              : 'cloudformation',
                        CF_DEPLOY                   : deploy,
                        VERBOSE                     : verbose ? '1' : '0',
                        GIT_COMMITER_EMAIL          : config.get('commiter', 'unknown')
                ]

                echo "Running cloudformation deploy for environment [${environment}]"

                withEnv(vars.collect { it.key + '=' + it.value }) {
                    sh "./cloudformation-deploy.sh"
                }
            }
        }
    }
}
