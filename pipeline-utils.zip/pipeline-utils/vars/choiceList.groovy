// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// choiceList

static call(List list) {
    return list.join("\n")
}