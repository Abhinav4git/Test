// prototypeBuildPipeline

import cvent.aws.AwsUtils;
import cvent.jenkins.BuildUtils;
import cvent.jenkins.FsUtils;
import cvent.jenkins.GroovyUtils;
import cvent.linters.CloudFormationLinter;
import cvent.aws.CdkManager;
import cvent.stash.Utils;
/*
 * Whether to publish artifact packages
 */
def shouldPublish(config) {
  def branch = GIT_BRANCH =~ config.publish.branches
  def forced = env.FORCE_PUBLISH == 'true'

  return branch || forced
}

/*
 * Whether we should cut a new 'release', or continue using pre-releases.
 */
def shouldRelease(config) {
  def branch = GIT_BRANCH =~ config.release.branches
  def forced = env.FORCE_RELEASE == 'true'

  return branch || forced
}

/*
 * Whether to push git changes back to the repository.
 */
def shouldContribute(config) {
  def branch = GIT_BRANCH =~ config.contribute.branches
  def forced = env.FORCE_CONTRIBUTE == 'true'

  return branch || forced
}

def runSpecMethod(config, specMap, methodName) {
  def methodContext = parallel FsUtils
    .glob(specMap.dir, specMap.specs)
    .collectEntries {
      GroovyUtils.specMethod(it, methodName, config)
    }

  config.context = GroovyUtils.mergeMaps(config.context, ["${methodName}": methodContext])

  echo "Context: ${config.context}"
}

def call(Map config) {
  def default_config = [
    apps: [
      [
        dir: 'apps',
        specs: [ '**/spec.groovy' ], // Globs
      ],
      [
        dir: 'cdk',
        specs: [ 'spec.groovy' ], // Globs
      ]
    ],
    ci: [
      isolation: true, // Set this to false if CI runs are not required to be fully isolated from each other
      teardown: true, // Set this to false if you do not want to teardown the CI env during each build
    ],
    slacks: [
      [ branches: /master/, channel: 'tech-release' ]
    ],
    release: [
      branches: /master/,
    ],
    publish: [
      branches: /master/,
    ],
    contribute: [
      branches: /master/,
    ],
    context: [:] // This is appended to later
  ]

  config = GroovyUtils.mergeMaps(default_config, config)

  pipeline {
    parameters {
      booleanParam(name: "FORCE_RELEASE", description: "Force the use of a release (non-snapshot) version number when generating any artifacts")
      booleanParam(name: "FORCE_PUBLISH", description: "Force any publishable artifacts to get published to relevant artifact stores")
      booleanParam(name: "FORCE_CONTRIBUTE", description: "Force changes to the git repository made by the build to be contributed back to the repository")
    }
    options {
      ansiColor('xterm')
      timestamps()
    }
    environment {
      // This doesn't use the Stash Utils class because we want to not have a top level executor defined
      // Having a top level executor would occupy a slot in jenkins while waiting for input
      JOB_NONCE = BuildUtils.getJobNonce()
    }
    agent {
      label 'jenkins-agent-cdk'
    }
    stages {
      stage ('Fail fast on commits from Jenkins') {
        when {
          allOf {
            anyOf {
              triggeredBy 'SCMTrigger'
              triggeredBy 'BranchEventCause'
            }
            not { changeRequest() }
          }
        }
        steps {
          script {
            def author = sh(returnStdout: true, script: 'git show -s --pretty=%an').trim()

            echo "Git Author: ${author}"

            if (author == 'Jenkins') {
              currentBuild.rawBuild.result = Result.ABORTED
              throw new hudson.AbortException("Commits from ${author} should not be built!")
            }
          }
        }
      }
      stage ('Display Job Info') {
        steps {
          printEnvInfo(config)
          // https://jira.cvent.com/browse/SRE-8115
          // Jenkins executors not properly configured to output unicode
          logInfo "Printing unicode"
          sh "printf '\\xE2\\x98\\xA0\\n'"
        }
      }
      stage('Verify Pre-commit Hooks') {
        options { ansiColor('xterm') }
        agent { label 'jenkins-agent-cdk' }
        when { expression { fileExists('.pre-commit-config.yaml') } }
        steps { precommit() }
      }
      stage('Bump Version') {
        steps {
          script {
            if (shouldRelease(config)) {
              sh 'standard-version'
            } else {
              sh "standard-version --prerelease=${GIT_BRANCH}"
            }

            config.version = sh(returnStdout: true, script: 'git describe --tags').drop(1).trim()
            env.VERSION = config.version

            config.timestamp = (new Date()).getTime()
            env.VERSION_TIMESTAMP = config.timestamp
          }
        }
      }
      stage ('Update Job Execution') {
        steps {
          script {
            currentBuild.displayName += " ${config.version} (${JOB_NONCE})"
          }
        }
      }
      stage ('Build') {
        steps {
          script {
            config.apps.each {
              runSpecMethod(config, it, 'build');
            }
          }
        }
      }
      // These are all in a single stage so they can be locked together
      stage ('CI') {
        when {
          changeRequest()
        }
        environment {
          REPO_ID = JOB_NAME.split("/").take(2).join('/')
        }
        steps {
          script {
            // Wrapped in a closure so that we can optionally lock the build below
            def runCi = {
              config.apps.each {
                runSpecMethod(config, it, 'ciSetup');
              }

              config.apps.each {
                runSpecMethod(config, it, 'ciTest');
              }

              // Optional Teardowns (in reverse order of setup)
              if (config.ci.teardown) {
                config.apps.reverse().each {
                  runSpecMethod(config, it, 'ciTeardown');
                }
              }
            }

            // Actually run the stage
            if (config.ci.isolation) {
              lock(resource: REPO_ID) { runCi.call() }
            } else {
              runCi.call()
            }
          }
        }
      }
      stage('Publish') {
        when { expression { shouldPublish(config) } }
        steps {
          script {
            config.apps.each {
              runSpecMethod(config, it, 'publish');
            }
          }
        }
      }
      stage('Contribute') {
        when { expression { shouldContribute(config) } }
        steps {
          sh "git push --follow-tags origin HEAD:${Utils.getBranch()}"
        }
      }
    }
  }
}
