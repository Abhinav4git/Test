// prototypeAwsCdkPipeline

import cvent.jenkins.BuildUtils
import cvent.jenkins.GroovyUtils
import cvent.slack.SlackUtils
import cvent.stash.Utils as StashUtils
import groovy.transform.Field

@Field def PIPELINE_ERRORS = []
@Field def PIPELINE_WARNINGS = []

boolean isLastCommitCdkPipelineJenkinsJob() {
  return (env.PIPELINE_GIT_LAST_COMMIT_MSG ==~ /^Jenkins:.*/)
}

boolean isReleaseBranch(pipelineArgs) {
  def release = pipelineArgs.release
  def branch = release && release.branch ? release.branch : []
  return env.BRANCH_NAME ==~ branch
}

// Returns true if this pipeline will build a release artifact
boolean isRelease(pipelineArgs) {
  // Never build release from a PR
  if (env.CHANGE_URL) {
    return false
  }

  // Let the user override building a release
  if (params.RELEASE) {
    return true
  }

  if (isReleaseBranch(pipelineArgs) && !StashUtils.changeSetContainsOnlyIgnoredFiles(pipelineArgs.ignoreFiles)) {
    return true
  }

  return false
}

/**
 * @return If building a PR then return the target branch otherwise return BRANCH_NAME
 */
def getTargetBranch() {
  return env.CHANGE_TARGET ?: env.BRANCH_NAME
}

def getGitUrl() {
  // GIT_URL when building a branch, GIT_URL_1 when building a PR
  return env.GIT_URL ?: env.GIT_URL_1
}

/**
 * Returns the first matching build based on the build branch
 */
def getAlphaPhase(pipelineArgs) {
  def builds = pipelineArgs.cdk.phases.alpha

  if (!builds) {
    echo "No builds found in the alpha phase"
    return []
  }
  echo "builds: ${builds}"
  def defaultBuildPhase = pipelineArgs.cdk.phases.alpha[0]

  for (build in builds) {
    echo "build: ${build}, build branch: ${build.branch}, targetBranch: ${getTargetBranch()}"
    if (build.branch == ".*") {
      defaultBuildPhase = build
    }
    if (getTargetBranch() ==~ build.branch) {
      return build
    }
  }

  echo "Default Phase Used: ${defaultBuildPhase}"
  return defaultBuildPhase
}

/**
 * Return the first slack configuration which matches the build branch
 * @param pipelineArgs
 * @return
 */
def findSlackConfig(pipelineArgs) {
  def slack = pipelineArgs.slack ?: []
  for (config in slack) {
    // For SOURCE branch type, use BRANCH_NAME for config branch matching, otherwise use target branch
    // BRANCH_NAME = `PR-xxx` for PR builds or actual branch name for non-PR builds
    def slackBranch = (config.branch_type == 'SOURCE') ? env.BRANCH_NAME : getTargetBranch()
    if (slackBranch ==~ config.branch) {
      return config
    }
  }
}

def getStack(pipelineArgs) {
  if (env.CHANGE_TARGET) {
    return ['ci']
  }
  if (params.PROD_DEPLOY) {
    return ['production']
  }
  if (env.PIPELINE_SRC_BRANCH_NAME == 'master') {
    return pipelineArgs.cdk.phases.staging.targets[0].stacks
  }
  def phase = getAlphaPhase(pipelineArgs)
  return phase.targets[0].stacks
}

/**
 * @param result 'START' or currentBuild.currentResult
 */
def notifySlack(pipelineArgs, result) {
  // if (!isSnapshotOrRelease(pipelineArgs)) {
  //   return
  // }

  def config = findSlackConfig(pipelineArgs)
  if (!config || !config.events.contains(result)) {
    return
  }

  def style = (result == 'SUCCESS' || result == 'START') ? 'good' : 'danger'

  def fields = [
    [
      value: env.PIPELINE_GIT_LAST_COMMIT_MSG
    ],
    [
      title: "Branch",
      value: env.PIPELINE_SRC_BRANCH_NAME,
      short: true
    ],
    [
      title: "Author",
      value: env.PIPELINE_GIT_LAST_COMMITTER,
      short: true
    ],
    [
      title: "Version",
      value: env.PIPELINE_ARTIFACT_VERSION,
      short: true
    ],
    [
      title: "Commit",
      value: env.PIPELINE_GIT_COMMIT,
      short: true
    ]
  ]
  def actions = [
    [
      type : "button",
      text : "View Details",
      url  : env.BUILD_URL,
      style: style
    ]
  ]

  if (result == 'SUCCESS') {
    def stack = getStack(pipelineArgs)
    if (stack) {
      fields.add([
        title: "Stack",
        value: stack.join(","),
        short: true
      ])
    }
  } else if (result == 'ABORTED' || result == 'FAILURE') {
    fields.add([
      title: "Build failed at step",
      value: env.PIPELINE_STAGE,
      short: false
    ])
  }

  if (result != 'START') {
    actions.add([
      type : "button",
      text : "Test Results",
      url  : "${env.BUILD_URL}testReport/",
      style: style
    ])
  }

  if (env.CHANGE_URL) {
    actions.add([
      type : "button",
      text : "Pull Request",
      // slack will not show the action unless URL uses FQDN
      url  : env.CHANGE_URL.replace("/stash/", "/stash.cvent.net/"),
      style: style
    ])
  }

  def attachments = [
    [
      pretext  : "*${env.PIPELINE_REPO_ID}* - ${result}",
      color    : style,
      fallback : "${env.PIPELINE_REPO_ID} build",
      fields   : fields,
      mrkdwn_in: ['pretext'],
      actions  : actions
    ]
  ]

  if (PIPELINE_WARNINGS) {
    attachments.add([
      color: "warning",
      text : PIPELINE_WARNINGS.join("\n")
    ])
  }

  if (params.PROD_DEPLOY) {
    SlackUtils.notifySlack(['tech-release'], [message: '', attachments: attachments])
  } else {
    def channels = SlackUtils.transformSlackChannel(config.channel)
    if (channels) {
      SlackUtils.notifySlack(channels, [message: '', attachments: attachments])
    }
  }
}

/*
 * Args - See `default_config` below
 *
 * Improvements that can/should be made
 * - Extract reused components into helper functions
 * - Pull and parse scurity diff from cdk to check for changes that
 *   - It's on their radar https://github.com/awslabs/aws-cdk/issues/978#issuecomment-439965431
 *   - TODO file an issue with the project to surface that requirement
 * - Multiple environments per account (e.g. ci/alpha/staging in development account)
 *   - To implement this we need some standard way to pass an environment name into
 *     the cdk execution environment
 * - Shift docker definition down to a level lower than the input so that we don't
 *   consume an executor slot while waiting for user input
 * - Add some notifications
 *   - Success/failure slack
 *   - Input needed slack
 */
def call(Map pipelineArgs) {
    def default_config = [
        lints: [],
        builds: [
              // [path: '', builder: '']
              // [path: '', builder: '', branch: 'silo457.*', environments: [ 'S457', 'S531'] ]
        ],
        app: [
            dir: 'app'
        ],
        cdk: [
            dir: 'cdk',
            releaseCommand: '',
            snapshotCommand: '',
            phases: [
                ci: [
                    targets: [
                        // `entrypoint` is the only required key in these maps
                        [entrypoint: 'bin/ci.ts', stacks: [], args: '', tests: [
                            [dir: '.', command: '']
                        ]]
                    ]
                ],
                alpha: [
                    // this is the only section that allows specific branch deploys
                    // you can override this section using pipelineArgs
                    [
                      // git branch to filter on
                      branch: '.*',
                      // targets specify the entrypoint and the stacks you want to deploy
                      targets: [
                          [entrypoint: 'bin/alpha.ts', stacks: [], args: '', tests: [
                              [dir: '.', command: '']
                          ]]
                      ]
                    ]
                ],
                staging: [
                    targets: [
                        [entrypoint: 'bin/staging.ts', stacks: [], args: '', tests: [
                            [dir: '.', command: '']
                        ]]
                    ]
                ],
                integration: [
                    targets: [
                        [entrypoint: 'bin/integration.ts', stacks: [], args: '', tests: [
                            [dir: '.', command: '']
                        ]]
                    ]
                ],
                production: [
                    targets: [
                        [entrypoint: 'bin/production.ts', stacks: [], args: '', tests: [
                            [dir: '.', command: '']
                        ]]
                    ]
                ]
            ]
        ]
    ]

    pipelineArgs = GroovyUtils.mergeMaps(default_config, pipelineArgs)

    pipeline {
        parameters {
            string(name: 'Entrypoint', defaultValue: '', description: 'The entrypoint to use for a custom deployment')
            text(name: 'Stacks', defaultValue: '', description: 'The stacks to use for a custom deployment (one per line)')
            string(name: 'Extra CDK Args', defaultValue: '', description: 'Any extra args to use for a custom deployment')
            booleanParam(name: 'RELEASE',
                defaultValue: false,
                description: 'Release this build? (This command only works on the master branch, this creates a git tag if cdk.releaseCommand is specified that can be used for production deployment.)')
            booleanParam(name: 'DRYRUN',
                defaultValue: false,
                description: 'Dry run the build instead of actually performing the deployments.')
            booleanParam(name: 'PROD_DEPLOY',
                defaultValue: false,
                description: 'Deploy to 🚨🚨🚨PRODUCTION🚨🚨🚨? (This command only works on git release tags or master if the RELEASE parameter is build.)')
        }
        options {
            ansiColor('xterm')
            timeout(time: 1, unit: 'HOURS')
            timestamps()
        }
        environment {
            // This doesn't use the Stash Utils class because we want to not have a top level executor defined
            // Having a top level executor would occupy a slot in jenkins while waiting for input
            REPO_ID = JOB_NAME.split("/").take(2).join('/')
            JOB_NONCE = BuildUtils.getJobNonce()
            // Build branch (not PR branch name)
            PIPELINE_SRC_BRANCH_NAME = StashUtils.getBranch()
            // URL of GIT repository
            PIPELINE_GIT_URL = getGitUrl()
            // Unique identifier of repo
            PIPELINE_REPO_ID = StashUtils.getProjectSlashRepo(getGitUrl())
            // Get the last commit hash
            PIPELINE_GIT_COMMIT = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()
            // Get the last commit author so we can see if it's jenkins
            PIPELINE_GIT_LAST_COMMITTER = sh(returnStdout: true, script: "git log -1 --pretty=format:'%an'").trim()
            // Get the last commit message so we can see if it was a maven release "[maven-release-plugin]"
            PIPELINE_GIT_LAST_COMMIT_MSG = sh(returnStdout: true, script: "git log -1 --pretty=format:'%s'").trim()
            // Get the email address for the last commiter; used to tag stacks if needed
            PIPELINE_GIT_LAST_COMMITTER_EMAIL = sh(returnStdout: true, script: "git log -1 --pretty=format:'%ae'").trim()
        }
        agent {
            label 'jenkins-agent-cdk'
        }
        stages {
            stage ('Update Job Execution') {
                when { changeRequest() }
                steps {
                    script {
                        currentBuild.displayName += " (${JOB_NONCE})"
                    }
                }
            }
            stage ('Display Job Info') {
                steps {
                    printEnvInfo(pipelineArgs)
                    // https://jira.cvent.com/browse/SRE-8115
                    // Jenkins executors not properly configured to output unicode
                    logInfo "Printing unicode"
                    sh "printf '\\xE2\\x98\\xA0\\n'"
                    script {
                        notifySlack(pipelineArgs, 'START')
                    }
                }
            }
            stage ('Build Apps') {
                when { expression { fileExists(pipelineArgs.app.dir) } }
                steps {
                    dir(path: pipelineArgs.app.dir) {
                        script {
                            logInfo "Reading directories inside ${pipelineArgs.app.dir}";
                            findFiles().each {
                                if (it.directory) {
                                    dir(it.name) {
                                        if (fileExists('package.json')) {
                                            script {
                                                logInfo "Building application in ${it.name}"
                                                def scripts = readJSON([file: './package.json']).scripts ?: [:]
                                                def runScript = { String name ->
                                                    if (scripts.containsKey(name)) sh "yarn ${name}"
                                                }
                                                sh 'yarn install --frozen-lockfile'
                                                runScript('lint')
                                                runScript('build')
                                                runScript('test')
                                                runScript('release')
                                                runScript('dist')
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            stage ('Prepare CDK') {
                steps {
                    dir(path: pipelineArgs.cdk.dir) {
                        sh 'yarn install'
                        sh 'yarn lint'
                        sh 'yarn build'
                        sh 'yarn test'
                    }
                }
            }
            // TODO shift this down to build so we can stash/unstash and not have an executor waiting on the input
            stage ('CI') {
                when { changeRequest() }
                steps {
                    script {
                        lock(resource: REPO_ID, inversePrecedence: true) {
                            def phase = pipelineArgs.cdk.phases.ci
                            dir(path: pipelineArgs.cdk.dir) {
                                cdk(phase.targets, { manager ->
                                    // Require lint exception approvals
                                    manager.linter.requireLintExceptionApprovals({
                                        dir(path: 'cdk.out') {
                                            deleteDir()
                                        }

                                        if (!manager.enabled()) {
                                            return false
                                        }

                                        sh 'yarn install'
                                        manager.synthesize()
                                    })

                                    manager.deploy(false, params['DRYRUN'])
                                })
                            }

                            echo "Running ITs for ci"
                            phase.targets.each { target ->
                                if (target.tests != null) {
                                    target.tests.each {
                                        // if directory is not defined, use current dir
                                        def testDir = '.'
                                        if (it.dir != null) {
                                            testDir = it.dir
                                        }
                                        dir(path: testDir) {
                                            sh it.command
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            stage ('Alpha') {
                when { allOf {
                  not { branch 'master' }
                  not { buildingTag() }
                  not { changeRequest() }
                } }
                steps {
                    script {
                        // Acquire the lock to terminate earlier jobs
                        // inversePrecedence allows the latest build of a branch to start execution first
                        // which leads to the latest code being applied
                        lock(resource: REPO_ID, inversePrecedence: true) {
                            echo "Running cdk deploy"
                            def phase = getAlphaPhase(pipelineArgs)
                            echo "phase ${phase}"
                            dir(path: pipelineArgs.cdk.dir) {
                                cdk(phase.targets, { manager ->
                                    manager.deploy(false, params['DRYRUN'])
                                })
                            }
                            echo "Running ITs for alpha"
                            phase.targets.each { target ->
                                if (target.tests != null) {
                                    target.tests.each {
                                        // if directory is not defined, use current dir
                                        def testDir = '.'
                                        if (it.dir != null) {
                                            testDir = it.dir
                                        }
                                        dir(path: testDir) {
                                            sh it.command
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            stage ('Master') {
                when {
                  allOf {
                    branch 'master'
                    expression { return !isLastCommitCdkPipelineJenkinsJob() || params['RELEASE'] }
                  }
                }
                stages {
                    stage ('Cut Release') {
                      when {
                        allOf {
                            expression { return pipelineArgs.cdk.releaseCommand }
                            expression { return params['RELEASE'] }
                        }
                      }
                      steps {
                        script {
                          dir(path: pipelineArgs.cdk.dir) {
                              sh pipelineArgs.cdk.releaseCommand
                          }
                          sh "git add -u"
                          sh "git commit -m \"Jenkins: Released AWS-CDK ${env.PIPELINE_REPO_ID}\""
                          sh "git push origin ${env.PIPELINE_SRC_BRANCH_NAME}"
                          sh "git tag -a release-${env.BUILD_NUMBER} -m \"Releasing AWS-CDK ${env.PIPELINE_REPO_ID} build number ${env.BUILD_NUMBER}\""
                          sh "git push --tags"
                        }
                      }
                    }
                    stage ('Custom') {
                        when { expression { return params['Entrypoint'] } }
                        stages {
                            stage ('Deploy') {
                                steps {
                                    dir(path: pipelineArgs.cdk.dir) {
                                        script {
                                            // Acquire the lock to terminate earlier jobs
                                            // inversePrecedence allows the latest build of a branch to start execution first
                                            // which leads to the latest code being applied
                                            lock(resource: REPO_ID, inversePrecedence: true) {
                                                def target = [
                                                    entrypoint: params['Entrypoint'],
                                                    stacks: params['Stacks'].readLines(),
                                                    args: params['Extra CDK Args']
                                                ]

                                                cdk([target], { manager ->
                                                    manager.deploy(false, params['DRYRUN'])
                                                })
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    stage ('Staging') {
                        when { not { expression { return params['Entrypoint'] } } }
                        steps {
                            script {
                                // Acquire the lock to terminate earlier jobs
                                // inversePrecedence allows the latest build of a branch to start execution first
                                // which leads to the latest code being applied
                                lock(resource: REPO_ID, inversePrecedence: true) {
                                    def phase = pipelineArgs.cdk.phases.staging
                                    dir(path: pipelineArgs.cdk.dir) {
                                        // Set the milestone. All pipelines that are executing before this will be aborted if they reach this stage
                                        // This keeps earlier commits from overriding later commits
                                        // TODO oridinal should be optional
                                        // according to https://jenkins.io/doc/pipeline/steps/pipeline-milestone-step/
                                        milestone(ordinal: 1, label: "Deploy to Staging")

                                        cdk(phase.targets, { manager ->
                                            manager.deploy(false, params['DRYRUN'])
                                        })
                                    }
                                    echo "Running ITs for staging"
                                    phase.targets.each { target ->
                                        if (target.tests != null) {
                                            target.tests.each {
                                                // if directory is not defined, use current dir
                                                def testDir = '.'
                                                if (it.dir != null) {
                                                    testDir = it.dir
                                                }
                                                dir(path: testDir) {
                                                    sh it.command
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    stage ('Integration') {
                        when { not { expression { return params['Entrypoint'] } } }
                        steps {
                            script {
                                // Acquire the lock to terminate earlier jobs
                                // inversePrecedence allows the latest build of a branch to start execution first
                                // which leads to the latest code being applied
                                lock(resource: REPO_ID, inversePrecedence: true) {
                                    def phase = pipelineArgs.cdk.phases.integration
                                    dir(path: pipelineArgs.cdk.dir) {
                                        // Set the milestone. All pipelines that are executing before this will be aborted if they reach this stage
                                        // This keeps earlier commits from overriding later commits
                                        // TODO oridinal should be optional
                                        // according to https://jenkins.io/doc/pipeline/steps/pipeline-milestone-step/
                                        milestone(ordinal: 2, label: "Deploy to Integration")

                                        cdk(phase.targets, { manager ->
                                            manager.deploy(true, params['DRYRUN'])
                                        })
                                    }
                                    echo "Running ITs for integration"
                                    phase.targets.each { target ->
                                        if (target.tests != null) {
                                            target.tests.each {
                                                // if directory is not defined, use current dir
                                                def testDir = '.'
                                                if (it.dir != null) {
                                                    testDir = it.dir
                                                }
                                                dir(path: testDir) {
                                                    sh it.command
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    stage ('Bump to next snapshot') {
                      when {
                        allOf {
                            expression { return pipelineArgs.cdk.snapshotCommand }
                            expression { return params['RELEASE'] }
                        }
                      }
                      steps {
                        script {
                          dir(path: pipelineArgs.cdk.dir) {
                              sh pipelineArgs.cdk.snapshotCommand
                          }
                          sh "git add -u"
                          sh "git commit -m \"Jenkins: Prepare SNAPSHOT for next AWS-CDK ${env.PIPELINE_REPO_ID} release.\""
                          sh "git push origin ${env.PIPELINE_SRC_BRANCH_NAME}"
                        }
                      }
                    }
                }
            }
            stage ('Production Release') {
              when {
                allOf {
                  anyOf {
                    tag 'release*'
                    allOf {
                        branch 'master'
                        expression { return !isLastCommitCdkPipelineJenkinsJob() }
                        expression { return pipelineArgs.cdk.releaseCommand }
                        expression { return params['RELEASE'] }
                    }
                  }
                  not { expression { return params['Entrypoint'] } }
                  expression { return params['PROD_DEPLOY'] }
                }
              }
              steps {
                  script {
                      // Acquire the lock to terminate earlier jobs
                      // inversePrecedence allows the latest build of a branch to start execution first
                      // which leads to the latest code being applied
                      lock(resource: REPO_ID, inversePrecedence: true) {
                          def phase = pipelineArgs.cdk.phases.production
                          dir(path: pipelineArgs.cdk.dir) {
                              // Set the milestone. All pipelines that are executing before this will be aborted if they reach this stage
                              // This keeps earlier commits from overriding later commits
                              // TODO oridinal should be optional
                              // according to https://jenkins.io/doc/pipeline/steps/pipeline-milestone-step/
                              milestone(ordinal: 3, label: "Deploy to Production")

                              cdk(phase.targets, { manager ->
                                  // Make sure this is always true. Switching it to false will now bypass the prompt, even for prod
                                  manager.deploy(true, params['DRYRUN'])
                              })
                          }
                          echo "Running ITs for production"
                          phase.targets.each { target ->
                              if (target.tests != null) {
                                  target.tests.each {
                                      // if directory is not defined, use current dir
                                      def testDir = '.'
                                      if (it.dir != null) {
                                          testDir = it.dir
                                      }
                                      dir(path: testDir) {
                                          sh it.command
                                      }
                                  }
                              }
                          }

                      }
                  }
              }
          }
        }
        post {
            always {
                echo 'finished'
                script {
                    notifySlack(pipelineArgs, currentBuild.currentResult)
                }
            }
            failure {
                echo 'failed'
            }
            success {
                echo 'success'
            }
        }
    }
}