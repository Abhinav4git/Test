import groovy.transform.Field
import java.text.SimpleDateFormat

@Field String stashMirror = 'ssh://git@git.crwd.cc:7999/stash/cc/'
@Field String stashSSH = 'ssh://git@stash.cvent.net:7999/cc/'
@Field String awsAccount = '748599846571'
@Field String bucket = 'vfeatures'
@Field String credentials_id='cc-vfeatures-upper'

//Cuts Release Branch
def cutReleaseBranch(project,version) {
  sh "git clone ${stashMirror}${project} repo-${project} --depth 1"
  sh "git --git-dir repo-${project}/.git push origin origin/master:refs/heads/release-${version}"
}

//creates a vfeatures tag using the current date
def createFeaturesTag() {
  def date = sh (returnStdout:true, script: "date +%Y%m%d").trim()
  featureTag = "${date}00"
  println "Feature Tag Created: ${featureTag}"
  return featureTag
}

//displays current vfeatures tag for a silo
def getEnvironmentVersion(silo) {
  def currentVersion = sh (returnStdout:true, script: "head -n 1 envs/${silo}/version").trim()
  return "${currentVersion}"
}

def getVersionFeatureTag(version) {
  def featureTag = sh (returnStdout:true, script: "head -n 1 versions/${version}").trim()
  return "${featureTag}"
}

//Links vfeatures tag with release version
def linkVersionToFeaturesTag(vfeaturestag,version) {
  writeFile file:"versions/${version}", text:"${vfeaturestag}"
  sh "git add versions/${version}"
  try {
    sh "git commit -m \"Version ${version} set to ${vfeaturestag}\""
  } catch(error) {
   println "${version} already exists. Proceeding..."
  }
  sh "git push origin master"
}

//  update the environment version
def updateEnvironmentVersion(silo, version) {
  sh "mkdir -p envs/${silo}"
  writeFile file:"envs/${silo}/version", text:"${version}"
}

// uploads current marketing version for a silo to stash
def setEnvironmentVersion(silo,version) {
  sh "git clean -fd"
  updateEnvironmentVersion(silo, version)

  sh "git add envs/${silo}"
  sh "git diff-index --quiet HEAD || git commit -m \"Setting ${silo} to version ${version}\""
  sh "git push"
}

//updates vfeatures S3 bucket/silo with specific vfeatures.json based on a version
def uploadVersion(silo,version) {
  ccDocker.buildScriptv2("vfeatures-${version}-generate",silo,"/usr/local/bin/generate_vfeatures_version.sh",'master',"Dockerfile","-e RELEASE_VERSION=${version}")
  withAWS(roleAccount:"${awsAccount}",credentials:"${credentials_id}") {
    s3Upload(file:"vfeatures-${silo}.json", bucket:"${bucket}", path:"${silo}/vfeatures.json")
  }
}

//creates a new vfeatures tag and links it with a release version
//checks out a new release branch and submits a PR
//teams are responsible for updating the PR to denote what features will ship
//creates a new vfeatures tag and links it with a release version
//checks out a new release branch and submits a PR
//teams are responsible for updating the PR to denote what features will ship
def createPR() {
  helpers.checkoutStash("releases")
  today = sh (script: "date +%Y%m%d",returnStdout: true).trim()
  dir('versions') {
    currentVersion = sh (script: '#!/bin/sh -e\n' + "ls * | sort -rV | tail -n +2 | head -1",returnStdout: true).trim().take(4)

    //gets the newest active version excluding hotfixes
    println("Found version: ${currentVersion}")
    currentVersionDate = sh (script: "cat ${currentVersion}",returnStdout: true).trim().take(8)
    currentVersionTag = "${currentVersionDate}00"

    //vfeatures date tag attached to that version
    //equates to the monday before the vfeatures date tag
    //this is the day we wish to create a new version and create a PR for the feature set
    println("Found vfeatures tag: ${currentVersionDate}")
    triggerDate = sh (script: "date -d \"${currentVersionDate} -2 days\" \"+%Y%m%d\"",returnStdout: true).trim()

    if ("${triggerDate}" == "${today}") {
      results = currentVersion.tokenize('.')
      def smallVer = results[1].toInteger()
      smallVer++
      newVersion = "${results[0]}.${smallVer}"

      //separates the version into two integers, iterates the second integer
      //e.g. 5.40 becomes 5 and 40, we iterate on the second to make 41
      println("New version: ${newVersion}")
      newVersionDate = sh (script: "date -d \"${currentVersionDate} +3 weeks\" \"+%Y%m%d\"",returnStdout: true).trim()

      //create a new vfeatures date tag that is 3 weeks from the last vfeatures date tag
      newVersionTag = "${newVersionDate}00"
      println("New vfeatures tag: ${newVersionTag}")
      writeFile file:"${newVersion}", text:"${newVersionTag}"

      //uses the stash API to create a new PR
      try {
        sh "git reset --hard origin/master"
        sh "git checkout -b features-${currentVersion}"
        sh "git add ${newVersion}"
        sh "git commit -m \"Pull request for features-${currentVersion}\""
        sh "git push --set-upstream origin features-${currentVersion}"
      } catch (error) {
        println "A branch named features-${currentVersion} already exists."
      }
      def title="Feature flags for version ${currentVersion} ${currentVersionTag}"

      def descriptorP1="Feature flag changes for:\n"
      def descriptorP2="- version `${currentVersion}` (`${currentVersionTag}`) promoted to `Staging`\n"
      def descriptorP3="- version `${newVersion}` (`${newVersionTag}`) created and deployed to `QA`\n"
      def descriptorP4="These changes are coincident with the *creation* of the release-`${currentVersion}` branch in each muservices repo; until the merging of the next one of these PRs, the branch for `${newVersion}` in QA will be master.\n"
      def descriptorP5="The vfeatures tag suffix 00 indicates that this is a major release version."
      def description="${descriptorP1}${descriptorP2}${descriptorP3}${descriptorP4}${descriptorP5}"
      def fromRef="refs/heads/features-${currentVersion}"
      def toRef="refs/heads/master"
      def slug="releases"
      helpers.stashPullRequest(title,description,fromRef,toRef,slug)
      return currentVersion //return new version created if triggerDate was met
    }
    else {
      return null //return nothing if triggerDate was not met
    }
  }
}
