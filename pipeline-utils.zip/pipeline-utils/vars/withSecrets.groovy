
/**
 * withSecrets
 *
 * Runs a closure within the AWS parameter store containing our secrets
 * @param body closure to run within the AWS parameter store
 */
def call(Closure body) {
  Map config = [
    credentialsId: 'cvent-management-shared-jenkins',
    namePrefixes : '',
    naming       : 'basename',
    path         : '/jenkins/secrets',
    recursive    : true,
    regionName   : 'us-east-1',
    hideSecureStrings: true
  ]

  withAWSParameterStore(config) {
    body()
  }
}
