def call(args = [:]) {
  String APPLICATION = args['application']

  pipeline {
    agent {
      label 'redhat'
    }
    parameters {
      string(name: 'branch', defaultValue: 'master', description: 'git target (branch, sha, tag)')
      string(name: 'silo', defaultValue: 'qa', description: 'silo name')
    }
    options { timestamps() }

    environment {
      DOCKER_BUILDKIT = '1'
      VAULT_TOKEN = credentials('VAULT_TOKEN')
    }

    stages {
      stage ('Build ember docker container') {
        steps {
          sh "docker-compose --file docker-compose.deployment.yml build --build-arg vault_token=${env.VAULT_TOKEN} --build-arg cc_environment=${params.silo} ember"
        }
      }
      stage ('Deploy ember docker container') {
        steps {
          sh "docker-compose --file docker-compose.deployment.yml run --rm ember yarn deploy:verbose ${params.silo}"
        }
      }
    }
    post {
      success {
        script {
          ccNotify.notifyDataDog(APPLICATION, params.silo, params.branch, "Deployed ${APPLICATION} artifact ${params.branch} to ${params.silo}", env.USER);

          ccNotify.slackMessageDetail(params.silo,'good',"SUCCESS: ${env.JOB_NAME.toUpperCase()} #${env.BUILD_NUMBER}","<${env.BUILD_URL}|Silo: ${params.silo.toUpperCase()} Target: ${params.branch} SHA: ${env.GIT_COMMIT}>")
          if (params.branch == "master") {
            build job: 'checkmarxScan', wait: false, parameters: [
              [$class: 'StringParameterValue', name: 'repo', value: APPLICATION],
              [$class: 'StringParameterValue', name: 'target', value: 'master'],
              [$class: 'StringParameterValue', name: 'type', value: 'web']
            ]
          }
        }
      }
      failure {
        script {
          ccNotify.slackMessageDetail(params.silo,'bad',"FAILED: ${env.JOB_NAME.toUpperCase()} #${env.BUILD_NUMBER}","<${env.BUILD_URL}|Silo: ${params.silo.toUpperCase()} Target: ${params.branch} SHA: ${env.GIT_COMMIT}>")
        }
      }
    }
  }
}
