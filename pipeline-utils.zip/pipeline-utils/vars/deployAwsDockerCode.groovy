// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// deployAwsDockerCode

def call(boolean beta, String build_deploy_branch, String environment) {

    build_deploy_branch_to_use = deployAwsDockerTag(beta, build_deploy_branch, environment)

    logInfo("Using branch ${build_deploy_branch_to_use}")

    checkout([
        $class: "GitSCM",
        branches: [[
            name: "${build_deploy_branch_to_use}"
        ]],
        doGenerateSubmoduleConfigurations: false,
        extensions: [[
            $class: "CloneOption",
            noTags: false,
            reference: "",
            shallow: true
        ]],
        gitTool: "Default",
        submoduleCfg: [],
        userRemoteConfigs: [[
            credentialsId: "e01b632a-4bb4-446b-9d93-793565f2293f",
            url: "ssh://git@stash:7999/dep/deploy-aws-docker.git"
        ]]
    ])
}

