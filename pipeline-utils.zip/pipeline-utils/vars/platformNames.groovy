// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// platformNames

static call() {
    List platform_names = [
        "dropwizard",
        "node",
        "cc",
        "basic"
    ]
    return platform_names
}