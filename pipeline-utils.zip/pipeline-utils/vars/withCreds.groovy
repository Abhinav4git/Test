/**
 * withCredentials
 *
 * Runs a closure within the AWS parameter store containing our secrets
 * @param body closure to run within the AWS parameter store
 */
def call(String aws_account_name, Closure body) {
    List config = [[
        $class: "AmazonWebServicesCredentialsBinding",
        credentialsId: aws_account_name
    ]]

    withCredentials(config) {
        body()
    }
}