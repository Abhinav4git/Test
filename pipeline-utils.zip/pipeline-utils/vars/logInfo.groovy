// logInfo - Prints a green INFO message
def call(message) {
  echo "\033[38;5;28mINFO: ${message}\033[38;5;0m"
}
