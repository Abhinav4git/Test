import groovy.transform.Field

@Field String gpsTag = 'GOLD'


def runGPS(command) {
  sh "docker pull ${ccDocker.registry}/ccops/gps:${gpsTag}"
  sh (script:"docker run -i --rm ${ccDocker.registry}/ccops/gps:${gpsTag} ${command}", returnStdout: true)
}
