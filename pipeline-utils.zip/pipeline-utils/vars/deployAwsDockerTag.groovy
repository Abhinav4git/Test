// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// deployAwsDockerTag

String call(boolean beta, String build_deploy_branch, String environment) {

    if (build_deploy_branch == "") {
        if (beta) {
            return "refs/tags/beta"
        } else if (environment == "staging" || environment == "sg50" || environment == "S820") {
            return "refs/tags/staging"
        } else if (isProductionEnvironment(environment)) {
            return "refs/tags/prod"
        } else {
            return "refs/tags/dev"
        }
    } else {
        return build_deploy_branch
    }
}
