#!/usr/bin/groovy

/**
 * liquibase
 *
 * Runs liquibase database migration for dropwizard services.
 * @param environments environments to migrate
 * @param groupId Maven group ID
 * @param artifactIds List of artifact IDs which contain the dropwizard liquibase bundles
 * @param version artifact version
 *
 * Requires:
 * ssh://git@git.core.cvent.org:7999/stash/dep/hogan-configs.git
 * ssh://git@git.core.cvent.org:7999/stash/dep/liquibase-deploy.git
 */
def call(Map config) {

    validateConfig('liquibase', config, [
        ['artifactIds', { !it.isEmpty() }, 'No artifacts specified'],
        ['environments', { !it.isEmpty() }, 'must provide at least one environment'],
        'groupId',
        'version'
    ])

    // Save time for services which do not support liquibase
    def found = config.artifactIds.any { fileExists("${it}/configs/template-liquibase.yaml") }
    if (!found) {
        return
    }

    def deploys = config.environments.collectEntries() {
        [ ("liquibase-" + it): { -> migrate(config, it) } ]
    }
    parallel deploys
}

def migrate(Map config, String environment) {
    dir('liquibase-deploy') {
        withSecrets {
            config.artifactIds.each { artifactId ->
                def vars = [
                    ARTIFACT_ID      : artifactId,
                    ENVIRONMENT      : environment,
                    GROUP_ID         : config.groupId,
                    HOGAN_CONFIGS_DIR: "${env.WORKSPACE}/hogan-configs",
                    VERSION          : config.version,
                    BUILD_WORKSPACE  : env.WORKSPACE
                ]

                logInfo "Running liquibase migration for environment [${environment}]"

                withEnv(vars.collect { it.key + '=' + it.value }) {
                    sh "./migrate.sh"
                }
            }
        }
    }
}