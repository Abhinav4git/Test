// logError - Prints a red ERROR message
def call(message) {
  echo "\033[38;5;124mERROR: ${message}\033[38;5;0m"
}
