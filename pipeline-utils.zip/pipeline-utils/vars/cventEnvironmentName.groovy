// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// cventEnvironmentName

static formatAws(String awsAccountName, String awsRegionName) {
    return [ "awsAccountName": awsAccountName, "awsRegionName": awsRegionName ]
}

static call(String cventEnvironmentName) {
    Map cventEnvironments = [
        "alpha": formatAws("cvent-development", "us-east-1"),
        "ci": formatAws("cvent-development", "us-east-1"),
        "ct50": formatAws("cvent-integration", "us-east-1"),
        "ep53": formatAws("ecommerce-prod", "eu-west-1"),
        "ep54": formatAws("ecommerce-prod", "eu-central-1"),
        "pr50": formatAws("cvent-production", "us-east-1"),
        "pr51": formatAws("cvent-production", "us-west-2"),
        "pr53": formatAws("core-app-prod", "eu-west-1"),
        "pr54": formatAws("core-app-prod", "eu-central-1"),
        "sg50": formatAws("cvent-development", "us-east-1"),
    ]

    return cventEnvironments[cventEnvironmentName]
}
