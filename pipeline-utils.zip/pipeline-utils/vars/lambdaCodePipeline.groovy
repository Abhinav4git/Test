// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// lambdaCodePipeline

import cvent.aws.AwsUtils

def call(def args = [:]) {
  pipeline {
    agent {
      label 'linux && docker'
    }
    options {
      ansiColor('xterm')
      timestamps()
    }
    stages {
      stage('Build') {
        steps {
          script {
            parallel findFiles().collectEntries {
              [(it.name): {
                if (it.directory) {
                  dir(it.name) {
                    if (fileExists('Dockerfile')) {
                      docker.build(it.name).withRun { c ->
                        sh "docker cp ${c.id}:/app/lambda.zip ./lambda.zip"
                      }
                    }
                  }
                }
              }]
            }
          }
        }
      }
      stage('Upload') {
        when {
          branch (args['trunk'] ?: 'master')
        }
        agent {
          docker {
            image 'cvent/aws-cli'
            reuseNode true
          }
        }
        steps {
          script {
            parallel args['locations'].collectEntries {
              [(it): {
                def (account, _environment, region, _availability_zone) = AwsUtils.parseLocation(it)

                withCredentials([[
                  $class: 'AmazonWebServicesCredentialsBinding',
                  credentialsId: "${account}-shared-jenkins",
                ]]) {
                  findFiles(glob: '**/lambda.zip').each {
                    sh "aws s3 cp ${it.path} s3://${account}-lambda-s3-${region}/${args['s3_prefix']}/${it.path}"
                  }
                }
              }]
            }
          }
        }
      }
    }
  }
}
