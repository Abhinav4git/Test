// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// runCheckmarx

import cvent.stash.Utils as StashUtils


/**
 * Run checkmarx scan
 */
def call (args) {
    /** set Checkmarx App Name to projectname-reponame to maintain uniqueness */
    def repoUrl = StashUtils.getProjectSlashRepo(env.GIT_URL)
    def projectKey = repoUrl.split('/')[0].toUpperCase()
    def repositoryName = repoUrl.split('/')[1].toLowerCase()
    def checkmarxProjectName = projectKey + "-" + repositoryName

    /** default preset for Java Applications (Cvent Microservices Policy)*/
    def defaultJavaCxPreset = '100011'

    if (args && args.presetValue) {
        defaultJavaCxPreset = args.presetValue
    }

    /** defautl checkmarx core team - CxServer\SAST\Cvent\Core-Services */
    def defaultCheckmarxTeam = '10c6f1f8-2a2d-46fb-b367-6a3195bde7c6'
    if (args && args.teamValue) {
        defaultCheckmarxTeam = args.teamValue
    }

    /** Enable synchronous mode - Build waits for Checkmarx scan to finish to obtain results. Turning this off means
     * your build will run faster but you don't see the reports in your build output. In future, when we introduce the
     * ability to fail a build when new vulnerabilities are found will require this setting to be enabled*/
    def syncMode = true
    if (args && args.containsKey('syncMode')) {
        if (!args.syncMode) {
            syncMode = false
        }
    }

    print 'Cx team was set to : ' + defaultCheckmarxTeam
    print 'Cx preset was set to : ' + defaultJavaCxPreset
    print 'Cx waitForResultsEnabled was set to : ' + syncMode

    /** use this for comments to easily identify delta scanned */
    def branchName = "Branch:" + env.CHANGE_BRANCH ?: env.GIT_BRANCH

    withCredentials([usernamePassword(credentialsId: 'cxintegration', passwordVariable: 'password', usernameVariable: 'username')]) {
        step([$class: 'CxScanBuilder',
              comment: branchName,
              credentialsId: '',
              excludeFolders: '',
              excludeOpenSourceFolders: '',
              exclusionsSetting: 'job',
              failBuildOnNewResults: false,
              failBuildOnNewSeverity: 'HIGH',
              filterPattern: '''!**/_cvs/**/*, !**/.svn/**/*,   !**/.hg/**/*,   !**/.git/**/*,  !**/.bzr/**/*, !**/bin/**/*,
                !**/obj/**/*,  !**/backup/**/*, !**/.idea/**/*, !**/*.DS_Store, !**/*.ipr,     !**/*.iws,
                !**/*.bak,     !**/*.tmp,       !**/*.aac,      !**/*.aif,      !**/*.iff,     !**/*.m3u, !**/*.mid, !**/*.mp3,
                !**/*.mpa,     !**/*.ra,        !**/*.wav,      !**/*.wma,      !**/*.3g2,     !**/*.3gp, !**/*.asf, !**/*.asx,
                !**/*.avi,     !**/*.flv,       !**/*.mov,      !**/*.mp4,      !**/*.mpg,     !**/*.rm,  !**/*.swf, !**/*.vob,
                !**/*.wmv,     !**/*.bmp,       !**/*.gif,      !**/*.jpg,      !**/*.png,     !**/*.psd, !**/*.tif, !**/*.swf,
                !**/*.jar,     !**/*.zip,       !**/*.rar,      !**/*.exe,      !**/*.dll,     !**/*.pdb, !**/*.7z,  !**/*.gz,
                !**/*.tar.gz,  !**/*.tar,       !**/*.gz,       !**/*.ahtm,     !**/*.ahtml,   !**/*.fhtml, !**/*.hdm,
                !**/*.hdml,    !**/*.hsql,      !**/*.ht,       !**/*.hta,      !**/*.htc,     !**/*.htd, !**/*.war, !**/*.ear,
                !**/*.htmls,   !**/*.ihtml,     !**/*.mht,      !**/*.mhtm,     !**/*.mhtml,   !**/*.ssi, !**/*.stm,
                !**/*.stml,    !**/*.ttml,      !**/*.txn,      !**/*.xhtm,     !**/*.xhtml,   !**/*.class, !**/*.iml, !Checkmarx/Reports/*.*,
                !**/src/test/*.*, !**/src/test/**,!*.Tests,!**/*.dll,!**/*.pdb,!**/*.pdf,''',
              fullScanCycle: 10,
              groupId: defaultCheckmarxTeam,
              includeOpenSourceFolders: '',
              osaArchiveIncludePatterns: '*.zip, *.war, *.ear, *.tgz',
              osaInstallBeforeScan: false,
              password: password,
              preset: defaultJavaCxPreset,
              projectName: "${checkmarxProjectName}",
              serverUrl: 'https://checkmarx.cvent.com',
              sourceEncoding: '1',
              username: username,
              vulnerabilityThresholdResult: 'FAILURE',
              waitForResultsEnabled: syncMode])
    }

}
