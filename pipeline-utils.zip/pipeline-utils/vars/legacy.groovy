def deployCapistrano(application,branch,cap_cmd,capistrano_branch){
  if (capistrano_branch.equals("")){
    capistrano_branch = branch
  }
  sshagent(['80de4c91-460d-4e7e-9517-b99b826860a8']) {
    sh 'git checkout ${capistrano_branch}'
    withEnv([
      "PATH=$HOME/.rbenv/bin:$HOME/.rbenv/shims:$PATH",
      "RBENV_SHELL=bash"
      ]) {
        sh 'bundle install'
        sh "bundle exec ${cap_cmd}"
    }
  }
}

def captureImage(application, version, environment){
  // This can return multiple instances. SRE-1526 is to limit this to one
  target = gps.runGPS("list --environment ${environment} --type ${application} --instance").trim()
  gps.runGPS("image ${target} --environment ${environment} --release ${version}")
}


String[] determiningTypes(environment,application){
  typesToBuild = consul.getEnvironmentData("${environment}/config/servers/${application}/linked_type")
  if (typesToBuild) {
    typesToBuild = "${application}," + typesToBuild
  } else {
    typesToBuild = "${application}"
  }
  String[] typeList = typesToBuild.split( ',' )
  println "typeList is ${typeList}"
  return typeList
}

//Tests sha vs what consul claims we already have deployed
Boolean deployNeeded(application, environment,tag){
  previousSHA = consul.getEnvironmentData("${environment}/config/servers/${application}/sha").trim()
  println "Previous SHA:${previousSHA}"
  println "New SHA:${tag}"
  return (tag != previousSHA)
}

def deployNewAutoscaleGroups(typesToBuild,version,environment,releaseSHA){
  def activateList = [:]
  def validateList = [:]
  def deactivateList = [:]
  for (int index = 0; index < typesToBuild.size(); index++) {
    type = typesToBuild[index]
    echo "Setting up to build ${type}"
    previousVersion = gps.runGPS("list --environment ${environment} --type ${type} --version").trim()
    activateList[type]   = activateAutoscaleGroups(type,version,environment)
    validateList[type]   = validateApplication(type,environment,version)
    deactivateList[type] = deactivateAutoscaleGroups(type,environment,version,previousVersion,releaseSHA)
  }

  parallel activateList
  parallel validateList
  parallel deactivateList
}

//Build and creates autoscale groups that aren't attached to ELBs
def activateAutoscaleGroups(type,version,environment){
  return {
    gps.runGPS("asg prep ${version} -e ${environment} -t ${type}")
    gps.runGPS("asg activate ${version} -e ${environment} -t ${type}")
  }
}

//Attached the autoscale groups to the ELB, updates consul, and deactivates the old groups
def deactivateAutoscaleGroups (type,environment,version,previousVersion,releaseSHA){
  return {
    gps.runGPS("asg activate ${version} -e ${environment} -t ${type} -a")
    sh (script: "curl --silent --request PUT --data \'${releaseSHA}\' http://consul.crwd.cc/v1/kv/${environment}/config/servers/${type}/sha > /dev/null")
    gps.runGPS("asg deactivate ${previousVersion} -e ${environment} -t ${type} --force")
  }
}

//Tests the hosts that they are fully booted
def validateApplication(type,environment,version){
  return {
    //TODO: Don't have this
    if ( type == "hubling" ||  type == "publing" || type == "workling" ){
      return
    }

    //Or this
    if (type == "api") {
        endpoint = "v3/internal_test/ping"
    }  else {
      endpoint = "okcomputer"
    }

    def count = 1
    def initialized, alive, servers
    String[] hostlist
    Boolean validated = false

    while(count<240 && !validated) {
      if (initialized != "VALID") { //First we check to see if enough hosts have been provisioned by AWS
        initialized = gps.runGPS("asg describe ${version} --environment ${environment} --type ${type} -q").trim()
      }
      else { //Build a list of IP's to check
        hostlist = gps.runGPS("list --environment ${environment} --type ${type} --release ${version} -q").split( '\n' )
        alive = true //Assume true until proven otherwise
        for (int index = 0; index < hostlist.size(); index++) { //Loop through every IP testing for health
          hostIP = hostlist[index]
          if (!url_health("http://${hostIP}/${endpoint}",'200')) {
              println "${hostIP} still isn't ready yet"
              alive = false // One host in the group still isn't ready yet
          }
        }
        if (alive) {
          break // Leave the while loop
        }
        count++
      }
      sleep(30)
    }
  }
}

def restartApplication(application, environment) {
  typesToRestart = determiningTypes(environment,application)
  String[] hostlist
  for (int index = 0; index < typesToRestart.size(); index++) {
    type = typesToRestart[index]
    echo "Restarting ${type}"
    hostlist = gps.runGPS("list --environment ${environment} --type ${type} -q").split( '\n' )
    println ("Hosts: ${hostlist}")
    for (int size = 0; size < hostlist.size(); size++) { //Loop through every IP testing for health
      hostIP = hostlist[size]
      sshagent(['80de4c91-460d-4e7e-9517-b99b826860a8']) {
        try {
          sh "ssh rails@${hostIP} \"/usr/local/bin/restartApp.sh\""
        } catch (err) {
           println "Failed to restart ${type} on ${hostIP}"
           return 1
        }
        if (!type.contains("ling")) {
          int count=0
          while (count < 24) { //Wait for an EC2 instance to come alive for 2 minutes
            count++
            sleep 5
            if (ccDocker.urlHealth("http://${hostIP}/okcomputer",'200')) {
                break // One host in the group still isn't ready yet
            }
            else if (count == 24) { //If instance isn't alive after 2 minutes there is probably something wrong
              println "Failed to restart ${type} on ${hostIP}"
              return 1
            }
          }
          try {
            sh "ssh rails@${hostIP} \"/usr/local/bin/lbAttach.sh\""
          } catch (err) {
             println "Failed to reattach ${type} on load balancer"
             return 1
          }
        }
        return 0
      }
    }
  }
}

//Helper method for determining if a url returns a given response code
def url_health(url,code) {
  resp = sh returnStdout:true, script: "curl -I -s -k -o /dev/null -w '%{http_code}' ${url} || exit 0"
  if (resp == "${code}"){
    return true
  }
  return false
}
