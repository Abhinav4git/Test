#!/usr/bin/groovy

/**
 * runMavenIntegrationTests
 *
 * Runs maven integration tests against a deployed service
 * @param environments one or more environments to run integration tests
 *
 * Requires:
 * ssh://git@git.core.cvent.org:7999/stash/dep/hogan-configs.git
 * ssh://git@git.core.cvent.org:7999/stash/dep/integration-tests-deploy.git
 */
def call(Map config) {

    validateConfig('runMavenIntegrationTests', config, [
        ['environments', { !it.isEmpty() }, 'must provide at least one environment']
    ])

    def failsafeReports = '*/target/failsafe-reports'
    def cucumberReportFiles = failsafeReports + '/cucumber/*.json'
    def junitTestResults = failsafeReports + '/*.xml'

    def moduleNames = readMavenPom().getProperties().get('modules.to.integration-test')

    withSecrets {
        config.environments.each { environment ->
            def vars = [
                BUILD_WORKSPACE  : env.WORKSPACE,
                ENVIRONMENT      : environment,
                HOGAN_CONFIGS_DIR: "${env.WORKSPACE}/hogan-configs"
            ]

            if (moduleNames) {
                vars['MODULE_NAMES'] = moduleNames;
            }

            echo "Running integration tests for environment [${environment}]"

            withEnv(vars.collect { it.key + '=' + it.value }) {
                try {
                    sh './integration-tests-deploy/execute.sh'
                } finally {
                    junit testResults: junitTestResults, allowEmptyResults: true
                    if (findFiles([glob: cucumberReportFiles]).size() > 0) {
                        cucumber fileIncludePattern: cucumberReportFiles
                    }
                }
            }
        }
    }
}