#!/usr/bin/env groovy

import cvent.aws.AwsUtils
import cvent.aws.DeployUtils
import cvent.docker.DockerUtils
import cvent.stash.Utils as StashUtils

def call(args = [:]) {
  args = [
    trunk: 'master'
  ] + args

  pipeline {
    agent {
      label 'linux && docker'
    }
    options {
      ansiColor('xterm')
      timestamps()
    }
    environment {
      // URL of GIT repository
      git_url = sh(returnStdout: true, script: "git config --get remote.origin.url").trim()
      // Unique identiifier of repo
      repo_id = StashUtils.getProjectSlashRepo(git_url)
      // Name
      name = "${args['name'] ?: StashUtils.getProjectAndRepo(git_url)[1]}"
    }
    stages {
      stage('CI') {
        steps {
          script {
            args?.ci?.stacks?.each { stackName, stackInfo ->
              findFiles(glob: "cloudformation/${stackName}/**/Dockerfile").each {
                DockerUtils.lint(it.path)

                dir(new File(it.path).parent) {
                  docker.build(stackName).run("-v ${pwd()}:${pwd()} -w ${pwd()}")
                }
              }

              DeployUtils.getDeployLocations(stackName, stackInfo).each {
                lock("${stackName}-${env.STAGE_NAME}-${it}") {
                  if (args.ci.shouldTearDown) {
                    // cleanup from previous failures
                    DeployUtils.removeFromLocation(name, stackName, it)
                  }

                  DeployUtils.packageToLocation(name, stackName, it, stackInfo)
                  DeployUtils.deployToLocation(name, stackName, it, stackInfo)

                  if (args.ci.shouldTearDown) {
                    DeployUtils.removeFromLocation(name, stackName, it)
                  }
                }
              }
            }
          }
        }
      }
      stage('Alpha') {
        steps {
          script {
            args?.alpha?.stacks?.each { stackName, stackInfo ->
              findFiles(glob: "cloudformation/${stackName}/**/Dockerfile").each {
                DockerUtils.lint(it.path)

                dir(new File(it.path).parent) {
                  docker.build(stackName).run("-v ${pwd()}:${pwd()} -w ${pwd()}")
                }
              }

              DeployUtils.getDeployLocations(stackName, stackInfo).each {
                lock("${stackName}-${env.STAGE_NAME}-${it}") {
                  DeployUtils.packageToLocation(name, stackName, it, stackInfo)
                  DeployUtils.deployToLocation(name, stackName, it, stackInfo)
                }
              }
            }
          }
        }
      }
      stage('Staging') {
        when {
          branch args.trunk
        }
        steps {
          script {
            args?.staging?.stacks?.each { stackName, stackInfo ->
              findFiles(glob: "cloudformation/${stackName}/**/Dockerfile").each {
                DockerUtils.lint(it.path)

                dir(new File(it.path).parent) {
                  docker.build(stackName).run("-v ${pwd()}:${pwd()} -w ${pwd()}")
                }
              }

              DeployUtils.getDeployLocations(stackName, stackInfo).each {
                lock("${stackName}-${env.STAGE_NAME}-${it}") {
                  DeployUtils.packageToLocation(name, stackName, it, stackInfo)
                  DeployUtils.deployToLocation(name, stackName, it, stackInfo)
                }
              }
            }
          }
        }
      }
      stage('Production') {
        options {
          // Having a 2-hour timeout to avoid job hanging forever on user-input
          // but keeping it at 2 hour timeout for now since most stacks (including cloudfront)
          // should complete within 2 hours.
          timeout(time: 2, unit: 'HOURS')
        }
        when {
          beforeInput true
          branch args.trunk
        }
        input {
          message "Should we continue with production deployment?"
          ok "Yes, proceed"
          submitterParameter "SUBMITTER"
        }
        steps {
          echo "${env.SUBMITTER} has authorized deployment to production"

          script {
            args?.production?.stacks?.each { stackName, stackInfo ->
              findFiles(glob: "cloudformation/${stackName}/**/Dockerfile").each {
                DockerUtils.lint(it.path)

                dir(new File(it.path).parent) {
                  docker.build(stackName).run("-v ${pwd()}:${pwd()} -w ${pwd()}")
                }
              }

              DeployUtils.getDeployLocations(stackName, stackInfo).each {
                lock("${stackName}-${env.STAGE_NAME}-${it}") {
                  DeployUtils.packageToLocation(name, stackName, it, stackInfo)
                  DeployUtils.deployToLocation(name, stackName, it, stackInfo)
                }
              }
            }
          }
        }
      }
    }
  }
}
