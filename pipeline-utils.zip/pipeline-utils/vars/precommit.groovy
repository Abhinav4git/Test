/**
 * Run pre-commit against:
 *   - All files in the repository.
 *   - All commits in the PR (If running in a PR context).
 * Any failures will cause the build to fail.
 *
 * Use with an agent that has precommit installed.
 *
 * Pre-commit works with a `.pre-commit-config.yaml` configuration file.
 * You should configure the stage to only run when this file is present.
 */
def call(Map config = [:]) {
  withEnv(["ASDF_PYTHON_VERSION=3.8.2"]) {
    // If asdf is available
    if (sh(script: 'command -v asdf', returnStatus: true) == 0) {
      echo "Reshimming everything"
      sh 'asdf reshim'

      echo 'Installing pip'
      sh "asdf install python ${ASDF_PYTHON_VERSION}"

      echo 'Installing pre-commit'
      sh 'pip install pre-commit'
    }

    // Run pre-commit against all files in the repository
    echo 'Running pre-commit. To setup pre-commit locally, refer to https://wiki.cvent.com/display/DEV/Pre-commit'
    sh 'pre-commit run --color always --all-files --show-diff-on-failure'

    script {
      // Run pre-commit against commit messages in the PR (if this is a PR)
      if (env.GIT_BRANCH.startsWith('PR-') && fileExists('.pre-commit-config.yaml') && readFile(file:'.pre-commit-config.yaml').contains('commit-msg')) {
        def tmpDir = sh(returnStdout: true, script: 'mktemp -d').trim()

        // find our master branch remote location (will likely be one of
        // origin/master or upstream/master)
        def remoteChangeTargetBranch = sh(
          returnStdout: true,
          script: "git branch -a | grep -m 1 \"remotes/.*/${env.CHANGE_TARGET}\""
        ).trim()

        def commits = sh(
          returnStdout: true,
          script: "git rev-list ${remoteChangeTargetBranch}..."
        )

        commits.split().each {
          def messageFile = "${tmpDir}/${it}.msg"
          sh "git show -s --format=%B ${it} > '${messageFile}'"
          sh "pre-commit run --color always --hook-stage commit-msg --commit-msg-filename '${messageFile}'"
        }
      }
    }
  }
}
