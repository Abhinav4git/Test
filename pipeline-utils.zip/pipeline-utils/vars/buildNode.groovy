#!/usr/bin/groovy
import cvent.jenkins.SlaveUtils
import cvent.stash.Utils as Stash

/**
 * Builds a SNAPSHOT version of a Node project.
 * @param coverage 'clover', 'jacoco', or null to not run coverage (Default: 'jacoco')
 * @param deploy true to deploy artifacts to nexus (Default: false)
 */
def call(Map config) {
    config = config ?: [:]
    def buildImage = config.get('buildImage') ?: 'centos7'
    def Node_BUILD_IMG = "docker.cvent.net/mobile-node-build-snapshot-docker:${buildImage}"

    def branch = Stash.getBranch()
    def commit = Stash.getCommit()
    List warnings

    if (SlaveUtils.isECS()) {
        // ECS workers have the required build tools
        warnings = build(config, branch, commit)
    } else {
        // Required to run docker within docker for testcontainers
        def dockerArgs = [
                '-v "$HOME/.m2:/home/jenkins/.m2:rw"',
                '-v /var/run/docker.sock:/var/run/docker.sock',
                "--group-add ${sh(returnStdout: true, script: 'getent group docker | cut -d: -f3').trim()}",
                // Required for services which run node
                '-v "$HOME/.npm:/.npm:rw"',
                '-v "$HOME/.package_cache:/home/jenkins/.package_cache"',
                '-v "$HOME/.ssh:/home/jenkins/.ssh:rw"',
                '-v $PWD:/code:rw',
                '-w /code'
        ].join(' ')

        sh "docker pull ${Node_BUILD_IMG}"
        docker.image(Node_BUILD_IMG).inside(dockerArgs) {
            warnings = build(config, branch, commit)
        }
    }

    return warnings
}

def build(Map config, String branch, String commit) {
    List warnings = []
    List cmds = []
    cmds << '/tmp/build-scripts/docker-build-node-service.sh'
    def snapshot = config.get('snapshot', false)
    if (snapshot) {
        cmds << './node_modules/.bin/gulp upload-snapshot --dev'
    } else {
        cmds << './node_modules/.bin/gulp clean && ./node_modules/.bin/gulp release --prod'
    }

    sh cmds.join("\n")

    return warnings
}
