import groovy.transform.Field
import groovy.json.JsonOutput

@Field String containerRepo = 'dt/containers.git'
@Field String stashMirrorSSH = 'ssh://git@git.crwd.cc:7999/stash'
@Field String stashHTTPS = 'https://stash.cvent.net/'


def repoMirrorUrl(repo, project='cc') {
  return "${stashMirrorSSH}/${project}/${repo}.git"
}
//Checks out the requested repo and the containers repo
def checkoutStash(repo,branch='master',project='cc'){
  stage ("git checkout "){
    git url: repoMirrorUrl(repo, project), branch: "${branch}"
  }
}

//Resets a git repo
def cleanBranch(){
  stage ("git clean"){
    sh "git clean -fdx"
    sh "git reset --hard"
  }
}

//Submits a pull request to stash
def stashPullRequest(title,description,fromRef,toRef,slug,project='cc',credentials="ccjenkinsman") {
  def data = [
      title: "${title}",
      description: "${description}",
      state: "OPEN",
      open: true,
      closed: false,
      fromRef:[
        id: "${fromRef}",
        repository:[
          slug: "${slug}",
          name: null,
          project:[
            key: "${project}"
          ]
        ]
      ],
      toRef:[
        id: "${toRef}",
        repository:[
          slug: "${slug}",
          name: null,
          project:[
            key: "${project}"
          ]
        ]
      ],
      locked: false
    ]
    def json = JsonOutput.toJson(data)
    json = JsonOutput.prettyPrint(json)
    writeFile(file:'request.json', text: json)
  try {
    withCredentials([usernamePassword(credentialsId: "${credentials}", passwordVariable: 'stashPassword', usernameVariable: 'stashUser')]) {
      sh """curl -s -u ${stashUser}:${stashPassword} -H \"Content-Type: application/json\" ${stashHTTPS}rest/api/1.0/projects/${project}/repos/${slug}/pull-requests -X POST -d \"@request.json\""""
    }
  } catch (err) {
    println "FAILED: There was a problem creating the pull request."
  }
}

//Looks up the short sha for the application code
String calculateTag() {
  applicationTag = sh (script: "git rev-parse --short HEAD",returnStdout: true).trim()
  return applicationTag
}

def generateToken(environment) {
  withCredentials([string(credentialsId: 'VAULT_TOKEN', variable: 'VAULT_TOKEN')]) {
    token = sh returnStdout:true, script:('#!/bin/sh -e\n' +"VAULT_ADDR=https://vault.crwd.cc VAULT_TOKEN=${VAULT_TOKEN} vault token create -field=token -policy ${environment} -ttl 1440h")
  }
  println "Vault Token created."
  return "${token}"
}
