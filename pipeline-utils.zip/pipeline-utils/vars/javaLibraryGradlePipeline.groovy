// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// javaLibraryGradlePipeline

// Is the release parameter set or is this the branch we run all releases off of?
def isReleaseExpected(release_filter) {
  // trunk_branch was lifted from an env var up to a hard coded value here
  // env vars that are set within this job can't be referenced from functions used during the environment block
  params.RELEASE || env.BRANCH_NAME =~ release_filter
}

def isRelease(release_filter) {
  return !isIncubating() && !isPR() && isReleaseExpected(release_filter)
}

def isIncubating() {
  return sh(returnStdout: true, script: "git config --get remote.origin.url").trim().contains("/INCB/")
}

def isPR() {
  return env.BRANCH_NAME.startsWith('PR-')
}

def version(module, release_filter) {
  // Snapshot version
  def snapshot_version = sh(
      script: "./gradlew -q :${module}:version",
      returnStdout: true
    ).trim()

  return isRelease(release_filter) ? snapshot_version.split('-')[0] : snapshot_version
}

def notifySlack(boolean success) {
  if (env.slack_channel) {
    slackSend(channel: env.slack_channel,
      color: success ? 'good' : 'danger',
      message: (success ? 'SUCCESS' : 'FAILURE') + ": ${env.slack_message_name_link}"
    )
  }
}

// Arguments:
//  slack_channel - Slack channel which receives RELEASE build notifications. To disable notifications do not include
//    this option in the arguments map.
//  allow_empty_junit_results - Default to 'false', if true empty or non existent junit results will be allowed
//                              Set this to 'true' if you don't have any tests in your repo
//  module - Name of the module being built
//  docker_image - The image to use for building with gradle
//  android_build - Default to false, if true create debug keystore
//
def call(def params = [:]) {
  pipeline {
    agent {
      docker {
        image params['docker_image']
        args '-v "$HOME/.m2:/root/.m2" -v "$HOME/.gradle:/root/.gradle"'
      }
    }
    options {
      timestamps()
      ansiColor('xterm')
    }
    environment {
      release_filter = "${params['release_filter'] ?: 'master'}"

      // Where should we send start and failure alerts?
      slack_channel = "${params['slack_channel']}"

      allow_empty_junit_results = "${params['allow_empty_junit_results'] ?: 'false'}"

      android_build = "${params['android_build'] ?: 'false'}"

      test_target = "${android_build == 'true' ? 'testDebug' : 'test'}"

      jacoco_found = """${sh(
        script: "./gradlew :${env.module}:tasks --all|grep jacocoTestReport",
        returnStatus: true
        ) == 0 ? 'true' : 'false'}"""

      potential_task = ":${env.module}:jacocoTestReport"

      jacoco_task = "${jacoco_found == 'true' ? potential_task : ' '}"

      module = "${params['module']}"

      // What artifact we are building
      artifact_id = sh(
          script: "./gradlew -q :${module}:artifactId",
          returnStdout: true
        ).trim()

      // Get the last commit hash
      git_commit = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()
      // Get the last commit author so we can see if it's jenkins
      git_last_commiter = sh(returnStdout: true, script: "git log -1 --pretty=format:'%an'").trim()
      // Get the last commit message so we can see if it was a maven release "[maven-release-plugin]"
      git_last_commit_msg = sh(returnStdout: true, script: "git log -1 --pretty=format:'%s'").trim()

      // Is this a release commit from maven?
      is_release_commit = "${git_last_commiter?.equalsIgnoreCase('jenkins') && git_last_commit_msg?.contains('[maven-release-plugin]')}"

      source_branch_name = cvent.stash.Utils.getBranch()

      // The slack message that contains the job name, number, and link
      slack_message_name_link = """\
                             ${artifact_id} - <${env.BUILD_URL}console|#${env.BUILD_NUMBER}> (<${env.BUILD_URL}console|Open>)
                             Branch: ${BRANCH_NAME}
                             Author: ${git_last_commiter}
                             Version: ${version(module, release_filter)} (${git_commit})
                             Message: ${git_last_commit_msg}
                         """.stripIndent()
    }
    parameters {
      booleanParam(name: 'RELEASE',
        defaultValue: false,
        description: 'Should gradle release this build?')
    }
    stages {
      stage('Print Environment') {
        steps {
          printEnvInfo()
          script {
            currentBuild.displayName = "#${env.BUILD_NUMBER} (${version(env.module, env.release_filter)})"
          }
        }
      }
      stage('Keystore') {
        when {
          expression { env.android_build.toBoolean() && !fileExists("${env.WORKSPACE}/.android/debug.keystore") }
        }
        steps {
          script {
            sh "mkdir -p ${env.WORKSPACE}/.android"
            sh "keytool -genkey -v -keystore ${env.WORKSPACE}/.android/debug.keystore -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000  -dname 'C=US, O=Android, CN=Android Debug'"
          }
        }
      }
      stage('Test') {
        steps {
          script {
            // TODO check unit test coverage and perform SonarQube analysis of release candidate code
            //sh 'mvn --batch-mode sonar:sonar -Dsonar.host.url=http://sonar.core.cvent.org/'
            sh "./gradlew --stacktrace -Duser.home=${env.WORKSPACE} :${env.module}:clean :${env.module}:${test_target} ${env.jacoco_task}"
          }
        }
        post {
          always {
            junit allowEmptyResults: env.allow_empty_junit_results.toBoolean(), testResults: '**/build/test-results/**/*.xml'
          }
        }
      }
      stage('Publish') {
        when {
          beforeAgent true
          expression { return isReleaseExpected(release_filter) }

          // not { changelog }
        }
        steps {
          script {
              if (isRelease(release_filter)) {
                withCredentials([usernamePassword(credentialsId: 'nexus-deployment', usernameVariable: 'NEXUS_USER', passwordVariable: 'NEXUS_PASSWORD')]) {
                    sh "./gradlew -Duser.home=${env.WORKSPACE} -DNEXUS_USER=${env.NEXUS_USER} -DNEXUS_PASSWORD=${env.NEXUS_PASSWORD} -DPUBLISH_LOCATION=release :${env.module}:uploadArchives"
                }
              } else {
                if (isIncubating()) {
                  echo "WARNING: Skipping release because this repository is still incubating"
                } else if (isPR()) {
                  echo "WARNING: Skipping release because this is a build of a PR. This shouldn't happen"
                } else {
                  echo "WARNING: Skipping release for an unknown reason"
                }
              }
            }
          }
        post {
          success {
            script {
              notifySlack(true)
            }
          }
          failure {
            script {
              notifySlack(false)
            }
          }
        }
      }
    }
  }
}
