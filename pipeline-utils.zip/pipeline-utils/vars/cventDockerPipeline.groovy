// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// cventDockerPipeline

import cvent.docker.DockerUtils
import cvent.stash.Utils as StashUtils

// Arguments:
//  trunk: The branch to publish images from
//  name: The name of the image to build
//  dockerfiles: Map of dockerfile path to the following map:
//    tags: tag-suffixes
//  registries: List of repositories to publish to
//
def call(args = [:]) {
  pipeline {
    agent { label 'linux && docker' }
    options {
      ansiColor('xterm')
      timestamps()
    }
    environment {
      // URL of GIT repository
      git_url = sh(returnStdout: true, script: "git config --get remote.origin.url").trim()
      // Name
      name = "${args['name'] ?: "cvent/${StashUtils.getProjectAndRepo(git_url)[1]}"}"
      trunk_branch = "${args['trunk'] ?: 'master'}"
    }
    stages {
      stage('Lint Dockerfiles') {
        agent {
          docker {
            image 'docker.cvent.net/cvent/lint-dockerfile'
            alwaysPull true
          }
        }
        steps {
          script {
            dockerfiles = args['dockerfiles'] ?: DockerUtils.defaultDockerfiles()
            echo "Dockerfiles: ${dockerfiles}"
            dockerfiles.each { path, _ ->
              sh "dockerfilelint ${path}"
            }
          }
        }
      }
      stage ('Deploy images') {
        agent { label 'linux && docker' }
        steps {
          script {
            dockerfiles = args['dockerfiles'] ?: DockerUtils.defaultDockerfiles()
            echo "Dockerfiles: ${dockerfiles}"
            dockerfiles.each { path, file_args ->
              // If added, build the dockerfile assuming the root of the repo
              if (file_args['root_build'] ?: false) {
                cventDocker(name: name,
                    tags: (file_args['tags'] ?: []),
                    file: path,
                    path: '.',
                    tests: file_args['tests'],
                    registries: args['registries'],
                    push: env.BRANCH_NAME == env.trunk_branch,
                    entrypoint: args['entrypoint'])

              } else {
                cventDocker(name: name,
                    tags: (file_args['tags'] ?: []),
                    path: path,
                    tests: file_args['tests'],
                    registries: args['registries'],
                    push: env.BRANCH_NAME == env.trunk_branch,
                    entrypoint: args['entrypoint'])
              }
            }
          }
        }
      }
      // TODO: Uncomment after https://jira.cvent.com/browse/SRE-2788
      /*stage ('Deploy tag') {
        agent { label 'linux && docker' }
        when {
          beforeAgent true
          buildingTag()
        }
        steps {
          script {
            dockerfiles = args['dockerfiles'] ?: DockerUtils.defaultDockerfiles()
            echo "Dockerfiles: ${dockerfiles}"
            dockerfiles.each { path, file_args ->
              (file_args['tags'] ?: []).each { suffix ->
                tag = suffix == 'latest' ? env.GIT_TAG : "${env.GIT_TAG}-${suffix}"
                cventDocker(name: args['name'],
                            tag: tag,
                            path: path,
                            registries: args['registries'])
              }
            }
          }
        }
      }*/
    }
  }
}
