import cvent.aws.CdkManager;

def call(targets, Closure c) {
  return targets.collect {
      def cdkManager = CdkManager.fromTarget(this, it)

      if (cdkManager) {
          c.call(cdkManager)
      } else {
          echo "WARNING: No CDK manager for ${it} - Skipping"
      }
  }
}
