// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// dockerApplicationPipeline

import cvent.aws.AwsUtils
import cvent.aws.CloudFormationUtils
import cvent.aws.DeployUtils
import cvent.docker.DockerUtils
import cvent.stash.Utils as StashUtils

// Arguments:
//  trunk: The branch to publish images from
//  name: The name of the image to build, defaults to `<repo name>`
//  version: The version to publish
def call(args = [:]) {
  args = [
    versions: ['latest'],
    trunk: 'master',
    additional_registries: []
  ] + args

  pipeline {
    agent { label 'linux && docker' }
    options {
      ansiColor('xterm')
      timestamps()
    }
    environment {
      // URL of GIT repository
      git_url = sh(returnStdout: true, script: "git config --get remote.origin.url").trim()
      // Unique identiifier of repo
      repo_id = StashUtils.getProjectSlashRepo(git_url)
      // Name
      name = "${args['name'] ?: StashUtils.getProjectAndRepo(git_url)[1]}"
    }
    stages {
      stage('Lint') {
        steps {
          script {
            DockerUtils.lint('Dockerfile')
          }
        }
      }
      stage('Setup') {
        steps {
          script {
            args?.setup?.stacks?.each { stackName, stackInfo ->
              DeployUtils.getDeployLocations(stackName, stackInfo).each {
                DeployUtils.deployToLocation(name, stackName, it, (args?.stacks?.get(stackName) ?: [:]) + stackInfo)
              }
            }
          }
        }
      }
      stage('Snapshot') {
        steps {
          script {
            lock("${repo_id}-snapshot") {
              image = DockerUtils.build(name, 'Dockerfile').id

              registries = [
                'cvent-management@us-east-1',
                'cvent-management@us-west-2',
                'cvent-management@eu-west-1',
                'cvent-management@eu-central-1'
              ] + args['additional_registries']

              snapshot_versions = args['versions'].collect { "snapshot__${it}" }

              registries.each { registry ->
                DockerUtils.pushToRegistry(docker.image(image), snapshot_versions, registry)
              }

              // Finished publishing snapshot

              args?.ci?.stacks?.each { stackName, stackInfo ->
                DeployUtils.getDeployLocations(stackName, stackInfo).each {
                  DeployUtils.removeFromLocation(name, stackName, it)
                  DeployUtils.packageToLocation(name, stackName, it, (args?.stacks?.get(stackName) ?: [:]) + stackInfo)
                  DeployUtils.deployToLocation(name, stackName, it, (args?.stacks?.get(stackName) ?: [:]) + stackInfo)

                  // Do any tests

                  DeployUtils.removeFromLocation(name, stackName, it)
                }
              }

              args?.alpha?.stacks?.each { stackName, stackInfo ->
                DeployUtils.getDeployLocations(stackName, stackInfo).each {
                  DeployUtils.packageToLocation(name, stackName, it, (args?.stacks?.get(stackName) ?: [:]) + stackInfo)

                  DeployUtils.deployToLocation(name, stackName, it, (args?.stacks?.get(stackName) ?: [:]) + stackInfo)

                  // Do any tests
                }
              }
            }
          }
        }
      }
      stage('Release') {
        when {
          branch args.trunk
        }
        steps {
          script {
            lock("${repo_id}-release") {
              image = DockerUtils.build(name, 'Dockerfile').id

              registries = [
                'cvent-management@us-east-1',
                'cvent-management@us-west-2',
                'cvent-management@eu-west-1',
                'cvent-management@eu-central-1'
              ] + args['additional_registries']

              release_versions = args['versions'].collectMany { [ it, "release__${it}" ] }

              registries.each { registry ->
                DockerUtils.pushToRegistry(docker.image(image), release_versions, registry)
              }

              // Finished publishing releases

              args?.staging?.stacks?.each { stackName, stackInfo ->
                DeployUtils.getDeployLocations(stackName, stackInfo).each {
                  DeployUtils.packageToLocation(name, stackName, it, (args?.stacks?.get(stackName) ?: [:]) + stackInfo)

                  DeployUtils.deployToLocation(name, stackName, it, (args?.stacks?.get(stackName) ?: [:]) + stackInfo)

                  // Do any tests
                }
              }

              args?.production?.stacks?.each { stackName, stackInfo ->
                DeployUtils.getDeployLocations(stackName, stackInfo).each {
                  DeployUtils.packageToLocation(name, stackName, it, (args?.stacks?.get(stackName) ?: [:]) + stackInfo)

                  DeployUtils.deployToLocation(name, stackName, it, (args?.stacks?.get(stackName) ?: [:]) + stackInfo)

                  // Do any tests
                }
              }
            }
          }
        }
      }
    }
  }
}
