#!/usr/bin/groovy

/**
 * postmanNewmanServiceTests
 *
 * Runs newman service tests
 * @param artifactId maven artifactId containing the postman tests
 * @param environments one or more environments to run postman tests
 * @param verbose - if we are going to enable verbose logging
 *
 * Requires:
 * ssh://git@git.core.cvent.org:7999/stash/dep/deploy-aws-docker.git
 * ssh://git@git.core.cvent.org:7999/stash/dep/hogan-configs.git
 */
def call(Map config) {

    validateConfig('postmanNewmanServiceTests', config, [
        ['environments', { !it.isEmpty() }, 'must provide at least one environment'],
        'artifactId',
        'verbose',
    ])

    if (!config.artifactId){
        return
    }

    def collectionsToRun
    if (config.platform == 'node') {
        if (fileExists("./package.json")) {
            collectionsToRun = readJSON(file: "./package.json").postmanTest.collections
                    .split(',')
                    .collect { it.trim() }
                    .join(",")
            if (!collectionsToRun) {
                return
            }
        } else {
            return
        }
    } else {
        if (fileExists("${config.artifactId}/pom.xml")) {
            collectionsToRun = readMavenPom(file: "${config.artifactId}/pom.xml").getProperties()
                    .get('collections.to.run')
                    .split(',')
                    .collect { it.trim() }
                    .join(",")
            if (!collectionsToRun) {
                return
            }
        } else {
            return
        }
    }


    def deploys = config.environments.collectEntries() {
        [("postman-" + it): { -> postman(config, it, collectionsToRun) }]
    }

    if (config.parallelTests) {
      parallel deploys
    } else {
      deploys.each { key, val ->
        logInfo("Running deploy $key")
        val()
      }
    }
}

def postman(Map config, String environment, String collectionsToRun) {
    def verbose = config.get('verbose', false).toBoolean()

    dir('deploy-aws-docker') {
        try {
            withSecrets {
                Map vars = [
                  ARTIFACT_ID       : config.artifactId,
                  COLLECTIONS_TO_RUN: collectionsToRun,
                  BUILD_WORKSPACE   : env.WORKSPACE,
                  ENV               : environment,
                  HOGAN_CONFIGS_DIR : "${env.WORKSPACE}/hogan-configs",
                  VERBOSE           : verbose ? '1' : '0'
                ]

                logInfo "Running postman tests for environment [${environment}]"

                withEnv(vars.collect { it.key + '=' + it.value }) {
                    sh './postman-newman-service-tests.sh'
                }
            }
        } finally {
            def reportDir = "${env.WORKSPACE}/${config.artifactId}/newman"

            if (fileExists(reportDir)) {
                List htmlFiles = []
                dir(reportDir) {
                    htmlFiles = findFiles glob: '*.html'
                }
                publishHTML([
                  reportDir            : reportDir,
                  reportFiles          : htmlFiles.join(','),
                  reportName           : "Postman Results ${environment}",
                  allowMissing         : true,
                  alwaysLinkToLastBuild: true,
                  keepAll              : true])
            }
        }
    }
}
