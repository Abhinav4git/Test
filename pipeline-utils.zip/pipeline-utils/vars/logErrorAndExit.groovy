// logErrorAndExit - Prints a red ERROR message and then calls error exiting the build
def call(message) {
  logError message
  error message
}
