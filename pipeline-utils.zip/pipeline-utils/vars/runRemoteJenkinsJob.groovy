#!/usr/bin/groovy

/**
 * runRemoteJenkinsJob
 *
 * Runs a remote Jenkins job (eg. https://qe-jenkins.core.cvent.org/job/runAPI) and waits for it to complete before
 * returning.
 * @param job Name of the Jenkins job
 * @param password Name of the environment variable which contains the remote Jenkins password
 * @param syncMode true to wait for remote jenkins job to complete before returning
 * @param token Value of Jenkins job's remote trigger token
 * @param url URL of the remote Jenkins
 * @param username Username of the remote Jenkins
 */
def call(Map config) {
  validateConfig('runRemoteJenkinsJob', config, [
    'job',
    'password',
    'token',
    'url',
    'username'
  ])

  withSecrets {
    def queueUrl = startJob(config)
    def jobUrl

    logInfo "Queued job: ${queueUrl}"

    while (true) {
      def json = loadApiJsonUrl(config, queueUrl)
      def job = readJSON text: json

      if (job.executable == null) {
        Thread.sleep(5000)
      } else {
        jobUrl = job.executable.url
        break
      }
    }

    logInfo "Remote Jenkins job: ${jobUrl}"

    if (config.get('syncMode', true)) {
      while (true) {
        def json = loadApiJsonUrl(config, jobUrl)
        def job = readJSON text: json

        if (job.result == 'null') {
          Thread.sleep(5000)
        } else if (job.result == 'SUCCESS') {
          break
        } else {
          logError "Remote Jenkins job failed: ${jobUrl}: ${job.result}"
          logErrorAndExit "Remote Jenkins job configuration: ${config}"
        }
      }
    }
  }
}

def encode(key, value) {
  return String.format("%s=%s",
    URLEncoder.encode(key.toString(), "UTF-8"),
    URLEncoder.encode(value.toString(), "UTF-8"))
}

@NonCPS
def body(HttpURLConnection connection) {
  StringBuilder sb = new StringBuilder()
  BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()))
  try {
    def line
    while ((line = br.readLine()) != null) {
      sb.append(line)
    }
  } finally {
    if (br != null) br.close()
  }
  return sb.toString()
}

def startJob(Map config) {
  def parameters = [ 'job': config.job, 'token': config.token ] << config.parameters
  def query = parameters
    .entrySet()
    .collect { encode(it.key, it.value) }
    .join('&')

  URL url = new URL("${config.url}/buildByToken/buildWithParameters?${query}")
  HttpURLConnection connection = (HttpURLConnection) url.openConnection();
  connection.setRequestMethod('POST')
  connection.connect()

  if (connection.responseCode == 201) {
    return connection.getHeaderField('Location')
  }
  logErrorAndExit("Error calling ${url}: ${connection.responseCode}")
}

@NonCPS
def loadApiJsonUrl(Map config, baseUrl) {
  def url = baseUrl + 'api/json'
  def authentication = "${config.username}:${env[config.password]}".bytes.encodeBase64().toString()
  HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection()
  connection.setRequestMethod('GET')
  connection.setRequestProperty("Authorization", "Basic ${authentication}")
  connection.connect()

  if (connection.responseCode == 200) {
    return body(connection)
  }
  logErrorAndExit("Error calling ${url}: ${connection.responseCode}")
}
