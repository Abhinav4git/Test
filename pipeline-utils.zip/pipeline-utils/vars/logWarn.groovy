// logWarn Prints a yellow WARN message
def call(message) {
  echo "\033[38;5;3mWARN: ${message}\033[38;5;0m"
}
