// nodeLibraryPipeline

import cvent.jenkins.GroovyUtils
import cvent.slack.SlackUtils
import cvent.stash.Utils as StashUtils
import groovy.transform.Field

@Field Map NPM_SCRIPTS = [:]

boolean isJenkinsCommit() {
  return env.GIT_LAST_COMMITTER == 'Jenkins' && !(env.GIT_LAST_COMMIT_MSG ==~ /Merge commit.+into HEAD/)
}

boolean isReleaseBranch(pipelineArgs) {
  return env.BRANCH_NAME ==~ pipelineArgs.release.branch
}

boolean isRelease(pipelineArgs) {
  // Never release from a PR
  if (env.CHANGE_URL) {
    return false
  }

  // Allow forcing a release via build param
  if (params.RELEASE) {
    return true
  }

  if (isReleaseBranch(pipelineArgs) && !isJenkinsCommit()
          && !StashUtils.changeSetContainsOnlyIgnoredFiles(pipelineArgs.ignoreFiles)) {
    return true
  }

  return false
}

// Check whether an npm script exists
boolean hasScript(String name) {
  return NPM_SCRIPTS && NPM_SCRIPTS.containsKey(name)
}

// Run an npm script if it exists
def runScript(String name) {
  if (hasScript(name)) {
    sh "yarn ${name}"
  }
}

def yarnVersion() {
  return sh(returnStdout: true, script: "yarn --version").trim()
}

def getGitUrl() {
  // GIT_URL when building a branch, GIT_URL_1 when building a PR
  return env.GIT_URL ?: env.GIT_URL_1
}

def getRepoName() {
  return StashUtils.getProjectAndRepo(getGitUrl())[1]
}

def notifySlack(channels) {
  def repo_id = StashUtils.getProjectSlashRepo(getGitUrl())
  def branch = StashUtils.getBranch()
  def style = (currentBuild.currentResult == 'SUCCESS') ? 'good' : 'danger'

  fields = [
      [
          value: env.GIT_LAST_COMMIT_MSG
      ],
      [
          title: "Branch",
          value: branch,
          short: true
      ],
      [
          title: "Author",
          value: env.GIT_LAST_COMMITTER,
          short: true
      ],
      [
          title: "Version",
          value: env.PACKAGE_VERSION,
          short: true
      ],
      [
          title: "Commit",
          value: env.GIT_COMMIT,
          short: true
      ]
  ]

  actions = [
      [
          type : "button",
          text : "View Details",
          url  : env.BUILD_URL,
          style: style
      ],
      [
          type : "button",
          text : "Changelog",
          url  : StashUtils.getChangelogUrl(getGitUrl(), branch).replace("/stash/", "/stash.cvent.net/"),
          style: style
      ]
  ]

  attachments = [
      [
          pretext  : "*${repo_id}*",
          color    : style,
          fallback : "${repo_id} build",
          fields   : fields,
          mrkdwn_in: ['pretext'],
          actions  : actions
      ]
  ]

  SlackUtils.notifySlack(channels, [message: '', attachments: attachments])
}

// Arguments:
//  slack_channel - Slack channel which receives RELEASE build notifications.
//  release.branch - Regular expression to determine which branch triggers a release build
//  release.publish - Whether to publish package to registry
def call(def pipelineArgs = [:]) {

  Map defaultConfig = [
      release: [
          branch: 'master',
          publish: true
      ]
  ]
  pipelineArgs = GroovyUtils.mergeMaps(defaultConfig, pipelineArgs)

  pipeline {
    agent {
      label 'jenkins-agent-cdk'
    }
    options {
      ansiColor('xterm')
      timestamps()
    }
    parameters {
      booleanParam(name: 'RELEASE',
          defaultValue: false,
          description: 'Force a release')

      choice(name: 'RELEASE_TYPE',
          choices: ['PATCH', 'MINOR', 'MAJOR'],
          description: '')
    }
    environment {
      // Repo name
      GIT_REPO_NAME = getRepoName()

      // Get the last commit hash
      GIT_COMMIT = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()

      // Get the last commit author
      GIT_LAST_COMMITTER = sh(returnStdout: true, script: "git log -1 --pretty=format:'%an'").trim()

      // Get the last commit message
      GIT_LAST_COMMIT_MSG = sh(returnStdout: true, script: "git log -1 --pretty=format:'%s'").trim()
    }
    stages {
      stage('Setup') {
        steps {
          script {
            printEnvInfo()
            def packageJson = readJSON file: './package.json'
            NPM_SCRIPTS = packageJson.scripts
            if (packageJson.version && !isRelease(pipelineArgs)) {
              currentBuild.displayName = "#${env.BUILD_NUMBER} v${packageJson.version}"
            }
          }
        }
      }
      stage('Build') {
        when {
          expression { !isJenkinsCommit() }
        }
        steps {
          script {
            withSecrets {
              if (yarnVersion().startsWith('2.')) {
                sh 'yarn install --immutable'
              } else {
                sh 'yarn install --frozen-lockfile'
              }

              /**
               * Workaround for `yarn install --frozen-lockfile` not failing on yarn.lock updates as expected
               * See:
               *   - https://github.com/yarnpkg/yarn/issues/4098
               *   - https://github.com/yarnpkg/yarn/issues/5840
               */
              if (sh(script: 'git diff --exit-code yarn.lock', returnStatus: true) > 0) {
                logErrorAndExit("Changes were detected in yarn.lock file after running 'yarn install', which is not expected. Please run 'yarn install' locally and commit the changes.")
              }
              runScript('build')
              runScript('lint')
              runScript('test')
            }
          }
        }
      }
      stage('Release') {
        when {
          expression { isRelease(pipelineArgs) }
        }
        steps {
          lock("${env.GIT_REPO_NAME}-release") {
            script {
              withSecrets {
                // If release script exists, run it and let it handle versioning
                if (hasScript('release')) {
                  sh 'yarn release'
                } else {
                  // Otherwise, bump release version based on RELEASE_TYPE param
                  sh "yarn version --${params.RELEASE_TYPE.toLowerCase()}"
                }

                if (pipelineArgs.release.publish) {
                  // if someone's overridden publish; use run publish instead of yarn publish
                  if (hasScript('publish')) {
                    sh 'yarn run publish'
                  } else {
                    sh 'yarn publish --non-interactive'
                  }
                }
              }

              sh "git push --follow-tags origin ${env.BRANCH_NAME}"

              // Read package version again after release for Slack notification and build display name
              def version = readJSON([file: './package.json']).version
              if (version) {
                env.PACKAGE_VERSION = version
                currentBuild.displayName = "#${env.BUILD_NUMBER} v${version}"
              } else {
                env.PACKAGE_VERSION = sh(returnStdout: true, script: "git fetch --tags && git tag --points-at HEAD").trim()
                currentBuild.description = env.PACKAGE_VERSION
              }
            }
          }
        }
        post {
          always {
            script {
              notifySlack(pipelineArgs['slack_channel'])
            }
          }
        }
      }
    }
  }
}
