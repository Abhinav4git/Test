// amiPipeline

import cvent.jenkins.SlaveUtils
import groovy.json.JsonOutput

/**
 * @param   params  A map containing the following keys:
 *                    - cookbook_dirs          List of directories containing
 *                                             cookbooks used by the AMI
 *                    - cookbook_vendor_dirs   Directory in which to
 *                                             download chef cookbooks.
 *                                             The chef-solo provisioner should
 *                                             reference this directory for
 *                                             cookbook resolution.
 *                    - packerfile             Path to file used to drive packer
 *                    - application            Name of applications AMI being
 *                                             provisioned.
 */
def call(def params = [:]) {
  // Configure default params
  params['cookbook_dirs'] = params['cookbook_dirs'] ?: []
  params['cookbook_vendor_dir'] = params['cookbook_vendor_dir'] ?: './berks-cookbooks'
  params['packerfile'] = params['packerfile'] ?: 'main.json'
  params['aws_account'] = env.BRANCH_NAME == 'master' ? 'cvent-management': 'cvent-sandbox'
  params['env_type'] = env.BRANCH_NAME == 'master' ? 'production': 'staging'
  params['subnet_prefix'] = env.BRANCH_NAME == 'master' ? 'management': 'standard'

  pipeline {
    options {
      timestamps()
      ansiColor('xterm')
    }
    agent {
      label SlaveUtils.anyDockerNodeLabel()
    }
    environment {
        GIT_COMMIT = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%H'").trim()
    }
    stages {
      stage('Vendor Cookbooks') {
        steps {
          withCredentials([file(credentialsId: 'chef-jenkinsman-pem',
                                variable: 'CLIENT_PEM')]) {
            configFileProvider([configFile(fileId: 'chef-jenkinsman-knife',
                                           variable: 'KNIFE_RB')]) {
              script {
                def docker_args = [
                  "-v ${CLIENT_PEM}:/etc/chef/client.pem",
                  "-v ${KNIFE_RB}:/tmp/.chef/config.rb",
                  "-e HOME=/tmp",
                ].join(' ')

                docker.image('chef/chefdk:4.7.108').inside(docker_args) {
                  // Vendor the cookbooks for chef-solo to use
                  params.cookbook_dirs.each {
                    berksfile_path = "${it}/Berksfile"
                    if (fileExists(file: berksfile_path)) {
                      sh "berks vendor -b ${berksfile_path} ${params.cookbook_vendor_dir}"
                    } else {
                      error "No Berksfile found under ${it}"
                    }
                  }
                }
              }
            }
          }
        }
      }
      stage('Generate Packerfile') {
        steps {
          script {
            if (fileExists('main.json')) {
              echo "Using provided main.json file."
            } else {
              sh "docker pull docker.cvent.net/cvent/ami-toolbox:latest && docker run --rm -v ${WORKSPACE}:/work docker.cvent.net/cvent/ami-toolbox:latest generate --ami-config-file ami-config.yaml --packer-file main.json"
            }
          }
        }
      }
      stage('Validate Packer') {
        agent {
          docker {
            reuseNode true
            image 'cvent/packer'
            args "--entrypoint ''"
          }
        }
        environment {
          USER = 'packer'
          ENV_TYPE = "${params['env_type']}"
          SUBNET_PREFIX = "${params['subnet_prefix']}"
          LAST_MERGE = "${GIT_COMMIT}"
        }
        steps {
          script {
            sh "packer validate ${params.packerfile}"
          }
        }
      }
      stage('Build Packer AMI') {
        agent {
          docker {
            reuseNode true
            image 'cvent/packer'
            args "--entrypoint ''"
          }
        }
        environment {
          // USER variable is required by packer.
          // Does not need to be real / significant.
          USER = 'packer'
          HOME = '/tmp'
          AWS_ACCOUNT = "${params.aws_account}"
          AWS_REGION = 'us-east-1'
          ENV_TYPE = "${params['env_type']}"
          SUBNET_PREFIX = "${params['subnet_prefix']}"
          LAST_MERGE = "${GIT_COMMIT}"
        }
        steps {
          script {
            withCredentials([[$class: 'AmazonWebServicesCredentialsBinding',
                                  credentialsId: "${params.aws_account}-shared-jenkins"]]) {
              sh "packer build ${params.packerfile} | tee ami_out.txt"
            }
            ami_ids = sh(script:"/bin/bash -c 'cat ami_out.txt | egrep \"[A-Za-z]+-[A-Za-z]+-[0-9]: ami-\" | tr -d \":\"'", returnStdout:true)
            sh(script:"test -n \"${ami_ids}\"")
            sh(script:"echo \"Build completed on `date`\"")
          }
        }
      }
      stage('Post-Build Dev') {
        when {
          not {
            branch 'master'
          }
        }
        environment {
          // USER variable is required by packer.
          // Does not need to be real / significant.
          USER = 'packer'
          HOME = '/tmp'
        }
        steps {
            echo "Cleaning up created images."
            script {
              ami_list = []
              for (line in ami_ids.split('\n')) {
                ami_region = line.split(' ')[0]
                ami_id = line.split(' ')[1]
                ami_list << ami_id
                withCredentials([[$class: 'AmazonWebServicesCredentialsBinding',
                  credentialsId: "${params.aws_account}-shared-jenkins"]]) {
                  out = sh(script:"aws --region ${ami_region} ec2 deregister-image --image-id ${ami_id}", returnStatus: true)
                }
                if (out != 0) {
                  echo "Failed to delete ${ami_id} in the ${ami_region} region."
                }
              }
            }
        }
      }
      stage('Post-Build Master') {
        when {
          branch 'master'
        }
        environment {
          // USER variable is required by packer.
          // Does not need to be real / significant.
          USER = 'packer'
          HOME = '/tmp'
        }
        steps {
          script {
            payload_map = [amis:ami_ids.split('\n'), application:"${params.application}"]
            payload = JsonOutput.toJson(payload_map)
            echo "Payload: ${payload}"
            // Update SSM with latest ami-id
            withCredentials([[$class: 'AmazonWebServicesCredentialsBinding',
              credentialsId: "${params.aws_account}-shared-jenkins"]]) {
              sh(script:"aws --region us-east-1 lambda invoke --function-name AMIPipelineLambda --payload '${payload}' response.json")
            }
          }
        }
      }
    }
  }
}
