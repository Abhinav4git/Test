import cvent.linters.*

/**
 * Should be run in a node that provides access to docker and linux.
 * E.g `label: 'linux && docker'`
 */
def everything(params = [:]) {
  return [
    'CloudFormation Lint': { cloudFormation(params['cloudformation'] ?: [:]) },
    'Shell Lint': { shell(params['shell'] ?: [:]) },
    'YAML Lint': { yaml(params['yaml'] ?: [:]) }
  ]
}

def cloudFormation(params = [:]) {
  (new CloudFormationLinter(this, params)).lint(params['onlyChanged'])
}

def shell(params = [:]) {
  (new ShellLinter(this, params)).lint(params['onlyChanged'])
}

def yaml(params = [:]) {
  (new YamlLinter(this, params)).lint(params['onlyChanged'])
}
