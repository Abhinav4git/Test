#!/usr/bin/groovy

/**
 * Builds a docker image for a java service and uploads it to ECR. The deploy-aws-docker must be cloned in the
 * deploy-aws-docker directory for this command to function.
 * @param groupId Maven group ID
 * @param artifactIds One or more Maven artifact IDs
 * @param version artifact version
 * @param platform deployment platform (eg. dropwizard)
 * @param verbose enable verbose logging
 * @return map - key = artifactId, value = ECR image tag
 *
 * Requires:
 * ssh://git@git.core.cvent.org:7999/stash/dep/deploy-aws-docker.git
 * ssh://git@git.core.cvent.org:7999/stash/dep/hogan-configs.git
 */
def call(Map config) {
  def groupId = config.groupId
  def artifactIds = config.artifactIds
  def version = config.version
  def platform = config.platform
  def verbose = config.get('verbose', false).toBoolean()

  logInfo "Build docker image for modules: ${artifactIds}"

  def result = [:]

  dir('deploy-aws-docker') {
    withSecrets {
      artifactIds.each { artifactId ->
        def vars = [
          ARTIFACT_ID      : artifactId,
          ASYNC            : true,
          FORCE_REBUILD    : false,
          GROUP_ID         : groupId,
          HOGAN_CONFIGS_DIR: "${env.WORKSPACE}/hogan-configs",
          VERSION          : version,
          BUILD_WORKSPACE  : env.WORKSPACE,
          VERBOSE         : verbose ? '1' : '0'
        ]

        withEnv(vars.collect { it.key + '=' + it.value }) {
          // For some reason passing PLATFORM in withEnv does not work.
          sh script: "PLATFORM=${platform} ./build_push_docker_img.sh"
        }

        def props = readProperties file: 'service_info.properties'
        result[artifactId] = props['ECR_IMAGE_TAG']
      }
    }
  }

  return result
}
