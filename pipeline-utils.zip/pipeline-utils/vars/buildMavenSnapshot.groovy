#!/usr/bin/groovy
import cvent.java.MavenUtils
import cvent.jenkins.SlaveUtils
import cvent.stash.Utils as Stash

/**
 * Builds a SNAPSHOT version of a Java Maven project.
 * @param coverage 'clover', 'jacoco', or null to not run coverage (Default: 'jacoco')
 * @param deploy true to deploy artifacts to nexus (Default: false)
 * @param properties allows extra maven arguments to be used, format(properties : [key : value ]) will build
 *        extra commands in format "-Dkey=value"
 */
def call(Map config) {
  config = config ?: [:]

  def branch = Stash.getBranch()
  def commit = Stash.getCommit()
  List warnings

  if (SlaveUtils.isECS()) {
    // ECS workers have the required build tools
    warnings = build(config, branch, commit)
  } else {
    // Required to run docker within docker for testcontainers
    def dockerArgs = [
      '-v "$HOME/.m2:/home/jenkins/.m2:rw"',
      '-v /var/run/docker.sock:/var/run/docker.sock',
      "--group-add ${sh(returnStdout: true, script: 'getent group docker | cut -d: -f3').trim()}",
      // Required for services which run node
      '-v "$HOME/.npm:/.npm:rw"',
      '-v "$HOME/.package_cache:/home/jenkins/.package_cache"',
      '-v "$HOME/.ssh:/home/jenkins/.ssh:rw"',
    ].join(' ')

    sh "docker pull ${MavenUtils.getBuildImage()}"
    docker.image(MavenUtils.getBuildImage()).inside(dockerArgs) {
      warnings = build(config, branch, commit)
    }
  }

  return warnings
}

def sonar(List cmds, Map config, String mvn, String branch) {
  if (config.get('runSonar', false)) {
    // TODO: Enable once sonar enterprise edition is installed
    String sonar = '' // (branch == 'master' ? '' : "-Dsonar.branch.name=${branch}")

    // "set +e" so failure to contact sonar does not fail the build
    cmds << "set +e; ${mvn} sonar:sonar -Dsonar.host.url=http://sonar.core.cvent.org/ ${sonar}; set -e"
  }
}

def isCloverInPom(String mvn) {
  def status = sh script: "${mvn} help:effective-pom -Pcoverage | grep -q clover-maven-plugin", returnStatus: true
  return status == 0
}

def build(Map config, String branch, String commit) {
  def threads = config.get('threads', '')
  if (threads != '') {
      threads = "-T " + threads
  }
  String extraMavenArgs = config.get('properties', [:]).inject("") { result, e ->
    return result + " -D${e.key}=\"${e.value}\""
  }
  def coverage = config.get('coverage', 'jacoco')
  def deploy = config.get('deploy', false)
  List warnings = []
  withMaven(options:[artifactsPublisher(disabled: true)]) {
    def props = [
      "${threads}",
      "-DgitCommit=${commit}",
      "-DgitBranch=${branch}",
      "--batch-mode",
      "-Dmaven.javadoc.skip=true",
      "-Prelease",
      "-Pdefault",
      "${extraMavenArgs}"
    ].join(' ')
    String mvn = "export PATH=\$MVN_CMD_DIR:\$PATH && mvn"
    List cmds = []
    boolean hasClover = isCloverInPom(mvn)

    if (fileExists('.nvmrc')) {
      cmds << 'source $HOME/.nvm/nvm.sh 2> log-nvm-source.txt'
      cmds << 'nvm use 2> log-nvm-use.txt || (echo "ERROR: nvm use failed. Ensure https://stash.cvent.net/projects/DOC/repos/dropwizard-jenkins/browse contains the required version of Node.js"; exit 1)'
    }

    if (coverage == 'jacoco') {
      if (hasClover) {
        cmds << "${mvn} org.jacoco:jacoco-maven-plugin:prepare-agent -U ${props} ${deploy ? 'deploy' : 'verify'}"
        warnings << "Please update from clover to jacoco. See https://wiki.cvent.com/display/RD/Jacoco+Code+Coverage+Migration"
      } else {
        cmds << "${mvn} clean ${deploy ? 'deploy' : 'verify'} -U ${props} -Pcoverage"
      }
      sonar(cmds, config, mvn, branch)
    } else if (coverage == 'clover') {
      cmds << "${mvn} clean verify -U -Pcoverage ${props}"
      sonar(cmds, config, mvn, branch)

      if (deploy) {
        // clover instruments the class files, therefore we need to rebuild to get non-instrumented classes to deploy
        cmds << "${mvn} clean deploy ${props}"
      }

      warnings << "Please update from clover to jacoco. See https://wiki.cvent.com/display/RD/Jacoco+Code+Coverage+Migration"
    } else {
      cmds << "${mvn} clean -U ${props} ${deploy ? 'deploy' : 'verify'}"
    }

    sh cmds.join("\n")
  }

  return warnings
}