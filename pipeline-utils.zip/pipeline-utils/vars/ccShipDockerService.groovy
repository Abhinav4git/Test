import crowdcompass.jenkins.ShipDockerService

def getShaOfTarget(String target = 'HEAD') {
  return sh(script: "git rev-parse -q --verify origin/${target} || git rev-parse -q --verify ${target}", returnStdout: true).trim()
}

def call(args = [:]) {
  String APPLICATION = args['application']
  String SILO_APPLICATION = args['silo_application'] ?: APPLICATION
  Boolean NO_DATABASE = args['no_database'] ?: false

  pipeline {
    agent {
      label 'redhat'
    }
    parameters {
      // using 'branch' here for the meantime to support backwards combatitibity
      string(name: 'branch', defaultValue: 'master', description: 'git target (branch, sha, tag)')
      string(name: 'silo', defaultValue: 'qa', description: 'silo name')
    }
    options { timestamps() }

    stages {
      stage ('ensure git state') {
        when {
          expression { return env.GIT_COMMIT != getShaOfTarget(params.branch) }
        }
        steps {
          error """
            The git sha you are building does not match the "branch" (git target) paramater specified.
            SHA specified ${getShaOfTarget(params.branch)} of target "${params.branch}"
            SHA that would be built :: ${env.GIT_COMMIT}"
            Please ensure this job is configured correctly, and redeploy.
          """
        }
      }
      stage ('deploying') {
        steps {
          script {
            ship = new ShipDockerService(params.silo, SILO_APPLICATION, env.GIT_COMMIT)

            ship.lookupConsulData(this)
            ship.build(this)

            if (!NO_DATABASE) {
              ship.migrateDatabase(this)
            }

            ship.update(this)
          }
        }
      }
      stage ('update code docs for lower environments') {
        agent none
        steps {
          slackSend color: "#B0BEC5", message: "Updating documentation for ${params.silo} ${APPLICATION}..."
          script {
            try {
              if (params.silo == "qa" || params.silo == "staging" || params.silo == "hotfix" ) {
                node ('redhat') {
                  build job: "Script Runner - Lower Environments", propagate: false, wait: false, parameters: [
                    [$class: 'StringParameterValue', name: 'branch', value: params.branch],
                    [$class: 'StringParameterValue', name: 'environment', value: params.silo],
                    [$class: 'StringParameterValue', name: 'repo', value: APPLICATION],
                    [$class: 'StringParameterValue', name: 'command', value: "bundle exec rake doc:build[${params.silo},${APPLICATION}]"],
                  ]
                }
              }
            } catch (err) {
              slackSend color: "#E53935", message: "doc update failed: ${APPLICATION} to ${params.silo}"
              slackSend message: "This is the error, ${err}"
            }
          }
        }
      }
    }
    post {
      success {
        script {
          ccNotify.notifyDataDog(APPLICATION, params.silo, params.branch, "Deployed ${APPLICATION} artifact ${params.branch} to ${params.silo}", env.USER);

          ccNotify.slackMessageDetail(params.silo,'good',"SUCCESS: ${env.JOB_NAME.toUpperCase()} #${env.BUILD_NUMBER}","<${env.BUILD_URL}|Silo: ${params.silo.toUpperCase()} Target: ${params.branch} SHA: ${env.GIT_COMMIT}>")
          if (params.branch == "master") {
            build job: 'checkmarxScan', wait: false, parameters: [
              [$class: 'StringParameterValue', name: 'repo', value: APPLICATION],
              [$class: 'StringParameterValue', name: 'branch', value: 'master'],
              [$class: 'StringParameterValue', name: 'type', value: 'microservice']
            ]
          }
        }
      }
      failure {
        script {
          ccNotify.slackMessageDetail(params.silo,'bad',"FAILED: ${env.JOB_NAME.toUpperCase()} #${env.BUILD_NUMBER}","<${env.BUILD_URL}|Silo: ${params.silo.toUpperCase()} Target: ${params.branch} SHA: ${env.GIT_COMMIT}>")
        }
      }
    }
  }
}
