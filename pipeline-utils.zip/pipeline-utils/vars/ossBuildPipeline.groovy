// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// ossBuildPipeline

// Libraries
import cvent.mobile.OSSUtils

def Map<String, Map<String, String>> ossEnvironments() {
  return [
          'alpha'  : [slack: '#oss-alpha-alerts'],
          'dev1'   : [slack: '#sre-mobile-test'],
          'dev2'   : [slack: '#oss-silver'],
          'dev3'   : [slack: ''],
          'dev4'   : [slack: '#oss-white'],
          'dev5'   : [slack: '#os-blue-deploy'],
          'dev6'   : [slack: '#oss-black-deploy'],
          'dev7'   : [slack: '#oss-red-deploy'],
          'dev8'   : [slack: '#oss-yellow-deploy'],
          'dev9'   : [slack: '#oss-purple-alerts'],
          'dev10'  : [slack: '#oss-bronze-deploy'],
          'dev11'  : [slack: '#oss-appointments'],
          'L1'     : [slack: '#oss-performance'],
          'L2'     : [slack: '#oss-performance'],
          'ci'     : [slack: '#oss-alpha-alerts'],
          'staging': [slack: '#oss-stage-info'],
          'sg50'   : [slack: '#oss-stage-info'],
          's820'   : [slack: '#oss-stage-info'],
          'ld50'   : [slack: '#oss-performance'],
  ]
}

def String slackChannel(String environment) {
  return ossEnvironments().get(environment, [:])['slack']
}

def boolean validateEnvironments(String environments) {
  valid = true
  environments.split(',').each { environment ->
    if (!ossEnvironments().containsKey(environment)) {
      OSSUtils.logError("${environment} is not supported by this pipeline, please fix the environment name or use release-bot to deploy")
      valid = false
    }
  }
  return valid
}

// Arguments:
//  trunk - The branch to use for deploying and testing to regions
//  language - The language used by the repository. One of 'node' or 'java'
//  docker - Only supported for 'java' repositories. Whether building with docker is supported.
//  environments - A list of environments to deploy to
//  api_test_name - The name of the API test to run; Add a branch name after an '@' symbol i.e. testName@branch
//  client_test_name - The name of the client test to run; ; Add a branch name after an '@' symbol i.e. testName@branch
//  performance_test_name - The name of the performance test to run; ; Add a branch name after an '@' symbol i.e. testName@branch
//
// ECS Specific Additional PARAMETERS
//    ecs - OPTIONAL Deploy to ECS in AWS or on premise, DEFAULT=false (DEPLOY to on PREM, true for ECS)
//    aws_account - OPTIONAL Cvent AWS account to deploy into DEFAULT=development
//    ecs_cluster - OPTIONAL ECS cluster to deploy into DEFAULT=shared1
//    memory - OPTIONAL Memory reservation in MB DEFAULT=128
//    instance_count -  OPTIONAL Instances of the application that should be deployed, DEFAULT=2
//    is_consumer -OPTIONAL IS_CONSUMER true\false, DEFAULT=false
//
def call(args = [:]) {
  pipeline {
    parameters {
      choice(name: 'ENV',
              choices: "\n${ossEnvironments().keySet().join('\n')}",
              description: '''The OSS environment to deploy to.  Leave blank to use the environments specified in the Jenkinsfile''')
    }

    agent { label 'linux' }

    options {
      timestamps()
      ansiColor('xterm')
    }

    environment {
      trunk_branch = "${args['trunk'] ?: 'develop'}"
      repo_type = "${args['language'] ?: 'java'}"
      docker = "${args['docker'] ?: true}"
      environments = "${params.ENV ?: (source_branch_name == trunk_branch) ? args['environments'].join(',') : ''}"
      enable_api_tests = "${args['api_test_name'] != null}"
      api_test_name = "${args['api_test_name'] ?: ''}"
      enable_client_tests = "${args['client_test_name'] != null}"
      client_test_name = "${args['client_test_name'] ?: ''}"
      client_test_url = "https://mobile-jenkins.core.cvent.org/job/pt-web-ui-automation-ci/"
      enable_performance_tests = "${args['performance_test_name'] != null}"
      performance_test_name = "${args['performance_test_name'] ?: ''}"
      performance_test_url = "https://plt-jenkins.core.cvent.org/view/OnSite%20Solutions/job/onsite-solutions-oss-services/"
      qe_slack = "${args['qe_slack'] ?: null}"
      hogan_configs_branch = "${args['hogan_configs_branch'] ?: 'master'}"
      service_root = "${args['service_root'] ?: null}"
      platform = "${args['platform'] ?: 'dropwizard'}"
      checkmarx = "${args['checkmarx'] ?: false}"

      // ECS Specific Additional PARAMETERS
      ecs = "${args['ecs'] ?: false}"
      aws_account = "${args['aws_account'] ?: 'development'}"
      ecs_cluster = "${args['ecs_cluster'] ?: 'shared1'}"
      test_user_docker = "${args['test_user_docker'] ?: false}"
      java_version = "${args['java_version'] ?: '8'}"
      python_pipeline = "${args['python_pipeline'] ?: false}"

      // Get the git url
      git_url = sh(returnStdout: true, script: "git config --get remote.origin.url").trim()
      // Get the last commit hash
      git_commit = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()
      // Hack until JENKINS-47617 is resolved
      source_branch_name = sh(script: "git ls-remote --heads | grep -m 1 ${git_commit} | awk '{print \$2}' | sed -e 's#.*refs/heads/##'", returnStdout: true).trim()
    }

    stages {
      stage('Print Environment') {
        steps {
          printEnvInfo()
        }
      }

      stage('Build Snapshot And Checkmarx Scan') {
        parallel {
          stage("Build Snapshot") {
            steps {
              script {
                // Send Message to start build to all environments.
                def build_messages = [:]
                def blue_color = '#4C4CFF'

                if (env.environments != null) {
                  env.environments.split(',').each { environment ->
                    build_messages[environment] = {
                      def slack_name = slackChannel(environment)
                      def slack_message = "building ${env.git_url} for ${environment}"
                      slack_message += "\n branch: ${env.source_branch_name}"
                      slack_message += "\n${env.JOB_NAME} [${env.BUILD_NUMBER}] <${env.BUILD_URL}|Open>"
                      OSSUtils.logInfo("Sending ' ${slack_message}' to ${slack_name} ")
                      slackSend message: "Starting ${slack_message}", channel: slack_name, color: blue_color
                    }
                  }
                  parallel build_messages
                }

                try {
                  if (env.repo_type == 'node') {
                    // start building node application
                    buildResult = OSSUtils.buildNodeSnapshot(env.git_url, env.source_branch_name)
                    // group_id, snapshot_version and artifact_id are the output of the build jon
                    env.group_id = buildResult.buildVariables.groupId
                    env.snapshot_version = buildResult.buildVariables.version
                    env.artifact_id = buildResult.buildVariables.artifactId

                    // Build Docker image and push to ECS
                    params = [
                            'group'               : env.group_id,
                            'artifact'            : env.artifact_id,
                            'version'             : env.snapshot_version,
                            'hogan_configs_branch': env.hogan_configs_branch,
                            'platform'            : 'node',
                    ]
                    env.ecr_image_tag = OSSUtils.pushNodeSnapshotECR(params)
                    // For ECS deployment, snapshot_modules is a list of [service_name, ecr_image_tag]
                    snapshot_modules = [[buildResult.buildVariables.artifactsToDeploy, env.ecr_image_tag]]
                    OSSUtils.logInfo('-------Snapshot ECR tag-----------------')
                    snapshot_modules.each { module ->
                      OSSUtils.logInfo(module[0])
                      OSSUtils.logInfo(module[1])
                    }
                  }
                  if (env.repo_type == 'java') {
                    // start building java application
                    if (env.docker == 'true') {
                      env.group_id = readMavenPom().getGroupId()

                      // Snapshot version
                      env.snapshot_version = readMavenPom().getVersion()
                      params = [
                              'git_url'         : env.git_url,
                              'BRANCH_NAME'     : env.source_branch_name,
                              'platform'        : env.platform,
                              'test_user_docker': env.test_user_docker
                      ]
                      snapshot_modules = OSSUtils.buildJavaSnapshot(params)

                      // For ECS deployment, snapshot_modules is a list of [service_name, ecr_image_tag]
                      OSSUtils.logInfo('-------Snapshot ECR tag-----------------')
                      snapshot_modules.each { module ->
                        OSSUtils.logInfo(module[0])
                        OSSUtils.logInfo(module[1])
                      }
                    } else {
                      // Missing on MavenUtils, add it somewhere ot just keep it here for reference.
                      // This job is deprecated in Jenkins, will just keep it here
                      buildResult = build job: 'jdk8-snapshot-dropwizard-service', parameters: [
                              string(name: "GIT_REPO", value: env.git_url),
                              string(name: "GIT_BRANCH", value: env.source_branch_name),
                              string(name: "OPTIMIZATIONS", value: 'dev'),
                      ]
                    }
                  }
                }
                catch (error) {
                  // Send Build Failure to all environments
                  if (env.environments != null) {
                    def error_messages = [:]
                    env.environments.split(',').each { environment ->
                      error_messages[environment] = {
                        def slack_name = slackChannel(environment)
                        def slack_message = "building ${env.git_url} for ${environment}"
                        slack_message += "\n branch: ${env.source_branch_name}"
                        slack_message += "\n${env.JOB_NAME} [${env.BUILD_NUMBER}] <${env.BUILD_URL}|Open>"
                        OSSUtils.logError("Sending 'FAILURE ${slack_message}' to ${slack_name}")
                        slackSend message: "FAILURE ${slack_message}", channel: slack_name, color: 'danger'
                      }
                    }
                    parallel error_messages
                  }
                  // halt the pipeline if build failed
                  currentBuild.result = 'FAILURE'
                  throw error
                }
              }
            }
          }

          stage("Checkmarx Scan") {
            when {
              beforeAgent true
              environment name: 'checkmarx', value: 'true'
              expression {
                return env.environments.contains('alpha')
              }
            }
            steps {
              script {
                try {
                  runCheckmarx()
                } catch (Exception e) {
                  logError('Checkmarx run failed: ' + e.getMessage())
                  e.printStackTrace()
                }
              }
            }
          }
        }
      }

      stage('Validate environments') {
        when {
          beforeAgent true
          not { environment name: 'environments', value: '' }
        }
        steps {
          script {
            if (!validateEnvironments(env.environments)) {
              currentBuild.result = 'ABORTED'
              error('Aborted pipeline due to unsupported environment')
            }
          }
        }
      }

      stage('Deploy') {
        when {
          beforeAgent true
          not { environment name: 'environments', value: '' }
        }
        steps {
          script {
            // Send Message to start deploy to all environments.
            def deploys = [:]
            env.environments.split(',').each { environment ->
              deploys[environment] = {

                def slack_name = slackChannel(environment)
                def slack_message = "deployment of ${env.git_url} ${env.snapshot_version} for ${environment}"
                slack_message += "\n${env.JOB_NAME} [${env.BUILD_NUMBER}] <${env.BUILD_URL}|Open>"

                OSSUtils.logInfo("Sending 'Starting ${slack_message}' to ${slack_name}")
                slackSend message: "Starting ${slack_message}", channel: slack_name, color: 'good'

                try {
                  snapshot_modules.each { module ->
                    OSSUtils.logInfo("deploying ${module[0]}")
                    if (!service_root) {
                      service_root = "${module[0]}/v1"
                    }
                    params = [
                            'module'              : module,
                            'aws_account_name'    : env.aws_account,
                            'ecs_cluster_name'    : env.ecs_cluster,
                            'git_url'             : env.git_url,
                            'branch_name'         : env.source_branch_name,
                            'group'               : env.group_id,
                            'ecs'                 : env.ecs,
                            'version'             : env.snapshot_version,
                            'location'            : environment,
                            'artifact'            : env.artifact_id,
                            'language'            : env.repo_type,
                            'service_root'        : service_root,
                            'hogan_configs_branch': env.hogan_configs_branch,
                            'platform'            : env.platform,
                            'java_version'        : env.java_version,
                            'python_pipeline'     : env.python_pipeline
                    ]
                    OSSUtils.logInfo("version: ${env.snapshot_version} & the target location: ${environment}")
                    OSSUtils.deployMobile(params)
                  }
                  OSSUtils.logInfo("Sending 'SUCCESS ${slack_message}' to ${slack_name}")
                  slackSend message: "SUCCESS ${slack_message}", channel: slack_name, color: 'good'
                } catch (error) {
                  OSSUtils.logError("Sending 'FAILURE ${slack_message}' to ${slack_name}")
                  slackSend message: "FAILURE ${slack_message}", channel: slack_name, color: 'danger'

                  // halt the pipeline if deploy failed
                  currentBuild.result = 'FAILURE'
                  throw error
                }
              }
            }
            parallel deploys
          }
        }
      }

      stage('Running Client Tests') {
        when {
          beforeAgent true
          allOf {
            environment name: 'enable_client_tests', value: 'true'
            not { environment name: 'environments', value: '' }
          }
        }
        steps {
          script {
            def tests = [:]

            List<String> clientTestInfo = env.client_test_name.tokenize('@')
            testSuite = "@" + clientTestInfo.get(0) + ",%20not%20@failing"
            testBranch = clientTestInfo.size() > 1 ? clientTestInfo.get(1) : 'master'

            env.environments.split(',').each { environment ->
              tests[environment] = {
                def slack_name = (environment == 'alpha' && env.qe_slack != null) ? env.qe_slack : slackChannel(environment)
                def slack_message = "Running client tests of ${env.git_url} for ${environment} <${client_test_url}|Open>"
                OSSUtils.logInfo("Sending 'Starting ${slack_message}' to ${slack_name}")
                slackSend message: slack_message, channel: slack_name, color: 'good'

                try {
                  params = ['type'         : 'client-tests',
                            'branch'       : testBranch,
                            'env'          : environment,
                            'tests'        : testSuite,
                            'slack_channel': slack_name.replace("#", "%23")
                  ]
                  OSSUtils.mobileTest(params)
                } catch (error) {
                  OSSUtils.logError("Sending 'FAILURE encountered when ${slack_message}' to ${slack_name}")
                  slackSend message: "FAILURE encountered when ${slack_message}", channel: slack_name, color: 'danger'

                  currentBuild.result = 'FAILURE'
                }
              }
            }
            parallel tests
          }
        }
      }

      stage('Running API Tests') {
        when {
          beforeAgent true
          allOf {
            environment name: 'enable_api_tests', value: 'true'
            not { environment name: 'environments', value: '' }
          }
        }
        steps {
          script {
            def tests = [:]

            List<String> apiTestInfo = env.api_test_name.tokenize('@')
            testSuite = apiTestInfo.get(0)
            testBranch = apiTestInfo.size() > 1 ? apiTestInfo.get(1) : 'develop'

            env.environments.split(',').each { environment ->
              tests[environment] = {
                def slack_name = (environment == 'alpha' && env.qe_slack != null) ? env.qe_slack : slackChannel(environment)
                def slack_message = "Running API tests of ${env.git_url} for ${environment}"
                OSSUtils.logInfo("Sending 'Starting ${slack_message}' to ${slack_name}")
                slackSend message: slack_message, channel: slack_name, color: 'good'

                try {
                  params = [
                          'type'         : 'api-tests',
                          'branch'       : testBranch,
                          'env'          : environment,
                          'tests'        : testSuite,
                          'slack_channel': slack_name
                  ]
                  OSSUtils.mobileTest(params)
                } catch (error) {
                  OSSUtils.logError("Sending 'FAILURE encountered when ${slack_message}' to ${slack_name}")
                  slackSend message: "FAILURE encountered when ${slack_message}", channel: slack_name, color: 'danger'

                  currentBuild.result = 'FAILURE'
                }
              }
            }
            parallel tests
          }
        }
      }

      stage('Running Performance Tests') {
        when {
          beforeAgent true
          allOf {
            environment name: 'enable_performance_tests', value: 'true'
            not { environment name: 'environments', value: '' }
          }
        }
        steps {
          script {
            List<String> perfomanceTestInfo = env.performance_test_name.tokenize('@')
            testSuite = "load." + perfomanceTestInfo.get(0)
            testBranch = "develop"
            def environment = "alpha"
            def slack_name = slackChannel("L2")
            def slack_message = "Running performance tests of ${env.git_url} for ${environment}"
            OSSUtils.logInfo("Kicked off performance tests of ${env.git_url} for ${environment} <${performance_test_url}|Open>")
            slackSend message: slack_message, channel: slack_name, color: 'good'

            try {
              params = ['type'         : 'performance-tests',
                        'branch'       : testBranch,
                        'env'          : environment,
                        'tests'        : testSuite,
                        'slack_channel': slack_name.replace("#", "%23")
              ]
              OSSUtils.mobileTest(params)
            } catch (error) {
              OSSUtils.logError("Sending 'FAILURE encountered when ${slack_message}' to ${slack_name}")
              slackSend message: "FAILURE encountered when ${slack_message}", channel: slack_name, color: 'danger'

              currentBuild.result = 'FAILURE'
            }
          }
        }
      }
    }
  }
}
