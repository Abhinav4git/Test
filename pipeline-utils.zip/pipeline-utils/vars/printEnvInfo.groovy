// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// printEnvInfo
def call(Map config = [:]) {
    print 'ENVIRONMENT'.center(30, '-')
    sh 'printenv | sort'
    print 'PARAMETERS'.center(30, '-')
    print params
    print 'ARGUMENTS'.center(30, '-')
    print config
}
