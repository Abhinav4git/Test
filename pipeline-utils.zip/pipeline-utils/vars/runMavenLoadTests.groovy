#!/usr/bin/groovy

/**
 * runMavenLoadTests
 *
 * Runs maven load tests against a deployed service
 * @param environments one or more environments to run load tests
 *
 * Requires:
 * ssh://git@git.core.cvent.org:7999/stash/dep/hogan-configs.git
 * ssh://git@git.core.cvent.org:7999/stash/dep/deploy-aws-docker.git
 */
def call(Map config) {

    validateConfig('runMavenLoadTests', config, [
        ['environments', { !it.isEmpty() }, 'must provide at least one environment']
    ])

    def moduleNames = readMavenPom().getProperties().get('modules.to.load-test')

    if (!moduleNames) {
        echo "Load tests will not run: modules.to.load-test missing or empty in pom.xml"
        return null
    }

    withSecrets {
        config.environments.each { environment ->
            def vars = [
                ENVIRONMENT: environment,
                MODULE_NAMES: moduleNames
            ]

            echo "Running load tests for environment [${environment}]"

            withEnv(vars.collect { it.key + '=' + it.value }) {
                try {
                    dir('deploy-aws-docker') {
                        sh "./dropwizard-load-tests.sh"
                    }
                } finally {
                    gatlingArchive()
                }
            }
        }
    }
}