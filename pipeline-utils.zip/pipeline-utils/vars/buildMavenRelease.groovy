#!/usr/bin/groovy

import cvent.stash.Utils as Stash
import cvent.jenkins.SlaveUtils
import cvent.java.MavenUtils

/**
 * Builds a RELEASE version of a Java Maven project and deploys it.
 * @param coverage 'clover', 'jacoco', or null to not run coverage (Default: 'jacoco')
 * clover
 */
def call(Map config) {
  config = config ?: [:]

  String branch = Stash.getBranch()
  String commit = Stash.getCommit()
  List warnings

  if (SlaveUtils.isECS()) {
    // ECS workers have the required build tools
    warnings = build(config, branch, commit)
  } else {
    // Required to run docker within docker for testcontainers
    def dockerArgs = [
      '-v "$HOME/.m2:/home/jenkins/.m2:rw"',
      '-v /var/run/docker.sock:/var/run/docker.sock',
      "--group-add ${sh(returnStdout: true, script: 'getent group docker | cut -d: -f3').trim()}",
      // Required for pushing to git
      "-v ${env.HOME}/.ssh:/home/jenkins/.ssh:rw",
      // Required for services which run node
      '-v "$HOME/.npm:/.npm:rw"',
      '-v "$HOME/.package_cache:/home/jenkins/.package_cache"',
    ].join(' ')

    sh "docker pull ${MavenUtils.getBuildImage()}"
    docker.image(MavenUtils.getBuildImage()).inside(dockerArgs) {
      warnings = build(config, branch, commit)
    }
  }
  return warnings
}

def isCloverInPom(String mvn) {
  def status = sh script: "${mvn} help:effective-pom | grep -q clover-maven-plugin", returnStatus: true
  return status == 0
}

def sonar(List cmds, Map config, String mvn, String branch) {
  if (config.get('runSonar', true)) {
    // TODO: Enable once sonar enterprise edition is installed
    String sonar = '' // (branch == 'master' ? '' : "-Dsonar.branch.name=${branch}")

    // "set +e" so failure to contact sonar does not fail the build
    cmds << "set +e; ${mvn} sonar:sonar -Pdefault -Dsonar.host.url=http://sonar.core.cvent.org/ ${sonar}; set -e"
  }
}

def build(Map config, String branch, String commit) {
  def threads = config.get('threads', '')
  if (threads != '') {
      threads = "-T " + threads
  }
  def coverage = config.get('coverage', true)
  List warnings = []

  def props = [
    "${threads}",
    "-DgitCommit=${commit}",
    "-DgitBranch=${branch}",
    "--batch-mode",
    "-Dmaven.javadoc.skip=true",
    "-Prelease",
    "-Pdefault"
  ].join(' ')
  String mvn = "export PATH=\$MVN_CMD_DIR:\$PATH && mvn"
  List cmds = []
  boolean hasClover = isCloverInPom(mvn)

  // Workaround https://issues.jenkins-ci.org/browse/JENKINS-46050
  sh 'git config user.email "jenkins@cvent.com"'
  sh 'git config user.name "Jenkins"'

  if (coverage == 'jacoco') {
    // The maven release plugin runs two builds which in turn runs unit tests twice. Many unit tests take a long time to
    // run. The code coverage build already ran unit tests so we don't need to run them again.
    // The release plugin runs "clean" which removes the code coverage unit test results. Therefore, we run code
    // coverage in a separate withMaven step so the test results are published to Jenkins.
    // This ensures we run tests only once instead of three times.
    withMaven(options: [artifactsPublisher(disabled: true)]) {
      initNvm(cmds)

      if (hasClover) {
        // We cannot run -Pcoverage in this case otherwise clover will run
        cmds << "${mvn} org.jacoco:jacoco-maven-plugin:prepare-agent clean verify -U ${props}"
        warnings << "Please update from clover to jacoco. See https://wiki.cvent.com/display/RD/Jacoco+Code+Coverage+Migration"
      } else {
        cmds << "${mvn} clean verify -U ${props} -Pcoverage"
      }

      sonar(cmds, config, mvn, branch)
      sh cmds.join("\n")
    }

    withMaven(options: [artifactsPublisher(disabled: true)]) {
      cmds = []
      initNvm(cmds)
      cmds << "${mvn} release:prepare release:perform -U ${props} -Darguments=\"-Dmaven.test.skip.exec=true -Dmaven.javadoc.skip=true -DgitBranch=${branch}\""
      sh cmds.join("\n")
    }
  } else {
    withMaven(options: [artifactsPublisher(disabled: true)]) {
      initNvm(cmds)

      if (coverage == 'clover') {
        cmds << "${mvn} clean verify -Pcoverage ${props} -U"
        warnings << "Please update from clover to jacoco. See https://wiki.cvent.com/display/RD/Jacoco+Code+Coverage+Migration"
        sonar(cmds, config, mvn, branch)
      }

      cmds << "${mvn} clean release:prepare release:perform -U ${props}"
      sh cmds.join("\n")
    }
  }
  return warnings
}

def initNvm(List cmds) {
  // nvm needs to run in the same shell instance as maven therefore we add these commands for every shell
  if (fileExists('.nvmrc')) {
    cmds << 'source $HOME/.nvm/nvm.sh 2> log-nvm-source.txt'
    cmds << 'nvm use 2> log-nvm-use.txt || (echo "ERROR: nvm use failed. Ensure https://stash.cvent.net/projects/DOC/repos/dropwizard-jenkins/browse contains the required version of Node.js"; exit 1)'
  }
}
