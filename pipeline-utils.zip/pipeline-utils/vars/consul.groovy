import groovy.transform.Field

@Field String consulHost = 'consul.crwd.cc'
@Field String vaultHost = 'vault.crwd.cc'
@Field String registry = 'docker-registry.crwd.cc'
@Field String registryVersion = 'v2'
@Field String imagePrefix = "crowdcompass"

//Gets a value from consul
GString getEnvironmentData(value,region='us-west-2') {
  def url = "http://${consulHost}/v1/kv/${value}?raw&dc=${region}"
  def connection =  new URL(url).openConnection() as HttpURLConnection

  connection.setRequestProperty( 'Accept', 'application/json' )

  if ( connection.responseCode == 200 ) {
    return "${connection.inputStream.text}"
  }
  else {
    println "INFO: ${url} does not exist."
    return null
  }
}

//Writes a value to consul
//Will be replaced at a later time with Git/Consul Workflow
def putSiloData(application,environment,key,value,region='us-west-2') {
  sh "curl --silent -X PUT http://${consulHost}/v1/kv/${environment}/config/services/${application}/${key} <<< ${value} > /dev/null"
}

// Returns a single IP of a specifc instance correlated to a role. This is useful for running ad-hoc containers
// We use AWS Cloud Map to query for a list of servers in an environment pull the IP used
GString getDockerHost(type, environment, awsRegion, vpcId, awsId) {
  withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', credentialsId: "${awsId}", accessKeyVariable: 'AWS_ACCESS_KEY_ID', secretKeyVariable: 'AWS_SECRET_ACCESS_KEY']]) {
    Random rnd = new Random()
    dockerNodes = sh (returnStdout:true, script: '#!/bin/bash -e\n'+"""docker run --rm \
      -e AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID} \
      -e AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY} \
      -e AWS_DEFAULT_REGION=${awsRegion} \
      ${registry}/${imagePrefix}/aws_1.18.30 aws servicediscovery discover-instances --namespace-name ${vpcId} --service-name ${environment}-${type} | jq -r '.Instances[] | .Attributes | .AWS_INSTANCE_IPV4'""").split("\n")
    if ( dockerNodes.size() == 0 ) {
      error("No docker hosts found.\nDoes the AWS Cloud Map Namespace ${vpcId} and service ${silo}-${type} contain a healthy host?")
    }
    else {
      return dockerNodes[rnd.nextInt(dockerNodes.size())]
    }
  }
}
