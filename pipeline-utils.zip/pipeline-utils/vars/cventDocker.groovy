// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// cventDocker

import cvent.docker.DockerUtils

/**
*  @param args - A map consisting of:
*                 name - The name of the image to build
*                 tag - The tag of the image to build
*                 path - Path to Dockerfile to build
*                 tests - path to inspec profile (relative to Dockerfile directory)
*                 registries - List of repositories to publish to
*                 push - boolean controlling whether to push the image to the registries
*                 entrypoint: command to run to keep the container alive while testing.
*                             Set to false to use entrypoint in the Dockerfile.
*                             If unspecified, will default to `cat`
*/
def call(args = [:]) {
  def image = DockerUtils.build(args['name'], args['path'], args)
  DockerUtils.test(image, args)

  if (args['push']) {
    DockerUtils.push(image, args['tags'], args['registries'] ?: ['http://docker.cvent.net'])
  }
}
