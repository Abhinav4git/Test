#!/usr/bin/groovy

// Functions to return HTTP links to various 3rd party systems

def aws(String env, String app) {
  "https://console.aws.amazon.com/ecs/home?region=us-east-1#/clusters/shared1/services/${app}__${env}__v2/details"
}

def datadog(String env, String app, String operation = 'servlet') {
  "https://cvent.datadoghq.com/apm/service/${app}/${operation}.request?end=1571766464649&env=${env.toLowerCase()}"
}

def splunk(String env, String app, String sourceType = 'json') {
  String index = "cvt_alpha"
  switch (env) {
    case isProductionEnvironment(env):
      index = "cvt_production"
      break
    case "ct50":
      index = "cvt_integration"
      break
    case ~/^(ld50|load|L2)$/:
      index = "cvt_load"
      break
    case ~/^(sg50|staging|ts50|T2)$/:
      index = "cvt_staging"
      break
    case ~/^(ci|dev\S*)$/:
      index = "cvt_dev"
      break
  }

  "https://logs.core.cvent.org/en-US/app/prodsupport/search?q=search%20index%3D${index}%20environment%3D${env}%20sourcetype%3D${sourceType}%20application%3D${app}"
}

