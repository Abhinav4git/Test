// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// staticUIPipeline

// Libraries
import groovy.transform.Field
import cvent.mobile.OSSUtils

// We are intentionally adding a layer of abstraction here between what are low-level "environments" under the hood, VS what we are referring to
// as "deployment targets" to the pipeline user.
// This enables us to have very end-user-friendly options when using this pipeline, with the goal being that product dev teams needn't know
// or care about what AWS accounts / regions / etc that their deployments map to under the hood. This also enables us to trivially do any
// arbitrary combo of multi-env deploys at any point now and in the future (see multi-prod deploy, and also multi-devX deploy below).
@Field deploymentTargets = [
  'Alpha (AP50)': ['Alpha'],
  'US Staging (SG50)': ['SG50'],
  'EU Staging (SG53)': ['SG53'],
  'US Production (PR50)': ['PR50'],
  'EU Production (PR53)': ['PR53'],
  'EU Production Disaster Recovery (PR54)': ['PR54'],
  'Customer Testing Production (CT50)': ['CT50'],
  'Multi-deploy To All Production Environments (CT50, PR50, PR53, PR54)': ['CT50', 'PR50', 'PR53', 'PR54'],
  'Preview': ['Preview'],
  'Load Testing (LD50)': ['LD50'],
  'Every Lower Environment (All DevX\'s + Alpha + Staging + Load Testing)': ['Dev1', 'Dev2', 'Dev3', 'Dev4', 'Dev5', 'Dev6', 'Dev7', 'Dev8', 'Dev9', 'Dev10', 'Dev11', 'Alpha', 'SG50', 'SG53', 'LD50'],
  'Every DevX Environment': ['Dev1', 'Dev2', 'Dev3', 'Dev4', 'Dev5', 'Dev6', 'Dev7', 'Dev8', 'Dev9', 'Dev10', 'Dev11'],
  'Development 1 (R&D)': ['Dev1'],
  'Development 2 (Silver Team)': ['Dev2'],
  'Development 3 (Pink Team)': ['Dev3'],
  'Development 4 (Global API Team)': ['Dev4'],
  'Development 5 (Blue Team)': ['Dev5'],
  'Development 6 (Black Team)': ['Dev6'],
  'Development 7 (Red Team)': ['Dev7'],
  'Development 8 (Yellow Team)': ['Dev8'],
  'Development 9 (Purple Team)': ['Dev9'],
  'Development 10 (Bronze Team)': ['Dev10'],
  'Development 11 (Appointments Team)': ['Dev11'],
  'Business Transient Development': ['bt-dev']
]

@Field environments = [
  'Alpha': [
    hoganRegionCode   : 'alpha',
    channelToNotify   : '#oss-alpha-alerts',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-alpha',
    cloudfrontId      : 'E1KAWY4NL8CWBI'
  ],
  'SG50': [
    hoganRegionCode   : 'sg50',
    channelToNotify   : '#oss-stage-info',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-staging',
    cloudfrontId      : 'E39RG2T0ONKNHL'
  ],
  'SG53': [
    hoganRegionCode   : 'S820',
    channelToNotify   : '#oss-stage-info',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-staging-eur',
    cloudfrontId      : 'E39PSRD1970TLJ'
  ],
  'CT50': [
    hoganRegionCode   : 'ct50',
    channelToNotify   : '#oss-release',
    jenkinsAuth       : 'cvent-integration-shared-jenkins',
    applicationBucket : 'onsite-apps-integration',
    cloudfrontId      : 'E1UZUG96QK8HFM'
  ],
  'PR50': [
    hoganRegionCode   : 'P2',
    channelToNotify   : '#oss-release',
    jenkinsAuth       : 'cvent-production-shared-jenkins',
    applicationBucket : 'onsite-apps-production',
    cloudfrontId      : 'E13P9DEFB4H49H'
  ],
  'PR53': [
    hoganRegionCode   : 'pr53',
    channelToNotify   : '#oss-release',
    jenkinsAuth       : 'core-app-prod-shared-jenkins',
    applicationBucket : 'onsite-apps-production-eur',
    cloudfrontId      : 'E2GGWUZY0YQNDE'
  ],
  'PR54': [
    hoganRegionCode   : 'pr54',
    channelToNotify   : '#oss-release',
    jenkinsAuth       : 'core-app-prod-shared-jenkins',
    applicationBucket : 'onsite-apps-production-eur-dr',
    cloudfrontId      : 'E1I8CMYLA6E7LU'
  ],
  'L1': [
    hoganRegionCode   : 'L1',
    channelToNotify   : '#oss-performance',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-load-testing',
    cloudfrontId      : 'E159U9B9QB4HAW',
    appURLPrefix      : 'L1'
  ],
  'L2': [
    hoganRegionCode   : 'L2',
    channelToNotify   : '#oss-performance',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-load-testing',
    cloudfrontId      : 'E159U9B9QB4HAW',
    appURLPrefix      : 'L2'
  ],
  'LD50': [
    hoganRegionCode   : 'ld50',
    channelToNotify   : '#oss-performance',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-load-testing',
    cloudfrontId      : 'E159U9B9QB4HAW',
    appURLPrefix      : 'ld50'
  ],
  'Preview': [
    hoganRegionCode   : 'alpha', // the preview environment (for pull request previews) uses alpha APIs, so alpha hogan config values
    channelToNotify   : '#oss-alpha-alerts',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-preview',
    cloudfrontId      : 'E1J09N6Y7QHFL6'
  ],
  'Dev1': [
    hoganRegionCode   : 'dev1',
    channelToNotify   : '#sre-mobile-test',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-dev',
    cloudfrontId      : 'E3AU7UV3HS03GK',
    appURLPrefix      : 'dev1'
  ],
  'Dev2': [
    hoganRegionCode   : 'dev2',
    channelToNotify   : '#oss-silver-deploy',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-dev',
    cloudfrontId      : 'E3AU7UV3HS03GK',
    appURLPrefix      : 'dev2'
  ],
  'Dev3': [
    hoganRegionCode   : 'dev3',
    channelToNotify   : ' ',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-dev',
    cloudfrontId      : 'E3AU7UV3HS03GK',
    appURLPrefix      : 'dev3'
  ],
  'Dev4': [
    hoganRegionCode   : 'dev4',
    channelToNotify   : '#oss-white',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-dev',
    cloudfrontId      : 'E3AU7UV3HS03GK',
    appURLPrefix      : 'dev4'
  ],
  'Dev5': [
    hoganRegionCode   : 'dev5',
    channelToNotify   : '#oss-blue-deploy',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-dev',
    cloudfrontId      : 'E3AU7UV3HS03GK',
    appURLPrefix      : 'dev5'
  ],
  'Dev6': [
    hoganRegionCode   : 'dev6',
    channelToNotify   : '#oss-black-deploy',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-dev',
    cloudfrontId      : 'E3AU7UV3HS03GK',
    appURLPrefix      : 'dev6'
  ],
  'Dev7': [
    hoganRegionCode   : 'dev7',
    channelToNotify   : '#oss-red-deploy',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-dev',
    cloudfrontId      : 'E3AU7UV3HS03GK',
    appURLPrefix      : 'dev7'
  ],
  'Dev8': [
    hoganRegionCode   : 'dev8',
    channelToNotify   : '#oss-yellow-deploy',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-dev',
    cloudfrontId      : 'E3AU7UV3HS03GK',
    appURLPrefix      : 'dev8'
  ],
  'Dev9': [
    hoganRegionCode   : 'dev9',
    channelToNotify   : '#oss-purple-alerts',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-dev',
    cloudfrontId      : 'E3AU7UV3HS03GK',
    appURLPrefix      : 'dev9'
  ],
  'Dev10': [
    hoganRegionCode   : 'dev10',
    channelToNotify   : '#oss-bronze-deploy',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-dev',
    cloudfrontId      : 'E3AU7UV3HS03GK',
    appURLPrefix      : 'dev10'
  ],
  'Dev11': [
    hoganRegionCode   : 'dev11',
    channelToNotify   : '#oss-appointments',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-dev',
    cloudfrontId      : 'E3AU7UV3HS03GK',
    appURLPrefix      : 'dev11'
  ],
  'bt-dev': [
    // TODO: Update this to bt-search-ui once the key has been added to hogan
    hoganRegionCode   : 'alpha',
    channelToNotify   : '#bt-search-ui-notify',
    jenkinsAuth       : 'cvent-development-shared-jenkins',
    applicationBucket : 'onsite-apps-dev',
    cloudfrontId      : 'E3AU7UV3HS03GK'
  ]
]

@Field reservedStashRepoToAppURLMappings = [
  'planner'             : 'ssh://git@stash.cvent.net:7999/pt/onsite-planner-portal.git',
  'admin'               : 'ssh://git@stash.cvent.net:7999/pt/onsite-admin-portal.git',
  'exhibitor'           : 'ssh://git@stash.cvent.net:7999/pt/onsite-exhibitor-portal.git',
  'rfid-admin'          : 'ssh://git@stash.cvent.net:7999/pt/rfid-admin.git',
  'socialwall-admin'    : 'ssh://git@stash.cvent.net:7999/pt/socialwall-admin.git',
  'cloud-insight'       : 'ssh://git@stash.cvent.net:7999/pt/cloud-insight-ui.git',
  'event-insights'      : 'ssh://git@stash.cvent.net:7999/pt/event-insight-assets.git',
  'powerpoint-livepoll' : 'ssh://git@stash.cvent.net:7999/cm/powerpoint-livepoll.git',
  'bt-search-ui'        : 'ssh://git@stash.cvent.net:7999/bt/bt-search-ui.git',
  'gamification'        : 'ssh://git@stash.cvent.net:7999/CM/gamification-ui.git'
]

String outputEnvironmmentListString() {
  def envs = [:] << deploymentTargets
  envs.remove('Preview')
  envs.keySet().join('\n')
}

String determinePreviewUrl() {
  def parts = [
    env.PIPELINE_URL_PATH,
    'pull-request',
    env.CHANGE_ID,
  ]
  parts.join('/')
}

String findEnvironmentUrl(environment) {
  def parts = []
  if (environment.appURLPrefix) {
    parts.add(environment.appURLPrefix)
  }
  parts.add(env.PIPELINE_URL_PATH)
  parts.join('/')
}

Boolean isPullRequest() {
  return env.CHANGE_ID != null
}

String determineS3Path(environment) {
  def bucket
  def url

  if (!isPullRequest()) {
    bucket = environment.applicationBucket
    url = findEnvironmentUrl(environment)
  } else {
    def previewEnv = findEnvironment('Preview')
    bucket = previewEnv.applicationBucket
    url = determinePreviewUrl()
  }

  return "s3://${bucket}/${url}"
}

String findEnvironment(destEnv) {
  if (isPullRequest()) {
    environment = environments.get('Preview')
  } else {
    environment = environments.get(destEnv)
  }
  if(!environment) {
    OSSUtils.logError("${destEnv} environment configuration was not found in the pipeline, you may need to update environment mappings or perhaps typo'd your environment name in your Jenkinsfile")
    error ''
  }
  return environment
}

String findDestinationEnvironment(pipelineArgs) {
  def isStartedByUser = currentBuild.rawBuild.getCause(hudson.model.Cause$UserIdCause) != null
  if (isStartedByUser) {
    return env["Destination Environment"]
  }
  return pipelineArgs['Default Destination Environment']
}

enum BuildStatus {
  STARTED,
  SUCCESS,
  FAILURE
}

void outputStageHeaderLog(String stageName = '') {
  // This makes it easier to discern between distinct stages in the pipeline log for easier debugging
  echo "\n\n\n\n\n\n\n\n\n\n\n---------------------------------------------------"
  OSSUtils.logInfo("${stageName}")
  echo "---------------------------------------------------"
}

void sendSlackMessage(BuildStatus status, String stage = '') {
  def environments = deploymentTargets.get(env.PIPELINE_DESTINATION_ENVIRONMENT, [:])
  environments.each { thisEnv ->
    def thisEnvObject = findEnvironment(thisEnv)
    def environment = thisEnvObject.hoganRegionCode
    def slack_name = thisEnvObject.channelToNotify
    def slack_message = "Started deployment of ${env.git_url} for ${environment}"
    if (stage?.trim()) {
      slack_message += "\n Stage: ${stage}"
    }
    slack_message += "\n Branch: ${env.PIPELINE_SOURCE_BRANCH_NAME}"
    slack_message += "\n${env.JOB_NAME} [${env.BUILD_NUMBER}] <${env.BUILD_URL}|Open>"

    switch(status) {
      case BuildStatus.STARTED:
        OSSUtils.logInfo("Sending 'Started deployment of ${slack_message}' to ${slack_name}")
        slackSend message: "STARTED ${slack_message}", channel: slack_name, color: 'good'
        break;
      case BuildStatus.SUCCESS:
        OSSUtils.logInfo("Sending 'Started deployment of ${slack_message}' to ${slack_name}")
        slackSend message: "SUCCESS ${slack_message}", channel: slack_name, color: 'good'
        break;
      default:
        OSSUtils.logInfo("Sending 'Started deployment of ${slack_message}' to ${slack_name}")
        slackSend message: "FAILURE ${slack_message}", channel: slack_name, color: 'danger'
        break;
    }
  }
}

def call(pipelineArgs = [:]) {
  pipeline {
    parameters {
      choice(
        name: 'Destination Environment',
        choices: outputEnvironmmentListString(),
        description: 'The environment you\'d like to to deploy to.'
      )
    }

    agent { label 'linux && docker' }

    options {
      // timestamps()
      ansiColor('xterm')
    }

    environment {
      // Convention of prefixing all env variables specific to [this pipeline]
      PIPELINE_DEP_INSTALL_COMMAND = "${pipelineArgs['Dependency Installation Command']}"
      PIPELINE_BUILD_COMMAND = "${pipelineArgs['Build Command']}"
      PIPELINE_SKIP_CONFIG_GENERATION = "${pipelineArgs['Skip Config Generation']}"
      PIPELINE_SKIP_DEP_INSTALL = "${pipelineArgs['Skip Dependency Installation']}"
      PIPELINE_SKIP_BUILD_STEP = "${pipelineArgs['Skip Build Step']}"
      PIPELINE_SKIP_DEPLOY_STEP = "${pipelineArgs['Skip Deploy Step']}"
      PIPELINE_SKIP_TEST_STEP = "${pipelineArgs['Skip Test Step']}"
      PIPELINE_SKIP_PREVIEW_GENERATION = "${pipelineArgs['Skip Preview Generation']}"
      PIPELINE_TEST_COMMAND = "${pipelineArgs['Test Command']}"
      PIPELINE_BUILD_OUTPUT_FOLDER = "${pipelineArgs['Build Output Folder']}"
      PIPELINE_GIT_URL = sh(returnStdout: true, script: "git config --get remote.origin.url").trim()
      PIPELINE_SOURCE_BRANCH_NAME = sh(script: "git ls-remote --heads | grep -m 1 ${git_commit} | awk '{print \$2}' | sed -e 's#.*refs/heads/##'", returnStdout: true).trim()
      PIPELINE_URL_PATH = "${pipelineArgs['App URL']}"
      PIPELINE_DESTINATION_ENVIRONMENT = findDestinationEnvironment(pipelineArgs)
    }

    stages {
        stage('Print Environment') {
          steps {
            script {
              sendSlackMessage(BuildStatus.STARTED)
              printEnvInfo()
              def targets = deploymentTargets.get(env.PIPELINE_DESTINATION_ENVIRONMENT, [:])
              OSSUtils.logInfo("DEPLOYING ${targets}")
          }
        }
      }

      stage('Validating pipeline inputs') {
        steps {
          script {
            try {
              outputStageHeaderLog("Validating Pipeline Inputs")
              def props = readJSON file: 'package.json'
              env.PIPELINE_VERSION_BEING_DEPLOYED = props.version
              env.PIPELINE_IS_RELEASE_DEPLOYMENT = !env.PIPELINE_VERSION_BEING_DEPLOYED.toLowerCase().contains("snapshot")
              env.PIPELINE_IS_PRODUCTION_DEPLOYMENT = env.PIPELINE_DESTINATION_ENVIRONMENT.toLowerCase().contains("production").toBoolean()

              // Fail the build if the user failed to specify their app URL
              if(env.PIPELINE_URL_PATH == 'null' && env.PIPELINE_SKIP_DEPLOY_STEP.toLowerCase() != 'true') {
                OSSUtils.logError('[Pipeline Validation Error] It looks like your application doesn\'t have App URL specified in its Jenkinsfile and it is a required parameter. Check your parameters and try again. Reach out to #os-ui-dev if you need any help.')
                error ''
              }
              // Fail the build if the user is attempting to hijack someone elses reserved app URL
              if ("${reservedStashRepoToAppURLMappings[env.PIPELINE_URL_PATH]}".toLowerCase() != "${env.PIPELINE_GIT_URL}".toLowerCase() && env.PIPELINE_SKIP_DEPLOY_STEP.toLowerCase() != 'true') {
                OSSUtils.logError('[Pipeline Validation Error] It looks like you are attempting to deploy an application to a URL that is reserved by another application. Check your Jenkinsfile to be sure your application name is correct, and reach out to #os-ui-dev if the problem persists.')
                error ''
              }
              // Fail the build if the user failed to specify their app dep install command, and *also* didn't explicitly tell the pipeline to skip the app dep install step
              if (env.PIPELINE_SKIP_DEP_INSTALL == 'null' && env.PIPELINE_DEP_INSTALL_COMMAND == 'null') {
                OSSUtils.logError('[Pipeline Validation Error] It looks like your application hasn\'t explicitly specified to skip the dependency installation step, but no \'Dependency Installation Command\' parameter has been specified in your Jenkinsfile. Check your parameters and try again. Reach out to #os-ui-dev if you need any help.')
                error ''
              }
              // Fail the build if the user failed to specify their app build command, and *also* didn't explicitly tell the pipeline to skip the app build step
              if (env.PIPELINE_SKIP_BUILD_STEP == 'null' && env.PIPELINE_BUILD_COMMAND == 'null') {
                OSSUtils.logError('[Pipeline Validation Error] It looks like your application hasn\'t explicitly specified to skip the build step, but no \'Build Command\' parameter has been specified in your Jenkinsfile. Check your parameters and try again. Reach out to #os-ui-dev if you need any help.')
                error ''
              }
              // Fail the build if the user failed to specify their app unit test command, and *also* didn't explicitly tell the pipeline to skip the app unit test step
              if (env.PIPELINE_SKIP_TEST_STEP == 'null' && env.PIPELINE_TEST_COMMAND == 'null') {
                OSSUtils.logError('[Pipeline Validation Error] It looks like your application hasn\'t explicitly specified to skip the unit testing step, but no \'Test Command\' parameter has been specified in your Jenkinsfile. Check your parameters and try again. Reach out to #os-ui-dev if you need any help.')
                error ''
              }
              // Fail the build if the user failed to specify a default destination environment
              if (env.PIPELINE_DESTINATION_ENVIRONMENT == 'null' && env.PIPELINE_SKIP_DEPLOY_STEP.toLowerCase() != 'true') {
                OSSUtils.logError('[Pipeline Validation Error] It looks like your application hasn\'t specified a default environment to deploy to. Check your parameters and try again. Reach out to #os-ui-dev if you need any help.')
                error ''
              }
              // Fail the build if the user failed to specify what the outputted build folder is called
              if(env.PIPELINE_BUILD_OUTPUT_FOLDER == 'null' && env.PIPELINE_SKIP_DEPLOY_STEP.toLowerCase() != 'true') {
                OSSUtils.logError('[Pipeline Validation Error] It looks like your application doesn\'t have Build Output Folder specified in its Jenkinsfile and it is a required parameter. Check your parameters and try again. Reach out to #os-ui-dev if you need any help.')
                error ''
              }

              OSSUtils.logInfo("All pipeline inputs valid! :shipit:")

            } catch (error) {
              OSSUtils.logError(error)
              sendSlackMessage(BuildStatus.FAILURE, STAGE_NAME)
              // halt the pipeline if build failed
              currentBuild.result = 'FAILURE'
              throw error
            }
          }
        }
      }

      stage('Install Application Dependencies') {
        agent {
          docker {
            image 'docker.cvent.net/nucleus-node:10.13.0-yarn-1.12.1'
            args '-v $HOME/.ssh:/home/jenkins/.ssh:rw'
            reuseNode true
          }
        }
        steps {
          script {
            try {
              outputStageHeaderLog("Installing Application Dependencies")
              if (env.PIPELINE_SKIP_DEP_INSTALL == 'true') {
                OSSUtils.logInfo('Skipping the dependency install step based on Jenkinsfile parameters')
              } else {
                sh "${env.PIPELINE_DEP_INSTALL_COMMAND}"
              }
            } catch (error) {
              OSSUtils.logError(error)
              sendSlackMessage(BuildStatus.FAILURE, STAGE_NAME)
              // halt the pipeline if build failed
              currentBuild.result = 'FAILURE'
              throw error
            }
          }
        }
      }

      stage('Run Unit Tests') {
        agent {
          docker {
            image 'docker.cvent.net/nucleus-node:10.13.0-yarn-1.12.1'
            args '-v $HOME/.ssh:/home/jenkins/.ssh:rw'
            reuseNode true
          }
        }
        steps {
          script {
            try {
              outputStageHeaderLog("Running Application Unit Tests")
              if (env.PIPELINE_SKIP_TEST_STEP == 'true') {
                OSSUtils.logInfo('Skipping the unit test step based on Jenkinsfile parameters')
              } else {
                sh "${env.PIPELINE_TEST_COMMAND}"
              }
            } catch (error) {
              OSSUtils.logError(error)
              sendSlackMessage(BuildStatus.FAILURE, STAGE_NAME)
              // halt the pipeline if build failed
              currentBuild.result = 'FAILURE'
              throw error
            }
          }
        }
      }

      stage('Generate Configs For Destination Environment') {
        agent {
          docker {
            image "docker.cvent.net/awscli-hogan"
            args '-v $HOME/.ssh:/home/jenkins/.ssh:rw'
            reuseNode true
          }
        }
        steps {
          script {
            try {
              outputStageHeaderLog("Generating Application Configs")
              if (env.PIPELINE_SKIP_CONFIG_GENERATION == 'true') {
                OSSUtils.logInfo('Skipping the hogan config generation step based on Jenkinsfile parameters')
              } else {
                def environments = deploymentTargets.get(env.PIPELINE_DESTINATION_ENVIRONMENT, [:])
                environments.each { thisEnv ->
                  def thisEnvObject = findEnvironment(thisEnv)
                  OSSUtils.logInfo("Generating Configs For: ${thisEnvObject.hoganRegionCode}")
                  sh "hogan transform --configs ssh://git@stash:7999/dep/hogan-configs.git -k /home/jenkins/.ssh/id_rsa --environments-filter ${thisEnvObject.hoganRegionCode} --templates ./configs --templates-filter config_template.js"
                }
              }
            } catch (error) {
              OSSUtils.logError(error)
              sendSlackMessage(BuildStatus.FAILURE, STAGE_NAME)
              // halt the pipeline if build failed
              currentBuild.result = 'FAILURE'
              throw error
            }
          }
        }
      }

      stage('Create Application Build') {
        agent {
          docker {
            image 'docker.cvent.net/nucleus-node:10.13.0-yarn-1.12.1'
            args '-v $HOME/.ssh:/home/jenkins/.ssh:rw'
            reuseNode true
          }
        }
        steps {
          script {
            try {
              outputStageHeaderLog("Building Application")
              def environments = deploymentTargets.get(env.PIPELINE_DESTINATION_ENVIRONMENT, [:])
              environments.each { thisEnv ->
                def thisEnvObject = findEnvironment(thisEnv)
                OSSUtils.logInfo("Generating Build For: ${thisEnvObject.hoganRegionCode}")

                if (env.PIPELINE_SKIP_BUILD_STEP == 'true') {
                  OSSUtils.logInfo('Skipping the application build step based on Jenkinsfile parameters')
                } else {
                  // we always want `production` webpack build mode in any env other than our local machines
                  sh "BUILD_MODE=production NODE_ENV=${thisEnvObject.hoganRegionCode} ${env.PIPELINE_BUILD_COMMAND}"
                }

                sh "mkdir ${thisEnvObject.hoganRegionCode}"
                OSSUtils.logInfo("COPYING TO ${thisEnvObject.hoganRegionCode}")
                sh "cp -R ${env.PIPELINE_BUILD_OUTPUT_FOLDER}/* ${thisEnvObject.hoganRegionCode}"
                sh "cp ${env.PIPELINE_BUILD_OUTPUT_FOLDER}/index.html ${thisEnvObject.hoganRegionCode}"

                if (!fileExists("${thisEnvObject.hoganRegionCode}/index.html")) {
                  OSSUtils.logError('[Pipeline Validation Error] It looks like your application doesn\'t produce an \'index.html\' as a part of its build process. An \'index.html\' is a required asset on this pipeline. Check your build and try again. Reach out to #os-ui-dev if you need any help.')
                  error ''
                }
              }
            } catch (error) {
              OSSUtils.logError(error)
              sendSlackMessage(BuildStatus.FAILURE, STAGE_NAME)
              // halt the pipeline if build failed
              currentBuild.result = 'FAILURE'
              throw error
            }
          }
        }
      }

      stage('Upload Built Application To Destination Environment') {
        agent {
          docker {
            image "docker.cvent.net/awscli-hogan"
            args '-v $HOME/.ssh:/home/jenkins/.ssh:rw'
            reuseNode true
          }
        }
        steps {
          script {
            try {
              outputStageHeaderLog("Uploading Application To S3")
              def environments = deploymentTargets.get(env.PIPELINE_DESTINATION_ENVIRONMENT, [:])
              environments.each { thisEnv ->
                def thisEnvObject = findEnvironment(thisEnv)
                OSSUtils.logInfo("Uploading Builds Contents To: ${thisEnvObject.hoganRegionCode}")
                OSSUtils.logInfo("(Sending /${thisEnvObject.hoganRegionCode} to ${determineS3Path(thisEnvObject)})")
                attemptingToOverwriteAnExistingBuild = null
                if (env.PIPELINE_SKIP_DEPLOY_STEP.toBoolean() == 'true') {
                  OSSUtils.logInfo('Skipping the application deploy step based on Jenkinsfile parameters')
                } else if (env.PIPELINE_IS_RELEASE_DEPLOYMENT.toBoolean() == true && attemptingToOverwriteAnExistingBuild == true) {
                  OSSUtils.logError('Oops, it looks like there is already a non-SNAPSHOT version deployed that matches this version number; please cut a new release version and re-deploy.')
                  error ''
                } else {
                  withCredentials([[
                    $class: 'AmazonWebServicesCredentialsBinding',
                    credentialsId: "${thisEnvObject.jenkinsAuth}"
                  ]]) {
                    // Upload the entire build except for the index.html - that needs to be uploaded separately with special caching headers
                    sh "aws s3 sync ${thisEnvObject.hoganRegionCode} ${determineS3Path(thisEnvObject)} --exclude 'index.html'"
                    // Now upload the index.html explicitly flagging it as never cached
                    sh "aws s3 cp ${thisEnvObject.hoganRegionCode}/index.html ${determineS3Path(thisEnvObject)}/index.html --metadata-directive REPLACE --cache-control public,must-revalidate,proxy-revalidate,max-age=0,no-cache"
                  }
                }
              }
              if (isPullRequest()) {
                if (env.PIPELINE_SKIP_PREVIEW_GENERATION == 'true') {
                  OSSUtils.logInfo('Skipping the preview generation based on Jenkinsfile parameters')
                } else {
                  // Use string concatenation here because Bitbucket API will return 500 if template strings are used :c
                  def previewHost = 'https://previews.core.cvent.org'
                  def previewPath = determinePreviewUrl()
                  previewUrl = "${previewHost}/${previewPath}"
                  def message = "Live preview: [${previewUrl}](${previewUrl})"
                  echo message
                  OSSUtils.logInfo(message)
                }
              }
            } catch (error) {
              OSSUtils.logError(error)
              sendSlackMessage(BuildStatus.FAILURE, STAGE_NAME)
              // halt the pipeline if build failed
              currentBuild.result = 'FAILURE'
              throw error
            }
          }
        }
      }

      stage('Invalidate Cloudfront Cache For Application') {
        agent {
          docker {
            image "docker.cvent.net/awscli-hogan"
            reuseNode true
          }
        }
        steps {
          script {
            try {
              if (env.PIPELINE_SKIP_DEPLOY_STEP.toLowerCase() != 'true') {
                outputStageHeaderLog("Invalidating Cloudfront Cache")
                def environments = deploymentTargets.get(env.PIPELINE_DESTINATION_ENVIRONMENT, [:])
                environments.each { thisEnv ->
                  def thisEnvObject = findEnvironment(thisEnv)
                  OSSUtils.logInfo("Invalidating Cache For: ${thisEnvObject.hoganRegionCode}")
                  withCredentials([[
                    $class: 'AmazonWebServicesCredentialsBinding',
                    credentialsId: "${thisEnvObject.jenkinsAuth}"
                  ]]) {
                    OSSUtils.logInfo("Creating invalidation in distribution ${thisEnvObject.cloudfrontId} and paths '/${env.PIPELINE_URL_PATH}/*'!")
                    sh "aws cloudfront create-invalidation --distribution-id ${thisEnvObject.cloudfrontId} --paths '/${env.PIPELINE_URL_PATH}/*'"
                  }
                }
                sendSlackMessage(BuildStatus.SUCCESS)
              }
            } catch (error) {
              OSSUtils.logError(error)
              sendSlackMessage(BuildStatus.FAILURE, STAGE_NAME)
              // halt the pipeline if build failed
              currentBuild.result = 'FAILURE'
              throw error
            }
          }
        }
      }
    }
    post {
      always {
        deleteDir()
      }
    }
  }
}
