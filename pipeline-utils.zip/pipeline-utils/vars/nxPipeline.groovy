// nxPipeline

import cvent.aws.AwsUtils
import cvent.jenkins.GroovyUtils
import cvent.jenkins.SlaveUtils
import cvent.linters.CdkMetadataLinter
import cvent.slack.SlackUtils
import cvent.stash.Utils as StashUtils

// Returns true if last commit is from Jenkins
boolean isLastCommitFromJenkins() {
  return env.PIPELINE_GIT_LAST_COMMITTER == 'Jenkins' &&
      // Exclude the local merge to target branch in PRs
      !(env.PIPELINE_GIT_LAST_COMMIT_MSG ==~ /Merge commit.+into HEAD/)
}

// Returns true if there's a release build config matching the build branch
boolean isReleaseBranch(pipelineArgs) {
  return getConfig(pipelineArgs.release)
}

// Returns true if this pipeline will build a release artifact
boolean isRelease(pipelineArgs) {
  // Never release from a PR
  if (env.CHANGE_URL) {
    return false
  }

  // Allow forcing a release via build param
  if (params.RELEASE) {
    return true
  }

  if (isReleaseBranch(pipelineArgs) &&
      !isLastCommitFromJenkins() &&
      !StashUtils.changeSetContainsOnlyIgnoredFiles(pipelineArgs.ignoreFiles)) {
    return true
  }

  return false
}

// Returns true if the build should run
boolean shouldBuild(pipelineArgs) {
  return isRelease(pipelineArgs) || !isLastCommitFromJenkins()
}

// Extract environments as a list from a build config
static Set getEnvironments(Map config) {
  if (config) {
    def envs = config.environments ?: []
    return (envs instanceof String) ? [envs] : envs as Set
  }
  return []
}

// Returns the first matching config based on the build branch out of an ordered list of configs
Map getConfig(Collection<Map> configs) {
  for (config in configs) {
    if (StashUtils.getBranch() ==~ config.branch) {
      return config
    }
  }
  return [:]
}

def runDocker(Closure body) {
  docker.image(env.PIPELINE_DOCKER_IMAGE).inside() {
    body()
  }
}

String getRepoName(String repoUrl) {
  return StashUtils.getProjectAndRepo(repoUrl).get(1)
}

def runCheckout(String repoUrl, String branch = 'master') {
  def repoName = getRepoName(repoUrl)
  def tags = branch.startsWith('refs/tags/')
  checkout([
      $class: 'GitSCM',
      branches: [[name: branch]],
      doGenerateSubmoduleConfigurations: false,
      extensions: [
          [$class: 'CloneOption', depth: 0, noTags: !tags, reference: '', shallow: true],
          [$class: 'RelativeTargetDirectory', relativeTargetDir: repoName]
      ],
      submoduleCfg: [],
      userRemoteConfigs: [[url: repoUrl]]])
}

def deployCDK(String environment) {
  runTimed "Deploying CDK to ${environment}", {
    runDocker {
      AwsUtils.withAwsProfiles {
        sh "yarn nx config:set ${environment} --branch=${params.HOGAN_CONFIGS_BRANCH}"
        sh "yarn cdk --app='nx deploy:build' diff --plugin @cvent/aws-cdk-credential-plugin ||:"
        sh "yarn cdk --app='nx deploy:build' deploy '*' --require-approval=never --plugin @cvent/aws-cdk-credential-plugin"
      }
    }
  }
}

def deployECS(environments) {
  runTimed "Deploying ECS to ${environments}", {
    ecs.deploy(
        ecrImageTag: env.PIPELINE_ECR_IMAGE_TAG,
        environments: environments,
        hoganBranch: params.HOGAN_CONFIGS_BRANCH ?: 'master',
        hoganGitSha: env.PIPELINE_HOGAN_GIT_SHA,
        logLevel: params.VERBOSE_LOGGING ? 'DEBUG' : 'INFO',
        migrate: false,
        serviceName: env.PIPELINE_ARTIFACT_ID,
        tagOverride: params.DEPLOY_SERVICE_ECS_TAG)
  }
}

static boolean shouldDeployInParallel() {
  // Enable parallel deploys for now, may change later
  return true
}

def runDeploys(steps) {
  if (shouldDeployInParallel()) {
    parallel steps
  } else {
    steps.each { key, val ->
      logInfo("Running $key")
      val()
    }
  }
}

/**
 * Send a Slack notification
 * @param event 'START', 'SUCCESS', or 'FAILURE'
 */
def notifySlack(pipelineArgs, event) {
  if (!shouldBuild(pipelineArgs)) {
    return
  }

  def config = getConfig(pipelineArgs.slack)
  if (!config || !config.events?.contains(event)) {
    return
  }

  def channels = SlackUtils.transformSlackChannel(config.channel)
  if (!channels) {
    return
  }

  String style = (event == 'SUCCESS' || event == 'START') ? 'good' : 'danger'

  def fields = [
      [
          value: env.PIPELINE_GIT_LAST_COMMIT_MSG
      ],
      [
          title: "Branch",
          value: StashUtils.getBranch(),
          short: true
      ],
      [
          title: "Author",
          value: env.PIPELINE_GIT_LAST_COMMITTER,
          short: true
      ],
      [
          title: "Version",
          value: env.PIPELINE_ARTIFACT_VERSION,
          short: true
      ]
  ]
  if (env.PIPELINE_ECR_IMAGE_TAG) {
    fields.add([
        title: "ECR Image Tag",
        value: env.PIPELINE_ECR_IMAGE_TAG,
        short: true
    ])
  }

  def app = env.PIPELINE_ARTIFACT_ID
  fields.add([
      value: "*${app}*",
      short: false
  ])
  def environments = getEnvironments(getConfig(pipelineArgs.ci)) + getEnvironments(getConfig(pipelineArgs.release))
  environments.each { e ->
    fields.add([
        value: "${e}: <${link.aws(e, app)}|AWS> | <${link.datadog(e, app, 'express')}|Datadog APM> | <${link.splunk(e, app, '*')}|Splunk>",
        short: false
    ])
  }

  def actions = [
      [
          type: "button",
          text: "Jenkins Log",
          url: env.BUILD_URL,
          style: style
      ]
  ]
  if (env.CHANGE_URL) {
    actions.add([
        type: "button",
        text: "Pull Request",
        url: env.CHANGE_URL,
        style: style
    ])
  }

  def attachments = [
      [
          pretext: "*${env.PIPELINE_REPO_ID}* - ${event}",
          color: style,
          fallback: "${env.PIPELINE_REPO_ID} build",
          fields: fields,
          mrkdwn_in: ['pretext', 'fields'],
          actions: actions
      ]
  ]

  SlackUtils.notifySlack(channels, [message: '', attachments: attachments])
}

def call(Map pipelineArgs) {
  Map defaultConfig = [
      ci: [
          [branch: '.*', environments: ['ci']]
      ],

      release: [
          [branch: 'master|release/.*', environments: []]
      ],

      slack: [
          [branch: '.*', channel: '_owner_', events: ['START', 'SUCCESS', 'FAILURE']]
      ],

      ignoreFiles: [
          'UPDATING.md'
      ]
  ]
  pipelineArgs = GroovyUtils.mergeMaps(defaultConfig, pipelineArgs)

  pipeline {
    agent {
      label SlaveUtils.anyDockerNodeLabel()
    }
    options {
      ansiColor('xterm')
      timeout(time: 1, unit: 'HOURS')
      timestamps()
    }
    parameters {
      booleanParam(name: 'RELEASE',
          defaultValue: false,
          description: 'Force a release')

      string(
          name: 'HOGAN_CONFIGS_BRANCH',
          defaultValue: 'master',
          description: 'The branch to use for hogan-configs')

      string(name: 'DEPLOY_AWS_DOCKER_BRANCH',
          defaultValue: '',
          description: 'deploy-aws-docker branch for build & push docker image to ECR')

      string(
          name: 'DEPLOY_SERVICE_ECS_TAG',
          defaultValue: '',
          description: 'deploy-service-ecs tag for deploying ECS service'
      )

      booleanParam(name: 'VERBOSE_LOGGING',
          defaultValue: false,
          description: 'Enable verbose logging')
    }
    environment {
      // Pipeline build image
      PIPELINE_DOCKER_IMAGE = 'docker.cvent.net/nx-build:latest'

      // Repo name
      PIPELINE_REPO_NAME = getRepoName(StashUtils.getGitUrl())

      // Unique identifier of repo in the form of `[project]/[repo]`
      PIPELINE_REPO_ID = StashUtils.getProjectSlashRepo(StashUtils.getGitUrl())

      // Last commit hash
      PIPELINE_GIT_COMMIT = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()

      // Last commit author
      PIPELINE_GIT_LAST_COMMITTER = sh(returnStdout: true, script: "git log -1 --pretty=format:'%an'").trim()

      // Last commit message
      PIPELINE_GIT_LAST_COMMIT_MSG = sh(returnStdout: true, script: "git log -1 --pretty=format:'%s'").trim()
    }
    stages {
      stage('Install & Setup') {
        steps {
          script {
            printEnvInfo()
            logInfo "pipelineArgs: ${pipelineArgs}"

            if (shouldBuild(pipelineArgs)) {
              runTimed 'Install', {
                runDocker {
                  sh 'yarn install --frozen-lockfile'
                  script {
                    if (sh(script: 'git diff --exit-code yarn.lock', returnStatus: true) > 0) {
                      logErrorAndExit "Changes were detected in yarn.lock file after running 'yarn install'.\nRun 'yarn install' locally and commit the changes."
                    }
                  }
                }
              }

              // Bump version
              runDocker {
                // lerna shells out to git but git inside docker is hosed ¯\_(⊙︿⊙)_/¯
                sh 'git config user.email "jenkins@cvent.com"'
                sh 'git config user.name "Jenkins"'
                if (isRelease(pipelineArgs)) {
                  sh 'yarn lerna version patch --no-push --force-publish --yes'
                } else {
                  sh 'yarn lerna version prerelease --preid SNAPSHOT --no-git-tag-version --no-push --force-publish --yes'
                }
              }

              // Tag release
              if (isRelease(pipelineArgs)) {
                sh "git push --follow-tags origin ${StashUtils.getBranch()}"
              }

              env.PIPELINE_APP_DIR = "packages/${env.PIPELINE_REPO_NAME}-app"
              if (!fileExists(env.PIPELINE_APP_DIR)) {
                logErrorAndExit "Unable to locale main app directory, ${env.PIPELINE_APP_DIR} does not exist."
              }
              dir(env.PIPELINE_APP_DIR) {
                def props = readJSON file: 'package.json'
                env.PIPELINE_ARTIFACT_ID = props.name.replace('@cvent/', '')
                env.PIPELINE_GROUP_ID = "com.cvent.${env.PIPELINE_ARTIFACT_ID}"
                env.PIPELINE_ARTIFACT_VERSION = props.version
                logInfo "groupId: ${env.PIPELINE_GROUP_ID}"
                logInfo "artifactId: ${env.PIPELINE_ARTIFACT_ID}"
                logInfo "version: ${env.PIPELINE_ARTIFACT_VERSION}"
              }
              currentBuild.displayName = "#${env.BUILD_NUMBER} (${env.PIPELINE_ARTIFACT_VERSION})"
            } else if (isLastCommitFromJenkins()) {
              currentBuild.displayName = "#${env.BUILD_NUMBER} (No build: Jenkins release commit)"
            } else if (StashUtils.changeSetContainsOnlyIgnoredFiles(pipelineArgs.ignoreFiles)) {
              currentBuild.displayName = "#${env.BUILD_NUMBER} (No build: Changeset contains only ignored files)"
            } else {
              currentBuild.displayName = "#${env.BUILD_NUMBER} (No build: Unknown reason)"
            }
          }
        }
        post {
          always {
            script {
              notifySlack(pipelineArgs, 'START')
            }
          }
        }
      }
      stage('Build') {
        when {
          expression { shouldBuild(pipelineArgs) }
        }
        steps {
          script {
            runTimed 'Build app', {
              runDocker {
                sh "yarn run lint"
                sh "yarn run test"
                def buildId = isRelease(pipelineArgs) ? env.PIPELINE_GIT_COMMIT : env.BUILD_NUMBER
                logInfo "BUILD_ID: ${buildId}"
                sh "NEXT_TELEMETRY_DISABLED=1 BUILD_ID=${buildId} yarn run build"
              }
            }

            runTimed 'Build & lint CDK', {
              def outDir = 'cdk.out'
              runDocker {
                sh "yarn cdk --app='nx deploy:build' synthesize --output ${outDir}"
              }

              logInfo "Linting CloudFormation templates"
              docker.image('docker.cvent.net/cvent/cfn-lint').inside("--entrypoint ''") {
                sh "cfn-lint-cvent --template ${outDir}/*.template.json"
              }

              logInfo "Linting CDK metadata"
              new CdkMetadataLinter(this, [globs: ["${outDir}/manifest.json"]]).lint()
            }

            runTimed 'Upload static assets', {
              runDocker {
                dir(env.PIPELINE_APP_DIR) {
                  // Upload assets to all AWS accounts used in lower regions
                  def accounts = ['cvent-sandbox', 'cvent-development']

                  /* TODO: enable this before going to Prod
                  // For a release build, also upload assets to cvent-production AWS account
                  if (isRelease(pipelineArgs)) {
                    accounts += 'cvent-production'
                  }
                  */

                  parallel accounts.collectEntries() {
                    [("upload-assets-" + it): { ->
                      withCredentials([[
                          $class: 'AmazonWebServicesCredentialsBinding',
                          credentialsId: "${it}-shared-jenkins"]]) {
                        sh "yarn nx upload-assets ${env.PIPELINE_ARTIFACT_ID} ${env.PIPELINE_ARTIFACT_VERSION} --account=${it}"
                      }
                    }]
                  }
                }
              }
            }

            runTimed 'Build artifacts', {
              def archive = "${env.WORKSPACE}/${env.PIPELINE_ARTIFACT_ID}-${env.PIPELINE_ARTIFACT_VERSION}.tar.gz"
              def configArchive = "${env.WORKSPACE}/${env.PIPELINE_ARTIFACT_ID}-${env.PIPELINE_ARTIFACT_VERSION}-configs.tar.gz"
              def v = params.VERBOSE_LOGGING ? 'v' : ''
              sh "tar -c${v}zf ${archive} node_modules -C ${env.PIPELINE_APP_DIR} --exclude=*.gz dist server next.config.js package.json"
              sh "tar -c${v}zf ${configArchive} -C ${env.PIPELINE_APP_DIR} ./configs"

              // Upload release artifacts to Nexus
              // TODO: determine if this step is really needed when using deploy time configs
              if (isRelease(pipelineArgs)) {
                def commonArgs = [
                    'deploy:deploy-file',
                    '--batch-mode',
                    "-DgroupId=${env.PIPELINE_GROUP_ID}",
                    "-DartifactId=${env.PIPELINE_ARTIFACT_ID}",
                    "-Dversion=${env.PIPELINE_ARTIFACT_VERSION}",
                    '-Durl=' + 'http://deployment:deployment123@nexus.core.cvent.org:8081/nexus/content/repositories/releases',
                    '-Dpackaging=tar.gz'
                ].join(' ')
                sh "mvn ${commonArgs} -Dfile=${archive} -DgeneratePom=true"
                sh "mvn ${commonArgs} -Dfile=${configArchive} -Dclassifier=configs -DgeneratePom=false"
              }
            }
          }
        }
      }
      stage('Docker Image') {
        when {
          expression { shouldBuild(pipelineArgs) }
        }
        steps {
          script {
            runTimed "Checkout", {
              runCheckout('ssh://git@stash.cvent.net:7999/dep/deploy-aws-docker.git', params.DEPLOY_AWS_DOCKER_BRANCH ?: 'develop')
              runCheckout('ssh://git@stash.cvent.net:7999/dep/hogan-configs.git', params.HOGAN_CONFIGS_BRANCH ?: 'master')
              dir('hogan-configs') {
                env.PIPELINE_HOGAN_GIT_SHA = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()
                logInfo "hogan-configs git sha: ${env.PIPELINE_HOGAN_GIT_SHA}"
              }
            }

            runTimed 'Build docker image', {
              dir('deploy-aws-docker') {
                withSecrets {
                  def vars = [
                      GROUP_ID: env.PIPELINE_GROUP_ID,
                      ARTIFACT_ID: env.PIPELINE_ARTIFACT_ID,
                      VERSION: env.PIPELINE_ARTIFACT_VERSION,
                      HOGAN_CONFIGS_DIR: "${env.WORKSPACE}/hogan-configs",
                      BUILD_WORKSPACE: env.WORKSPACE,
                      PLATFORM: 'node',
                      VERBOSE: params.VERBOSE_LOGGING ? '1' : '0',
                      ASYNC: true,
                      FORCE_REBUILD: false,
                      GIT_SHA: env.PIPELINE_GIT_COMMIT
                  ]

                  withEnv(vars.collect { it.key + '=' + it.value }) {
                    sh './build_push_docker_img.sh'
                  }

                  def props = readProperties file: 'service_info.properties'
                  env.PIPELINE_ECR_IMAGE_TAG = props['ECR_IMAGE_TAG']
                  def msg = "ECR_IMAGE_TAG: ${env.PIPELINE_ECR_IMAGE_TAG}"
                  logInfo msg
                  currentBuild.description = msg
                }
              }
            }
          }
        }
      }
      stage('CI') {
        when {
          expression { shouldBuild(pipelineArgs) }
        }
        steps {
          script {
            def config = getConfig(pipelineArgs.ci)
            def environments = getEnvironments(config)
            if (environments) {
              def steps = environments.collectEntries() {
                [("deploy-cdk-" + it): { -> deployCDK("${it}") }]
              }
              steps['deploy-ecs'] = {
                deployECS(environments)
              }
              lock("${env.PIPELINE_ARTIFACT_ID}-ci") {
                runDeploys(steps)
              }
            } else {
              logWarn "No environments defined for CI!"
            }
          }
        }
      }
      stage('Deploy Release') {
        when {
          expression { isRelease(pipelineArgs) }
        }
        steps {
          script {
            def config = getConfig(pipelineArgs.release)
            if (!config) {
              logInfo "No release build config matching ${StashUtils.getBranch()} for release deployment"
            }
            def environments = getEnvironments(config)
            if (environments) {
              def steps = environments.collectEntries() {
                [("deploy-cdk-" + it): { -> deployCDK("${it}") }]
              }
              steps['deploy-ecs'] = {
                deployECS(environments)
              }
              lock("${env.PIPELINE_ARTIFACT_ID}-release") {
                runDeploys(steps)
              }
            } else {
              logInfo "No environments defined for release deployment"
            }
          }
        }
      }
    }
    post {
      always {
        script {
          notifySlack(pipelineArgs, currentBuild.currentResult)
        }
      }
    }
  }
}