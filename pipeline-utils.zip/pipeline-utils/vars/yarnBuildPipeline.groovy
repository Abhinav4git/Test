#!/usr/bin/env groovy

import cvent.aws.AwsUtils;
import cvent.jenkins.GroovyUtils;
import cvent.stash.Utils;
import cvent.slack.SlackUtils;

/*
 * Whether this build should create a release.
 */
def boolean isRelease(config) {
  // Never release from a PR
  if (env.CHANGE_URL) {
    return false
  }

  // Release from trunk
  if (env.GIT_BRANCH =~ config?.trunk) {
    return true
  }

  // Release from release branches
  if(config?.release?.branches.any { it =~ env.GIT_BRANCH }) {
    return true
  }

  return false
}

/*
 * Whether to contribute changes made in the build back to the repository
 * This intentionally does not take params['Publish'] into account, so that PR
 * builds that publish prereleases do not get updated.
 */
def boolean shouldContribute(config) {
  return isRelease(config)
}

/**
 * Whether this build should be published
 */
def boolean shouldPublish(config) {
  shouldContribute(config) || params['Publish']
}

/*
 * The prerelease identifier to use for the build.
 * Currently just uses the git branch.
 * Empty means 'release'
 */
def String prereleaseId(config) {
  return isRelease(config) ? '' : env.GIT_BRANCH
}

/**
 * The versions taking part in this build.
 * This is an array to support repositories with many different versions.
 */
def String[] packageVersions() {
  def version = readJSON([file: './package.json']).version
  if (version) {
    return [version]
  } else {
    return sh(returnStdout: true, script: "git tag --points-at HEAD").trim().split('\n')
  }
}

def call(Map config) {
  // Default config if not otherwise specified.
  def default_config = [
    // Top level agent to use.
    label: 'codebuild-medium',
    ci: [
      // Isolate CI runs to be one-at-a-time
      isolation: true,
    ],
    // trunk is implicitly also a release branch
    trunk: 'master',
    release: [
      branches: [ /release\/.+/ ]
    ]
  ]

  // Deep merge config
  config = GroovyUtils.mergeMaps(default_config, config)

  pipeline {
    parameters {
      booleanParam(name: "Publish", description: "Force any publishable artifacts to get published to relevant artifact stores")
    }
    options {
      ansiColor('xterm')
      timestamps()
      parallelsAlwaysFailFast()
    }
    environment {
      CI = 'true'

      REPO_ID = JOB_NAME.split("/").take(2).join('/')

      // Get the last commit hash
      GIT_COMMIT = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()

      // Get the last commit author
      GIT_LAST_COMMITTER = sh(returnStdout: true, script: "git log -1 --pretty=format:'%an'").trim()
    }
    agent { label config?.label }
    stages {
      stage ('Prepare') {
        parallel {
          // Output useful information about the job.
          stage ('Display Job Info') {
            steps {
              printEnvInfo(config)
            }
          }
          /*
           * If this pipeline runs on the same workspace, on the same agent,
           * it is possible to encounter old tags of the same name as those we
           * are going to create later in the version bump. Pruning removes
           * any tags that are not present on the remote, to make sure we don't
           * run into them.
           */
          stage ('Prune git tags') {
            steps {
              sshagent(['e01b632a-4bb4-446b-9d93-793565f2293f']) {
                sh 'git tag'
                sh 'git ls-remote --tags'
                sh 'git tag --list | xargs git tag --delete && git fetch --tags'
                sh 'git tag'
                sh 'git ls-remote --tags'
              }
            }
          }
          /*
           * Pre-commit will stash changes to files that are supposed to be
           * changed (e.g. from version bumps). It therefore needs to happen
           * in a different context from the steps below. That different
           * context could be making sure they happen sequentially, or making
           * them happen on different agents
           */
          stage('Verify Pre-commit Hooks') {
            options { ansiColor('xterm') }
            agent { label config?.label }
            when {
              beforeAgent true
              expression { fileExists('.pre-commit-config.yaml') }
            }
            steps { precommit() }
          }
          // Do everything yarn related
          stage('Yarn') {
            stages {
              stage ('Prepare') {
                steps {
                  // Run asdf for all subdirectories that contain '.tool-versions'
                  sh "command -v asdf && find . -name '.tool-versions' | xargs -r -L1 dirname | xargs -r -I@@ sh -c 'cd @@ && asdf install' && asdf reshim"
                }
              }
              stage ('Install') {
                steps {
                  withSecrets {
                    // We may be running as root inside docker containers
                    sh 'npm set unsafe-perm true'

                    sh 'yarn install --frozen-lockfile'
                  }

                  /**
                   * Workaround for `yarn install --frozen-lockfile` not
                   * failing on yarn.lock updates as expected
                   * See:
                   *   - https://github.com/yarnpkg/yarn/issues/4098
                   *   - https://github.com/yarnpkg/yarn/issues/5840
                   */
                  script {
                    if (sh(script: 'git diff --exit-code yarn.lock', returnStatus: true) > 0) {
                      logErrorAndExit("Changes were detected in yarn.lock file after running 'yarn install', which is not expected. Please run 'yarn install' locally and commit the changes.")
                    }
                  }
                }
              }
              stage ('Bump version') {
                steps {
                  withSecrets {
                    sh "yarn run release:version ${prereleaseId(config)}"
                  }

                  script {
                    currentBuild.description = packageVersions().join('\n')
                  }
                }
              }
              stage ('Build') {
                steps {
                  script {
                    withSecrets {
                      AwsUtils.withAwsProfiles {
                        sh "yarn run build"
                      }
                    }
                  }
                }
              }
              stage ('Validate') {
                steps {
                  script {
                    withSecrets {
                      AwsUtils.withAwsProfiles {
                        parallel(
                          lint: { sh "yarn run lint" },
                          test: { sh "yarn run test" },
                          ci: {
                            if (config?.ci?.isolation) {
                              lock(resource: "${REPO_ID}-ci") {
                                sh "yarn ci"
                              }
                            } else {
                              sh "yarn ci"
                            }
                          }
                        )
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      stage('Publish') {
        when {
          expression { shouldPublish(config) }
        }
        steps {
          lock(resource: "${REPO_ID}-publish") {
            script {
              withSecrets {
                AwsUtils.withAwsProfiles {
                  // TODO: Add any other credentials for other artifact stores
                  withCredentials([string(credentialsId: 'octopus-deploy-apikey',
                                  variable: 'OCTO_API_KEY')]) {

                    sh "yarn run release:publish"
                  }
                }
              }

              if (shouldContribute(config)) {
                // Contribute changes back to repository
                sshagent(['e01b632a-4bb4-446b-9d93-793565f2293f']) {
                  sh "git push --follow-tags origin HEAD:${Utils.getBranch()}"
                }
              }
            }
          }
        }
      }
    }
    post {
      always {
        script {
          SlackUtils.sendFields(config?.slack?.channels, [
            'Branch': env.GIT_BRANCH,
            'Author': env.GIT_LAST_COMMITTER,
            'Version(s)': packageVersions(),
            'Commit': env.GIT_COMMIT,
          ])
        }
      }
    }
  }
}
