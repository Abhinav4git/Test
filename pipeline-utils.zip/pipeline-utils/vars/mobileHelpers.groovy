def unlockMACKeyChain() {
  withCredentials([string(credentialsId: 'osx_CC_keychain', variable: 'OSX_CC_KEYCHAIN_PASSWORD')]) {
    sh '''security list-keychain -s /Users/jenkins-slave/CCProvisioning.keychain
    security default-keychain -s /Users/jenkins-slave/CCProvisioning.keychain
    security -v unlock-keychain -p "$OSX_CC_KEYCHAIN_PASSWORD" /Users/jenkins-slave/CCProvisioning.keychain'''
  }
}

def setupIOSEnvironment() {
  sh '''export PATH="$PATH:/usr/local/bin:$HOME/.rbenv/bin:$HOME/.rbenv/shims"
  eval "$(rbenv init -)"'''
}