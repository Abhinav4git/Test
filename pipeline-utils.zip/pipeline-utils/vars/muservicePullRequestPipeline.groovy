// Used only on QA to run pull requests with the latest version of Hub or Event
// Center if they are specified as dependencies.
private String getTagForService(String serviceName) {
    sh(script: "DOCKER_HOST='docker.qa.crowdcompass.com:2376' docker service ls --format '{{.Image}}' | grep -m 1 ${serviceName} | awk -F ':' '{print \$NF}'", returnStdout: true).trim()
}

private String dockerComposeWithActions(String action, String service='', String options) {
    "docker-compose --project-name ${env.PULL_REQUEST_FROM_HASH} -f docker-compose.pull-request.yml ${action} ${service} ${options}"
}

def buildDatabase() {
    // Alias for db:create, db:migrate
    sh(script: dockerComposeWithActions("run", "web", "bundle exec rake db:setup"))
}

def databaseConfigExists() {
    // Used to execute buildDatabase() conditionally
    fileExists("config/database.yml")
}

def cleanBranch() {
  sh "git clean -fdx"
  sh "git reset --hard"
}

def checkoutRepo() {
    stage("Git checkout and --ff") {
        git url: "ssh://git@git.crwd.cc:7999/stash/cc/${env.PULL_REQUEST_FROM_REPO_SLUG}.git", branch: "${env.PULL_REQUEST_TO_BRANCH}"
        sh "git checkout -B '${env.PULL_REQUEST_FROM_BRANCH}-merged'"
        sh "git merge --ff 'origin/${env.PULL_REQUEST_FROM_BRANCH}'"
    }
}

def bundleAndBuild() {
    stage("Bundle package --all, build docker containers") {
        // We only need to environment for SSH access to execute bundle package --all for the local repository
        // and does not affect pull requests
        script { ccDocker.buildScriptv2(env.PULL_REQUEST_FROM_REPO_SLUG, "qa", "bundle package --all") }
        // Compose and start container for the application in detached mode so subsequent commands can run
        sh(script: dockerComposeWithActions("up", "--build --detach"))
    }
}

def setupDatabaseIfPresent() {
    if (databaseConfigExists()) {
        stage("Building database") { buildDatabase() }
    } else {
        stage("Skipping database") { sh "echo Skipping stage..."}
    }
}

def runTests() {
    stage("Running unit tests") {
        sh(script: dockerComposeWithActions("run", "web", "bundle exec rspec --format documentation"))
    }
}

def destroyTestContainersAndImages() {
    // Stop and kill all containers, including potentially orphaned containers from failed runs
    sh(script: dockerComposeWithActions("down", "--remove-orphans"))
    // Remove all images associated with the run in order to preserve space on jenkins instances
    sh(script: "docker rmi ${env.PULL_REQUEST_FROM_HASH}_web:latest")
}

def notifyBitbucketWithState() {
    notifyBitbucket(
            commitSha1: "${env.PULL_REQUEST_FROM_HASH}",
            credentialsId: '846e5461-96ab-4577-bccd-684c794d8a00',
            disableInprogressNotification: false,
            ignoreUnverifiedSSLPeer: true,
            includeBuildNumberInKey: false,
            prependParentProjectKey: false,
            considerUnstableAsSuccess: false,
            projectKey: 'CC',
            stashServerBaseUrl: 'https://stash.cvent.net'
    )
}

def call() {
    pipeline {
        agent { label 'redhat' }
        options {
            timestamps()
            ansiColor('xterm')
        }

        stages {
            stage('Building and running tests') {
                environment {
                    HUB_DOCKER_TAG = getTagForService('hub')
                    EVENTCENTER_DOCKER_TAG = getTagForService('eventcenter')
                }
                steps {
                    notifyBitbucketWithState()
                    cleanBranch()
                    checkoutRepo()
                    bundleAndBuild()
                    setupDatabaseIfPresent()
                    runTests()
                }
            }
        }
        post {
            always {
                destroyTestContainersAndImages()
                script {
                    currentBuild.result = currentBuild.result ?: 'SUCCESS'
                    notifyBitbucketWithState()
                }
            }
        }
    }
}
