// Function is available with the filename. Filename in a comment so it's bitbucket searchable.
// experiment

@Grab("com.launchdarkly:launchdarkly-java-server-sdk:4.8.0")
import com.launchdarkly.client.*

@NonCPS
boolean boolVariation(String artifactId, String featureFlag) {
  return withClient(artifactId, { client, user ->
    return client.boolVariation(featureFlag, user, false)
  })
}

@NonCPS
String stringVariation(String artifactId, String featureFlag, String defaultValue) {
  return withClient(artifactId, { client, user ->
    return client.stringVariation(featureFlag, user, defaultValue)
  })
}

@NonCPS
private Object withClient(String artifactId, Closure body) {
  LDClient ldClient = new LDClient("sdk-7bf9afd8-4291-4e18-8fdc-3e0f0aace387")
  try {
    LDUser user = new LDUser(artifactId)
    return body(ldClient, user)
  } finally {
    ldClient.close()
  }
}
