import cvent.aws.AwsAccount

/**
 * Run an action with a particular AWS user.
 * Simple wrapper around `withCredentials`.
 */
def withUser(String user, Closure action) {
  withCredentials([[
    $class: 'AmazonWebServicesCredentialsBinding',
    credentialsId: user,
  ]], action)
}

def withSharedUser(AwsAccount account, Closure action) {
  withUser("${account.alias}-shared-jenkins", action)
}

def withCdkUser(AwsAccount account, Closure action) {
  withUser("${account.alias}-shared-jenkins-cdk", action)
}
