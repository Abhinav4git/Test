package org.jenkinsci.plugins.workflow.actions

// This class just needs to exist so we can add stubs and mocks to it.
