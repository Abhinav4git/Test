package com.cloudbees.jenkins.plugins.awscredentials

// This class just needs to exist so we can add stubs and mocks to it.
