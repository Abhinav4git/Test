package com.amazonaws.auth

// This class just needs to exist so we can add stubs and mocks to it.
