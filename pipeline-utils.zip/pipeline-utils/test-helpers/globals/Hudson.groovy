package globals

import groovy.transform.Field

@Field def static instance = [:]

static setInstance(i) {
  instance = i
}