package globals

import groovy.transform.AnnotationCollector

/**
* Defines an NonCPS annotation as a substitute for the one that exists globally in the Jenkins
* groovy interpreter so that scripts-under-test that use that annotation can be compiled against
* this one.
*
*  Note that you can'e really define purely new annotations in groovy but you can define
*  shortcuts that aggregate mutliple existing annotations.  So we just aggregate an empty set.
*/
@AnnotationCollector([])
public @interface NonCPS { }