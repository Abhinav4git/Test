/**
* A Utility Class for working with AWS CloudFormation.
* Some of the methods assume that the `aws` tool is available.
*/

package cvent.aws

/**
* Get the status of a stack
*/
def static stackStatus(region, name) { new CloudFormationUtils()._stackStatus(region, name) }
def _stackStatus(region, name) {
  sh(returnStdout: true, script: """aws cloudformation describe-stacks
                                        --region ${region}
                                        --query="Stacks[?StackName=='${name}'].StackStatus"
                                        --output=text""".replaceAll("\n", "")).trim()
}

/**
* Get the URL of a stack
*/
def static stackUrl(region, name) { new CloudFormationUtils()._stackUrl(region, name) }
def _stackUrl(region, name) {
  arn = sh(returnStdout: true, script: """aws cloudformation describe-stacks
                                              --region ${region}
                                              --query="Stacks[?StackName=='${name}'].StackId"
                                              --output=text""".replaceAll("\n", "")).trim()

  "https://console.aws.amazon.com/cloudformation/home?region=${region}#/stack/detail?stackId=${arn.replaceAll('/', '%2F')}"
}

/**
 * Get the list of stacks from the cloudformation/pom.xml property stacks.to.deploy
 */
def static getCloudformationStacksFromPom() { new CloudFormationUtils()._getCloudformationStacksFromPom() }
def _getCloudformationStacksFromPom() {
  if (fileExists('cloudformation/pom.xml')) {
    return readMavenPom(file: 'cloudformation/pom.xml').getProperties()
      .get('stacks.to.deploy')
      .split(',')
      .collect { "cloudformation/stacks/${it.trim()}" }
      .join(",")
  }
}

/**
* Attempt to create a CloudFormation stack
*/
def static createStack(region, name, args = [:]) { new CloudFormationUtils()._createStack(region, name, args) }
def _createStack(region, name, args = [:]) {
    echo "Creating stack ${name} in ${region}"

    if (args['templateS3']) {
      template_argument = "--template-url ${args['templateS3']}"
    } else {
      template_argument = "--template-body 'file://${args['templatePath']}'"
    }

    if (args['parameters']) {
      parameters_arg = "--parameters " + args['parameters']
        .collect { k,v ->
          "ParameterKey=${k},ParameterValue=${v.toString().replaceAll(",", "\\\\,")}"
        }
        .join(" ")
    } else {
      parameters_arg = ""
    }

    sh """aws cloudformation create-stack
              --region ${region}
              --stack-name ${name}
              ${template_argument} ${parameters_arg}
              --timeout-in-minutes=${args['timeout'] ?: 10}
              --capabilities CAPABILITY_NAMED_IAM CAPABILITY_AUTO_EXPAND""".replaceAll("\n", "")

    echo "Waiting for stack ${name} to finish creating..."
    echo "Visit ${stackUrl(region, name)} to follow in the AWS console"

    catchError {
      sh "aws cloudformation wait stack-create-complete --region ${region} --stack-name ${name}"
    }

    if(stackStatus(region, name) == "ROLLBACK_COMPLETE") {
      echo "Cannot recover from a failed create, deleting the stack."
      deleteStack(region, name)
      error "Failed to create stack"
    }
}

/**
* Attempt to update a CloudFormation stack
*/
def static updateStack(region, name, args = [:]) { new CloudFormationUtils()._updateStack(region, name, args) }
def _updateStack(region, name, args = [:]) {
    echo "Updating stack ${name} in ${region}"

    if (args['templateS3']) {
      template_argument = "--template-url ${args['templateS3']}"
    } else {
      template_argument = "--template-body 'file://${args['templatePath']}'"
    }

    if (args['parameters']) {
      parameters_arg = "--parameters " + args['parameters']
        .collect { k,v ->
          "ParameterKey=${k},ParameterValue=${v.toString().replaceAll(",", "\\\\,")}"
        }
        .join(" ")
    } else {
      parameters_arg = ""
    }

    update_cmd = """aws cloudformation update-stack
            --region ${region}
            --stack-name ${name}
            ${template_argument} ${parameters_arg}""".replaceAll("\n", "")

    // https://stackoverflow.com/a/8811800
    updates = sh(returnStdout: true, script: "output=\"\$(${update_cmd} 2>&1)\" || if [ \"\${output#*No updates are to be performed.}\" != \"\${output}\" ]; then echo 'No updates'; else exit 255; fi").trim()

    echo "Updates: /${updates}/"

    if(updates == "No updates") {
      echo "No stack updates"
    } else {
      echo "Waiting for stack ${name} to finish updating..."
      echo "Visit ${stackUrl(region, name)} to follow in the AWS console"
      sh "aws cloudformation wait stack-update-complete --region ${region} --stack-name ${name}"
    }
}

/**
* Attempt to delete a CloudFormation stack
*/
def static deleteStack(region, name) { new CloudFormationUtils()._deleteStack(region, name) }
def _deleteStack(region, name) {
  echo "Disabling any termination protection on stack ${name} in ${region}"
  sh "aws cloudformation update-termination-protection --region ${region} --no-enable-termination-protection --stack-name ${name}"

  echo "Deleting CloudFormation stack with name ${name} in ${region}"
  sh "aws cloudformation delete-stack --region ${region} --stack-name ${name}"

  echo "Waiting for stack ${name} to finish deleting..."
  echo "Visit ${stackUrl(region, name)} to follow in the AWS console"
  sh "aws cloudformation wait stack-delete-complete --region ${region} --stack-name ${name}"
}

/**
* Update/Create a stack as necessary
*/
def static upsertStack(region, name, args = [:]) { new CloudFormationUtils()._upsertStack(region, name, args) }
def _upsertStack(region, name, args = [:]) {
  echo "Upserting stack ${name} in ${region}"

  if (stackStatus(region, name) == "") {
    createStack(region, name, args)
  } else {
    updateStack(region, name, args)
  }
}

/**
* Lint a template
*/
def static lintTemplate(region, path) { new CloudFormationUtils()._lintTemplate(region, path) }
def _lintTemplate(region, path) {
  linters = [:]

  linters['CFN Lint'] = {
    docker.image('docker.cvent.net/cvent/cfn-lint').inside("--entrypoint ''") {
      sh "cfn-lint-cvent --regions ${region} --template ${path}"
    }
  }

  parallel linters
}

/**
* Package a template
*/
def static packageTemplate(region, path, bucket, prefix) { new CloudFormationUtils()._packageTemplate(region, path, bucket, prefix) }
def _packageTemplate(region, path, bucket, prefix) {
  newPath = "${path}.packaged"

  echo "Packaging template ${path} into ${newPath}"

  sh "aws cloudformation package --region ${region} --template-file ${path} --output-template-file ${newPath} --s3-bucket ${bucket} --s3-prefix ${prefix}"
}

/**
* Deploy a template
*/
def static deployTemplate(region, path, name, bucket, prefix, parameters = [:]) { new CloudFormationUtils()._deployTemplate(region, path, name, bucket, prefix, parameters) }
def _deployTemplate(region, path, name, bucket, prefix, parameters = [:]) {
  path = "${path}.packaged"

  echo "Deploying template ${path} in ${region}"

  if (parameters) {
    parameters_arg = "--parameter-overrides " + parameters
      .collect { k,v ->
        "${k}=\"${v.toString()}\""
      }
      .join(" ")
  } else {
    parameters_arg = ""
  }

  sh """aws --region ${region} cloudformation deploy
            --template-file '${path}'
            --stack-name ${name}
            ${parameters_arg}
            --s3-bucket ${bucket} --s3-prefix ${prefix}
            --no-fail-on-empty-changeset
            --capabilities CAPABILITY_NAMED_IAM""".replaceAll("\n", "")
}

/**
* Create a numeric ID that is unique for a given STRING and within the range 0 - 50000
* This is used for LB rule priorities
*/
def static generatePriorityId(s) {
  s.hashCode() % 49999 + 1
}

/**
* For all parameter files for the current module, replace the special variables
*/
def static addDynamicParameters(parameters, tag) { new CloudFormationUtils()._addDynamicParameters(parameters, tag) }
def _addDynamicParameters(parameters, tag) {
  environment = parameters.find { it['ParameterKey'] == 'Environment' }['ParameterValue']
  lbPath = parameters.find { it['ParameterKey'] == 'LbPath' }['ParameterValue']

  if (environment && lbPath) {
    id = generatePriorityId "${environment}${lb_path}"
    parameters.find { it['ParameterKey'] == 'Id' }['ParameterValue'] = id
  }

  parameters.find { it['ParameterKey'] == 'Tag' }['ParameterValue'] = tag

  parameters
}

/**
* Publish parameter files to S3
*/
def static publishStackParameters(location, environment, args = [:]) { new CloudFormationUtils()._publishStackParameters(location, environment, args) }
def _publishStackParameters(location, environment, args = [:]) {
  splitted_location = target.location.tokenize('@')

  switch (splitted_location.size) {
    case 2:
      build job: 'publish-cloudformation-parameters', parameters: [
        string(name: 'AWS_ACCOUNT_NAME', value: splitted_location.get(0)),
        string(name: 'AWS_REGION', value: splitted_location.get(1)),
        string(name: 'GIT_REPO', value: env.git_url),
        string(name: 'BRANCH', value: StashUtils.getBranch()),
        string(name: 'SERVICE_NAME', value: publish_args.service_name),
        string(name: 'ECR_IMAGE_TAG', value: 'latest'),
        string(name: 'CLUSTER_NAME', value: 'shared1'),
        string(name: 'REGION_LIST', value: ''),
        booleanParam(name: 'GENERATE_TEMPLATES', value: false)
      ]
    default: error 'Deploying to non AWS accounts is not supported'
  }
}

def static normalizeTemplate(String filePath) { new CloudFormationUtils()._normalizeTemplates([filePath]) }
def static normalizeTemplates(List<String> filePaths) { new CloudFormationUtils()._normalizeTemplates(filePaths) }
def private _normalizeTemplates(List<String> filePaths) {
  // TODO: Short-circuit the case when the template is already JSON

  def runFlip = {
    return parallel(filePaths.collectEntries {
      // We use cfn-flip to transform all our templates into JSON.
      // We cannot use native parsers because of the CFN-specific YAML instructions
      [(it): { sh(returnStdout: true, script: "cfn-flip --json ${it}") }]
    })
  }

  try {
    if (!sh(returnStatus: true, script: 'command -v cfn-flip')) {
      return runFlip.call()
    } else {
      docker.image('cvent/cfn-flip').inside("--entrypoint=''") {
        return runFlip.call()
      }
    }
  } catch (e) {
    echo "WARNING: Unable to flip ${filePaths} (${e})"
  }
}

/**
 * Deserialize a CloudFormation file into a groovy object.
 * Warn if a file cannot be parsed.
 * Return null if the file is not a cloudformation template.
 */
def static deserializeTemplate(String filePath) { new CloudFormationUtils()._deserializeTemplates([filePath]) }
def static deserializeTemplates(List<String> filePaths) { new CloudFormationUtils()._deserializeTemplates(filePaths) }
def private _deserializeTemplates(List<String> filePaths) {
  def normalized = CloudFormationUtils
    .normalizeTemplates(filePaths)
    .findAll { _, contents -> contents }

  return parallel(normalized.collectEntries { path, contents ->
    [(path): {
      def deserialized

      try {
        deserialized = readJSON(text: contents)
      } catch (e) {
        echo "WARNING: Unable to parse ${it} as JSON (${e})"
        return null
      }

      // Cloudformation identifiers
      if (deserialized instanceof net.sf.json.JSONObject && (deserialized['AWSTemplateFormatVersion'] || deserialized['Resources'])) {
        return deserialized
      } else {
        return null
      }
    }]
  })
}
