/**
 * A Utility Class for deploying.
 */

package cvent.aws

/**
 * Get a list of deploy locations from a 'stack name' and 'stack info' (metadata about the stack)
 *
 * @param stackName       The name of the stack we are working with
 * @param stackInfo       A map of metadata about the stack
 *
 * @returns               A list of location-compatible Strings
 */
def static getDeployLocations(stackName, stackInfo) { new DeployUtils()._getDeployLocations(stackName, stackInfo) }
private _getDeployLocations(stackName, stackInfo) {
  stackInfo?.locations ?: []
}

/**
 * Deploys a stack with CloudFormation to a location
 * Template formats supported:
 *   template.yaml -> A CloudFormation template
 *   template.groovy -> A groovy file that provides a `templateUrl(region) -> templateUrl` function
 *
 * @param name            The name of the application to deploy
 * @param stackName       The name of the stack (directory under `cloudformation`)
 * @param location        The AwsUtils location string (ie. cvent-development@us-east-1)
 * @param stackInfo       The location to deploy to
 */
def static deployToLocation(name, stackName, location, args = [:]) { new DeployUtils()._deployToLocation(name, stackName, location, args) }
private _deployToLocation(name, stackName, location, args = [:]) {
  def (account, environment, region, _availability_zone) = AwsUtils.parseLocation(location)

  stackDirectoryPath = "cloudformation/${stackName}"
  if (!fileExists(stackDirectoryPath)) {
    error "No stack directory found for ${stackName}"
  }

  deployArgs = args

  // First try to find the template by location
  templateFile = (findFiles(glob: "${stackDirectoryPath}/template.${location}.*") as List)[0]

  // If no template exist by location then fallback to looking for a default template
  if (!templateFile) {
    templateFile = (findFiles(glob: "${stackDirectoryPath}/template.*") as List)[0]
  }

  echo "INFO:_deployToLocation: templateFile ${templateFile.name}"

  if (!templateFile) {
    error "No template found for ${stackName}"
  } else if (templateFile.name.endsWith("groovy")) {
    deployArgs['templateS3'] = load(templateFile.path).templateUrl(region)
    deployMethod = 'upsert'
  } else if (templateFile.name.endsWith("yaml")) {
    templatePath = templateFile.path
    deployMethod = 'deploy'
  } else {
    error "Unknown template format ${templateFile.name}"
  }

  parametersFile = (findFiles(glob: "${stackDirectoryPath}/${location}.json") as List)[0]
  deployArgs['parameters'] = (deployArgs['parameters'] ?: [:])
  if (parametersFile) {
    fileParameters = readJSON(file: parametersFile.path).collectEntries {
      [(it['ParameterKey']): it['ParameterValue']]
    }

    deployArgs['parameters'] = deployArgs['parameters'] + fileParameters
  }

  stackName = [ name, stackName, environment ].findAll().join('-')

  echo "INFO:_deployToLocation: stackName ${stackName}"
  if (parametersFile) {
    echo "INFO:_deployToLocation: parametersFile ${parametersFile.name}"
  }
  echo "INFO:_deployToLocation: templatePath ${templatePath}"
  echo "INFO:_deployToLocation: deployMethod ${deployMethod}"

  echo "Deploying ${stackName} to ${location} with args: ${deployArgs}"
  withCredentials([[
      $class: 'AmazonWebServicesCredentialsBinding',
      credentialsId: "${account}-shared-jenkins",
  ]]) {
    docker.image('cvent/aws-cli')
          .inside("-e AWS_ACCESS_KEY_ID -e AWS_SECRET_ACCESS_KEY -e AWS_SESSION_TOKEN --entrypoint ''")  {

      if (deployMethod == 'upsert') {
        CloudFormationUtils.upsertStack(region, stackName, deployArgs)
      } else if (deployMethod == 'deploy') {
        CloudFormationUtils.deployTemplate(region, templatePath, stackName, "${account}-lambda-s3-${region}", stackName, deployArgs['parameters'])
      } else {
        error 'Unknown deploy method'
      }
    }
  }
}

/**
 * Pacakges a CloudFormation template ready for deploy
 *
 * @param name            The name of the application to package
 * @param stackName       The name of the stack (directory under `cloudformation`)
 * @param location        The AwsUtils location string (ie. cvent-development@us-east-1)
 * @param stackInfo       The location to upload any assets to
 */
def static packageToLocation(name, stackName, location, args = [:]) { new DeployUtils()._packageToLocation(name, stackName, location, args) }
private _packageToLocation(name, stackName, location, args = [:]) {
  def (account, environment, region, _availability_zone) = AwsUtils.parseLocation(location)

  stackDirectoryPath = "cloudformation/${stackName}"
  if (!fileExists(stackDirectoryPath)) {
    error "No stack directory found for ${stackName}"
  }

  // First try to find the template by location
  templateFile = (findFiles(glob: "${stackDirectoryPath}/template.${location}.*") as List)[0]

  echo "INFO:_packageToLocation: templateFile1 ${templateFile}"

  // If no template exist by location then fallback to looking for a default template
  if (!templateFile) {
    templateFile = (findFiles(glob: "${stackDirectoryPath}/template.*") as List)[0]
  }

  echo "INFO:_packageToLocation: templateFile2 ${templateFile.name}"

  if (!templateFile) {
    error "No template found for ${stackName}"
  } else if (templateFile.name.endsWith("yaml")) {
    templatePath = templateFile.path
  } else {
    error "Unknown template format ${templateFile.name}"
  }

  echo "INFO:_packageToLocation: templatePath=${templatePath}"

  CloudFormationUtils.lintTemplate(region, templatePath)

  stackName = [ name, stackName, environment ].findAll().join('-')

  echo "Packaging ${stackName} to ${location}"

  withCredentials([[
      $class: 'AmazonWebServicesCredentialsBinding',
      credentialsId: "${account}-shared-jenkins",
  ]]) {
    docker.image('cvent/aws-cli')
          .inside("-e AWS_ACCESS_KEY_ID -e AWS_SECRET_ACCESS_KEY -e AWS_SESSION_TOKEN --entrypoint ''")  {
      CloudFormationUtils.packageTemplate(region, templatePath, "${account}-lambda-s3-${region}", stackName)
    }
  }
}

/**
 * Deletes a CloudFormation stack from a location
 *
 * @param name            The name of the application to delete
 * @param stackName       The name of the stack (directory under `cloudformation`)
 * @param location        The AwsUtils location string (ie. cvent-development@us-east-1)
 * @param stackInfo       The location to delete from
 */
def static removeFromLocation(name, stackName, location) { new DeployUtils()._removeFromLocation(name, stackName, location) }
private _removeFromLocation(name, stackName, location) {
  def (account, environment, region, _availability_zone) = AwsUtils.parseLocation(location)

  stackName = [ name, stackName, environment ].findAll().join('-')

  docker.image('cvent/aws-cli').inside("--entrypoint ''")  {
    withCredentials([[
      $class: 'AmazonWebServicesCredentialsBinding',
      credentialsId: "${account}-shared-jenkins",
    ]]) {
      if (CloudFormationUtils.stackStatus(region, stackName) != "") {
        echo "Undeploying ${stackName} from ${location}"
        CloudFormationUtils.deleteStack(region, stackName)
      }
    }
  }
}
