package cvent.aws

import cvent.linters.CdkMetadataLinter
import cvent.linters.CloudFormationLinter

import java.text.SimpleDateFormat
/**
 * Class for dealing with CDK stacks
 */
class CdkManager {
  def jenkins; // org.jenkinsci.plugins.workflow.cps.CpsScript

  // Path (relative to current CDK dir) to CDK app/bin file for this deployment
  String entrypoint;

  // Stacks within the entrypoint's app to use for deployment
  List<String> stacks;

  // Extra arguments to pass to CDK (not recommended to use much)
  String args;

  // parameter to skip deployment and only perform relevant checks
  boolean skipDeployment;

  // Do NOT use directly - use getAwsAccount() instead.
  // AWS Account that the stack(s) will deploy to.
  AwsAccount awsAccount;

  String outDir;

  // CFN Stack linter
  CloudFormationLinter linter;
  CdkMetadataLinter cdklinter;

  def CdkManager(context, Map map) {
    this.jenkins = context

    this.entrypoint = map.entrypoint
    this.skipDeployment = map.skipDeployment
    this.stacks = map.stacks ?: []
    this.args = map.args ?: ''
    this.outDir = map.outDir ?: 'cdk.out'

    this.linter = new CloudFormationLinter(context, [globs: ["${this.outDir}/*.template.*"]])
    this.cdklinter = new CdkMetadataLinter(context, [globs: ["${this.outDir}/manifest.json"]])
  }

  def static CdkManager fromTarget(context, Map map) {
    def manager = new CdkManager(context, map)

    if (!manager.enabled()) {
      return null
    }

    manager.validate()
    manager.lint()

    return manager
  }

  /**
   * String for use with shell commands.
   * Append with cdk arguments and commands
   */
  def String cdk() {
    if (this.entrypoint.endsWith('.ts')) {
      return "yarn --silent cdk --ci --output ${this.outDir} --app 'npx ts-node --prefer-ts-exts ${this.entrypoint}'"
    } else if (this.entrypoint.endsWith('.js')) {
      return "yarn --silent cdk --ci --output ${this.outDir} --app 'node ${this.entrypoint}'"
    } else {
      return "yarn --silent cdk --ci --output ${this.outDir} --app '${this.entrypoint} > /dev/null'"
    }
  }

  /**
   * String for use with shell commands
   * This is a complete command. Use string operations if you need to update it
   */
  def String cdk(command) {
    return [cdk(), command, args].join(' ')
  }

  /**
   * Get detailed information about the stacks in an entrypoint
   * filterStacks = false will output information for all stacks
   * filterStacks = true will output information for only stacks in the `stacks` field
   */
  def stacksInfo(boolean filterStacks = true) {
    def listCmd = this.cdk('list') + ' --long --json'

    jenkins.awsUser.withCdkUser(getAwsAccount()) {
      def allStacksJson = jenkins.sh(returnStdout: true, script: listCmd)

      def allStacks = jenkins.readJSON(text: allStacksJson)

      jenkins.echo "All Stacks: ${allStacks}"

      if (filterStacks && stacks.size() > 0) {
        jenkins.echo "Filtering out only the stacks in: ${stacks}"

        def filteredStacks = allStacks.findAll { stacks.collect { it.toString() }.contains(it.id ? it.id.toString() : it.name.toString()) }
        jenkins.echo "Found ${filteredStacks}"

        return filteredStacks
      } else {
        return allStacks
      }
    }
  }

  /**
   * Lazy getter for the AWS Account associated with the stacks in the entrypoint
   */
  def AwsAccount getAwsAccount() {
    if (awsAccount) {
      return awsAccount
    }

    def listCmd = this.cdk('list') + ' --long --json'

    Set<String> accountIds
    try {
      def stacksJson = jenkins.sh(returnStdout: true, script: listCmd)
      accountIds = jenkins.readJSON(text: stacksJson).collect { it.environment.account }
    } catch (e) {
      // We failed above so lets capture the error and extract it
      def listErrors = jenkins.sh(returnStdout: true, script: listCmd + ' 2>&1 ||:')

      def accountId = (listErrors =~ /(?ms).*Need to perform AWS calls for account (\d+), but no credentials found.*/).with { it.matches() ? it[0][1] : null }

      if (accountId) {
        accountIds = [accountId] as Set
      }
    }

    if (accountIds == null || accountIds.size() == 0) {
      jenkins.error "No AWS accounts found"
    } else if (accountIds.size() == 1) {
      def accountId = accountIds[0]
      jenkins.echo "AWS Account ID: ${accountId}"

      return AwsAccount.find(accountId) ?: new AwsAccount(id: accountId)
    } else {
      jenkins.error "Too many AWS accounts found (${accountIds.join(", ")})"
    }
  }

  /**
   * Is this manager enabled.
   * If not, everything else should be skipped
   */
  def enabled() {
    return !(entrypoint =~ /\.[tj]s$/) || jenkins.fileExists(file: entrypoint)
  }

  /**
   * Validate that this manager is internally valid
   * This should throw errors if not valid
   */
  def validate() {
    // Ensure the stacks all exist
    def availableStacks = stacksInfo()

    def availableStackNames = availableStacks.collect { it.id ? it.id : it.name }

    def unavailableStacks = stacks - availableStackNames
    if (unavailableStacks.size() > 0) {
      jenkins.error "The following stacks are not available in ${entrypoint}: ${unavailableStacks.join(", ")}."
    }

    jenkins.awsUser.withCdkUser(getAwsAccount()) {
      // Ensure that CDK is set-up correctly
      jenkins.sh cdk('doctor')
    }
  }

  /**
   * Synthesize the stacks
   */
  def synthesize() {
    jenkins.awsUser.withCdkUser(getAwsAccount()) {
      // Remove any old stacks if we might be re-synthesizing
      jenkins.dir(path: this.outDir) {
        jenkins.deleteDir()
      }

      jenkins.sh cdk('synthesize') + ' > /dev/null'
    }
  }

  /**
   * Validate the stacks for consistency and compliance
   * Will throw error if lint fails.
   */
  def lint() {
    // Ensure we are synthesized first
    synthesize()

    // Lint the generated templates
    this.cdklinter.lint()
    this.linter.lint()
  }

  /**
   * Display a diff between the CDK stacks and the stack in AWS CloudFormation
   * i.e. what changes will be made when deployed
   */
  def diff() {
    jenkins.awsUser.withCdkUser(getAwsAccount()) {
      // Always make the diff return true so pipeline execution continues
      // By defauld cdk diff will exit with status 1 which fails the pipeline
      jenkins.sh cdk('diff') + ' ||:'
    }
  }

  /*
  * Returns a timestamp in the ISO 8601 format: yyyy-MM-ddTHH:mm:ss.SSSXXX
  * https://docs.oracle.com/javase/8/docs/api/java/text/SimpleDateFormat.html
  */
  @NonCPS
  String getTime(String timezone = 'UTC') {
    def dt_format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    dt_format.setTimeZone(TimeZone.getTimeZone(timezone))
    return "${dt_format.format(new Date())}"
  }

  String stackTags(String stackName, String username) {
    def tags = [
      'created-by': username,
      'created-at': this.getTime()
    ]

    def manifestFile = jenkins.readJSON(file: "${this.outDir}/manifest.json")
    tags += manifestFile['artifacts'][stackName]?.metadata.find {stackres ->
        stackres.key[1..-1].indexOf('/') < 0 }?.value.find{ it.type == 'aws:cdk:stack-tags'}?.data.collectEntries { [(it.Key):it.Value] }

    return tags.collect { tag -> String.format("-t '%s'='%s'", tag.key, tag.value) }.join(' ')
  }

  /**
   * Deploy the stacks
   * The stacks should contain information about where they should be deployed to
   */
  def deploy(prompt = true, dryRun = false) {
    if (skipDeployment) {
      jenkins.sh "echo 'Skipping deployment of ${this.toString()}'"
      return
    }

    diff()

    if (prompt) {
      if (isProduction()) {
        jenkins.input(message: "Please confirm deployment of ${this.toString()} to 🚨🚨🚨${getAwsAccount().toString()}🚨🚨🚨")
      } else {
        jenkins.input(message: "Please confirm deployment of ${this.toString()} to ${getAwsAccount().toString()}")
      }
    }

    jenkins.awsUser.withCdkUser(getAwsAccount()) {
      def stackInfo = stacksInfo()

      def lastCommitUser = jenkins.env.PIPELINE_GIT_LAST_COMMITTER_EMAIL ?: jenkins.sh(script:'echo $(git show -s --pretty=%ae)', returnStdout: true).trim()
      lastCommitUser = lastCommitUser.split('@')[0].toLowerCase()

      if (!jenkins.fileExists("${this.outDir}/manifest.json")) {
        synthesize()
      }
      // Disable approvals through cdk because that happens at the previous stage in Jenkins
      stackInfo.each {
        def stackName = it.id ? it.id : it.name
        if (dryRun) {
          jenkins.echo "Dry Run: ${stackName}"
        } else {
          jenkins.sh cdk(String.format('%s %s %s', 'deploy', stackName, stackTags(stackName, lastCommitUser))) + ' --require-approval=never'
        }
      }

    }
  }

  boolean isProduction() {
    return (getAwsAccount().alias.toString() ==~ /.*prod.*/);
  }

  /**
   * Destroy the stacks
   */
  def destroy() {
    jenkins.awsUser.withCdkUser(getAwsAccount()) {
      jenkins.sh cdk('destroy') + "'*' --force"
    }
  }

  /**
   * Return a map of stack name -> outputs
   */
  def outputs() {
    jenkins.awsUser.withCdkUser(getAwsAccount()) {
      return stacksInfo()
        .collectEntries {
          [(it.id ? it.id : it.name): jenkins.sh(returnStdout: true, script:
              "aws cloudformation describe-stacks --region ${it.environment.region} --stack-name ${it.name} --query 'Stacks[].Outputs[]'")]
        }
    }
  }

  @Override
  String toString() {
    if (stacks.size() > 0) {
      return stacks.collect { "${entrypoint}:${it}" }.join(", ")
    } else {
      return entrypoint
    }
  }
}
