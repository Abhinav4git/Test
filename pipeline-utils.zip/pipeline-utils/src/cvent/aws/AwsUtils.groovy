/**
* A Utility Class for working with AWS.
*/

package cvent.aws

import java.io.File
import com.cloudbees.plugins.credentials.CredentialsProvider
import com.cloudbees.jenkins.plugins.awscredentials.AmazonWebServicesCredentials



/**
* Parse the AWS account, Cvent environment, region and availability zone from a location.
* The result can be destructured into the four components
* Examples of a location:
*   * cvent-sandbox -> ['cvent-sandbox', null, null, null]
*   * cvent-development_S431@us-east-1 -> ['cvent-development', 'S431', 'us-east-1', null]
*   * cvent-production@us-west-2a -> ['cvent-production', null, 'us-west-2', 'us-west-2a']
*/
def static parseLocation(location) {
  def (account_environment, region_or_az) = location.tokenize('@').withDefault { null }
  def (account, environment) = account_environment.tokenize('_').withDefault { null }

  if (region_or_az) {
    def (availability_zone, region) = (region_or_az =~ /(.+)[a-z]/).with { it.matches() ? it[0] : [null, region_or_az] }

    [account, environment, region, availability_zone]
  } else {
    [account, environment, null, null]
  }
}

/**
 * This function will return a string of text compatible with the
 * AWS Credentials file.
 * It will contain credentials for all *-shared-jenkins users that Jenkins knows
 * about (all known AWS accounts), and if those credentials are STS enabled,
 * they will be valid for the default period (1 hour).
 */
@NonCPS
private static refreshAwsProfiles() {
  def creds = CredentialsProvider.lookupCredentials(
    AmazonWebServicesCredentials.class,
    Jenkins.instance,
    null,
    null
  );

  StringBuffer profiles = new StringBuffer();

  for (c in creds) {
    def account = (c.id =~ /(.+)-shared-jenkins/).with { matches() ? it[0][1] : null }

    if (account != null) {
      def awsCreds = c.getCredentials()

      profiles.append("[${account}]\n")
      profiles.append("aws_access_key_id=${awsCreds.getAWSAccessKeyId()}\n")
      profiles.append("aws_secret_access_key=${awsCreds.getAWSSecretKey()}\n")

      if (awsCreds instanceof com.amazonaws.auth.BasicSessionCredentials) {
        awsCreds = (com.amazonaws.auth.BasicSessionCredentials) awsCreds
        profiles.append("aws_session_token=${awsCreds.getSessionToken()}\n")
      }
    }
  }

  return profiles
}

/**
 * This function will create temporary `credentials` and `config` files.
 *
 * The `credentials` file wil contain all known AWS credentials
 * (see `refreshAwsProfiles` for details).
 * The `config` file is empty.
 *
 * It will also set AWS environment variables to point to those files, so that
 * the profiles are available to CLI/SDKs
 */
def static withAwsProfiles(Closure action) { new AwsUtils()._withAwsProfiles(action) }
private _withAwsProfiles(Closure action) {
  def tmpDir = sh(returnStdout: true, script: 'mktemp -d').trim()

  def credentialsPath = "${tmpDir}/credentials"
  sh "set +x && echo '${refreshAwsProfiles()}' > ${credentialsPath}"

  def configPath = "${tmpDir}/config"
  sh "touch ${configPath}"

  withEnv([
    'AWS_SDK_LOAD_CONFIG=true',
    "AWS_CONFIG_FILE=${configPath}",
    "AWS_SHARED_CREDENTIALS_FILE=${credentialsPath}",
  ], action)
}
