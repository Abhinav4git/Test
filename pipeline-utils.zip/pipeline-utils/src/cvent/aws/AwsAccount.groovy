package cvent.aws

/**
 * Class for holding info about an AWS account
 */
class AwsAccount {
  String id;
  String alias;

  static final List<AwsAccount> CVENT_ACCOUNTS = [
      new AwsAccount(id: '062509052028', alias: 'alliancetech'),
      new AwsAccount(id: '748599846571', alias: 'crowdcompass-development'),
      new AwsAccount(id: '410104171726', alias: 'crowdcompass-production'),
      new AwsAccount(id: '118122180901', alias: 'conference-development'),
      new AwsAccount(id: '452525046480', alias: 'conference-production'),
      new AwsAccount(id: '924052762697', alias: 'core-app-prod'),
      new AwsAccount(id: '359168641131', alias: 'core-bt-dev'),
      new AwsAccount(id: '594924633499', alias: 'core-cb-prod'),
      new AwsAccount(id: '611736519059', alias: 'core-cdt-prod'),
      new AwsAccount(id: '270991354588', alias: 'core-els-prod'),
      new AwsAccount(id: '752921502988', alias: 'core-fnd-prod'),
      new AwsAccount(id: '449196748993', alias: 'core-kapow-dev'),
      new AwsAccount(id: '226541770672', alias: 'core-passkey-dev'),
      new AwsAccount(id: '219736445914', alias: 'core-reinforce-dev'),
      new AwsAccount(id: '981730702137', alias: 'core-reinforce-prod'),
      new AwsAccount(id: '298967238569', alias: 'core-rmq-prod'),
      new AwsAccount(id: '980043037575', alias: 'core-sec-prod'),
      new AwsAccount(id: '499994853999', alias: 'core-socialtables-dev'),
      new AwsAccount(id: '128086499455', alias: 'core-socialtables-prod'),
      new AwsAccount(id: '028821455465', alias: 'core-tst-prod'),
      new AwsAccount(id: '549967700865', alias: 'core-weddingspot-dev'),
      new AwsAccount(id: '648478728586', alias: 'core-weddingspot-prod'),
      new AwsAccount(id: '466157013880', alias: 'corp-datasys-dev'),
      new AwsAccount(id: '554240366578', alias: 'corp-datasys-prod'),
      new AwsAccount(id: '176015922052', alias: 'corp-entsrv-dev'),
      new AwsAccount(id: '831388342160', alias: 'corp-entsrv-prod'),
      new AwsAccount(id: '504055967630', alias: 'cvent-development'),
      new AwsAccount(id: '834623602341', alias: 'cvent-integration'),
      new AwsAccount(id: '667621734181', alias: 'cvent-management'),
      new AwsAccount(id: '659687181524', alias: 'cvent-production'),
      new AwsAccount(id: '353814863677', alias: 'cvent-production-legacy'),
      new AwsAccount(id: '572724207364', alias: 'cvent-sandbox'),
      new AwsAccount(id: '948269656986', alias: 'decision-street'),
      new AwsAccount(id: '843446578200', alias: 'emi-development'),
      new AwsAccount(id: '482883289550', alias: 'emi-production'),
      new AwsAccount(id: '380741956730', alias: 'eu-ecommerce-prod'),
      new AwsAccount(id: '791439489411', alias: 'kapowdev'),
      new AwsAccount(id: '377257083715', alias: 'kapowprod'),
      new AwsAccount(id: '781050725773', alias: 'lanyon-conferencedr'),
      new AwsAccount(id: '323497583293', alias: 'lanyon-corporateit'),
      new AwsAccount(id: '310368121865', alias: 'lanyon-ebspreprod'),
      new AwsAccount(id: '722263847348', alias: 'lanyon-ebsprod'),
      new AwsAccount(id: '126918722474', alias: 'lanyon-infracore'),
      new AwsAccount(id: '952671928785', alias: 'lanyon-mobile'),
      new AwsAccount(id: '237287497127', alias: 'lanyon-passkey'),
      new AwsAccount(id: '853122785612', alias: 'lanyon-rolpreprod'),
      new AwsAccount(id: '060374500705', alias: 'lanyon-rolprod'),
      new AwsAccount(id: '892055645816', alias: 'quickmobile'),
      new AwsAccount(id: '852512332536', alias: 'quickmobile-dev'),
      new AwsAccount(id: '089964245684', alias: 'socialtables'),
      new AwsAccount(id: '306207302532', alias: 'us-ecommerce-dev'),
      new AwsAccount(id: '211190124038', alias: 'us-ecommerce-prod'),
      new AwsAccount(id: '668679206736', alias: 'wedding-spot'),
      new AwsAccount(id: '556857931977', alias: 'core-hackathon-dev'),
      new AwsAccount(id: '560432367217', alias: 'cvent-conference-dev')
  ]

  /**
   * Find an account by ID or name
   */
  def static AwsAccount find(account) {
    if (account ==~ /\d{12}/) {
      return AwsAccount.CVENT_ACCOUNTS.find { it.id == account }
    } else {
      return AwsAccount.CVENT_ACCOUNTS.find { it.alias == account }
    }
  }

  /**
   * Pretty print an account
   */
  @Override
  String toString() {
    return "${this.id} (${this.alias})"
  }
}
