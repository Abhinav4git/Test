/**
 * A utility class for mobile builds and deployments
 */
package cvent.mobile

/** logInfo
 * This function prints info log with green color
 * @log log is the log message needs to display
 */
def static logInfo(log) { new cvent.mobile.OSSUtils()._logInfo(log) }

def private _logInfo(log) {
  echo "\033[38;5;28m INFO:\033[38;5;0m ${log}"
}

/** logWarn
 * This function prints warning log with yellow color
 * @log log is the log message needs to display
 */
def static logWarn(log) { new cvent.mobile.OSSUtils()._logWarn(log) }

def private _logWarn(log) {
  echo "\033[38;5;3m WARN:\033[38;5;0m ${log}"
}

/** logError
 * This function prints error log with red color
 * @log log is the log message needs to display
 */
def static logError(log) { new cvent.mobile.OSSUtils()._logError(log) }

def _logError(log) {
  echo "\033[38;5;124m ERROR: ${log}\033[38;5;0m"
}

/** deployMobile
 * This function deploys a module to a specified region
 *
 * @params params is a map that has the following elements:
 *  module: it is a list for [service_name,ecr_image_tag]
 *  ecs: whether to deploy to Amazon ECS or to on premise
 *  aws_account_name: the aws account that is used if the deployment is to an aws region
 *  ecs_cluster_name: The ecs cluster to deploy to if deploying to ecs
 *  git_url: The url of the git repository from the module that is being deployed
 *  branch_name: The name of the branch that the module that is being deployed came from
 *  is_consumer: Whether or not this service is a consumer. If unsure, it should be specified in the base.properties file, and if it is not than it is not a consumer, likely
 *  service_root: the service root, often in the form of service_name/v1
 *  memory: how much memory needs to be reserved if the deployment is to ecs
 *  location: the region to deploy to, for example, it is 'ci' for a deployment to ci
 *  desired_count: How many instances of the services should be run on ecs?
 *  group: the group id for the deployment
 *  version: the version number being deployed
 *  language: The project's language. Valid options are java or node
 *  clover: whether or not to run clover. This should only be 'yes' if it is a deploy to ci, and the region being deployed to is the region 'ci'
 *  platform: 'dropwizard 1.x' if it is dropwizard 1.x, anything else for the regular build of dropwizard
 *  hogan_configs_branch: the hogan config branch used by deployment
 * @return
 */
@NonCPS
def static deployMobile(params) { new cvent.mobile.OSSUtils()._deployMobile(params) }

def private _deployMobile(params) {
  module = params['module']
  aws_acct_name = params['aws_account_name']
  ecs_cluster_name = params['ecs_cluster_name']
  git_url = params['git_url']
  branch_name = params['branch_name']
  service_root = params['service_root']
  location = params['location']
  group = params['group']
  version = params['version']
  language = params['language']
  clover = params['clover'] ?: 'no'
  service_root = params['service_root']
  hogan_configs_branch = params['hogan_configs_branch']
  platform = params['platform']
  java_version = params['java_version']
  python_pipeline = params['python_pipeline']

  if (params['ecs'].toBoolean() || location == 'alpha') {
    // start deploy node/java into ECS
    _logInfo("deploying ${module[0]} with tag ${module[1]} to ECS in ${aws_acct_name} ${ecs_cluster_name}")
    try {
      build(job: 'deploy-service-ecs',
              parameters: [
                      string(name: 'AWS_ACCOUNT_NAME', value: aws_acct_name),
                      string(name: 'ECS_CLUSTER_NAME', value: ecs_cluster_name),
                      string(name: 'SERVICE_NAME', value: module[0]),
                      string(name: 'ENV', value: location),
                      string(name: 'ECR_IMAGE_TAG', value: module[1]),
                      string(name: 'SERVICE_URL_ROOT', value: service_root),
                      string(name: 'VERBOSE', value: '0'),
                      string(name: 'PLATFORM', value: platform),
                      booleanParam(name: 'SYNCHRONOUS', value: true),
                      booleanParam(name: 'USE_PYTHON_PIPELINE', value: python_pipeline),
                      //Temporary while analyzing datadog beta feature for node runtime metrics
                      string(name: 'DEPLOY_AWS_DOCKER_BRANCH', value: 'refs/tags/dev')
              ])
    } catch (err) {
      _logError('deployment to ECS failed')
      throw err
    }
  } else {
    _logInfo("deploying ${module[0]} with version ${version} to on Prem in ${location}")
    if (language == 'java') {
      // start deploy java On Prem
      try {
        build(job: 'deploy-dropwizard-flow-2.0', parameters: [
                string(name: 'ENVIRONMENT', value: location),
                string(name: 'GIT_REPO', value: git_url),
                string(name: 'GIT_BRANCH', value: branch_name),
                string(name: 'NEW_DEPLOYMENT', value: 'no'),
                string(name: 'VERSION', value: version),
                string(name: 'START', value: 'yes'),
                string(name: 'SOAPUI', value: 'no'),
                string(name: 'HOGAN_CONFIGS_BRANCH', value: hogan_configs_branch),
                string(name: 'JAVA_VERSION', value: java_version)
        ])
      } catch (err) {
        _logWarn("first try of deployment failed, retry without starting the service ")
        build(job: 'deploy-dropwizard-flow-2.0', parameters: [
                string(name: 'ENVIRONMENT', value: location),
                string(name: 'GIT_REPO', value: git_url),
                string(name: 'GIT_BRANCH', value: branch_name),
                string(name: 'NEW_DEPLOYMENT', value: 'no'),
                string(name: 'VERSION', value: version),
                string(name: 'START', value: 'no'),
                string(name: 'SOAPUI', value: 'no'),
                string(name: 'HOGAN_CONFIGS_BRANCH', value: hogan_configs_branch),
                string(name: 'JAVA_VERSION', value: java_version)
        ])
      }
    } else {
      // start deploy node On Prem
      artifact = params['artifact']
      try {
        build job: 'mobile-node-deploy-ansible', parameters: [
                string(name: "ENVIRONMENT", value: location),
                string(name: "SERVICE_ACCOUNT", value: 'javaman'),
                string(name: "NEW_DEPLOYMENT", value: 'no'),
                string(name: "START", value: 'yes'),
                string(name: "GROUP_ID", value: group),
                string(name: 'ARTIFACT_ID', value: artifact),
                string(name: 'VERSION', value: version),
                string(name: 'HOGAN_CONFIGS_BRANCH', value: hogan_configs_branch)
        ]
      } catch (err) {
        _logWarn("first try of deployment failed, retry without starting the service ")
        build job: 'mobile-node-deploy-ansible', parameters: [
                string(name: "ENVIRONMENT", value: location),
                string(name: "SERVICE_ACCOUNT", value: 'javaman'),
                string(name: "NEW_DEPLOYMENT", value: 'no'),
                string(name: "START", value: 'no'),
                string(name: "GROUP_ID", value: group),
                string(name: 'ARTIFACT_ID', value: artifact),
                string(name: 'VERSION', value: version),
                string(name: 'HOGAN_CONFIGS_BRANCH', value: hogan_configs_branch)
        ]
      }
    }
  }
}

/**mobileTest
 * This funciton runs api and client tests on a mobile project
 * @param params is a map with the following key/value pairs
 *  type: the type of tests that will be run.
 *    Right now, there is only support for api and client, but it is possible to add in more later.
 *    It takes in a string, and if the string contains api, then it runs api tests.
 *    Similarly if it contains client then it runs client tests
 *  envs: the environments to run the tests in
 *  branch: The testing branch to use. It is not the branch of the repository that the code came from, it is the branch of the appropriate testing repository
 * @return
 */
@NonCPS
def static mobileTest(params) { new cvent.mobile.OSSUtils()._mobileTesting(params) }

def private _mobileTesting(params) {
  type = params['type'] ?: ""
  env = params['env']
  test_suite = params['tests']
  test_branch = params['branch']
  slack_channel = params['slack_channel']
  if (type.contains('client')) {
    _logInfo("starting client test for ${test_suite} in ${env}")
    try {
      build job: 'kick-off-pt-web-ui-automation', parameters: [
              string(name: "TESTS", value: test_suite),
              string(name: "ENVIRONMENT", value: env),
              string(name: "GIT_BRANCH", value: test_branch),
              string(name: "SLACK_CHANNEL", value: slack_channel)

      ]
    } catch (err) {
      _logError('the client tests failed')
      throw err
    }
  }
  if (type.contains('api')) {
    _logInfo("starting api test for ${test_suite} in ${env}")
    try {
      if (env == 'alpha') {
        build job: 'mobile-pt-postman-services-ci', parameters: [
                string(name: "gitRepo", value: "${test_suite}-postman"),
                string(name: "testSuite", value: test_suite),
                string(name: "gitBranch", value: test_branch),
                string(name: "environment", value: env),
                string(name: 'slackChannel', value: slack_channel)
        ]
      } else {
        build job: 'mobile-pt-postman-services', parameters: [
                string(name: "gitRepo", value: "${test_suite}-postman"),
                string(name: "testSuite", value: test_suite),
                string(name: "gitBranch", value: test_branch),
                string(name: "environment", value: env),
                string(name: 'slackChannel', value: slack_channel)
        ]
      }
    } catch (err) {
      _logError('the api tests failed')
      throw err
    }
  }

  if (type.contains('performance')) {
    _logInfo("starting performance test for ${test_suite} in ${env}")
    try {
      build job: 'kick-off-plt-oss-services', parameters: [
              string(name: "TESTS", value: test_suite),
              string(name: "SLACK_CHANNEL", value: slack_channel)
      ]
    } catch (err) {
      _logError('the performance tests failed')
      throw err
    }
  }
}

/**
 * buildJavaSnapshot
 * @param params
 *  a map of arguments containing the following:
 *      git_url: the url of the git repository being built
 *      BRANCH_NAME: the name of the branch being built
 *      platform: only needs to be specified if the snapshot being built is a dropwizard 1.x build, in which case extra functionality is needed.
 * @return returns the release modules, which is a list of lists which contain each contain two elements:
 *      the artefact name and its ECR tag
 */
def static buildJavaSnapshot(params){ new cvent.mobile.OSSUtils()._buildJavaSnapshot(params) }
private  _buildJavaSnapshot(params){
  git_url=params['git_url']
  BRANCH_NAME=params['BRANCH_NAME']
  platform=params['platform']?:'dropwizard'
  test_user_docker=params['test_user_docker']

  //If the project uses dropwizard 1.x, then the snapshot build job needs extra parameters, specifically the dropwizard 1.x platform tag and the updated base img tag.
  base_image_tag = platform.contains('dropwizard-1.x') ? 'dropwizard-1.x:cvt_java11__us-east-1__v1.16.53' : ''
  software_platform = platform.contains('dropwizard-1.x') ? 'dropwizard-1.x' : ''

  _logInfo('start building java snapshot')
  try {
    snapshot_image_build = build job: "snapshot-dropwizard-service-docker", parameters: [
            string(name: 'SOFTWARE_PLATFORM', value: software_platform),
            string(name: 'BASE_IMG_TAG', value: base_image_tag),
            string(name: 'GIT_REPO', value: git_url),
            string(name: 'GIT_BRANCH', value: BRANCH_NAME),
            // TODO SRE-4611 needs to be resolved before this parameter can be removed
            booleanParam(name: 'TEST_USE_DOCKER', value: test_user_docker)
    ]
    } catch(err){
    _logError('the snapshot build failed')
    throw err
  }
  snapshot_modules = [snapshot_image_build.buildVariables.ECR_ARTIFACTS.split(','),
                     snapshot_image_build.buildVariables.ECR_IMAGE_TAGS.split(',')].transpose()
  return snapshot_modules
}

/**
 * buildNodeSnapshot
 * This function takes the following parameters then builds a node snapshot. The job clones down the (specific branch of the) repository.
 * @param git_url the url to the git repository for the snapshot.
 * @param branch the url of the branch of the git repository to build.
 * @return
 */
@NonCPS
def static buildNodeSnapshot(git_url, branch) {
  return new cvent.mobile.OSSUtils()._buildNodeSnapshot(git_url, branch)
}

def private _buildNodeSnapshot(git_url, branch) {
  _logInfo('start building node snapshot')
  try {
    snapshot_image_build = build job: "mobile-node-build-snapshot-docker", parameters: [
            string(name: 'GIT_REPO', value: git_url),
            string(name: 'GIT_BRANCH', value: branch),
            string(name: 'OPTIMIZATIONS', value: 'dev')
    ]
  } catch (err) {
    _logError('the snapshot build failed')
    throw err
  }
  return snapshot_image_build
}

/**
 * pushNodeSnapshotECR
 * This function takes the following parameters then builds a node snapshot for ECS deployment. The job clones down the (specific branch of the) repository.
 * @param params params is a map that has the following elements:
 *  AWS_ACCOUNT_NAME: the aws account that is used if the deployment is to an aws region
 *  group: the group id for the deployment
 *  artifact: what is actually being deployed, the service, consumer etc
 *  version: the version number being deployed
 *  base_image_tag: The base image used for building the docker image
 *  clover: whether or not to run clover. This should only be 'yes' if it is a deploy to ci, and the region being deployed to is the region 'ci'
 *  platform: 'dropwizard 1.x' if it is dropwizard 1.x, anything else for the regular build of dropwizard
 *  hogan_configs_branch: the hogan config branch used to build the docker image
 * @return

 */
@NonCPS
def static pushNodeSnapshotECR(params) {
  return new cvent.mobile.OSSUtils()._pushNodeSnapshotECR(params)
}

def private _pushNodeSnapshotECR(params) {
  group = params['group']
  artifact = params['artifact']
  version = params['version']
  platform = params['platform']
  clover = params['clover'] ?: 'no'
  hogan_configs_branch = params['hogan_configs_branch']

  _logInfo("start push ${artifact} with ${version} to ECR")
  try {
    build_result = build(job: 'build-push-service-docker-img-to-ecr',
            parameters: [
                    string(name: 'GROUP_ID', value: group),
                    string(name: 'ARTIFACT_ID', value: artifact),
                    string(name: 'VERSION', value: version),
                    string(name: 'HOGAN_CONFIGS_BRANCH', value: hogan_configs_branch),
                    string(name: 'PLATFORM', value: platform),
                    string(name: 'CLOVER_ENABLED', value: clover),
                    string(name: 'VERBOSE', value: '0'),
                    string(name: 'DEPLOY_AWS_DOCKER_BRANCH', value: 'refs/tags/dev')
            ])
  } catch (err) {
    _logError('push to ECR failed')
    throw err
  }
  _logInfo("ECR_IMAGE_TAG = ${build_result.buildVariables.ECR_IMAGE_TAG}")
  return build_result.buildVariables.ECR_IMAGE_TAG
}

/**
 * buildNodeRelease
 * This function takes the following parameters then builds a node release. The job clones down the (specific branch of the) repository.
 * @param git_url the url to the git repository for the release.
 * @param branch the url of the branch of the git repository to build.
 * @return
 */
@NonCPS
def static buildNodeRelease(git_url, branch) {
  return new cvent.mobile.OSSUtils()._buildNodeSnapshot(git_url, branch)
}

def private _buildNodeRelease(git_url, branch) {

  _logInfo('building the node release')
  try {
    release_image_build = build job: "mobile-node-release", parameters: [
            string(name: 'GIT_REPO', value: git_url),
            string(name: 'GIT_BRANCH', value: BRANCH_NAME)
    ]
  } catch (err) {
    _logError('build node release image failed')
    throw err
  }
  return release_image_build
}
