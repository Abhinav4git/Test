/**
* A Utility Class for performing Git Clone operations in cvent-standard ways.
*
* NOTE: All of the functions in this class assume that they are operating within the context
*       of a node and workspace.
*/
package cvent.stash

import groovy.transform.Field
import cvent.jenkins.SlaveUtils
import cvent.jenkins.OSType

// This is the Git Tool instance to use on Linux nodes
@Field def static final LINUX_GIT_TOOL = 'Default'

// This is the Git Tool instance to use on Windows nodes
@Field def static final WINDOWS_GIT_TOOL = 'Windows-64'

/**
* Checks out a repo using cvent-standard settings--most of which are overrideable (see args parameter).
*
* @param repoUrl Can either be the full repo URL or the short for of simply 'project/repo'.
* @param args    a set of optional named arguments as follows.
*                  branch: Defaults to 'master'. Specified branch to check out.
*                  shallowClone: Defaults to true.  Specifies if a shallow clone should be performed.
*                  subDir: If present will check out the repo to a sub-dir of the workspace.
*                  checkoutLocalBranch: Default is false: If true, the checkout will checkout to a local branch.
*                      Otherwise the branch is checked out as a detached head.
*                  timeout: Defaults to 20.  Operation will timeout in N minute.
*                  retry: Defaults to 2.  If operation times out or fails, will be retried N times.
*                  poll: Defaults to false: whether this job should poll for changes at intervals.
*                  generateChangelog: Defaults to true: whether a changelog should be computed for this checkout.
*                  cleanAfterCheckout: Defaults to true: whether git clean will be run in the repo after it has been checked out.
*                  modConfig: Defults to null.  If non-null should be a closure accepting on argument, a hash.  This
*                      Hash is the configuration that will be passed to the Jenkins 'checkout' command.  The
*                      closure may make any needed modifications to the config to effect behaviors not otherwise
*                      supported by means of other args values.
*
*   NOTE: If the repo to checkout is listed by getRefRepos() as having a refernece repo for the OS of the current
*         slave the checkout will be configured to use the reference repo.
*
* @See #getRefRepos()
*/
def static checkoutRepo(Map args = [:], String repoUrl, Closure action = null) { new GitClient()._checkoutRepo( args, repoUrl, action) }
def private _checkoutRepo(Map args = [:], String repoUrl, Closure action = null) {
  args = [
    branch: 'master',
    shallowClone: true,
    timeout: 20 ,
    retry: 2,
    poll: false,
    generateChangelog: true,
    cleanAfterCheckout: true
  ] + args

  def scmExtensions = [[
    $class: 'CloneOption',
    depth: 0,
    noTags: true,
    shallow: args.shallowClone,
    timeout: args.timeout
  ]]

  if (args.cleanAfterCheckout) {
    scmExtensions << [
      $class: 'CleanCheckout'
    ]
  }

  def stashCloneUrl = Utils.getStashCloneUrl(repoUrl)

  if (args.subDir) {
    scmExtensions << [
      $class: 'RelativeTargetDirectory',
      relativeTargetDir: args.subDir
    ]
  }

  if (args.checkoutLocalBranch) {
    scmExtensions << [
      $class: 'LocalBranch',
      localBranch: args.branch
    ]
  }

  if (!args.generateChangelog) {
    scmExtensions << [
      $class: 'ChangelogToBranch',
      options: [compareRemote: 'origin', compareTarget: args.branch]
    ]
  }

  def os = SlaveUtils.getOsType()
  def refRepo = ReferenceRepoUtils.getRepoPath(stashCloneUrl, SlaveUtils.getSlaveName())
  if( refRepo ) {
    scmExtensions[0]['reference'] = refRepo
  }

  def checkoutConfig = [ changelog: false,
      poll: args.poll,
      scm: [
        $class: 'GitSCM',
        branches: [[name: args.branch]],
        doGenerateSubmoduleConfigurations: false,
        extensions: scmExtensions,
        gitTool: os == OSType.WINDOWS ? WINDOWS_GIT_TOOL : LINUX_GIT_TOOL,
        submoduleCfg: [],
        userRemoteConfigs: [[
          credentialsId: Utils.SSH_CREDENTIALS_ID,
          url: stashCloneUrl
        ]]
      ]
    ]

  if (args.modCheckout) {
    args.modCheckout(checkoutConfig)
  }

  retry( args.retry ) {
    checkout( checkoutConfig )
  }

  if(action != null) {
    if (args.subDir) {
      dir(args.subDir, action)
    } else {
      action()
    }
  }
}

/**
* Checks out the cvt/c4 repo using cvent-standard settings--most of which are overrideable (see args parameter).
*
* @param args a set of optional named arguments as follows.  See checkoutRepo for details, except that the
*        following defaults are overridden:
*           branch: Defaults to 'prod'.
*           timeout: Defaults to 60.
*           retry: Defaults to 3.
*           generateChangelog: Defaults to false.
*
*   NOTE: getRefRepos lists ref repos for cvt/v4 which will be used to speed up checkout.
*
* @See #getRefRepos()
* @See #checkoutRepo(Map, String)
*/
def static checkoutC4(Map args = [:]) { new GitClient()._checkoutC4( args ) }
def private _checkoutC4(Map args = [:]) {
  args = [
    branch: 'prod',
    timeout: 60 ,
    retry: 3,
    generateChangelog: false
  ] + args

  checkoutRepo(args, 'cvt/c4')
}

/**
* Checks out a repo to a sub-directory using cvent-standard settings--most of which are overrideable (see args parameter).
*
* @param args a set of optional named arguments as follows.  See checkoutRepo for details, except that the
*        subDir value is overridden to be the name of the repo parsed from repoUrl.
*
* @See #checkoutRepo(Map, String)
*/
def static checkoutToSubdir(Map args = [:], String repoUrl, Closure action = null) { new GitClient()._checkoutToSubdir( args, repoUrl, action) }
def private _checkoutToSubdir(Map args = [:], String repoUrl, Closure action = null) {
  repoUrl = Utils.getStashCloneUrl(repoUrl)

  def subDir = args.subDir
  if(subDir == null) {
    def m = repoUrl =~ /.*\/(.*?)\.git$/
    subDir = m[0][1]
  }

  checkoutRepo(args + [subDir: subDir], repoUrl, action)
}
