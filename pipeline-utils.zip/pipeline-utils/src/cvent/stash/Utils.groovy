/**
 * A Utility Class for performing non-git (e.g. rest-api, etc.) operations against Stash.
 */
package cvent.stash

import groovy.transform.Field
import org.apache.tools.ant.types.selectors.TokenizedPath
import org.apache.tools.ant.types.selectors.TokenizedPattern
@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.7.1' )

import groovyx.net.http.HTTPBuilder
import groovyx.net.http.ContentType

// Root URL for Stash REST operations
@Field def static final STASH_BASE_URL_HTTPS = "https://stash.cvent.net"

// Root URL for Stash git operations
@Field def static final STASH_BASE_URL_SSH = "ssh://git@stash:7999"

// Root URL for Stash git operations
@Field def static final STASH_MIRROR_BASE_URL_SSH = "ssh://git@git.core.cvent.org:7999/stash"

// Credentials to be used for Stash git operations
@Field def static final SSH_CREDENTIALS_ID = 'e01b632a-4bb4-446b-9d93-793565f2293f'

// Credentials to be used for Stash REST operations
@Field def static final BASIC_AUTH_CREDENTIALS_ID = 'stash-credentials'

/**
 * Given a remote SSH stash URL, returns the corresponding HTTPS URL
 */
def static getStashHttpsUrl(String projectSlashRepo) {
  def parts = getProjectAndRepo(projectSlashRepo)

  return "${STASH_BASE_URL_HTTPS}/projects/${parts[0]}/repos/${parts[1]}/browse"
}

/**
 * Given a stash clone url (either http/https or ssh) will return a HTTPS URL to the project's changelog
 */
def static getChangelogUrl(String projectSlashRepo, String branch) {
  def url = getStashHttpsUrl(projectSlashRepo)
  def ref = java.net.URLEncoder.encode("refs/heads/${branch}", 'UTF-8')

  return url + "/CHANGELOG.md?at=${ref}"
}

/**
 *  Given a project and a repo, returns the git remote url needed to clone the repo.
 *
 * @param project  The project slug of the project under which the repo lives in Stash.
 * @param repo     The name of the reop wiht the Stash project.
 *
 * @return a string containing the git clone url.
 */
def static getStashCloneUrl(String project, String repo) {
  if (project=="cvt" && repo=="c4") {
    return "${STASH_MIRROR_BASE_URL_SSH}/${project}/${repo}.git"
  }
  else{
    return "${STASH_BASE_URL_SSH}/${project}/${repo}.git"
  }
}

/**
 *  Given a combined "project-slug/repo-name" string, returns the git remote url needed
 *  to clone the repo.
 *
 *  NOTE: To simplify logic elsewhere, if a full git clone repo is passed in (anythign starting
 *        with http|https|ssh), that url is returned unmodified.
 *
 * @param projectSlashRepo  The repo in which the file resides specified as 'project/repo'
 *
 * @return a string containing the git clone url.
 */
def static getStashCloneUrl(String projectSlashRepo) {
  if (projectSlashRepo ==~ /^((https?)|(ssh)):.*$/) {
    return projectSlashRepo
  }
  def parts = projectSlashRepo.split("/")
  return getStashCloneUrl(parts[0], parts[1])
}

/**
 *  Given a stash clone url (either http/https or ssh) will return the project and repo in a
 *  string of the form '[project]/[repo]'.
 *
 *  NOTE: If the value passed is not parseable as a valid clone url, null is returned.
 *
 * @param cloneUrl  A stash url of the form used to clone a repo.
 *
 * @return a string containing project and repo that would be cloned.
 */
def static getProjectSlashRepo(String cloneUrl) {
  def parsed = (cloneUrl =~ /(ssh|https?):\/\/.*\/([^\/]+)\/([^\/]+).git/)
  if (parsed.matches()) {
    return "${parsed[0][2]}/${parsed[0][3]}"
  } else {
    return null
  }
}

/**
 *  Given a stash clone url (either http/https or ssh) will return the project and repo
 *  as a two element array.
 *
 *  NOTE: If the value passed is not parseable as a valid clone url, the array elemnts will be null.
 *
 * @param cloneUrl  A stash url of the form used to clone a repo.
 *
 * @return a string containing project and repo that would be cloned.
 */
def static getProjectAndRepo(String cloneUrl) {
  def parsed = (cloneUrl =~ /(ssh|https?):\/\/.*\/([^\/]+)\/([^\/]+).git/)
  if (parsed.matches()) {
    return parsed[0].drop(2)
  } else {
    return [null, null]
  }
}

/**
 * Given a string of the form 'project/repo' and a relative path, returns a string containing the
 * file's raw content form Stash.  Optionally a branch may be specified.
 *
 * NOTE: Technically this function needs to work in the context of a node.  If invoked outside
 *       of such a context, it will wrap part of its operation in a node{...} closure.
 *
 * This method authenticates to Stash using the jenkins credentials identified by CREDENTIALS_ID.
 *
 * @param projectSlashRepo  The repo in which the file resides specified as 'project/repo'
 * @param branch (Optional) The branch or commit SHA to fetch from.  'Master' is assumed if omitted.
 * @param relativeFilePath  The path to the file within the repo.  Path is relative to repo root and
 *                          should start with '/'.  But '/' will be appended if omitted.
 *
 * @return a string containing raw content of the file from Stash.
 */
def static getRawFile(String projectSlashRepo, String branch='master', String relativeFilePath) {
  return new Utils()._getRawFile(projectSlashRepo, branch, relativeFilePath)
}
def private _getRawFile(String projectSlashRepo, String branch, String relativeFilePath) {

  def user, password

  getCredentials = { ->
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: BASIC_AUTH_CREDENTIALS_ID,
                      usernameVariable: 'STASH_USER', passwordVariable: 'STASH_PASSWORD']]) {
      user = env.STASH_USER
      password = env.STASH_PASSWORD
    }
  }

  if(env.NODE_NAME == null) {
    node getCredentials
  } else {
    getCredentials()
  }

  def parts = projectSlashRepo.split("/")
  def path = "/projects/${parts[0]}/repos/${parts[1]}/browse/${relativeFilePath}"

  return httpsGetWithBasicAuth( 'https://stash.cvent.net', user, password,
          [path: path, query: [at:branch, raw: null], contentType : ContentType.TEXT ]
  ).text
}

@NonCPS
def private httpsGetWithBasicAuth(String host, String user, String password, Map args) {

  def auth = "${user}:${password}"
  auth = auth.bytes.encodeBase64().toString()

  def http = getHttpBuilder('https://stash.cvent.net')
  http.ignoreSSLIssues()
  http.setHeaders([Authorization: "Basic ${auth}"])
  return http.get( args )
}

// This method exists only to allow for mocking of the HTTPBuilder by tests
@NonCPS
def protected getHttpBuilder(String baseUrl) { return new HTTPBuilder(baseUrl) }

/**
 * Gets the current branch name, accounting for Jenkins' weirdness around PR jobs
 *
 * @return a string representing the current git branch name (or FROM branch of a PR).
 */
def static getBranch() { return new Utils()._getBranch() }
def private _getBranch() {
  return env.CHANGE_BRANCH ?: env.BRANCH_NAME
}

/**
 * @param shortValue true to return the short commit (default: true)
 * @return git commit
 */
def static getCommit(boolean shortValue=true) {
  return new Utils()._getCommit(shortValue)
}
def private _getCommit(boolean shortValue) {
  return sh(script: 'git rev-parse ' + (shortValue ? '--short' : '') + ' HEAD', returnStdout: true).trim()
}

/**
 * @return list of changed paths in this PR, or null if not PR.
 */
def static getChanges() { return new Utils()._getChanges() }
def private _getChanges() {
  if (env.CHANGE_TARGET) {
    return sh(returnStdout: true,
            script: "git fetch origin ${env.CHANGE_TARGET} && \
                       git diff --name-only FETCH_HEAD").readLines()
  }
}

/**
 * Use bitbucket-commenter to ensure a comment is present on a Pull Request.
 * Does nothing if not a Pull Request.
 */
def static commentOnPullRequest(message) { return new Utils()._commentOnPullRequest(message) }
def private _commentOnPullRequest(message) {
  if (env.CHANGE_URL && env.CHANGE_ID) {
    def url_regex = /\/projects\/(.+?)\/repos\/(.+?)\//

    def (projectSlug, repositorySlug) = (env.CHANGE_URL =~ url_regex).with {
      it.hasGroup() ? it[0][1..-1] : [null, null]
    }

    if (projectSlug && repositorySlug) {
      withCredentials([usernamePassword(credentialsId: 'stash-credentials',
              passwordVariable: 'BITBUCKET_PASSWORD',
              usernameVariable: 'BITBUCKET_USER')]) {
        sh 'docker pull docker.cvent.net/cvent/bitbucket-commenter'
        sh "docker run -e BITBUCKET_PASSWORD \
                       -e BITBUCKET_USER \
                       docker.cvent.net/cvent/bitbucket-commenter \
                        ${projectSlug} \
                        ${repositorySlug} \
                        ${env.CHANGE_ID} \
                        '${message}'"
      }
    } else {
      error "Project or Repository slug not found in change URL: ${env.CHANGE_URL}"
    }
  }
}

/**
 * Returns true if only ignored files (defaults, and those specified in JenkinsFile) are present in changeset OR if
 * changeset is empty.
 */
static boolean changeSetContainsOnlyIgnoredFiles(ignoreFiles) { return new Utils()._changeSetContainsOnlyIgnoredFiles(ignoreFiles) }
private boolean _changeSetContainsOnlyIgnoredFiles(ignoreFiles) {
  // return true if change set is empty, or there are no ignore files defined
  if (!currentBuild.changeSets) {
    return false
  }

  if (!ignoreFiles) {
    ignoreFiles = []
  }

  def defaultIgnoreFiles = [
          '.gitignore',
          'CHANGELOG.md',
          'CODEOWNERS',
          'Jenkinsfile',
          'pull_request.md',
          'README.md',
          'renovate.json',
          '**/UPGRADE.md'
  ]

  ignoreFiles += defaultIgnoreFiles

  // build ignore patterns string
  def ignorePatterns = ""
  for (ignoreFile in ignoreFiles) {
    ignorePatterns = "${ignorePatterns}${ignoreFile},"
  }

  // setup wildcard pattern matcher
  def patterns = ignoreFiles.collect { new TokenizedPattern(it) }

  // check if change set contains only ignore files
  for (entries in currentBuild.changeSets) {
    for (entry in entries) {
      for (file in entry.affectedFiles) {
        def path = new TokenizedPath(file.path)
        if (!patterns.any { it.matchPath(path, false) }) {
          // non-ignore file found
          logInfo "Found non-ignore file in changeset: ${file.path}"
          return false
        }
      }
    }
  }


  // only ignore files found
  logInfo "Only ignore files found!"
  return true
}

/**
 * Gets the current repository's git URL
 *
 * @return the git URL
 */
def static getGitUrl() { return new Utils()._getGitUrl() }
def private _getGitUrl() {
  // GIT_URL when building a branch, GIT_URL_1 when building a PR
  return env.GIT_URL ?: env.GIT_URL_1
}
