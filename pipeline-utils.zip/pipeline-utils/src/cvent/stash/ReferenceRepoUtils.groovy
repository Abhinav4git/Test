package cvent.stash

import groovy.transform.Field
import cvent.jenkins.SlaveUtils

// This is the Git Tool instance to use on Linux nodes
@Field def static final LINUX_REF_REPO_ROOT = '~/ref-repos'

// This is the Git Tool instance to use on Windows nodes
@Field def static final WINDOWS_REF_REPO_ROOT = 'E:\\jenkins\\ref-repos'

// This is the Git Tool instance to use on Windows nodes
@Field def static final C4_SLAVE_REGEX = /(?i).*-jen(win|ddb)-\d+/

/**
* Returns the path to the reference repo if a reference repo exists for the given
* stash repo on the named slave.
*
* @param stashCloneUrl The clone url (or project/repo) of the repo in question.
* @param slaveName The name of the slave in question.
*
* @return The fully qualified path to the reference repo or null if there isn't one.
*/
def static getRepoPath(String stashCloneUrl, String slaveName) {
  def key = Utils.getProjectSlashRepo(stashCloneUrl)
  //As its not forseen that will use a ref-repo for any other repo at this time, are simply hard coding our logic for now.
  if(key == 'cvt/c4' && slaveName ==~ C4_SLAVE_REGEX) {
    WINDOWS_REF_REPO_ROOT + '\\' + key.replaceAll(~/.*\//, '') + ".git"
  }
}

/**
* Returns an array of maps representing the slaves on which reference repos exist.  The map
* has the same structure as is returned by SlaveUtils.getSlaveMetadata except for having one
* additional entry, 'repos', which is an array of project/repo values for the repos that
* have reference instances on that slave.
*/
def static getSlavesWithRefRepos() { new ReferenceRepoUtils()._getSlavesWithRefRepos { s -> true } }
def static getSlavesWithRefRepos(Closure filter) { new ReferenceRepoUtils()._getSlavesWithRefRepos(filter) }
def private _getSlavesWithRefRepos(Closure filter) {

  matchingSlaves = SlaveUtils.getSlaveMetadata { slave ->
    filter(slave) && slave.name ==~ C4_SLAVE_REGEX
  }

  def onlineSlaves = []
  for (def s = 0; s < matchingSlaves.size(); s++) {
    def slave = matchingSlaves[s]
    //The list of ref-repos on this slave: gain just hard coding things for now.
    slave.repos = ['cvt/c4']
    if(slave.isOnline) {
      onlineSlaves <<  slave
    } else {
      println ("Skipping ${slave.name}: slave is off line.")
    }
  }
  return onlineSlaves
}

/**
* Updates the reference repos for the indicated slaves.
*
* @param slaves, an array of maps, on map per slave of the format returned by getSlavesWithRefRepos.
*
* @return Returns an array of error messages, one for each slave or repo that failed to
*         refresh.  If all repos are refreshed an empty array is returned.
*
* Note that slaves are freshed in parallel.
*/
def static updateRepos(slaves) { new ReferenceRepoUtils()._updateRepos(slaves) }
def private _updateRepos(slaves) {

  def failures = []

  // To avoid: https://issues.jenkins-ci.org/browse/JENKINS-29413  VERY BAD
  if(slaves.size() == 0 ) return failures

  def cloneActions = [:]

  for (def i = 0; i < slaves.size(); i++) {
    def slave = slaves[i]

    cloneActions[slave.name] = {
      node(slave.name) {

        try {

          def rootRepoPath

          if(slave.isUnix) {
            rootRepoPath = LINUX_REF_REPO_ROOT

            println "Creating folder: '${rootRepoPath}'"
            sh "mkdir -p ${rootRepoPath}"
          } else {
            rootRepoPath = WINDOWS_REF_REPO_ROOT

            println "Creating folder: '${rootRepoPath}'"
            bat "IF not exist \"${rootRepoPath}\" mkdir \"${rootRepoPath}\""
          }

          for(def r = 0; r < slave.repos.size(); r++) {
            def repo = slave.repos[r]

            try {

              def gitUrl = Utils.getStashCloneUrl repo
              def dirName = Utils.getProjectSlashRepo(gitUrl).replaceAll(~/.*\//, '')

              def startMills = new Date().getTime()

              if(slave.isUnix) {
                //When using the --mirror argument git adds .git to the end of the directory name
                def thisRepoPath = "${rootRepoPath}/${dirName}.git"

                println "Cloning repo."
                sh "[ -e ${thisRepoPath} ] && git -C ${thisRepoPath} remote update || git git -C ${rootRepoPath} clone --mirror ${gitUrl}"

              } else {
                //When using the --mirror argument git adds .git to the end of the directory name
                def thisRepoPath = "${rootRepoPath}\\${dirName}.git"

                println "Cloning repo."
                bat "IF not exist \"${thisRepoPath}\" (git -C ${rootRepoPath} clone --mirror ${gitUrl}) ELSE git -C ${thisRepoPath} remote update"
              }

              def endMills = new Date().getTime()
              def durationMills = endMills - startMills
              int seconds = ((int) (durationMills / 1000)) % 60 ;
              int minutes = ((int) (durationMills / 60000)) % 60;
              int hours   = ((int) (durationMills / 3600000)) % 24;
              println String.format("Clone completed in %d:%02d:%02d", hours, minutes, seconds)

            } catch(ex) {
              failures << "Failed to refresh repo ${repo} on slave ${slave.name}: ${ex}"
            }

          }

        } catch(ex) {
          failures << "Failed to refresh repos on slave ${slave.name}: ${ex}"
        }
      }
    }
  }

  parallel cloneActions

  failures
}