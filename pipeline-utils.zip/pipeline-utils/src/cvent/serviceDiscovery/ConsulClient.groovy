/**
* A Client for performing service registration/de-registration actions against Consul
*/
package cvent.serviceDiscovery

@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.7.1' )
import groovyx.net.http.HTTPBuilder
import groovyx.net.http.ContentType
import cvent.serviceDiscovery.ConsulEnv

class ConsulClient {

  def static final CONSUL_PORT = 8500

  def static final CONSUL_URL = { p -> "http://${p}-consul-101.core.cvent.org:${CONSUL_PORT}" }
  def static final SERVICE_URL = { s -> "http://discovery${s?'-':''}${s}.core.cvent.org" }

  def static final ENV_CONFIG = [
    ALPHA      : [regionPrefix: 'ap20', serviceUrlSuffix: 'alpha'],
    STAGING    : [regionPrefix: 'sg20', serviceUrlSuffix: 'staging'],
    PRODUCTION : [regionPrefix: 'pr01', serviceUrlSuffix: ''],
    DR         : [regionPrefix: 'pr20', serviceUrlSuffix: 'dr'],
  ]

  final def consulClient
  final def serviceBaseUrl

  /**
  * Creates an instance of the ConsulClient for accessing Consul in a given Environment.
  *
  * @param env The ConsulEnv of the consul instance to connect to.
  *
  * NOTE: This Client is not serializable via CPS so do not maintian references to instances in non-cps methods!
  */
  // @NonCPS <--not allowed on constructors
  public ConsulClient(ConsulEnv env) {
    def key = env as String

    consulClient = getHttpBuilder(CONSUL_URL(ENV_CONFIG[key].regionPrefix))

    serviceBaseUrl = SERVICE_URL(ENV_CONFIG[key].serviceUrlSuffix)
  }

  /**
  * Gets a map of services registered with the Consul instance.
  *
  * @param filterRegex Optional.  A regex that will be use to filter the list of services by name.
  *
  * @return A map where the key is the name of the serivce and the value is a an ArrayList of the service's tags.
  */
  @NonCPS
  public getServices(filterRegex) {
    def services = consulClient.get path: '/v1/catalog/services', contentType : ContentType.JSON
    if(filterRegex){
      def filtered = [:]
      services.each {name, details ->
        if( name ==~ filterRegex) {
          filtered[name] = details
        }
      }
      return filtered
    } else {
      return services
    }
  }

  /**
  * Gets a array of service instances for given service.
  *
  * @param name            The name of the service as registered with consul.
  * @param throwIfNotFound If true will throw an IllegalArgumentException if the service does not exist.
  *                        If false, an empty array is returned.  Default is true.
  *
  * @return An ArrayList of maps.  One entry for each node the service is regestered as running on.
  *
  * @See https://www.consul.io/docs/agent/http/catalog.html#catalog_service for documentation on the
  *  structure of the map returned for each service instance.
  */
  @NonCPS
  public getService(name, throwIfNotFound = true) {
    def serviceInstances = consulClient.get path: "/v1/catalog/service/${name}", contentType : ContentType.JSON
    if( throwIfNotFound && !serviceInstances ) {
      throw new IllegalArgumentException("No service with the name of ${name} was found.")
    }

    //The new JsonSlurper returns the non-serializable LazyMap so we must convert it.
    return serviceInstances.collect { new HashMap<>(it) }

  }

  /**
  * Removes the serviceRegistration for a given service from Consul.
  *
  * @param name            The name of the service as registered with consul.
  * @param throwIfNotFound If true will throw an IllegalArgumentException if the service does not exist.
  *                        If false, an empty array is returned.  Default is true.
  *
  * @return An ArrayList of maps.  One entry for each node the service that was de-registered.
  *
  * @See https://www.consul.io/docs/agent/http/catalog.html#catalog_service for documentation on the
  *  structure of the map returned for each service instance.
  */
  @NonCPS
  public deregisterService(name, throwIfNotFound = true) {
    def serviceInstances = getService(name, throwIfNotFound)
    serviceInstances.each { instance ->
      def agentHttpClient = getHttpBuilder("http://${instance.Address}:${CONSUL_PORT}")
      agentHttpClient.get path: "/v1/agent/service/deregister/${instance.ServiceID}"
    }
  }


  /**
  * Gets the base url by which a service can be invoked.  Does not validate that the service
  * is actually available at the endpoint.
  *
  * @param serviceName     The name of the service. e.g. 'auth-service-web'.
  * @param region          The region for which the service is registered.
  *                        e.g. 'staging', 'S400', etc.
  *
  * @return A string containing the http (not https) endpoint by which the service can be invoked.
  */
  @NonCPS
  public getServiceEndpoint(serviceName, region) {
    return "${serviceBaseUrl}/${serviceName}-${region}"
  }

  // This method exists only to allow for mocking of the HTTPBuilder by tests
  @NonCPS
  def protected getHttpBuilder(String baseUrl) { return new HTTPBuilder(baseUrl) }
}
