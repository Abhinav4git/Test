package cvent.serviceDiscovery

/**
* A Enum used with ConsulClient to specify which Environment the client should connect to.
*/
enum ConsulEnv {
  ALPHA,
  STAGING,
  PRODUCTION,
  DR
}
