/**
* A Utility Class to pull additional info that is not directly exposed by a build and requires
* invoking getRawBuild(), a method that we prefer not to white-list for direct invocation.
*/
package cvent.jenkins

import org.jenkinsci.plugins.workflow.graph.FlowGraphWalker;
import org.jenkinsci.plugins.workflow.graph.AtomNode;
import org.jenkinsci.plugins.workflow.actions.ArgumentsAction;

/**
*  Returns additional information about a build not directly available from the RunWrapper instance.
*
* @param build - An optional RunWrapper instance. If omitted, uses currentBuild.
* @return A map containing the following entries:
*     cause: An array of causes each, a map containing a type: and other entries specific to that type.
*            See below implementation for details.
*     log: A string; the log output for the job, current as of the time of invocation.
*     env: The build's environment variables
*/
public static getBuildInfo() { new BuildUtils()._getBuildInfo() }
public static getBuildInfo(build) { new BuildUtils()._getBuildInfo(build) }
private _getBuildInfo(build = currentBuild) {
  def rawBuild = build.getRawBuild()
  def causes = rawBuild.getCauses().collect {c ->
    switch(c.class.toString()) {
      case 'class hudson.model.Cause$UpstreamCause':
        return [
          type: 'UpstreamCause',
          upstreamProject: c.getUpstreamProject(),
          upstreamUrl: c.getUpstreamUrl(),
          upstreamBuildNum: c.getUpstreamBuild()
        ]

      case 'class hudson.model.Cause$UserIdCause':
        return [
          type: 'UserIdCause',
          userId: c.getUserId(),
          userName: c.getUserName()
        ]

      default:
        return [type: c.class.toString().replaceAll(/^.*\$/, '')]
    }
  }

  [
    causes: causes,
    log: rawBuild.log,
    env: rawBuild.getEnvironment()
  ]
}

/**
*  Returns links (url and display text) to steps in a pipeline build that have been marked as 'errors'
*
* @param build - An optional RunWrapper instance. If omitted, uses currentBuild.
* @return A list of maps containing the following entries:
*     display: The DSL step function and any arguments
*     url: A link to the failing step's console output
*/
public static getErrorStepUrls() { new BuildUtils()._getErrorStepUrls() }
public static getErrorStepUrls(build) { new BuildUtils()._getErrorStepUrls(build) }
private _getErrorStepUrls(build = currentBuild) {
  fgw = new FlowGraphWalker(build.getRawBuild().getExecution())

  fgw
    .findAll { it.getError() != null }
    .findAll { it instanceof AtomNode }
    .collect {
      [
        display: "${it.getDisplayFunctionName()} ${ArgumentsAction.getStepArgumentsAsString(it)}",
        url: "${env.JENKINS_URL}${it.getUrl()}log/"
      ]
    }
}

/**
 * Get a nonce value that is unique to this job.
 * This value should be:
 *   1. As short as possible
 *   2. Alphanumeric
 *   3. Case-insensitive
 *   4. Consitent within a jab
 */
def static getJobNonce() { new BuildUtils()._getJobNonce() }
private _getJobNonce() {
  def defaultNonce = Long.toString(((new Date().getTime() + new Random().nextFloat()) * 1000).longValue(), 36)
  return BuildUtils.getJobKVDataOrDefault('nonce', defaultNonce)
}

/**
 * Given a key, look up the value in a job-scoped KV store.
 * The defaultValue parameter will be saved to the KV store if the key is not found.
 */
def static getJobKVDataOrDefault(key, defaultValue) { new BuildUtils()._getJobKVDataOrDefault(key, defaultValue) }
private _getJobKVDataOrDefault(key, defaultValue) {
  def value = BuildUtils.getJobKVData(key)

  if (value != null) {
    return value
  } else {
    return BuildUtils.setJobKVData(key, defaultValue)
  }
}

/**
 * Given a key, look up the value in a job-scoped KV store.
 */
def static getJobKVData(key) { new BuildUtils()._getJobKVData(key) }
private _getJobKVData(key) {
  withCredentials([[$class: 'AmazonWebServicesCredentialsBinding',
                     credentialsId: "cvent-sandbox-shared-jenkins"]]) {
    try {
      return sh(returnStdout: true,
                script: "aws ssm get-parameter \
                    --region us-east-1 \
                    --name '${BuildUtils.getJobKey(key)}' \
                    --query Parameter.Value \
                    --output text").trim()
    } catch (e) {
      return null
    }
  }
}

/**
 * Given a key, set the value in a job-scoped KV store.
 */
def static setJobKVData(key, value) { new BuildUtils()._setJobKVData(key, value) }
private _setJobKVData(key, value) {
  withCredentials([[$class: 'AmazonWebServicesCredentialsBinding',
                     credentialsId: "cvent-sandbox-shared-jenkins"]]) {
    sh "aws ssm put-parameter \
            --region us-east-1 \
            --type String \
            --overwrite \
            --name '${BuildUtils.getJobKey(key)}' \
            --value '${value}'"

    return value
  }
}

/**
 * Given a key, return the fully qualified path to store it at.
 */
def static getJobKey(key) { new BuildUtils()._getJobKey(key) }
private _getJobKey(key) {
  return "/jenkins/jobs/${env['JOB_NAME']}/${key}".replaceAll(' ', '_')
}
