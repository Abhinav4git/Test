/**
* A Utility Class user to perform FileSystem operations.
*/

package cvent.jenkins

import java.nio.file.Paths

/*
 * This function will turn a list of globs into a list of Paths.
 * Glob negation is supported with a leading exclamation mark (!).
 */
public static glob(String baseDir, List<String> globs) { new FsUtils()._glob(baseDir, globs) }
private _glob(String baseDir, List<String> globs) {
  if (fileExists(baseDir)) {
    dir(baseDir) {
      def (excludes, includes) = globs.split { it.startsWith('!') }
      def files = findFiles(glob: includes.join(','), excludes: excludes.join(','))
      return files.collect { Paths.get(baseDir, it.path).toString() }
    }
  } else {
    return []
  }
}
