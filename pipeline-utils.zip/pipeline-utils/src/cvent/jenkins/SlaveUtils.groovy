/**
* A Utility Class for getting metadata about slaves.  This namespace is generally not intended for
* use by typical CD Pipeline jobs but for administrative job that manage jenkins, etc.
*/

package cvent.jenkins
import cvent.jenkins.OSType
/**
* Gets the metadata for the slaves attached to this master in a serializable form filtered
* to only those slaves for which the filter returns true.
*
* @param  filter A closure to which is passed a map of metadata for a given slave.  Called
*                once per slave.
*
* @return An array of Maps, one map per slave.
*
* See https://issues.jenkins-ci.org/browse/JENKINS-42635 for why this is coded this way!
*/
def static getSlaveMetadata(Closure filter) {
  List slaves = getSlaveMetadata()
  def filtered = []
  for(slave in slaves){
    if (filter(slave)){
      filtered << slave
    }
  }
  filtered
}

/**
* Gets the metadata for the slaves attached to this master in a serializable form.
*
* @return An array of Maps, one map per slave.
*/
@NonCPS
def static getSlaveMetadata() {
  Hudson.instance.slaves.collect { slave ->
    def isOnline = slave.computer.isOnline()
    [
      name: slave.getNodeName(),
      description: slave.getNodeDescription(),
      // getOSDescription() throw null pointer error if slave is off line. See https://issues.jenkins-ci.org/browse/JENKINS-42658
      os: isOnline ? slave.computer.getOSDescription() : null,
      isUnix: slave.computer.isUnix(),
      remoteHomeDir: slave.getRemoteFS(),
      labels: slave.getAssignedLabels().collect { l -> l.toString() },
      isOnline: isOnline
    ] as Map
  }
}

/**
* Returns a OSType enum indicating the type of OS of the slave on which it is run.
*
* NOTE: This method must be invoked in the context of an allocated node.
*
* @return Returns either OSType.WINDOWS or OSType.LINUX.
*/
def static OSType getOsType() { new SlaveUtils()._getOsType() }
def private _getOsType() {
  _getEnv().OS ==~ /(?i).*windows.*/ ? OSType.WINDOWS : OSType.LINUX
}

/**
* Returns a name of the slave on which it is run.
*
* NOTE: This method must be invoked in the context of an allocated node.
*
* @return Returns either OSType.WINDOWS or OSType.LINUX.
*/
def static String getSlaveName() { new SlaveUtils()._getSlaveName() }
def private _getSlaveName() {
  _getEnv().NODE_NAME
}

//This method only exists to allow for mocking the evn value in tests.
//IMPORTANT: Don't call this method getEnv() or Groovy (in jenkins but not in unit tests ?!) will consider it
//an accessor for env, resulting in this method becomming an infinite recursive call into itself.  BAD!
def protected _getEnv() { return env }

/**
 * @return true if this is running in ECS
 */
def static boolean isECS() {
  return new SlaveUtils()._isECS()
}
def private _isECS() {
  return getSlaveName().startsWith('ecscloud-management')
}

def static anyDockerNodeLabel() {
  return 'ecs-slave-docker-daemon || (linux && docker)'
}
