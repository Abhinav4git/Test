/*
* Jenkins Job: admin-refresh-global-parameters
* Jenkins Job Description:
*
*  This job updates the global parameter list of silos and dropwizard service repos.
* It updates it using as reference "RELEASE_MANAGEMENT.dbo.SILOS" and
* "http://discovery-staging.core.cvent.org/service-registry-service-staging/service/list"
*
* Dependencies : Extensible Choice Parameter plugin
*/
package cvent.jenkins;

import jenkins.*;
import jenkins.model.*;
import hudson.*;
import hudson.model.*;
import jp.ikedam.jenkins.plugins.extensible_choice_parameter.*;


/*Update the list of deployment silos
*
* It is important to notice that this method works differently than the other(updateServiceRepoChoiceList)
* This one removes and adds individual records to the existing list.
* The other completely overwrites the list with the newly defined one.
* The reason for the difference is that the Environment parameter
* has additional parameters other then the silo list, while the git_repo list
* is based solely on what we are putting in every time.
*/
def static updateEnvironmentChoiceList(){ new GlobalChoiceParameterUpdater()._updateEnvironmentChoiceList()}
def private _updateEnvironmentChoiceList(){

  def silo_db_server = "HQ-APPSPT-001.cvent.net"

  //Get the list of silos from the canonical database (this database is managed by lmao@cvent.com)
  withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "tableau-read-only",
    usernameVariable: 'DB_USER', passwordVariable: 'DB_PASSWORD']]) {
      bat """
      sqlcmd -S ${silo_db_server} -U %DB_USER% -P %DB_PASSWORD% -Q "select SILO_NUM  from RELEASE_MANAGEMENT.dbo.SILOS (nolock) where STATUS='Delivered'" > result
      """
  }

  // I tried without writing to a file, but it did not work. This works.
  def queryOutput = readFile('result').trim()
  // Only pick up the silos
  def silos = queryOutput.findAll(/S[0-9]{3}/)

  println "List of silos: \n" + silos

  //Get the global choice parameters
  def descriptor = new GlobalTextareaChoiceListProvider("name", null, false, null).getDescriptor();
  def choiceListEntryList = descriptor.getChoiceListEntryList();

  //Find the "ENVIRONMENT" global parameter
  def index = -1;
  for(int i = 0; i < choiceListEntryList.size(); i++){
    if(choiceListEntryList.get(i).getName() == "ENVIRONMENT"){
      index = i;
      break;
    }
  }

  //Make sure that you don't alter if you you never found if
  if(index != -1){
    def choiceList = (ArrayList) choiceListEntryList.get(index).getChoiceList();

    println "Old ENVIRONMENT choices: \n" + choiceList

    //Remove all the ones that are Silos
    for(int i = choiceList.size()-1; i >= 0; i --){
      if(choiceList.get(i) ==~ /S[0-9]{3}/){
        choiceList.remove(i);
      }
    }

    //Add all the silos found in the database
    for(int i = 0; i < silos.size(); i++){
      choiceList.add(silos.get(i))
    }

    println "New Complete ENVIRONMENT choices: \n" + choiceList
  }
}

/*
 * Update the list of dropwizard service repo list
 */
def static updateServiceRepoChoiceList(){ new GlobalChoiceParameterUpdater()._updateServiceRepoChoiceList()}
def private _updateServiceRepoChoiceList(){

  //Using this as a canonical list of current dropwizard services
  def rawHtml = "http://discovery-staging.core.cvent.org/service-registry-service-staging/service/list".toURL().text;
  def listOfRepos = []

  def goodHtmlLines = rawHtml.split( '\n' )

  //Build the list of repos
  for(int i = 0; i < goodHtmlLines.size() ; i++){
    if(goodHtmlLines[i].contains("https://stash.cvent.net/") && !goodHtmlLines[i].contains("INCB")){
      def repo = "ssh://git@stash:7999/" + goodHtmlLines[i].find(/projects(.*?)\/browse/) - "/projects" - "/repos"- "/browse" + ".git";
      listOfRepos.add(repo);
    }
  }

  //These repos are not in the canonical list for a variety fo reasons. They are still valid and are used in jobs.
  def hardCodedRepos = [
    "ssh://git@stash:7999/anl/analytics.git",
    "ssh://git@stash:7999/dep/test-ansible-deploy.git",
    "ssh://git@stash:7999/dp/service-registry.git",
    "ssh://git@stash:7999/evt/event-calendar-ui.git",
    "ssh://git@stash:7999/int/integrations-ix.git",
    "ssh://git@stash:7999/ls/venue-reflag-consumer.git",
    "ssh://git@stash:7999/ls/venue-reflag-service.git",
    "ssh://git@stash:7999/oslo/oslo.git",
    "ssh://git@stash:7999/pt/email-service.git",
    "ssh://git@stash:7999/pt/event-api.git",
    "ssh://git@stash:7999/pt/import-service.git",
    "ssh://git@stash:7999/pt/license-api.git",
    "ssh://git@stash:7999/pt/planner-service.git",
    "ssh://git@stash:7999/pt/search-service.git",
    "ssh://git@stash:7999/pt/user-api.git",
    "ssh://git@stash:7999/rep/extensions.git",
    "ssh://git@stash:7999/sear/elasticsearch-index-loader.git"
  ]

  listOfRepos.addAll(hardCodedRepos)

  listOfRepos.unique();
  listOfRepos.sort();

  //Get the global choice parameters
  def descriptor = new GlobalTextareaChoiceListProvider("name", null, false, null).getDescriptor();
  def choiceListEntryList = descriptor.getChoiceListEntryList();

  //Find the "GIT_REPO" global parameter
  def index = -1;
  for(int i = 0; i < choiceListEntryList.size(); i++){
    if(choiceListEntryList.get(i).getName() == "DROPWIZARD_SERVICE_GIT_REPO"){
      index = i;
      break;
    }
  }

  //Make sure that you don't alter if you you never found if
  if(index != -1){
    def choiceList = (ArrayList) choiceListEntryList.get(index).getChoiceList();

    println "Old DROPWIZARD_SERVICE_GIT_REPO choices: \n" + choiceList

    choiceListEntryList.get(index).setChoiceList(listOfRepos);

    println "New DROPWIZARD_SERVICE_GIT_REPO choices: \n" + listOfRepos
  }
}
