/**
* A Utility Class basically to stand in for the fact that the Jenkins DSL doesn't have a groovy task
* as it does for bat and sh.
*
* Also provides wrappers around common groovy boilerplate.
*/

package cvent.jenkins

import cvent.jenkins.SlaveUtils
import cvent.jenkins.OSType
import groovy.text.SimpleTemplateEngine
import java.nio.file.Paths

/**
*  Takes a string of powershell script and runs it on the node.
*
*  @param groovyScript The powershell script to run. Filenames or code are supported
*  @param args   Optional named arguments as follows:
*                    params: An ArryList of arguments to be passed the file script.
*                    returnStatus: if true the exit code of the script is returned.
*                    returnStdout: if true the standard output of the script is returned.
*
*  returnStatus and returnStdout may not both be set to true at the same time.  If neither is set
*  an exception is thrown if the script errors out.
*
*  @return void, integer or string depending upon the values of returnStatus and returnStdout.
*/
def static runScript(args = [:], String groovyScript) { new GroovyUtils()._runScript(args, groovyScript) }
def private _runScript(args = [:], String groovyScript) {

  def os = SlaveUtils.getOsType()
  def pathSeperator = os == OSType.WINDOWS ? '\\' : '/'

  def tempDir = pwd(tmp: true)
  def scriptFile = [tempDir, 'script.groovy'].join(pathSeperator)
  writeFile file: scriptFile, text: groovyScript

  def groovyPath = tool( name: 'groovy', type: 'hudson.plugins.groovy.GroovyInstallation')
  script = "${[groovyPath, 'bin', 'groovy'].join(pathSeperator)} ${scriptFile}"
  if(args?.params) {
    script += " ${args?.params?.join(' ')}"
  }

  args = args.subMap(['returnStatus', 'returnStdout'])
  args.script = script as String // needed to that test pass, else is a random subclass of GString eg GString$2

  def rtn
  if(os == OSType.WINDOWS) {
    rtn = bat args
    bat "del /Q/F ${scriptFile}"
  } else {
    rtn = sh args
    sh "rm -f ${scriptFile}"
  }

  return rtn
}

def static loadTemplate(Map bindings, String resourcePath) { new GroovyUtils()._loadTemplate(bindings, resourcePath) }
def private _loadTemplate(Map bindings, String resourcePath) {

  def templateEngine = new SimpleTemplateEngine()
  def scriptTemplate = libraryResource resourcePath
  def template = templateEngine.createTemplate(scriptTemplate).make(bindings)

  return template.toString()
}

/**
 * Merge many maps together, maps that come later override maps that come before
 */
def static Map mergeMaps(Map... maps) {
    Map result

    if (maps.length == 0) {
        result = [:]
    } else if (maps.length == 1) {
        result = maps[0]
    } else {
        result = [:]
        maps.each { map ->
            map.each { k, v ->
                result[k] = result[k] instanceof Map ? GroovyUtils.mergeMaps(result[k], v) : v
            }
        }
    }

    result
}

/**
 * Prepare a method in a specfile to be called in parallel
 * @return: A 2 element list containing the name of the method, and a
 *          closure that runs the method. If the method does not exist, a
 *          default warning closure is returned
 */
public static specMethod(String path, String method, Map args = [:]) { new GroovyUtils()._specMethod(path, method, args) }
private _specMethod(String path, String method, Map args = [:]) {
  def spec = load(path)

  def name = path
  if (spec.metaClass.methods.name.contains('name')) {
    name = spec.name()
  }

  def methodClosure
  if (spec.metaClass.methods.name.contains(method)) {
    methodClosure = {
      logInfo "Running ${method} from ${path}"

      dir(Paths.get(path).parent.toString()) {
        methodCall(spec, method, args)
      }
    }
  } else {
    methodClosure = {
      logWarn "${method} not found in ${path}"
    }
  }

  return [name, methodClosure]
}

@NonCPS
private methodCall(spec, String method, Map args = [:]) {
  return spec."${method}"(args)
}
