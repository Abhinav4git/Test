package cvent.jenkins

/**
* A Enum used to indicate the general type of an OS.  Currently returned by the SlaveUtils.getOsType().
*/
enum OSType {
  LINUX,
  WINDOWS
}
