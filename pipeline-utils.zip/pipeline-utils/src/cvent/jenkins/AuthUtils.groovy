/**
* A Utility Class user to perform authorization checks.  Currently runs aginst the Jenkins
* security realm.
*/
package cvent.jenkins

import cvent.jenkins.BuildUtils
import hudson.model.User

/**
* Determins if the user who started the current job has the specified role.
*
* @param role - The role to test for.
*
* @return True if the user who started the current job has the specified role, else returns false.
*         False is also returned if the job was not user-started.
*/

public static isJobRunnerInRole(role) { new AuthUtils()._isJobRunnerInRole(role) }
private _isJobRunnerInRole(role) {
  def currentBuild = BuildUtils.getBuildInfo()

  if(currentBuild.causes[0].type == 'UserIdCause'){
      def currentUser = User.get(currentBuild.causes[0].userId)
      return role in currentUser.getAuthorities()
  } else {
      return false
  }
}
