/**
* A Utility Class for interactive with the cvent maven repo and related stuff.
*/

package cvent.java

import cvent.stash.Utils

import groovy.transform.Field

@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.7.1' )
import groovyx.net.http.HTTPBuilder
import groovyx.net.http.ContentType


@Field def static final MAVEN_REPO_BASE_URL = 'https://nexus.core.cvent.org'

@Field def static final JAVA_BUILD_IMG = 'docker.cvent.net/dropwizard-jenkins'

/**
* Gets the docker image used for builds
*/
@NonCPS
def static getBuildImage() {
  return JAVA_BUILD_IMG
}
/**
* Given repo containing a maven project, returns the GroupId and ArtifactId, Version, and ArtifactsToDeploy
*
* @param stashProjectSlashRepo  The project/repo of the Stash repo containing the maven project
*
* @return A map, containing groupId, artifactId, version and artifactsToDeploy properties.  All are
*         strings except for artifactsToDeploy which is an ArrayList of strings.
*/
//@NonCPS  -- Can't be non-CPS because it invokes getRawFile which is not NonCPS.
def static getArtifactsToBuildAndDeploy(String stashProjectSlashRepo) {
  def pomXml = Utils.getRawFile(stashProjectSlashRepo, '/pom.xml')
  def pom = new XmlSlurper().parseText(pomXml)

  def result = [
      groupId    : pom.groupId.toString(),
      artifactId : pom.artifactId.toString(),
      version    : pom.version.toString(),
    ]

  if(pom.properties.'modules.to.deploy' != '') {
    result.artifactsToDeploy = pom.properties.'modules.to.deploy'.toString().split(/\s*,\s*/) as ArrayList
  } else if(pom.properties.'module.to.deploy' != '') {
    result.artifactsToDeploy = [ pom.properties.'module.to.deploy'.toString() ]
  } else if(pom.build.finalName != '') {
    result.artifactsToDeploy = [ pom.build.finalName.toString() ]
  } else {
    result.artifactsToDeploy = [ pom.artifactId.toString() ]
  }

  return result
}

/**
* Given a GroupId and ArtifactId, queries the Cvent Maven release repo for the most recent release version
* pushed to the repo.
*
* @param groupId    The groupId of the artifact to query.
* @param artifactId The artifactId of the artifact to query.
*
* @return A string representation of the version number.
*/
@NonCPS
def static getMostRecentReleaseVersion(String groupId, String artifactId) {
  return getArtifactMetadata(groupId, artifactId).versioning.release.toString()
}

/**
* Given a GroupId and ArtifactId, queries the Cvent Maven release repo for the most highest value
* release version pushed to the repo, regardless or when they were pushed.
*
* @param groupId    The groupId of the artifact to query.
* @param artifactId The artifactId of the artifact to query.
*
* @return A string representation of the version number.
*/
@NonCPS
def static getHighestReleaseVersion(String groupId, String artifactId) {
  def metadata = getArtifactMetadata(groupId, artifactId)

  def sortedVersions = metadata.versioning.versions.version
    .collect({ node -> node.toString()})
    .sort(false) { a, b ->
      [a,b]*.tokenize('.')*.collect { it as int }.with { u, v ->
        [u,v].transpose().findResult{ x,y-> x<=>y ?: null } ?: u.size() <=> v.size()
      }}

  return sortedVersions[-1]
}

/**
* Given a GroupId and ArtifactId, queries the Cvent Maven snapshot or release repo for the maven-metadata file.
*
* @param groupId    The groupId of the artifact to query.
* @param artifactId The artifactId of the artifact to query.
* @param release    If true, queries the release repo, otherwise the snapshot repo is queired.
*                   Defaults to true.
*
* @return The maven-metadata.xml file parsed into a Map.
*/
@NonCPS
def static getArtifactMetadata(String groupId, String artifactId, Boolean release = true) {

  def repo = release ? 'releases' : 'snapshots'
  def path = "/nexus/content/repositories/${repo}/${groupId.replaceAll(/\./, "/")}/${artifactId}/maven-metadata.xml"

  def http = getHttpBuilder(MAVEN_REPO_BASE_URL)
  def metadata = http.get( [path: path, contentType : ContentType.XML ] )

  return metadata
}

// This method exists only to allow for mocking of the HTTPBuilder by tests
@NonCPS
def protected static getHttpBuilder(String baseUrl) { return new HTTPBuilder(baseUrl) }

/**
 * buildJavaSnapshot
 * @param params
 *  a map of arguments containing the following:
 *      git_url: the url of the git repository being built
 *      BRANCH_NAME: the name of the branch being built
 *      platform: only needs to be specified if the snapshot being built is a dropwizard 1.x build, in which case extra functionality is needed.
 * @return returns the release modules, which is a list of lists which contain each contain two elements:
 *      the artefact name and its ECR tag
 */
def static buildJavaSnapshot(params) {
  if (params['use_java_11'].toBoolean()) {
    return new cvent.java.MavenUtils()._buildJava11Snapshot(params)
  }
  return (new cvent.java.MavenUtils()._buildJavaSnapshot(params))
}
private  _buildJavaSnapshot(params){
    git_url=params['git_url']
    BRANCH_NAME=params['BRANCH_NAME']
    platform=params['platform']?:'dropwizard'
    docker_image=params['docker_image']?:'cvt_java11__us-east-1__v1.16.53'
    base_img_tag=platform + ':' + docker_image

    print 'building the snapshot'
    try {
        //If the project uses dropwizard 1.x, then the snapshot build job needs extra parameters, specifically the dropwizard 1.x platform tag and the updated base img tag.
        if (platform.contains('dropwizard-1.x')) {
            snapshot_image_build = build job: "snapshot-dropwizard-service-docker", parameters:
                    ([string(name: 'SOFTWARE_PLATFORM', value: platform),
                      string(name: 'BASE_IMG_TAG', value: base_img_tag),
                      string(name: 'GIT_REPO', value: git_url),
                      string(name: 'GIT_BRANCH', value: BRANCH_NAME),
                      // TODO SRE-4611 needs to be resolved before this parameter can be removed
                      booleanParam(name: 'TEST_USE_DOCKER', value: true)
                    ])
        } else {
            echo 'this is not using dropwizard 1.x, to migrate to the new version, follow the steps on this wiki page: https://wiki.cvent.com/display/DEV/Dropwizard+1.x+-+Migration+guide'
            snapshot_image_build = build job: "snapshot-dropwizard-service-docker", parameters:
                    [string(name: 'GIT_REPO', value: git_url),
                     string(name: 'GIT_BRANCH', value: BRANCH_NAME),
                     // TODO SRE-4611 needs to be resolved before this parameter can be removed
                     booleanParam(name: 'TEST_USE_DOCKER', value: true),
                     string(name: 'BASE_IMG_TAG', value: base_img_tag)]
        }
    } catch(error){
        echo 'the snapshot build has failed'
        throw error
    }
  snapshot_modules = [snapshot_image_build.buildVariables.artifactsToDeploy.split(','),
                      snapshot_image_build.buildVariables.ECR_IMAGE_TAGS.split(',')].transpose()
  return snapshot_modules
}
// target java 11
private _buildJava11Snapshot(params) {
    git_url=params['git_url']
    BRANCH_NAME=params['BRANCH_NAME']

    print 'building the snapshot, targeting java 11'
    try {
        snapshot_image_build = build job: "jdk11-snapshot-dropwizard-service-docker", parameters:
                    ([string(name: 'GIT_REPO', value: git_url),
                      string(name: 'GIT_BRANCH', value: BRANCH_NAME)
                    ])
    } catch(error){
        echo 'the snapshot build has failed'
        throw error
    }
  snapshot_modules = [snapshot_image_build.buildVariables.artifactsToDeploy.split(','),
                      snapshot_image_build.buildVariables.ECR_IMAGE_TAGS.split(',')].transpose()
  return snapshot_modules
}
/**
 * buildJavaRelease
 * @param params
 *  a map of arguments containing the following:
 *      git_url: the url of the git repository being built
 *      BRANCH_NAME: the name of the branch being built
 *      platform: only needs to be specified if the release being built is a dropwizard 1.x build, in which case extra functionality is needed.
 * @return returns the release modules, which is a list of lists which contain each contain two elements:
 *      the artifact name and its ECR tag
 */
def static buildJavaRelease(params) {
  if (params['use_java_11'].toBoolean()) {
    return new cvent.java.MavenUtils()._buildJava11Release(params)
  }
  return new cvent.java.MavenUtils()._buildJavaRelease(params)
}
private _buildJavaRelease(params){
    git_url=params['git_url']
    BRANCH_NAME=params['BRANCH_NAME']
    platform=params['platform']?:'dropwizard'
    docker_image=params['docker_image']?:'cvt_java11__us-east-1__v1.16.53'
    base_img_tag=platform + ':' + docker_image

    try {
      //If the project uses dropwizard 1.x, then the snapshot build job needs extra parameters, specifically the dropwizard 1.x platform tag and the updated base img tag.
      if (platform.contains('dropwizard-1.x')) {
          release_image_build = build job: 'release-dropwizard-service-docker',
                  parameters: [
                    string(name: 'SOFTWARE_PLATFORM', value: platform),
                    string(name: 'BASE_IMG_TAG', value: base_img_tag),
                    string(name: 'GIT_REPO', value: git_url),
                    string(name: 'GIT_BRANCH', value: BRANCH_NAME),
                    // TODO SRE-4611 needs to be resolved before this parameter can be removed
                    booleanParam(name: 'TEST_USE_DOCKER', value: true)
                  ]
      } else {
          echo 'this is not using dropwizard 1.x, to migrate to the new version, follow the steps on this wiki page: https://wiki.cvent.com/display/DEV/Dropwizard+1.x+-+Migration+guide'
          release_image_build = build job: 'release-dropwizard-service-docker',
                  parameters: [
                          string(name: 'GIT_REPO', value: git_url),
                          string(name: 'GIT_BRANCH', value: BRANCH_NAME),
                          // TODO SRE-4611 needs to be resolved before this parameter can be removed
                          booleanParam(name: 'TEST_USE_DOCKER', value: true),
                          string(name: 'BASE_IMG_TAG', value: base_img_tag)
                  ]
      }

      release_modules = [
              release_image_build
                      .buildVariables.artifactsToDeploy
                      .split(','),
              release_image_build
                      .buildVariables.ECR_IMAGE_TAGS
                      .split(',')
      ].transpose()
    }catch(error){
       echo 'failed to build the release'
      throw error
    }
  return release_modules
}

private _buildJava11Release(params) {
    git_url=params['git_url']
    BRANCH_NAME=params['BRANCH_NAME']
    print 'building the release, targeting java 11'
    try {
      release_image_build = build job: 'jdk11-release-dropwizard-service-docker',
                  parameters: [
                    string(name: 'GIT_REPO', value: git_url),
                    string(name: 'GIT_BRANCH', value: BRANCH_NAME)
                  ]

      release_modules = [
              release_image_build
                      .buildVariables.artifactsToDeploy
                      .split(','),
              release_image_build
                      .buildVariables.ECR_IMAGE_TAGS
                      .split(',')
      ].transpose()
    }catch(error){
       echo 'failed to build the release'
      throw error
    }
  return release_modules
}
