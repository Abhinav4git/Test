/**
*  A for building maven projects
*/
package cvent.java

import cvent.stash.GitClient
import cvent.jenkins.GroovyUtils
import cvent.parsers.Yaml

import groovy.transform.Field

// The name of the maven tool instance to use by default.
@Field def static final DEFAULT_MVN_INSTANCE = 'mvn-3.3.9'

// The default branch to build from.
@Field def static final DEFAULT_CHECKOUT_BRANCH = 'master'


// The default branch to build from.
@Field def static final EXTRACT_BUILD_INFO_RESC_PATH = 'cvent/java/extractBuildInfoFromPom.TEMPLATE.groovy'
@Field def static final ENSURE_SNAPSHOT_RESC_PATH = 'cvent/java/ensureSnapshotVersion.groovy'

/**
* Builds a snapshot version of a Java (Maven) code base and pushes it to the Cvent Maven repository.
*
* @param repoUrl  The Stash clone url of the repository to build
* @param args     A set of optional named arguments as follows.
*                   branch:       The value to set -DgitBranch to.  Must be passed in due to
*                                 https://issues.jenkins-ci.org/browse/JENKINS-35230 / 26000
*                   mavenInstance The name of the maven tool instance to use.  Defaults to mvn-3.3.9
*
* @return Returns a map contain the groupId, artifactId(s) and version number of what was pushed.
*/
def static buildSnapshot(Map args = [:], String repoUrl) {  new MavenBuilder()._buildSnapshot(args, repoUrl) }
def private _buildSnapshot(Map args = [:], String repoUrl) {

  args = applyDefaults(args)

  GitClient.checkoutRepo(repoUrl, branch: args.branch)

  ensureSnapshotVersion()

  doBuild(args, 'clean deploy -DperformRelease=true')

  return extractBuildInfoFromPom()
}

/**
* Builds a release version of a Java (Maven) code base and pushes it to the Cvent Maven repository.
*
* @param repoUrl  The Stash clone url of the repository to build
* @param args     A set of optional named arguments as follows.
*                   branch:       The value to set -DgitBranch to.  Must be passed in due to
*                                 https://issues.jenkins-ci.org/browse/JENKINS-35230 / 26000
*                   mavenInstance The name of the maven tool instance to use.  Defaults to mvn-3.3.9
*
* @return Returns a map contain the groupId, artifactId(s) and version number of what was pushed.
*/
def static buildRelease(Map args = [:], String repoUrl) {  new MavenBuilder()._buildRelease(args, repoUrl) }
def private _buildRelease(Map args = [:], String repoUrl) {

  args = applyDefaults(args)

  GitClient.checkoutRepo(repoUrl, branch: args.branch)

  doBuild(args, 'clean release:prepare release:perform')

  return extractBuildInfoFromPom()
}

def private applyDefaults(args) {
  [
    branch: DEFAULT_CHECKOUT_BRANCH,
    mavenInstance:  DEFAULT_MVN_INSTANCE
  ] + args
}

def private ensureSnapshotVersion(){

  def script = libraryResource ENSURE_SNAPSHOT_RESC_PATH

  GroovyUtils.runScript(script)
}

def private doBuild(args, goals) {
  withMaven( maven: args.mavenInstance) {

    // Run the maven build
    sh """GIT_COMMIT=\$(git rev-parse HEAD)
    mvn -B -s \$HOME/.m2/settings.xml -f \$WORKSPACE/pom.xml -U ${goals} -Prelease,jenkins -DbuildId=\$BUILD_ID -DgitCommit=\$GIT_COMMIT -DgitBranch=${args.branch}"""
  }
}

def private extractBuildInfoFromPom() {

  def resultsYaml = "${pwd(tmp: true)}/results.yaml"

  def script = GroovyUtils.loadTemplate(
    EXTRACT_BUILD_INFO_RESC_PATH,
    outFileYaml: resultsYaml
  )

  GroovyUtils.runScript(script)

  results = Yaml.parse(readFile(file: resultsYaml))

  sh "rm -f ${resultsYaml}"

  return results
}
