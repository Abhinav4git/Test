/**
* This class contains various methods needed to undeploy services, move them between hosts, roll back, etc.
*
* Should this also be where we put method to manage the chef attribute that control where services go
* or should those get their own class/file?
*/

package cvent.java

import groovy.transform.Field

// This is the user that used for ssh access to dropwizard hosts.
@Field def static final SSH_USER = 'javaman'

/**
* Returns the version of a service that is currently deployed for a specific region on specified dropwizard host.
*
* @param serviceName     The name of the service. e.g. 'auth-service-web'.
* @param region          The region for which the service is registered.
*                        e.g. 'staging', 'S400', etc.
* @param hostFQDN        The FQDN of the dropwizard host on which to look.
* @param throwIfNotFound If true will throw an IllegalArgumentException if the service does not exist.
*                        If false, an empty array is returned.  Default is true.
*
* @return A string containing the version found.
*
* NOTE: This method works by looking for the symlink that points to the version specific jar for the service.
*       It then parses the path of the jar pointed to to extract the version.  This is done via executing remote
*       SSH commands.  Therefore **this method must run in the context of an Linux node** If not already in the
*       context of a node, node('linux') is invoked.  If in the context of a windows node, an exception will occur.
*/
public static getDeployedVersion(String serviceName, String region, String hostFQDN, throwIfNotFound = true) {
 new ServiceManager()._getDeployedVersion(serviceName, region, hostFQDN, throwIfNotFound)
}
private  _getDeployedVersion(String serviceName, String region, String hostFQDN, throwIfNotFound = true) {
  def out
  def symLink = "/services/cvent/${region}/${serviceName}/${serviceName}.jar"
  def readlink = {
    out = sh returnStdout: true, script: "ssh ${SSH_USER}@${hostFQDN} \"echo; readlink -f ${symLink} || echo 'NOT_FOUND'\""
  }

  if(env.NODE_NAME == null) {
    node 'linux', readlink
  } else {
    readlink()
  }

  if( out ==~ /(?s).*NOT_FOUND.*/ ) {
    if (throwIfNotFound) {
      throw new IllegalArgumentException("${symLink} not found on ${hostFQDN}.")
    } else {
      return null
    }
  } else {
    def ver = out =~ /.*\/${serviceName}\/([^\/]+)\/${serviceName}.*/
    return ver[0][1]
  }

}