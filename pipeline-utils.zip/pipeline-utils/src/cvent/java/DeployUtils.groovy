/**
 * A Utility Class for deploying.
 */

 package cvent.java
/** deploy
 * This function deploys a module to a specified region
 *
 * @param params params is a map that has the following elements:
 *  module: what is actually being deployed, the service, consumer etc
 *  ecs: whether to deploy to Amazon ECS or to on premise
 *  AWS_ACCOUNT_NAME: the aws account that is used if the deployment is to an aws region
 *  ECS_CLUSTER_NAME: The ecs cluster to deploy to if deploying to ecs
 *  git_url: The url of the git repository from the module that is being deployed
 *  branch_name: The name of the branch that the module that is being deployed came from
 *  is_consumer: Whether or not this service is a consumer. If unsure, it should be specified in the base.properties file, and if it is not than it is not a consumer, likely
 *  service_root: the service root, often in the form of servicename/v1
 *  memory: how much memory needs to be reserved if the deployment is to ecs
 *  location: the region to deploy to, for example, it is 'ci' for a deployment to ci
 *  desired_count: How many instances of the services should be run on ecs?
 *  group: the group id for the deployment
 *  version: the version number being deployed
 *  clover: whether or not to run clover. This should only be 'yes' if it is a deploy to ci, and the region being deployed to is the region 'ci'
 *  platform: 'dropwizard 1.x' if it is dropwizard 1.x, anything else for the regular build of dropwizard
 *  temporary: if true then spin down module afterward
 * @return
 */
def static deploy(params) { new cvent.java.DeployUtils()._deploy(params) }

private _deploy(params) {
  def location = params['location']
  if ([Collection, String[]].any { it.isAssignableFrom(location.getClass()) }) {
    def locations = location as Set
    def deploys = locations.collectEntries() {
      ["${it}" : { -> _deploySingle(params + [location: "${it}"]) }]
    }
    parallel deploys
  } else {
    _deploySingle(params)
  }
}

private _deploySingle(params) {
  def module = params['module']
  def aws_acct_name = params['AWS_ACCOUNT_NAME']
  def ecs_cluster_name = params['ECS_CLUSTER_NAME']
  def git_url = params['git_url']
  def branch_name = params['branch_name']
  def is_consumer = params['is_consumer']
  def service_root = params['service_root']
  def memory = params['memory']
  def location = params['location']
  def desired_count = params['desired_count']
  def group = params['group']
  def version = params['version']
  def clover = params['clover'] ?: 'no'
  def platform = params['platform'] ?: 'dropwizard'
  def temporary = params['temporary'] ?: false

  echo 'Deploy to location: ' + location

  if (params['ecs'].toBoolean()) {
    echo 'deploying to ecs, to deploy to on prem instead change the pipeline paramaters in the Jenkinsfile'
    try {
      build(job: 'deploy-service-ecs', parameters: [
          string(name: 'AWS_ACCOUNT_NAME', value: aws_acct_name),
          string(name: 'ECS_CLUSTER_NAME', value: ecs_cluster_name),
          string(name: 'SERVICE_NAME', value: module[0]),
          string(name: 'ENV', value: location),
          booleanParam(name: 'IS_CONSUMER', value: (is_consumer.toBoolean())),
          string(name: 'ECR_IMAGE_TAG', value: module[1]),
          string(name: 'SERVICE_URL_ROOT', value: service_root),
          string(name: 'MEMORY_RESERVATION_MB', value: memory),
          string(name: 'DESIRED_COUNT', value: "${desired_count}"),
          string(name: 'VERBOSE', value: '0'),
          string(name: 'PLATFORM', value: platform),
          booleanParam(name: 'SYNCHRONOUS', value: true),
      ])

      // ECS doesn't manage services at the host level, but this variable is needed later
      hosts = ''
    }
    catch(err) {
      echo 'deployment to aws failed'
      throw err
    }
  } else {
    echo 'deploying to on prem instead of ecs, as per the parameters in the pipeline'

    try {
      deploy = build job: "deploy-dropwizard-service", parameters: [
        string(name: 'ENVIRONMENT', value: location),
        string(name: 'NEW_DEPLOYMENT', value: 'yes'),
        string(name: 'GROUP_ID', value: group),
        string(name: 'ARTIFACT_ID', value: module[0]),
        string(name: 'VERSION', value: version),
        string(name: 'START', value: 'yes'),
        string(name: 'JIRA_ISSUE', value: params["jira_issue"] ?: '')
      ]

      hosts = deploy.buildVariables['HOSTS_TO_DEPLOY']
    } catch (err) { //if the deploy fails, then retry it without starting it up.
      echo 'the deployment to on prem failed.'
      throw err
    }
  }

  try {
    echo 'Run integration test to location: ' + location

    build job: 'it-dropwizard-service-docker-2.0', parameters: [
      string(name: 'ENVIRONMENT', value: location),
      string(name: 'GIT_REPO', value: git_url),
      string(name: 'GIT_BRANCH', value: branch_name)
    ]
  }
  catch (err) {
    echo 'Integration Tests failed'
    throw err
  }

  if(temporary) {
    spinDown(params + [hosts:  hosts])
  }
}
/** spinDown
 * This function spins down a module in a specified region
 *
 * @param params params is a map that has the following elements:
 *  module: what is actually being spun down, the service, consumer etc
 *  ecs: whether it is in Amazon ECS or premise
 *  AWS_ACCOUNT_NAME: the aws account that is used if the deployment was to an aws region
 *  ECS_CLUSTER_NAME: The ecs cluster to use, if it is in aws
 *  git_url: The url of the git repository from the module that is being spun down
 *  branch_name: The name of the branch that the module that is being spun down came from
 *  is_consumer: Whether or not this service is a consumer. If unsure, it should be specified in the base.properties file, and if it is not than it is not a consumer, likely
 *  service_root: the service root, often in the form of servicename/v1
 *  memory: how much memory was reserved if the deployment was to ecs
 *  location: the region that the module is in, for example, it is 'ci' for a deployment to ci
 *  desired_count: How many instances are running on ecs?
 *  group: the group id for the deployment
 *  version: the version number
 *  hosts: the hosts to uninstall the service from
 * @return
 */
def static spinDown(params) { new cvent.java.DeployUtils()._spinDown(params) }

private _spinDown(params) {

  def module = params['module']
  def aws_acct_name = params['AWS_ACCOUNT_NAME']
  def ecs_cluster_name = params['ECS_CLUSTER_NAME']
  def location = params['location']

  // Default to false so that future deploys can be faster
  def delete = params['delete'] ?: false

  if (params['ecs'].toBoolean()) {
    try {
      build job: 'manage-ecs-service', parameters: [
        string(name: 'AWS_ACCOUNT_NAME', value: aws_acct_name),
        string(name: 'ECS_CLUSTER_NAME', value: ecs_cluster_name),
        string(name: 'SERVICE_NAME', value: module[0]),
        string(name: 'ENV', value: location),
        booleanParam(name: 'DELETE', value: delete),
        string(name: 'DESIRED_COUNT', value: '0'),
        booleanParam(name: 'SYNCHRONOUS', value: true),
        string(name: 'VERBOSE', value: '1')
      ]
    } catch (error) {
      echo "spinning down from ${location} failed"
      throw error
    }
  } else {
    try {
      build job: 'uninstall-dropwizard-service', parameters: [
        string(name: 'HOSTS', value: params['hosts']),
        string(name: 'ENVIRONMENT', value: location),
        string(name: 'SERVICE_NAME', value: module[0]),
        booleanParam(name: 'UNTAG_HOST', value: false)
      ]
    } catch (error) {
      echo "spinning down from ${location} failed"
      throw error
    }
  }
}

/** liquibase
 * Runs liquibase migrations on one or more modules. Does nothing if modules is null or empty
 *
 * @param params map that has the following elements:
 *  environment: environment to migrate
 *  group_id: Maven groupId
 *  modules: List of modules which contain Dropwizard liquibase bundles
 *  version: Maven version
 */
def static liquibase(params) {
  new cvent.java.DeployUtils()._liquibase(params);
}

private _liquibase(params) {
  def environment = params['environment']
  if ([Collection, String[]].any { it.isAssignableFrom(environment.getClass()) }) {
    def environments = environment as Set
    def deploys = environments.collectEntries() {
      ["${it}" : { -> _liquibaseSingle(params + [environment: "${it}"]) }]
    }
    parallel deploys
  } else {
    _liquibaseSingle(params)
  }
}

private _liquibaseSingle(params) {
  def environment = params['environment']
  def groupId = params['group_id']
  def version = params['version']
  def modules = params['modules']

  if (modules) {
    echo "Running liquibase migration for environment [${environment}]"

    modules.each { module ->
      build job: 'liquibase-deploy-2.0',
        parameters: [
          string(name: 'ENVIRONMENT', value: environment),
          string(name: 'GROUP_ID', value: groupId),
          string(name: 'ARTIFACT_ID', value: module),
          string(name: 'VERSION', value: version)
        ]
    }
  } else {
    echo "No liquibase modules specified, skipping liquibase migrations."
  }
}
