/**
* A Utility Class for working with docker images.
*/

package cvent.docker

import java.nio.file.*
import java.util.regex.Matcher

import cvent.aws.AwsUtils
import cvent.aws.CloudFormationUtils

/**
* Find all dockerfiles in a directory
*
* @return A list of relative paths to Dockerfiles
*/
def static String[] findDockerfiles() { new DockerUtils()._findDockerfiles() }
def private String[] _findDockerfiles() {
  findFiles(glob: '**/Dockerfile').collect { it.toString() }
}

/**
* Get the basename of a path
*
* @return The parent directory of a path (could be null)
*/
def static String basename(String path) {
  Paths.get(path).getParent()?.toString()
}

/**
* Find dockerfiles and associate them with their directories
*
* @return A map of relative paths to Dockerfiles to their directories
*         (or latest for the root Dockerfile)
*/
def static Map<String, String> defaultDockerfiles() {
  DockerUtils.findDockerfiles().collectEntries { [
    (it): [ tags: [ DockerUtils.basename(it) ?: 'latest' ] ]
  ] }
}

/**
* Lint a dockerfile
*/
def static lint(path) { new DockerUtils()._lint(path) }
def _lint(path) {
  docker.image('docker.cvent.net/cvent/lint-dockerfile').inside {
    sh "dockerfilelint ${path}"
  }
}

/**
* Build a docker image
*
* @param args  A map that accepts the following parameters:
*                name: The name of the image to build
*                tag: The tag of the image to build
*                path: Path to dockerfile to build
*                file: The dockerfile to build with the --file option
*                build_args: Arguments to pass through to docker build
* @return      A docker image
*/
def static build(name, path, args = [:]) { new DockerUtils()._build(name, path, args) }
def _build(name, path, args = [:]) {
  def repo_url = sh(returnStdout: true, script: 'git config --get remote.origin.url').trim()
  def git_sha = sh(returnStdout: true, script: '''git log --pretty=format:'%h' -n 1''').trim()

  def build_args = [
    '--pull',
    "--label 'git_repo=${repo_url}'",
    "--label 'git_repo_dir=${path}'",
    "--label 'git_repo_sha=${git_sha}'",
    (env.BUILD_USER_ID ? "--label built_by='${env.BUILD_USER_ID}'" : null),
    args['build_args'],
    (DockerUtils.basename(path) ?: '.'),
    (args['file'] ? "--file ${args['file']}" : null)
  ].findAll()

  docker.build(name, build_args.join(" "))
}

/**
* Test a docker image with inspec
*
* @param image A docker image
* @param args  A map that accepts the following parameters:
*                path: path to Dockerfile
*                tests: path to inspec profile (relative to Dockerfile directory)
*                entrypoint: command to run to keep the container alive while testing.
*                            Set to false to use entrypoint in the Dockerfile.
*                            If unspecified, will default to `cat`
*/
def static test(image, args = [:]) { new DockerUtils()._test(image, args) }
def _test(image, args = [:]) {
  def base_path = DockerUtils.basename(args['path'] ?: 'Dockerfile') ?: '.'
  def tests_path = "${base_path}/${args['tests'] ?: 'tests'}"
  def entrypoint = ''
  if (args['entrypoint'] == null) {
    entrypoint = '--entrypoint cat'
  } else if (args['entrypoint']) {
    entrypoint = "--entrypoint ${args['entrypoint']}"
  }

  if (fileExists(tests_path)) {
    image.withRun("-it ${entrypoint}") { c ->
      docker.image('chef/inspec:3.9.3').inside("-v /var/run/docker.sock:/var/run/docker.sock -u root --entrypoint ''")  {
        sh("inspec exec ${tests_path} --no-create-lockfile -t docker://${c.id}")
      }
    }
  }
}

/**
* Push a docker image to a set of repositories
*
* @param image A docker image
* @param args  A map that accepts the following parameters:
*                registries: List of repositories to publish to
*/
def static push(image, tags, registries = ['http://docker.cvent.net']) { new DockerUtils()._push(image, tags, registries) }
def _push(image, tags, registries = ['http://docker.cvent.net']) {
  parallel registries.collectEntries {
    [(it): { pushToRegistry(image, tags, it) }]
  }
}

/**
* Push a docker image to a repository
*
* @param image A docker image
* @param args  A map that accepts the following parameters:
*                registries: List of repositories to publish to
*/
def private static pushToRegistry(image, tags, registry) { new DockerUtils()._pushToRegistry(image, tags, registry) }
def private _pushToRegistry(image, tags, registry) {
  image_name = image.id.split(":")[0]

  switch (registry) {
    case ~/(.+)@(.+)/:
      def (account, environment, region, _availability_zone) = AwsUtils.parseLocation(registry)

      // Handle slashes in image_name since CF stacks cannot contain slashes
      if(image_name.contains("/")) {
        stack_name = image_name.split("/")[1]
      }
      else {
        stack_name = image_name
      }

      withCredentials([[
          $class: 'AmazonWebServicesCredentialsBinding',
          credentialsId: "${account}-shared-jenkins",
      ]]) {
        docker.image('mesosphere/aws-cli').inside("-e AWS_ACCESS_KEY_ID -e AWS_SECRET_ACCESS_KEY -e AWS_SESSION_TOKEN --entrypoint ''")  {
            docker_login = sh(returnStdout: true, script: "aws ecr get-login --region ${region} --no-include-email").trim()

            DockerUtils.upsertRepository(region, stack_name)
        }
      }

      ecr_url = docker_login.split(" ")[-1]

      sh("set +x && ${docker_login}")
      docker.withRegistry(ecr_url) {
        tags.each {
          image.push(it)
        }
      }
      sh("docker logout ${ecr_url}")
      break;
    case 'http://docker.cvent.net':
      docker.withRegistry(registry) {
        tags.each {
          image.push(it)
        }
      }
      break
    default:
      error 'Deploying to repositories other than docker.cvent.net or ECR is not yet supported'
  }
}

/**
* Upsert an ECR repository
*
* @param region       The AWS region to upsert in
* @param repository   The repository name
*/
def private static upsertRepository(region, repository) { new DockerUtils()._upsertRepository(region, repository) }
def private _upsertRepository(region, repository) {
  echo "Upserting the ${repository} ECR repository in ${region}"
  CloudFormationUtils.upsertStack(region,
                                  "${repository}-ecr",
                                  [
                                    templateS3: "https://cvent-management-iaas-cfn-templates-${region}.s3.amazonaws.com/ecs/ecr/repository-v1/template.yaml",
                                    parameters: [
                                      Name: repository
                                    ]
                                  ])
}
