/**
* A Utility Class for parsing YAML strings to groovy Maps/Arrays/etc and vice-versa.
*
* This class is really just a wrapper around the snakesyaml parser. See its docs for full
* details on expected behavior: https://bitbucket.org/asomov/snakeyaml/wiki/Documentation
*/
package cvent.parsers

@Grab(group='org.yaml', module='snakeyaml', version='1.16' )
import org.yaml.snakeyaml.Yaml as YamlParser //Avoid conflict with this files class name Yaml
import org.yaml.snakeyaml.DumperOptions

/**
* Given a string containing YAML, parses it and returns a goovy map, array or other
* appropriate data structure representing the contents of the YAML.
*
* @param yaml A string containing valid YAML content.
*
* @return A map, array or other data structure representing the content of the given YAML.
*/
def static parse(String yaml) {
  return new YamlParser().load(yaml)
}

/**
* Given a Map, array, etc. returns a string representation of it in YAML format.
*
* @param obj The object to be converted to yaml.
*
* @return A string representation of the object in YAML format.
*/
static String emit(obj) {
  DumperOptions options = new DumperOptions()
  options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK)
  options.setIndent(2)
  return new YamlParser(options).dump(obj)
}
