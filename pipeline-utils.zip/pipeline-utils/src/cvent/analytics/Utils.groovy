/**
*  Utility classes for helping with gathering and posting analytics metrics.
*/
package cvent.analytics

/**
* Executes an action and returns start time, end time and duration all in milliseconds.
*
* @param action A closure, the action to measure.
*
* @return A map, containing startTs, endTs and durationMillis.  In addition the map will
*         contain success, which is true if the action did not throw, false if it did.
*         If successful result will contain any return value from the action, else
*         exception will contain the exception thrown.
*/
def static measureDuration(Closure action) {
  def rtn = [ startTs:  System.currentTimeMillis() ]
  try{
    rtn.result = action()
    rtn.success = true
  } catch (ex) {
    rtn.success = false
    rtn.exception = ex
  } finally {
    def end = System.currentTimeMillis()

    return rtn << [
      endTs: end,
      durationMillis: end - rtn.startTs
    ]
  }
}

/**
* Starts a timer that can be later stopped in order to meature the duration of a action
* that cannot be encapsulated within a single closure.
*
* @return A map, containing startTs, endTs and durationMillis as well as running (boolean)
*         and stop (a method).  endTs and durationMillis will be null and running true until
*         stop is called.  At that point endTs and durationMillis is populated and running
*         is set to false.
*
*         Calling stop more than once will result in an IllegalStateException.
*/
def static startMeasureDuration() {
  def timer = [
    startTs: System.currentTimeMillis(),
    endTs: null,
    durationMillis: null,
    running: true,
  ]
  timer.stop = { ->
      def end = System.currentTimeMillis()
      timer << [
        endTs: end,
        durationMillis: end - timer.startTs,
        running: false,
        stop: { -> throw new IllegalStateException('Duration measurement has already been stopped.') }
      ]
      return
  }
  return timer
}
