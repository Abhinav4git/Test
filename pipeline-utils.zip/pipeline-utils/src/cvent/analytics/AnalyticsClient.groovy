/**
*  An Client for use in sending analytics data to the Cvent analytics platform
*/
package cvent.analytics

@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.7.1' )
import groovyx.net.http.HTTPBuilder;
import groovyx.net.http.ContentType;
import groovyx.net.http.Method;
import groovy.json.JsonOutput;

import groovy.transform.Field

@Field def static final ANALYTICS_ENDPOINT = 'https://io.cvent.com/dai/v1/fact'

/**
* sends a fact to the Cvent analytics platform.
*
* @param fact        A map containing the fact data to be send.  At a minimum must contain a 'type'.
*                    A ts (timestamp) will be added if missing.  Must be in milliseconds since epoc.
*
*        logFalures: If true, any failures that occur will be logged to stdout.  Optional.
*                    Defaults to true.  This is the only form of error output.  The function swallows
*                    all errors (is gauranteed never to throw.)
*
*/
@NonCPS
def static recordFact(Map fact, logFailures = true) {

  def payload = fact // for error logging
  try {
    if(!fact.containsKey('ts')) {
      fact.ts = System.currentTimeMillis()
    }

    payload = JsonOutput.toJson(fact)

    getHttpBuilder(ANALYTICS_ENDPOINT).request(Method.POST) {
      body = payload
      requestContentType = ContentType.JSON

      response.failure = { resp ->
        if(logFailures){
          println "INFO: Analytics recordFact failed with status: ${resp.status} for fact ${payload}."
        }
      }
    }
  } catch (ex) {
    if(logFailures){
      println "INFO: Analytics recordFact failed with exception: ${ex} for fact ${payload}."
    }
  }
}

// This method exists only to allow for mocking of the HTTPBuilder by tests
@NonCPS
def protected static getHttpBuilder(String baseUrl) { return new HTTPBuilder(baseUrl) }
