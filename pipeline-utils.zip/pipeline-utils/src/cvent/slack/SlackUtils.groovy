/**
 * A Utility Class for Slack.
 */

package cvent.slack

import cvent.stash.Utils as StashUtils
import groovy.json.JsonOutput

/**
 * Sends messages to slack channels
 *
 * @param channels       The slack channels to send a message to
 * @param args           A map accepting the following optional keys:
 *                          message: A custom message to send, rather than the default
 *                          attachments: A list of attachments (https://api.slack.com/docs/message-attachments)
 */
def static notifySlack(channels, args = [:]) { new SlackUtils()._notifySlack(channels, args) }
private _notifySlack(channels, args = [:]) {
  // https://stackoverflow.com/a/7281596
  // Is the channels parameter a collection or array?
  if ([Collection, Object[]].any { it.isAssignableFrom(channels.getClass()) }) {
    channels = channels.join(",")
  }

  message = args['message'] == '' ? '' : """\
    ${currentBuild.currentResult}: <${env.BUILD_URL}console|#${env.BUILD_NUMBER}> (<${env.BUILD_URL}console|Open>)
    Branch: ${StashUtils.getBranch()}
    Author: ${sh(returnStdout: true, script: "git log -1 --pretty=format:'%an'").trim()}
    Commit: ${sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()}
    Message: ${sh(returnStdout: true, script: "git log -1 --pretty=format:'%s'").trim()}
  """.stripIndent()

  attachments = args['attachments'] ? JsonOutput.toJson(args['attachments']) : null

  slackSend(channel: channels,
            color: (currentBuild.currentResult == 'SUCCESS') ? 'good' : 'danger',
            message: message,
            attachments: attachments)
}

/**
 * Sends fields to slack channels
 *
 * @param channels       The slack channels to send a message to
 * @param fields         A map of field keys and values to send in the message
 */
def static sendFields(channels, fields = [:]) { new SlackUtils()._notifySlack(channels, fields) }
private _sendFields(channels, fields = [:]) {
  def repo_id = StashUtils.getProjectSlashRepo(StashUtils.getGitUrl())

  def slackFields = fields.collect { k, v ->
    [
      title: k,
      value: v,
      short: true
    ]
  }

  style = (currentBuild.currentResult == 'SUCCESS') ? 'good' : 'danger'

  actions = [
      [
          type : "button",
          text : "View Details",
          url  : env.BUILD_URL,
          style: style
      ],
      [
          type : "button",
          text : "Changelog",
          url  : StashUtils.getChangelogUrl(StashUtils.getGitUrl(), branch).replace("/stash/", "/stash.cvent.net/"),
          style: style
      ]
  ]

  attachments = [
      [
          pretext  : "*${repo_id}*",
          color    : style,
          fallback : "${repo_id} build",
          fields   : fields,
          mrkdwn_in: ['pretext'],
          actions  : actions
      ]
  ]

  slackSend(channel: channels.join(","),
            color: style,
            message: '',
            attachments: attachments)
}

/**
 * Return a list of Slack channels with special "_owner_" token transformed into actual Slack username
 * @param channel - a string as channel name or a list of channels
 */
def static transformSlackChannel(channel) { new SlackUtils()._transformSlackChannel(channel) }
private _transformSlackChannel(channel) {
  if (!channel) {
    return []
  }
  def channels = channel instanceof String ? [channel] : channel as Set
  if (channels.remove('_owner_')) {
    // CHANGE_AUTHOR_EMAIL is only available in PRs
    if (env.CHANGE_AUTHOR_EMAIL) {
      // TODO: figure out a more reliable way to retrieve Slack username, for now use first part of PR author email
      def slackUserName = '@' + env.CHANGE_AUTHOR_EMAIL.split('@')[0]
      channels.add(slackUserName)
    }
  }
  return channels
}