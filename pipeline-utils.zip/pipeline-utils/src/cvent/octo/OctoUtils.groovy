/**
 * Utility class for performing REST API operations against Octopus Deploy
 */
package cvent.octo

@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.7.1' )
import groovyx.net.http.HTTPBuilder
import groovyx.net.http.ContentType

/**
 * Gets all the environments
 */
def static getEnvironments() {
  return new OctoUtils()._getEnvironments()
}
def private _getEnvironments() {
  return doOctoCall("/api/environments/all")
}

/**
 * Gets the project corresponding to the project name passed in. Project name should look like it does in
 * the Octopus UI, or as it does in the URL bar in the UI.
 */
def static getProject(String projectName) {
  return new OctoUtils()._getProject(projectName)
}
def private _getProject(String projectName) {
  def urlSafeSlug = projectName.replaceAll("\\.", "-")
  return doOctoCall("/api/projects/${urlSafeSlug}")
}

/**
 * Gets the most recent successful deployment for the passed in project and environment
 *
 * @param projectId     The project id, not project name (see getProject)
 * @param environmentId The environment id (see getEnvironments)
 */
def static getLatestGoodDeployment(String projectId, String environmentId) {
  return getDeployments(projectId, environmentId, true).Items.first()
}
/**
 * Gets all recent deployments for the passed in project and environment
 *
 * @param projectId      The project id, not project name (see getProject)
 * @param environmentId  The environment id (see getEnvironments)
 * @param onlySuccessful When set, only returns successful deployments, otherwise returns them all
 */
def static getDeployments(String projectId, String environmentId, boolean onlySuccessful = true) {
  return new OctoUtils()._getDeployments(projectId, environmentId, onlySuccessful)
}
def private _getDeployments(String projectId, String environmentId, boolean onlySuccessful) {
  def taskStateQuery = onlySuccessful ? '&taskState=Success' : ''
  return doOctoCall("/api/deployments?projects=${projectId}&environments=${environmentId}${taskStateQuery}")
}

/**
 * Gets release information
 *
 * @param releaseId   The release id. You would likely get this by checking ReleaseId on a deployment.
 */
def static getRelease(String releaseId) {
  return new OctoUtils()._getRelease(releaseId)
}
def private _getRelease(String releaseId) {
  return doOctoCall("/api/releases/${releaseId}")
}

def private doOctoCall(String callPath) {
  withCredentials([string(credentialsId: 'octopus-deploy-apikey', variable: 'OCTO_API_KEY')]) {
    return readJSON(text: reallyDoOctoCall(callPath, OCTO_API_KEY))
  }
}

@NonCPS
def private reallyDoOctoCall(String callPath, String apiKey) {
  def octo = new HTTPBuilder('https://octo.core.cvent.org')

  def response = octo.get(path: callPath, headers: ['X-Octopus-ApiKey': apiKey], contentType: ContentType.JSON)
  //use a string here and use jenkins's json parser later to avoid cps issues
  return groovy.json.JsonOutput.toJson(response)
}