/*
* This is a simple wrapper to clean up the normand-build-new job and condense it so a one
* line call( except for the args, which are job parameters transposed into a map)
*/

package cvent.dotnet

def static normandyWrapper(Map args = [:]) { new NormandyWrapper()._normandyWrapper(args) }

def private _normandyWrapper(Map args = [:]) {
  try{
    //This builds and publishes all the c4 applications in parallel, as well as running the audit-repository job

    timestamps {Normandy.buildAndReleaseAllApplications(args)}

    def slackChannel = null;
    def identifier = branchIdentifier
    if (identifier.startsWith("alpha")  ) {
        slackChannel =  branchIdentifier;
    } else if (identifier == 'S511' ) {
        slackChannel = 'alpha-event-1';
    } else if (identifier == 'S512' ) {
        slackChannel = 'alpha-event-2';
    } else if (identifier == 'S521' ) {
        slackChannel = 'alpha-smm-1';
    } else if (identifier == 'S531' ) {
        slackChannel = 'alpha-csn-1';
    } else if (identifier == 'S541' ) {
        slackChannel = 'alpha-survey-1';
    } else if (identifier == 'S551' ) {
        slackChannel = 'alpha-crosstab-1';
    }

    //Adding these might be counterproductive. What if multiple functions might have comunications.
    if (slackChannel != null) {
      println '#cvt-' + slackChannel
      def issues
      try{
        issues = build(job:'util-issues-between', parameters:[[$class: 'StringParameterValue', name: 'toBranch', value :branchName]]).environment.get("ISSUES_BETWEEN")
      }catch(e){
        println e
        issues = "Failed util-issues-between"
        println issues
      }
      //It would be nice, for later imporvements, to use our slack function
      steps.build job: "slack-jenkins-message", parameters:[
        [$class: 'StringParameterValue', name: 'channelName', value: "#cvt-" + slackChannel],
        [$class: 'StringParameterValue', name: 'message', value: "'${branchName}' has been built and released as '${args["version"]}'. Issues since prod: '${issues}'"]
        ];
    }
  } catch(ex) {
    println ex;
    //Send failure messages
    node(){emailext attachLog: true,
      body: "Build failed in Jenkins: ${BUILD_URL} at ${new Date()}" + "\n\n" + ex + "\n\n",
      compressLog: true,
      recipientProviders: [[$class: 'RequesterRecipientProvider']],
      subject: "Build failed in Jenkins: ${JOB_NAME}, build ${BUILD_NUMBER}",
      to: 'd.jain@cvent.com'
    }

    //!fallbackChannelName=cvt-silo-notification
    steps.build job: "slack-jenkins-message", parameters:[
      [$class: 'StringParameterValue', name: 'channelName', value: "#cvt-'${branchIdentifier}'"],
      [$class: 'StringParameterValue', name: 'message', value: "Normandy build failed '${BUILD_URL}' "]
      ];

    currentBuild.result = "FAILURE"
    throw ex
  }

}
