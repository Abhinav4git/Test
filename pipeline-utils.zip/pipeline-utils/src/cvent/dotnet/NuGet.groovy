/**
* A Class containing wrappers around nuget commands
*/
package cvent.dotnet

import cvent.windows.Powershell

/**
* NuGet pack
* See https://docs.microsoft.com/en-us/nuget/tools/nuget-exe-cli-reference#pack
*
* @param path           The path to the file to pack
* @param args           A set of optional named arguments as follows:
*                         - Passthru to powershell
*                         - Parameters to pass to nuget (see validParams).
*/
def static pack(Map args = [:], String path) {
  def validParams = [
    'BasePath',
    'Build',
    'Exclude',
    'ExcludeEmptyDirectories',
    'ForceEnglishOutput',
    'Help',
    'IncludeReferencedProjects',
    'MinClientVersion',
    'MSBuildPath',
    'MSBuildVersion',
    'NoDefaultExcludes',
    'NoPackageAnalysis',
    'OutputDirectory',
    'Properties',
    'Suffix',
    'Symbols',
    'Tool',
    'Verbosity',
    'Version'
  ]
  println "Running 'nuget pack ${path}' with ${args + [params: args.subMap(validParams)]}"
  Powershell.runScript(args + [params: args.subMap(validParams)], "nuget pack ${path}")
}

@NonCPS
def static extractVersion(String pkgName) {
  def match = pkgName =~ /([^.]+(\.[^.]+){2})\.nupkg$/
  println "Match: ${match}"

  if (match) {
    def version = match.group(1)
    println "Version: ${version}"

    return version
  }
}