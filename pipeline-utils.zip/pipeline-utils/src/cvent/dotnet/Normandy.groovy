/*
 * This package makes use of the parallelDeploy function from NuGetBuilder.groovy to
 * build all of the Normandy applications in a pipeline.
 *
 * It uses methods and classes from cvent.dotnet.NuGetBuilder and cvent.dotnet.PackageType, so both
 * must be included when running this method
 */
package cvent.dotnet

/*
* Runs both the buildAllApplications method and the octopus-deply-create-release job.
* The octopus-deploy-create-release is still a job in jenkins (not pipelined)
* It should be migrated in the future.
*
* @param args simply all the args that need to be passed to buildAllApplications
*/
def static buildAndReleaseAllApplications(Map args = [:]){ new Normandy(). _buildAndReleaseAllApplications(args)}
def private _buildAndReleaseAllApplications(Map args = [:]){
  buildAllApplications(args)

  def octoChannel = "Default"
    if(args.sev1 == true){
      octoChannel = "Sev1"
    }
  if (args["package"] == "yes") {
    build job: "octopus-deploy-create-release", parameters:[
        [$class: 'StringParameterValue', name: 'projectName', value: "normandy"],
        [$class: 'StringParameterValue', name: 'versionNumber', value: args["version"]],
        [$class: 'StringParameterValue', name: 'releaseNotes', value: args["releaseNotes"]],
        [$class: 'StringParameterValue', name: 'octoChannel', value: octoChannel]
      ];
    build job: "octopus-deploy-create-release", parameters:[
        [$class: 'StringParameterValue', name: 'projectName', value: "sql-deploy"],
        [$class: 'StringParameterValue', name: 'versionNumber', value: args["version"]],
        [$class: 'StringParameterValue', name: 'releaseNotes', value: args["releaseNotes"]],
        [$class: 'StringParameterValue', name: 'octoChannel', value: octoChannel]
      ];
  }
}

/*
* Takes in the args, which are defined in the jenkins job, and pass them through to parallelDeploy.
* The args are job parameters just placed in a map. They are: buildNumber,appVersion, branchName,
* release, incReference,releaseNotes, configBranch, auditFailPackageDowngrades,
* branchIdentifier, package,cleanupArtifacts, loggingLevel, precomp, version.
* Each normandy App also has their own set of individual args, which are defined here.
*
* @param args simply all the args that need to be passed to buildAllApplications
*/
def static buildAllApplications(Map args = [:]){new Normandy()._buildAllApplications(args)}
def private _buildAllApplications(Map args = [:]){
    //Each project has its own specific arguments
    def projects = [
        auditRepository: [
            name:"auditRepository",
            separateNode: true
        ],
        assets: [
            name:"assets",
            enableZipDirectories: true,
            zipDirectories: [ [ path: 'wwwroot' ] ],
            packages: [
                [
                 path: 'app.cvent.com/Cvent.App.Root.nuspec',
                 type: PackageType.OCTO
                ],
                [
                    path: 'guest.cvent.com/Cvent.Guest.Root.nuspec',
                    type: PackageType.OCTO
                ]
            ],
            separateWorkspace: false
        ],
        deployment: [
            name:"deployment",
            enableCreatePartialSQL: true,
            compareBranch: "PROD",
            packages: [
                [
                 path: 'Database/Cvent.Subscribers.SQL.nuspec',
                 type: PackageType.OCTO
                ],
                [
                 path: 'VSProjects/CventReports/Cvent.Subscribers.RDL.nuspec',
                 type: PackageType.OCTO
                ]
            ],
            separateWorkspace: false
        ],
        obfuscationMetadata: [
            name:"obfuscationMetadata",
            enableCreatePartialObfuscationMetadata: true,
            compareBranch: "PROD",
            packages: [
                [
                 path: 'Database/Cvent.ObfuscationMetadata.nuspec',
                 type: PackageType.OCTO
                ]
            ],
            separateWorkspace: false
        ],
        global_configs: [
            name:"global_configs",
            packages: [
                    [
                    path: 'VSProjects/global-configs/Cvent.Normandy.GlobalConfigs.nuspec',
                    type: PackageType.OCTO
                    ]
            ],
            separateWorkspace: false
        ],
        cvent: [
            name:"cvent",
            release: args["release"],
            precomp: args["precomp"],
            precompPackages: [
                    [
                    path: 'Cvent.Web.Subscribers-precomp.nuspec',
                    type: PackageType.OCTO
                    ]
            ],
            solutionAudit: [ options: "-ft", gradeSolution: '$true' ],
            path: 'VSProjects/Cvent/Solution.Cvent/Solution.Cvent.sln',
            separateNode: true ],
        cvent2: [
            name:"cvent2",
            solutionAudit: [ options: "-ft", gradeSolution: '$true' ],
            path: 'VSProjects/Cvent2/Cvent2.sln',
            separateNode: true ],
        events: [
            name:"events",
            solutionAudit: [ options: "-ft", gradeSolution: '$true' ],
            path: 'VSProjects/Cvent.Subscribers.Event/Cvent.Subscribers.Event/Cvent.Subscribers.Event.sln',
            separateNode: true ],
        dashboards: [
            name:"dashboards",
            solutionAudit: [ options: "-ft", gradeSolution: '$true' ],
            path: 'VSProjects/Cvent.Subscribers.Dashboards/Cvent.Subscribers.Dashboards.sln',
            separateWorkspace: true ],
        abstract_mgmt: [
            name:"abstract_mgmt",
            solutionAudit: [ options: "-ft", gradeSolution: '$true' ],
            path: 'VSProjects/Cvent.Subscribers.AbstractMgmt/Cvent.Subscribers.AbstractMgmt.sln',
            separateWorkspace: true ],
        appointments: [
            name:"appointments",
            solutionAudit: [ options: "-ft", gradeSolution: '$true' ],
            path: 'VSProjects/Cvent.Subscribers.Appointments/Cvent.Subscribers.Appointments.sln',
            separateWorkspace: true ],
        admin: [
            name:"admin",
            solutionAudit: [ options: "-ft", gradeSolution: '$true' ],
            path: 'VSProjects/Cvent.Subscribers.Admin/Cvent.Subscribers.Admin.sln',
            separateWorkspace: true ]
    ]

    if(args["branchName"].toLowerCase().matches("ccid-.*")){
      projects = projects + [sqlRollback: [
            name:"sqlrollback",
            compareBranch: "PROD",
            packages: [
                [
                 path: 'Database/Cvent.SQLRollback.nuspec',
                 type: PackageType.OCTO
                ]
            ],
            separateNode: true
        ],
      ]
    }

    //These arguments are in common for all applications
    parallelArgs = [
      project_name: 'Normandy',
      enablePublish: true,
      branch: args["branchName"],
      version: args["version"],
      versionOverride: args["version"],
      logging: args["loggingLevel"],
      build_number: args["buildNumber"],
      cleanupArtifacts: args["cleanupArtifacts"],
      pushToNuget: args["package"],
      doSonarAnalysis: "no", //Because it was set to "no" on ALL of the old jenkins jobs
      compareBranch: args["incReference"],
      updateConfigsWithHogan: [ configBranch: args["configBranch"] ],
      failPackageDowngrades: args["auditFailPackageDowngrades"],
      sev1: args["sev1"],
      platform: args["bitness"],
      enableCdn: args["enableCdn"],
      enableOctoPack: args["package"]
    ]

    println args["version"]
    println "Parameters: "+ args
    println "Args passed to parallelDeploy" + parallelArgs
    NuGetBuilder.parallelDeploy(parallelArgs,"cvt/c4",projects,'net46')
}
