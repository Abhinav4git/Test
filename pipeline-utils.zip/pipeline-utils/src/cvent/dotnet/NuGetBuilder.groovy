/**
* A Class for building/publishing nuget packages.
*/
package cvent.dotnet

import cvent.stash.GitClient
import cvent.windows.Powershell
import cvent.windows.Robocopy

/**
* Takes details for multiple projects, and deploys them in parallel.
* This will allocate nodes.
*
* @param args           A set of optional named arguments as follows:
*                         - Passthru to makeNodeForParallelDeploy
*                         - name            The name of the project being built,
*                                           so that generated files do not collide
*                                           with other projects
* @param repoUrl        The Stash clone url of the repository to build
* @param projects       Map of `name` to project details
* @param label          Jenkins label used to determine slaves to choose
*/
def static parallelDeploy(Map args = [:], String repoUrl, Map projects, String label) { new NuGetBuilder()._parallelDeploy(args, repoUrl, projects, label) }
def private _parallelDeploy(Map args = [:], String repoUrl, Map projects, String label) {
  def builders=[:]
  if(repoUrl == 'cvt/c4'){
    builders['single node']={
      def singleNode = [:];
      for(int i = 0; i < projects.keySet().size(); i++){
        def appName = projects.keySet()[i];
        if (projects[appName].separateNode != true) {
          if (projects[appName].separateWorkspace == true) {
            projects[appName].path = projects[appName].path.replace('VSProjects/',"${appName}Build/")
          }
          singleNode[appName] = makeArrayForParallelDeploy(args + projects[appName],appName);
        }
      }
      if(singleNode.size()>0){
        node(label) {
          try{
            echo "Deleting lock file from path: ${pwd()}\\.git\\"
            Powershell.runScript("if(Test-Path ${pwd()}\\.git) {get-childitem ${pwd()}\\.git\\ -include *.lock -recurse | foreach (\$_) {remove-item \$_.fullname}}")
          }
          catch(ex) {
            println ex;
          }
          stage("singleNode-repo-clone"){
            def c4BranchParams = [:]
            try{
            	Powershell.runScript("if(Test-Path ${pwd()}\\target) {rm -r ${pwd()}\\target -ErrorAction SilentlyContinue > null}")
            }
          	catch(ex) {
            	println "Failed while cleaning up before c4 checkout in 'single node' stage. Continuing ahead.";
          	}
              //GitClient.checkoutToSubdir(args+c4BranchParams, repoUrl)
              GitClient.checkoutC4(args+c4BranchParams)
          }

          _checkoutNugetBuild(args)
          NuGetBuildWrappers.updateConfigsWithHoganWrapper(args)
          Powershell.runScript("Add-Type -assembly 'system.io.compression.filesystem'; [io.compression.zipfile]::CreateFromDirectory('VSProjects', 'VSProjects.zip', [System.IO.Compression.CompressionLevel]::Fastest, \$false) ")
          echo "Updated Configs"
          singleNode.failFast = true
          parallel singleNode
          try{
          	Powershell.runScript("if(Test-Path ${pwd()}\\target) {rm -r ${pwd()}\\target -ErrorAction SilentlyContinue > null}")
          }
          catch(ex) {
            println "Failed while cleaning up after complete execution in 'single node' stage. Continuing ahead.";
          }
          try{
            echo "Deleting lock file from path: ${pwd()}.git\\"
            Powershell.runScript("get-childitem ${pwd()}\\.git\\ -include *.lock -recurse | foreach (\$_) {remove-item \$_.fullname}")
          }
          catch(ex) {
            println ex;
          }
          try{
            echo "Deleting lock file from path: ${pwd()}\\nuget-build\\.git\\"
            Powershell.runScript("get-childitem ${pwd()}\\nuget-build\\.git\\ -include *.lock -recurse | foreach (\$_) {remove-item \$_.fullname}")
          }
          catch(ex) {
            println ex;
          }
        }
      }
    }
  }

  builders['separate node']={
    def separateNode = [:];
    for(int i = 0; i < projects.keySet().size(); i++){
      def appName = projects.keySet()[i];
      if (projects[appName].separateNode == true) {
        separateNode[appName] = makeNodeForParallelDeploy(args + projects[appName],repoUrl, label, appName);
      }
    }
    separateNode.failFast = true
    parallel separateNode
  }

  builders.failFast = true
  parallel builders
}

/**
* checkouts nuget-build
* @param args           A set of optional named arguments as follows:
*
*/
def static checkoutNugetBuild(Map args = [:]) { new NuGetBuilder()._checkoutNugetBuild(args) }
def private _checkoutNugetBuild(Map args = [:]) {
  def nugetBranchParams = [:]
    GitClient.checkoutToSubdir(args.nuget_build ?: nugetBranchParams, "DEP/nuget-build")
}


/**
* Takes details for multiple projects, and deploys them in parallel.
* This will allocate separate workspace for projects on same node.
*
* @param args           A set of optional named arguments as follows:
*                         - name            The name of the zip being extracted
* @param appName        The name of project being build
*/
def private createParallelWorkSpace(Map args = [:], String appName){
  echo "Starting to create separate workspace for ${appName}"
  createDirectory("${appName}Build")
  Powershell.runScript("Add-Type -assembly 'system.io.compression.filesystem'; [io.compression.zipfile]::ExtractToDirectory('VSProjects.zip', '${appName}Build' ) ")
  echo "Created separate workspace for ${appName}"
}

/**
* Takes details for multiple projects, and deploys them in parallel.
*
*
* @param args           A set of optional named arguments as follows:
*                         - Passthru to buildAndPublish
*                         - name            The name of the project being built,
*                                           so that generated files do not collide
*                                           with other projects
* @param appName        The name of project being build
*/
def private makeArrayForParallelDeploy(Map args = [:], String appName){
  { ->
    stage(appName){
      if (args.separateWorkspace == true) {
        echo "creating workspace"
        createParallelWorkSpace(args,appName)
      }

      buildAndPublishWithoutCheckout(args,appName)

      if (args.separateWorkspace == true) {
        echo "Performing clean to knock off some space"
        try{
        	bat "del /f/s/q ${appName}Build > nul"
        }
        catch(ex) {
        	println "Failed while cleaning up ${appName}Build. Continuing ahead.";
        }
      }
    }
  }
}

/**
* Takes details for multiple projects, and deploys them in parallel.
* This will allocate nodes.
*
* @param args           A set of optional named arguments as follows:
*                         - Passthru to buildAndPublish
*                         - name            The name of the project being built,
*                                           so that generated files do not collide
*                                           with other projects
* @param repoUrl        The Stash clone url of the repository to build
* @param label          Jenkins label used to determine slaves to choose
* @param appName        The name of project being build
*/
def private makeNodeForParallelDeploy(Map args = [:], String repoUrl, String label, String appName){
  { -> node(label)
    {
      stage(appName){
      //Need to use ws because if not the path it too long
        ws("${pwd()}".replaceAll(/jenkins[\\\/]workspace/,"jw")){
          buildAndPublish(args, repoUrl)
        }
      }
    }
  }
}

/**
* Given a repository and details of a project within, do the following:
* Checkout the repo, build, pack, and publish that project.
*
* @param args           A set of optional named arguments as follows:
*                         - Passthru to checkoutToSubdir
*                         - Passthru to build
*                         - Passthru to pack
*                         - Passthru to publish
*                         - packages          The list of packages to create explicitly
* @param repoUrl        The Stash clone url of the repository to build
*/
def static buildAndPublish(Map args = [:], String repoUrl){new NuGetBuilder()._buildAndPublish(args,repoUrl)}
def private _buildAndPublish(Map args = [:], String repoUrl) {
    if(repoUrl == 'cvt/c4'){
      try{
        echo "Deleting lock file from path: ${pwd()}\\c4\\.git\\"
        Powershell.runScript("if(Test-Path ${pwd()}\\c4\\.git) {get-childitem ${pwd()}\\c4\\.git\\ -include *.lock -recurse | foreach (\$_) {remove-item \$_.fullname}}")
      }
      catch(ex) {
        println ex;
      }
      try{
        echo "Deleting lock file from path: ${pwd()}\\nuget-build\\.git\\"
        Powershell.runScript("if(Test-Path ${pwd()}\\nuget-build\\.git) {get-childitem ${pwd()}\\nuget-build\\.git\\ -include *.lock -recurse | foreach (\$_) {remove-item \$_.fullname}}")
      }
      catch(ex) {
        println ex;
      }
    }
    try{
      Powershell.runScript("if(Test-Path ${pwd()}\\c4\\target) {rm -r ${pwd()}\\c4\\target -ErrorAction SilentlyContinue > null}")
    }
    catch(ex) {
      println "Failed while cleaning up before C4 checkout. Continuing ahead.";
    }
    GitClient.checkoutToSubdir(args, repoUrl) {
      _checkoutNugetBuild(args)

      if(args["name"] != "auditRepository"){
        NuGetBuildWrappers.updateConfigsWithHoganWrapper(args)
        echo "Updated Configs"
      }

      if(args["name"] != "auditRepository"){
        retry(2){ build(args) }
      }else{
        build(args)
      }

      for(int i = 0; i < (args.packages ?: []).size(); i++) {
        pack([package: args.packages[i]] + args)
      }

      if(args["name"] == "cvent") {
        if(args["precomp"]) {
          for(int i = 0; i < (args.precompPackages ?: []).size(); i++) {
            pack([package: args.precompPackages[i]] + args)
          }
        }
      }

      if(args["name"] != "auditRepository"){
        retry(2){
          publish(args)
          if(args["name"] == "cvent" && args["precomp"]){
            precompPublish(args)
          }
        }
      }

      if (args["separateNode"] == true && args["cleanupArtifacts"] == true) {
        echo "Performing a git clean to knock off some space"
        try{bat 'git clean -dfx > nul'}
        catch(ex) {
          println ex;
        }
      }
      try{
        echo "Deleting lock file from path: ${pwd()}\\.git\\"
        Powershell.runScript("get-childitem ${pwd()}\\.git\\ -include *.lock -recurse | foreach (\$_) {remove-item \$_.fullname}")
      }catch(ex) {
        println ex;
      }
    }
}

/**
* Given a repository and details of a project within, do the following:
* Build, pack, and publish that project.
*
* @param args           A set of optional named arguments as follows:
*                         - Passthru to checkoutToSubdir
*                         - Passthru to build
*                         - Passthru to pack
*                         - Passthru to publish
*                         - packages          The list of packages to create explicitly
*/
def static buildAndPublishWithoutCheckout(Map args = [:], String appName){new NuGetBuilder()._buildAndPublishWithoutCheckout(args, appName)}
def private _buildAndPublishWithoutCheckout(Map args = [:], String appName) {

  retry(2){ build(args) }
  for(int i = 0; i < (args.packages ?: []).size(); i++) {
    pack([package: args.packages[i]] + args)
  }

  retry(2){ publish(args) }

}

/**
* If any common or 'compilation' steps are required, do them. This may create
* packages, prepare the workspace for future operations, run lints/tests etc.
*
* @param args           A set of optional named arguments as follows:
*                        - Passthru to updateConfigsWithHoganWrapper
*                        - Passthru to createReleaseNotesWrapper
*                        - Passthru to zipDirectories
*                        - Passthru to compileSolutionWrapper
*                        - Passthru to precompileSolution
*                        - Passthru to solutionAuditAnalysisWrapper
*                        - Passthru to runTestsWrapper
*                        - Passthru to copySQLFilesWrapper
*                        - Passthru to createLookupFileWrapper
*                        - zipDirectories     The list of directories to zip up
*                        - path               The path to the solution to be built
*                        - enableCreatePartialSQL   Whether this build contains
*                                             SQL files that should be used to
*                                             support a 'partial' deploy
*/
def static build(Map args = [:]){ new NuGetBuilder()._build(args)}
def private _build(Map args = [:]) {

  if(args["name"] != "auditRepository"){
    NuGetBuildWrappers.createReleaseNotesWrapper(args)
    echo "Created Release Notes"
  }

  if(args["name"] == "cvent" && args["enableCdn"] == true) {

        echo "Starting to CDN the assets for wwwroot"
        def cdnWWW = [
          asset_dir:'.\\wwwroot'
        ]
        NuGetBuildWrappers.cdnAssetize(args + cdnWWW)

        echo "Starting to CDN the asset on RFP"
        def cdnRFP = [
          wwwroot_file:'.\\wwwroot\\cdn_asset_mapping.json',
          app_prefix:'/rfp',
          asset_dir:'.\\VSProjects\\Cvent\\Cvent.Web.RFP'
        ]
        NuGetBuildWrappers.cdnAssetize(args + cdnRFP)
        echo "Done CDNing the assets for RFP"
    }

  zipDirectories(args, args.zipDirectories)
  echo "Zipped directories"

  if (args.path?.endsWith(".sln")) {
    if(args["name"] == "cvent"){
      if(args["precomp"]){
        args["precompile"] = ''
        args["organization"]="precomp"
      }
    }

    NuGetBuildWrappers.compileSolutionWrapper(args)
    echo "Compiled solution"

    if(args["name"] == "cvent") {
      if(args["precomp"]) {
        precompileSolution(args)
        echo "Precompiled solution"
      }
    }

    if(!(args.containsKey('disableAudit') && args.disableAudit == true)) {
      NuGetBuildWrappers.solutionAuditAnalysisWrapper(args)
      echo "Audited solution"
    }

    NuGetBuildWrappers.runTestsWrapper(args)
    echo "Run tests"

    //If this is true it means it is cvent and it has precomp enabled
    if(args["organization"] == "precomp"){
      NuGetBuildWrappers.postBuildCleanupWrapper()
    }
  }

  if(args.enableCreatePartialSQL) {
    NuGetBuildWrappers.copySQLFilesWrapper(args)
    NuGetBuildWrappers.createLookupFileWrapper(args)
  }
  if(args.enableCreatePartialObfuscationMetadata) {
    NuGetBuildWrappers.copyObfuscationMetadataFilesWrapper(args)
  }
  if(args["name"] == "auditRepository"){
    NuGetBuildWrappers.auditRepository(args)
  }
  if(args["name"] == "sqlrollback"){
    NuGetBuildWrappers.copySQLRollbackFiles(args)
  }
}

/**
* Uses a project file (nuspec or csproj) to create a nupkg file.
*
* @param args           A set of optional named arguments as follows:
*                         - Passthru to createPackageWrapper, OR
*                         - Passthru to publishPackageWrapper
*                         - name            The name of the project being built,
*                                           so that generated files do not collide
*                                           with other projects
*                         - path            The path to the package to be built,
*                                           supports nuspec and csproj files
*                         - type            The type of project being created,
*                                           see `PackageType`
*/
def static pack(Map args = [:]) { new NuGetBuilder()._pack(args) }
def private _pack(Map args = [:]) {
  Map pkg = args.package ?: [:]
  def packageType = pkg.type ?: PackageType.NUGET
  def packageDir = "${PackageType.path(packageType)}/${args.name}"
  if(args["name"] == "cvent" && args["precomp"]){
    packageDir = "${PackageType.path(packageType)}-precomp/${args.name}"
  }
  def buildDir = "target/${pkg.name}"
  createDirectory(packageDir)
  switch(pkg.path) {
    case ~/.+\.nuspec$/:
      NuGetBuildWrappers.createPackageWrapper(args + pkg + [outputDirectory: packageDir])
      break
    default:
      NuGetBuildWrappers.updateNuspecVersionsWrapper(args)

      NuGet.pack(pkg.path, Properties: "\"Configuration=Release;OutDir=${pwd()}/${buildDir}\\\"", OutputDirectory: packageDir, IncludeReferencedProjects: null)
      break
  }
}

/**
* Using the directories that are expected to contain the packages,
* take the files in those directories and publish them.
*
* @param args           A set of optional named arguments as follows:
*                         - Passthru to publishPackageFolderWrapper
*                         - name            The name of the project being built,
*                                           so that generated files do not collide
*                                           with other projects
*                         - enablePublish   set this to false if you do not
*                                           want the project to be published.
*                                           Defaults to true.
*/
def static publish(Map args = [:]) { new NuGetBuilder()._publish(args) }
def private _publish(Map args = [:]) {
  if(args.get('enablePublish',true)){
    def packageTypes = [PackageType.OCTO, PackageType.NUGET]
    for(int i = 0; i < packageTypes.size(); i++) {
      def packageType = packageTypes[i]

      def publishArgs = [
        packageFolder: "${PackageType.path(packageType)}/${args.name}",
        feedName: PackageType.feedName(packageType)
      ]

      if (fileExists(publishArgs['packageFolder'])) {
        NuGetBuildWrappers.publishPackageFolderWrapper(publishArgs + args)
      } else {
        echo "Nothing to publish for ${packageType}"
      }
    }
  }
}

/**
* Using the directories that are expected to contain the packages,
* take the files in those directories and publish them.
*
* @param args           A set of optional named arguments as follows:
*                         - Passthru to publishPackageFolderWrapper
*                         - name            The name of the project being built,
*                                           so that generated files do not collide
*                                           with other projects
*                         - enablePublish   set this to false if you do not
*                                           want the project to be published.
*                                           Defaults to true.
*/
def static precompPublish(Map args = [:]) { new NuGetBuilder()._precompPublish(args) }
def private _precompPublish(Map args = [:]) {
  if(args.get('enablePublish',true)){
    def packageType = PackageType.OCTO
    def publishArgs = [
      packageFolder: "${PackageType.path(packageType)}-precomp/${args.name}",
      feedName: PackageType.feedName(packageType)
    ]
    if (fileExists(publishArgs['packageFolder'])) {
      NuGetBuildWrappers.publishPackageFolderWrapper(publishArgs + args)
    } else {
      echo "Nothing to publish for ${packageType}"
    }
  }
}

/**
* Create a release in Octopus Deploy
*
* @param args           A set of optional named arguments as follows:
*                         - Passthru to getVersionForProjectWrapper
*                         - enablePublish   set this to false if you do not
*                                           want the project to be published.
*                                           Defaults to true.
*/
def static release(Map args = [:]) { new NuGetBuilder()._release(args) }
def private _release(Map args = [:]) {
  if(args.get('enablePublish',true)){
    def packageGlob = "${PackageType.path(PackageType.OCTO)}/${args.name}/*.nupkg"
    def octoChannel = "Default"
    if(args.sev1 == true){
      octoChannel = "Sev1"
    }
    echo "Package Glob: ${packageGlob}"

    octoPackage = findFiles(glob: packageGlob).first()
    echo "Octo Package: ${octoPackage} (from ${findFiles(glob: packageGlob)})"

    if (octoPackage) {
      def version = NuGet.extractVersion(octoPackage.toString())

      if (version) {
        build job: 'octopus-deploy-create-release', parameters: [
          string(name: 'projectName', value: args['octoProject']),
          string(name: 'versionNumber', value: version),
          string(name: 'octoChannel', value: octoChannel)
        ]
      }
    }
  }
}

/**
* TODO: Genericise to more projects than just Cvent.Web.Subscribers
* This will copy the views into the _PublishedWebsites directory, and remove
* any non-precompiled packages.
*
* @param args           A set of optional named arguments as follows:
*                         - name            The name of the project being built,
*                                           so that generated files do not collide
*                                           with other projects
*/
def static private precompileSolution(Map args = [:]) {
  def directory = "${PackageType.path(PackageType.OCTO)}/${args.name}"
  Robocopy.run(['target/Cvent.Web.Subscribers-precomp',
                'target/Cvent.Web.Subscribers/_PublishedWebsites/Cvent.Web.Subscribers',
                '/e'])
  Powershell.runScript("Remove-Item '${directory}/Cvent.Web.Subscribers.*'")
}

/**
* Create a directory at the path specified
*
* @param directory      Path to the directory to be created
*/
def static private createDirectory(String directory) {
  Powershell.runScript("New-Item -ItemType Directory -Force '${directory}'")
}

/**
* Take a list of directories, and zip them up into files for Octopus Deploy.
* This uses the zipFolder.ps1 script to create the files.
*
* @param args           A set of optional named arguments as follows:
*                         - Passthru to zipFolderWrapper
* @param zipDirectories List of Maps, with each map having a `path` field with
*                       the relative path of the directory to zip up.
*/
def static zipDirectories(Map args = [:], List zipDirectories) { new NuGetBuilder()._zipDirectories(args,zipDirectories)}
def private _zipDirectories(Map args = [:], List zipDirectories) {
  for(int i = 0; i < (zipDirectories ?: []).size(); i++) {
    def zipArgs = [
      zipFolder: [
        zipFolder: "${pwd()}/${zipDirectories[i].path}",
        outputFile: "${zipDirectories[i].path}.octo.zip"
      ]
    ]
    NuGetBuildWrappers.zipFolderWrapper(args + zipArgs)
  }
}

/**
* get version id for nuspec packages
* @param args           A set of optional named arguments as follows:
*
*/
def static getVersionForProject(Map args = [:]) { new NuGetBuilder()._getVersionForProject(args) }
def private _getVersionForProject(Map args = [:]) {
  args=[appVersion:"2.0",preReleaseIdentifier:"SNAPSHOT",preRelease:"yes"] +args
  packageVersion = "${args.appVersion}.${args.build_number}"
  if(args.preRelease == "yes"){
    packageVersion = "${packageVersion}-${args.preReleaseIdentifier}"
  }
  args.versionOverride ?: args.version?:packageVersion
}
