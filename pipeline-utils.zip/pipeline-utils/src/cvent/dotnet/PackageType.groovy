package cvent.dotnet

public enum PackageType {
  NUGET, OCTO

  public static String path(PackageType type) {
    switch(type) {
      case NUGET: return 'nugetPackages'
      case OCTO: return 'octoPackages'
    }
  }

  public static String feedName(PackageType type) {
    switch(type) {
      case NUGET: return 'default'
      case OCTO: return 'applications'
    }
  }

  public static String toString(PackageType type) {
    switch(type) {
      case NUGET: return 'NuGet Package'
      case OCTO: return 'Octopus Deploy Package'
    }
  }
}
