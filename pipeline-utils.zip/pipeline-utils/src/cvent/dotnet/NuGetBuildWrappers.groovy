/**
* A Class containing wrappers around scripts in nuget-build
*/
package cvent.dotnet

import cvent.stash.GitClient
import cvent.windows.Powershell
import groovy.transform.Field

@Field def static final NUGET_BUILD_REPO = 'nuget-build'

/**
* Wrapper around nuget-build powershell scripts
*
* @param args Parameters to pass to the Powershell script.
* @param script Name of the script to call.
* @param validParams List of valid parameters that the script accepts.
*/
def private static nugetBuildWrapper(Map args = [:], String name, String script, List validParams) {
  new NuGetBuildWrappers()._nugetBuildWrapper(args, name, script, validParams)
}
def private _nugetBuildWrapper(Map args = [:], String name, String script, List validParams) {
  def overrideParams = args[name] ?: [:]

  def params = (args + overrideParams).subMap(validParams)
  echo "Running ${script} with parameters: ${params}"

  Powershell.runScript("${NUGET_BUILD_REPO}/${script}.ps1", params: params)
}

/**
* Restore packages and run MSBuild.
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static compileSolutionWrapper(Map args = [:]) {
  new NuGetBuildWrappers()._compileSolutionWrapper(args)
}
def private _compileSolutionWrapper(Map args = [:]) {
  def defaultParams = [
    appName: args.name,
    buildVersion: args.build_number,
    rootDir: pwd(),
    solutionPath: args.path,
    enableOctoPack: 'yes',
    pushToNuget: 'yes',
    packageFolder: "octoPackages/${args.name}",
    doSonarAnalysis: 'no',
  ]
  def validParams = [
    'appName', 'buildVersion', 'preRelease', 'loggingLevel',
    'rootDir', 'solutionPath', 'enableOctoPack', 'preReleasePrefix',
    'versionOverride', 'pushToNuget', 'configuration', 'platform',
    'releaseNotesFile', 'referencePath', 'compileViews', 'packageFolder',
    'projectVersionPath', 'doSonarAnalysis', 'precompile', 'precompDir'
  ]
  nugetBuildWrapper(defaultParams + args, 'compileSolution', 'compileSolution', validParams)
}

/**
* Create invalidation.json based on a diff against a branch.
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static createLookupFileWrapper(Map args = [:]) {
  def defaultParams = [:]
  def validParams = ['compareBranch']
  nugetBuildWrapper(defaultParams + args, 'createLookupFile', 'createLookupFile', validParams)
}

/**
* Pack a nuspec file that does not require compilation.
* This assumes that the current working directory is the root of the repository.
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static createPackageWrapper(Map args = [:]) {
  def defaultParams = [
    nuspecFile: args.path
  ]
  def validParams = ['nuspecFile', 'version', 'outputDirectory']
  nugetBuildWrapper(defaultParams + args, 'createPackage', 'createPackage', validParams)
}

/**
* Create release notes for the build.
* This assumes that the current working directory is the root of the repository.
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static createReleaseNotesWrapper(Map args = [:]) {
  def defaultParams = [:]
  def validParams = ['commitSha', 'releaseNotes', 'filePath']
  nugetBuildWrapper(defaultParams + args, 'createReleaseNotes', 'Create-ReleaseNotes', validParams)
}

/**
* Create files/directories required for partial deploys
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static copySQLFilesWrapper(Map args = [:]) {
  def defaultParams = [:]
  def validParams = ['compareBranch']
  nugetBuildWrapper(defaultParams + args, 'copySQLFiles', 'copySQLFiles', validParams)
}

/**
* Create files/directories required for partial deploys
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static copyObfuscationMetadataFilesWrapper(Map args = [:]) {
  def defaultParams = [:]
  def validParams = ['compareBranch']
  nugetBuildWrapper(defaultParams + args, 'copyObfuscationMetadataFiles', 'copyObfuscationMetadataFiles', validParams)
}

/**
* Get the version of a project
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static getVersionForProjectWrapper(Map args = [:]) {
  def defaultParams = [:]
  def validParams = [
    'projectName', 'buildVersion', 'preRelease',
    'preReleaseIdentifier', 'projectPath'
  ]
  nugetBuildWrapper(defaultParams + args, 'getVersionForProject', 'getVersionForProject', validParams)
}

/**
* Publish all packages in a folder to a feed.
* This assumes that the current working directory is the root of the repository.
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static publishPackageFolderWrapper(Map args = [:]) {
  def defaultParams = [:]
  def validParams = [
    'packageFolder', 'appendPackageName', 'organization', 'feedName',
    'extraFeedName', 'feedEndpoint', 'feedApiKey', 'pushTimeout'
  ]
  nugetBuildWrapper(defaultParams + args, 'publishPackageFolder', 'publishPackageFolder', validParams)
}

/**
* Publish a project to all feeds specified.
* This assumes that the current working directory is the root of the repository
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static pushPackageWrapper(Map args = [:]) {
  def defaultParams = [:]
  def validParams = ['nupkgFile', 'feedName', 'extraFeedName', 'pushTimeout']
  nugetBuildWrapper(defaultParams + args, 'pushPackage', 'pushPackage', validParams)
}

/**
* Run all tests that can be found.
* This assumes that the current working directory is the root of the repository.
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static runTestsWrapper(Map args = [:]) { new NuGetBuildWrappers()._runTestsWrapper(args) }
def private _runTestsWrapper(Map args = [:]) {
  def defaultParams = [
    buildOutputPath: "${pwd()}/target",
    testOutputPath: "${pwd()}/target/${args.name}/test_output",
  ]
  def validParams = ['buildOutputPath', 'testOutputPath']
  nugetBuildWrapper(defaultParams + args, 'runTests', 'runTests', validParams)
}

/**
* Run solution-audit against the solution.
* This assumes that the current working directory is the root of the repository.
* See https://wiki.cvent.com/display/DEV/.NET+Solution+auditor for information on
* solution auditor.
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static solutionAuditAnalysisWrapper(Map args = [:]) {
  def defaultParams = [
    solutionPath: args.path,
    version: '1.1.1',
    gradeSolution: '$true',
    options: "-ft"
  ]
  def validParams = ['solutionPath', 'version', 'gradeSolution', 'options']
  nugetBuildWrapper(defaultParams, 'solutionAudit', 'SolutionAuditAnalysis', validParams)
}

/**
* Update config files using hogan.
* This assumes that the current working directory is the root of the repository.
* See https://wiki.cvent.com/display/DEV/Hogan+Configs for information on hogan configs.
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static updateConfigsWithHoganWrapper(Map args = [:]) {
  def defaultParams = [:]
  def validParams = ['hoganBranch', 'configBranch', 'regionRegex', 'rootDir']
  nugetBuildWrapper(defaultParams + args, 'updateConfigsWithHogan', 'Update-Configs-With-Hogan', validParams)
}

/**
* Update versions in nuspec files so that they are all consistent.
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static updateNuspecVersionsWrapper(Map args = [:]) {
  def defaultParams = [
    buildVersion: args.build_number
  ]
  def validParams = ['buildVersion', 'preRelease', 'preReleaseIdentifier', 'versionOverride']
  nugetBuildWrapper(defaultParams + args, 'updateNuspecVersions', 'updateNuspecVersions', validParams)
}

/**
* Zip a directory.
* This assumes that the current working directory is the root of the repository.
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static zipFolderWrapper(Map args = [:]) {
  def defaultParams = [:]
  def validParams = ['zipFolder', 'outputFile']
  nugetBuildWrapper(defaultParams + args, 'zipFolder', 'zipFolder', validParams)
}

def private static postBuildCleanupWrapper(){
  def defaultParams = [:]
  def validParams = []
  nugetBuildWrapper(defaultParams,'postBuildCleanup','postBuildCleanup',validParams)
}


/**
* auditRepository
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static auditRepository(Map args = [:]) {
  def defaultParams = [:]
  def validParams = ['failBasicTest','branch','failPackageDowngrades','workspace','defaultBranch','solutionAudit','failSolutionAudit','auditParameters']
  nugetBuildWrapper(defaultParams + args, 'auditRepository', 'auditRepository', validParams)
}

/**
* CDN assets
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static cdnAssetize(Map args = [:]) {
  def defaultParams = [:]
  def validParams = ['asset_dir','wwwroot_file','app_prefix']
  nugetBuildWrapper(defaultParams + args, 'cdnAssetize', 'cdnAssetize', validParams)
}

/**
* copy partial sql code rollback files in partial folder
*
* @param args Parameters to pass to the Powershell script (see validParams).
*/
def private static copySQLRollbackFiles(Map args = [:]) {
  def defaultParams = [:]
  def validParams = ['compareBranch', 'branch']
  nugetBuildWrapper(defaultParams + args, 'copySQLRollbackFiles', 'copySQLRollbackFiles', validParams)
}

