package cvent.linters

class CdkMetadataLinter extends BaseLinter {
  // Path to explicit config file to customize the linter
  // TODO: Not currently used
  String configFile;

  def CdkMetadataLinter(script, Map map = [:]) {
    super(script)

    this.globs = map.globs ?: ['**/*.json']
    this.configFile = map.configFile
  }

  def void lintFiles(List<String> filePaths) {
    if (filePaths) {
      def parallel_steps = [:]
      filePaths.each {
        parallel_steps.put(it, this.lintTags(it))
      }
      parallel parallel_steps
    } else {
      script.error "No files provided to CDK Lint"
    }
  }

  def lintTags(String filepath){
    return {
      def file = script.readJSON(file: filepath)
      this.checkMandatoryTags(file)
    }
  }

  def checkMandatoryTags(def file) {
    def mandatory_tags = [
      'business-unit',
      'env',
      'pod',
      'platform',
      'product',
      'sub-env'
    ]
    def missing_tags = [:]
    file['artifacts']
      .findAll { it.key != 'Tree' }
      .each {
        missing_tags[it.key] = mandatory_tags.minus(it.value.metadata.find {stackres ->
          stackres.key[1..-1].indexOf('/') < 0 }?.value.find { it.type == 'aws:cdk:stack-tags'}?.data.collect { it.Key })
      }
    if (missing_tags != [:] && missing_tags.any { it.value.size() > 0}) {
      String error_message = "Missing Required Tags: "
      missing_tags.each { error_message += "\n${it.key}: ${it.value.join(', ')}" }
      logErrorAndExit error_message
      return false
    }
    return true
  }
}
