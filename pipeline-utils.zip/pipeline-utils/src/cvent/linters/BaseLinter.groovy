package cvent.linters

import cvent.stash.Utils as StashUtils

abstract class BaseLinter extends cvent.jenkins.ScriptContext {
  // Globs to search for files with
  public List<String> globs;

  def BaseLinter(script) {
    super(script)

    this.globs = ['*']
  }

  /**
   * Perform lint against all eligible files
   * If onlyChanged is true, then be Pull Request aware, and only check files that have changed
   */
  def lint(onlyChanged = false) {
    def files = findFiles()
    if (onlyChanged) {
      files = filterChanged(files)
    }

    lintFiles(files)
  }

  /*
  * This function will turn a list of globs into a list of file paths.
  * The paths are plain old strings rather than the FileWrappers that findFiles
  * provides. Glob negation is supported with a leading exclamation mark (!).
  */
  protected Set<String> globFiles(List<String> globs) {
    def (excludes, includes) = globs.split { it.startsWith('!') }

    def files = script.findFiles(glob: includes.join(','), excludes: excludes.join(','))

    return files.collect { it.path }
  }

  /**
   * Return only those files that are being changed
   * If this is not a Pull Request, do not filter out anything
   */
  protected List<String> filterChanged(List<String> list) {
    def changes = StashUtils.getChanges()

    if (changes == null) {
      return list
    } else {
      return list.findAll { changes.contains(it) }
    }
  }

  /**
   * Find all files matching glob that are eligible for linting
   * Does not account for whether or not they are being changed
   */
  protected Set<String> findFiles() {
    globFiles(this.globs)
  }

  /**
   * This method should error the build if appropriate
   */
  protected abstract void lintFiles(List<String> filePath)
}
