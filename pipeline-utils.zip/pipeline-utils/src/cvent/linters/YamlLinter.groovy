package cvent.linters

class YamlLinter extends BaseLinter {
  // Path to explicit config file to customize the linter
  // TODO: Not currently used
  String configFile;

  def YamlLinter(script, Map map = [:]) {
    super(script)

    this.globs = map.globs ?: ['**/*.yml', '**/*.yaml']
    this.configFile = map.configFile
  }

  def void lintFiles(List<String> filePaths) {
    script.docker
          .image('giantswarm/yamllint')
          .inside("--entrypoint=''") {
      script.sh "yamllint ${filePaths.join(' ')}"
    }
  }
}
