package cvent.linters

import cvent.stash.Utils
import cvent.aws.CloudFormationUtils


class CloudFormationLinter extends BaseLinter {
  // Path to explicit config file to customize the linter
  // TODO: Not currently used
  String configFile;

  def CloudFormationLinter(script, Map map = [:]) {
    super(script)

    this.globs = map.globs ?: ['**/*.yml', '**/*.yaml', '**/*.json']
    this.configFile = map.configFile
  }

  def Set<String> findFiles() {
    CloudFormationUtils
      .deserializeTemplates(globFiles(this.globs))
      .findAll { _, template -> template }
      .collect { path, _ -> path }
  }

  def void lintFiles(List<String> filePaths) {
    if (filePaths) {
      script.docker
            .image('docker.cvent.net/cvent/cfn-lint')
            .inside("--entrypoint=''") {
        script.sh "cfn-lint-cvent ${filePaths.join(' ')}"
      }
    } else {
      script.error "No files provided to CFN Lint"
    }
  }

  /**
   * Get a map of '<Template Path>/<CFN Resource>' to 'lint exceptions'
   * Globally defined lint exceptions in a template will be under '<Template Path>/Global'
   */
  def lintExceptions() {
    def deserializedTemplates = CloudFormationUtils
      .deserializeTemplates(globFiles(this.globs))
      .findAll { _, template -> template }

    def globalExceptions = deserializedTemplates.collectEntries { path, template ->
      [(path): template
        .get('Metadata', [:])
        .get('cfn-lint', [:])
        .get('config', [:])
        .get('ignore_checks', [])
      ]
    }

    def exceptions = deserializedTemplates.collectEntries { path, template ->
      template.get('Resources', [:]).collectEntries { name, resource ->
        [
          (path + '/Global'): globalExceptions[path],
          (path + '/Resources/' + name): globalExceptions[path] + resource
          .get('Metadata', [:])
          .get('cfn-lint', [:])
          .get('config', [:])
          .get('ignore_checks', [])
        ]
      }
    }

    return exceptions.findAll { _, rules -> rules }
  }

  /**
   * Create PR required-approva comments as required based on the addition of
   * lint exceptions in the PR
   */
  def requireLintExceptionApprovals(Closure postCheckout = {}) {
    if (!env.CHANGE_TARGET) {
      error 'Calling requireLintExceptionApprovals requires the context of a PR'
    }

    postCheckout.call()
    def newExceptions = this.lintExceptions()

    def relativeCwd = pwd() - "${env.WORKSPACE}/"

    def oldExceptions = [:]

    // This is just a useful label to use that
    // has cfn-flip already installed
    node('jenkins-agent-cdk') {
      checkout scm

      try {
        dir(relativeCwd) {
          sh "git fetch origin ${env.CHANGE_TARGET}"
          sh "git checkout FETCH_HEAD"

          postCheckout.call()

          oldExceptions = this.lintExceptions()
        }
      } catch(Exception e) {
        logInfo "Exception caught (${e}) while looking for old exceptions."
      }
    }

    postCheckout.call()

    def addedExceptions = newExceptions
      .collectEntries { path, rules -> [(path): rules - oldExceptions[path]] }
      .collectMany { path, rules -> rules.collect { [path, it] } }
      .groupBy { it[1] }
      .collect { rule, paths -> [rule, paths.collect { it[0] }] }

    echo "Old exceptions: ${oldExceptions}"
    echo "New exceptions: ${newExceptions}"
    echo "Added Exceptions: ${addedExceptions.collectEntries()}"

    def securityRules = [
      'E9001',
      'E9002',
      'E9007',
      'E9008',
      'E9009',
      'E9010',
      'E9012',
      'E9013',
      'E9014'
    ]

    def whitelistedRules = [
      'E3001',
      'W2001',
      'W3005',
      'I1022'
    ]

    def (securityAdditions, nonSecurityAdditions) = addedExceptions
      .split { securityRules.contains(it[0]) }

    def (whitelistedAdditions, otherAdditions) = nonSecurityAdditions
      .split { whitelistedRules.contains(it[0]) }

    if (securityAdditions) {
      securityAdditions = securityAdditions.collectEntries()
      echo "Require Security to approve the Pull Request because of the following lint additions:\n${securityAdditions}"
      Utils.commentOnPullRequest("require-approval::IT, Security Engineering\nLint Additions: ${securityAdditions.collect { rule, _ -> rule }}")
    }

    if (whitelistedAdditions) {
      whitelistedAdditions = whitelistedAdditions.collectEntries()
      echo "The following lint additions are whitelisted, and do not require approvals:\n${whitelistedAdditions}"
    }

    if (otherAdditions) {
      otherAdditions = otherAdditions.collectEntries()
      echo "Require SRE to approve the Pull Request because of the following lint additions:\n${otherAdditions}"
      Utils.commentOnPullRequest("require-approval::SRE Global\nLint Additions: ${otherAdditions.collect { rule, _ -> rule }}")
    }
  }

  /**
   * Aggregate methods below
   */
  def private handleLintLine(String lintLine) {
    return isSignificantLine(lintLine) &&
      handleRequiredApprovals(lintLine)
  }

  /**
   * Returns true if the line is a potentially error-worthy line
   * based on if it is non-empty.
   * Otherwise returns falsey
   */
  def private isSignificantLine(String lintLine) {
    return lintLine.trim()
  }

  /**
   * Returns true if the line is a potentially error-worthy line
   * based on it containing a `requires approval` message.
   * Otherwise posts a comment on the pull request, and returns falsey
   */
  def private handleRequiredApprovals(String lintLine) {
    def requirements = (lintLine =~ /requires? approval::(\w+)/).with { it.hasGroup() ? it.collect { it[1] } : [] }

    // The line is referring to a real lint issue,
    // not one for triggering an approval
    if (requirements.isEmpty()) {
      return true
    }

    requirements.each {
      if (env.CHANGE_TARGET && env.CHANGE_ID) {
        def approvalGroup = it
        if (approvalGroup == 'security') {
          approvalGroup = 'IT, Security Engineering'
        }

        script.echo "Adding comment to Pull Request for ${approvalGroup} because of:\n${lintLine}"
        Utils.commentOnPullRequest("require-approval::${approvalGroup}")
      }
    }

    return false
  }
}
