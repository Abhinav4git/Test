package cvent.linters

class ShellLinter extends BaseLinter {
  // Path to explicit config file to customize the linter
  // TODO: Not currently used
  String configFile;

  def ShellLinter(script, Map map = [:]) {
    super(script)

    this.globs = map.globs ?: ['**/*.sh']
    this.configFile = map.configFile
  }

  def void lintFiles(List<String> filePaths) {
    script.docker
          .image('koalaman/shellcheck-alpine')
          .inside("--entrypoint=''") {
      script.sh "shellcheck ${filePaths.join(' ')}"
    }
  }
}
