/**
* A set of utility functions for running powershell scripts on windows nodes.
* This is needed until https://issues.jenkins-ci.org/browse/JENKINS-34581 is implemented.
*
* NOTE: All of the functions in this class assume you are already working in the
        context of a windows node for which the Powershell executable is on the path.
*/
package cvent.windows

/**
*  Takes a string of powershell script and runs it on the node.
*
*  @param script The powershell script to run. Filenames or code are supported
*  @param args   Optional named arguments as follows:
*                    params: A map of parameters to be passed to the file.
*                    returnStatus: if true the exit code of the script is returned.
*                    returnStdout: if true the standard output of the script is returned.
*
*  returnStatus and returnStdout may not both be set to true at the same time.  If neither is set
*  an exception is thrown if the script errors out.
*
*  @return void, integer or string depending upon the values of returnStatus and returnStdout.
*/
def static runScript(args = [:], String script) { new Powershell()._runScript(args, script) }
def private _runScript(args = [:], String script) {
  def psParams = [
    NoProfile: null,
    ExecutionPolicy: 'ByPass',
    EncodedCommand: encode(toPSCommand(script, args.params))
  ] + (args.psParams ?: [:])

  def validPSParams = [
    'EncodedCommand',
    'ExecutionPolicy',
    'InputFormat',
    'Mta',
    'NoExit',
    'NoLogo',
    'NonInteractive',
    'NoProfile',
    'OutputFormat',
    'PSConsoleFile',
    'Version',
    'Sta',
    'WindowStyle',
    'File',
    'Command',
    'Help', '?'
  ]

  // https://jenkins.io/doc/pipeline/steps/workflow-durable-task-step/#bat-windows-batch-script
  args.script = toPSCommand('@powershell.exe', psParams.subMap(validPSParams))
  bat args
}

/**
*  Takes a string and encodes it into PowerShell compatible base64
*
*  @param command  The command to encode.
*
*  @return Base64 encoded String.
*/
@NonCPS
def private encode(String command) {
  command.getBytes("UTF-16LE").encodeBase64().toString()
}

/**
*  Takes an arbitrary script and its parameters and joins them together.
*
*  @param script  The powershell script.
*  @param parameters  A map of parameters to be passed to the script.
*
*  @return String of the joined parameters.
*/
@NonCPS
def private toPSCommand(String script, Map parameters = [:]) {
  def params = parameters?.collect { k, v -> "-${k}${toPSParameter(v)}" }
  return [script, params].flatten().findAll().join(' ')
}

/**
*  Converts argument into a powershell compatible snippet.
*
*  @param parameter  The powershell parameter.
*
*  @return Powershell compatible String.
*/
@NonCPS
def private toPSParameter(parameter) {
  switch(parameter) {
    case Boolean: return ":\$${parameter}"
    case null: return ""
    case ~/.*\s.*/: return " '${parameter}'"
    default: return " ${parameter}"
  }
}
