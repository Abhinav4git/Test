/**
* A set of utility functions for running robocopy on windows nodes.
*
* NOTE: All of the functions in this class assume you are already working in the
        context of a windows node for which the Robocopy executable is on the path.
*/

package cvent.windows

/**
* Takes a list of robocopy parameters and uses them to execute robocopy.
* This will error if robocopy returns an exit code signifying failure (> 4).
* See https://ss64.com/nt/robocopy-exit.html for an explanation of robocopy's
* exit codes.
*
* @param script A list of parameters to pass to robocopy.
*
* @return exit code from robocopy execution
*/
def static run(List params) { new Robocopy()._run(params) }
def private _run(List params) {
  def args = [:]
  args.script = [ "robocopy", params ].flatten().findAll().join(' ')
  args.returnStatus = true
  status = bat args
  if(status >= 4) {
    error "Robocopy failed with a status code of: ${status}"
  } else {
    status
  }
}
