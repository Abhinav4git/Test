# Spec Files

## Contract

Spec files SHOULD expose the following methods:

- `String name()` - Name of spec. Returns a string
- `Map build(Map config)` - Build all artifacts
- `Map ciSetup(Map config)` - Everything required for CI. Returns context values
- `Map ciTest(Map config)` - Integration test against CI.
- `Map ciTeardown(Map config)` - Teardown anything that was created just for CI testing.
- `Map publish(Map config)` - Publish the application to an artifact store. Returns context values

## Helpers

The files in this directory may be used to help create spec files by providing
compatible classes and methods that can be hooked into.
