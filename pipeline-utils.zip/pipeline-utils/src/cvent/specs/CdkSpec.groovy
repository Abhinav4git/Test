package cvent.specs

import cvent.aws.AwsAccount

/**
 * Note: cross-function calls within this file will always resolve to the
 * functions in this file. That is, you cannot create a different `build`
 * method, and have it automatically be used from publish
 */

/**
 * Default entrypoints
 *
 * To override these, set `cdk.entrypoints.ci` and/or `cdk.entrypoints.all`
 * values in your config.
 * This can either be done at a global level (in a Jenkinsfile), or at a
 * method level (`build`, `ci*` within a CDK spec file).
 */
private entrypoints(config) {
  return [
    'ci': config?.cdk?.entrypoints?.ci ?: 'dist/bin/ci.js',
    'all': config?.cdk?.entrypoints?.all ?: [ 'dist/bin/*.js' ]
  ]
}

/**
 * This builds and validates all entrypoints.
 *
 * To be compatible, your package.json should provide the following scripts:
 *   - `build:ts` Should just build the typescript
 *   - `build:cfn` Should take a single path to an entrypoint, and synth it.
 *   - `lint` Should lint everything (ts, js, cfn, ...)
 *   - `test` Should test everything (ts, js, cfn, ...)
 * The exact balance between lint and test is not defined here.
 *
 * `build:ts` and `build:cfn` are broken apart as building CFN often requires
 * the context of an AWS account, and it is difficult to provide many AWS accounts
 * in an ergonomic way.
 */
public static build(Map config = [:]) { new CdkSpec()._build(config) }
private _build(Map config = [:]) {
  // Install dependencies
  sh 'yarn install'

  // Make sure the compiled JS files are available
  sh 'yarn build:ts'

  // Build all the environments
  parallel entrypoints(config).all
    .collectMany { findFiles(glob: it) }
    .collectEntries { file ->
      [(file.path): {
        awsUser.withCdkUser(awsAccount(file.path)) {
          sh "yarn build:cfn ${file.path}"
        }
      }]
    }

  sh 'yarn lint'
  sh 'yarn test'
}

/**
 * This deploys the CI entrypoint stack(s) to AWS.
 * We can assume that build has been run, so no need to rerun yarn steps.
 *
 * To be compatible, your package.json should provide the following scripts:
 *   - `build:ts` Should just build the typescript
 *   - `build:cfn` Should take a single path to an entrypoint, and synth it.
 */
public static ciSetup(Map config = [:]) { new CdkSpec()._ciSetup(config) }
private _ciSetup(Map config = [:]) {
  updateCdkContext(config)

  def entrypoint = entrypoints(config).ci
  if (!fileExists(entrypoint)) {
    error "Entrypoint ${entrypoint} does not exist"
  }

  // Deploy to CI
  def target = [
    entrypoint: entrypoint,
    stacks: [],
    args: '',
  ]

  return cdk([target], { manager ->
    if (env.GIT_BRANCH.startsWith('PR-')) {
      // Require lint exception approvals
      manager.linter.requireLintExceptionApprovals({
        dir(path: manager.outDir) {
          deleteDir()
        }

        // Just build CI, thats all we need for now
        sh 'yarn install'
        sh 'yarn build:ts'
        sh "yarn build:cfn ${entrypoint}"

        if (!manager.enabled()) {
          return false
        }

        manager.synthesize()
      })
    }

    manager.deploy(false)

    return manager.outputs()
  })
}

/**
 * This destroys the CI entrypoint stack(s) from AWS.
 * We can assume that build has been run, so no need to rerun yarn steps.
 */
public static ciTeardown(Map config = [:]) { new CdkSpec()._ciTeardown(config) }
private _ciTeardown(Map config = [:]) {
  updateCdkContext(config)

  def entrypoint = entrypoints(config).ci
  if (!fileExists(entrypoint)) {
    error "Entrypoint ${entrypoint} does not exist"
  }

  // Destroy CI
  def target = [
    entrypoint: entrypoint,
    stacks: [],
    args: '',
  ]

  cdk([target], { manager ->
    manager.destroy()
  })
}

/**
 * This publishes the cdk.out directory to an artifact store (usually Octopus Deploy)
 *
 * To be compatible, your package.json should provide the following scripts:
 *   - `push` Should package and publish the cdk.out directory.
 */
public static publish(Map config = [:]) { new CdkSpec()._publish(config) }
private _publish(Map config = [:]) {
  updateCdkContext(config)

  /* While we can assume that `build` has already been run, we cannot safely say
   * that CI has not run and polluted the cdk.out directory.
   * Therefore, we clear out the cdk.out directory, and re-run build to ensure
   * a clean package.
   */
  dir('cdk.out') {
    deleteDir()
  }
  build(config)

  withCredentials([string(credentialsId: 'octopus-deploy-apikey',
                          variable: 'OCTO_API_KEY')]) {
    sh "yarn push '${config.version}'"
  }

  return ['publish': true]
}

/**
 * Update the context.jenkins section of cdk.json based on a config.context map.
 * This allows us to pass structured data from jenkins into CDK
 */
public static updateCdkContext(Map config) { new CdkSpec()._updateCdkContext(config) }
private _updateCdkContext(Map config) {
  def cdkJson = [:]
  if (fileExists('cdk.json')) {
    echo "Reading cdk.json"
    cdkJson = readJSON(file: 'cdk.json')
  }

  if (cdkJson.context == null) {
    cdkJson.context = [:]
  }

  cdkJson.context.jenkins = config.context
  writeJSON file: 'cdk.json', json: cdkJson, pretty: 2
}

/**
 * Get the AWS Account
 */
public static awsAccount(String entrypoint) { new CdkSpec()._awsAccount(entrypoint) }
private _awsAccount(String entrypoint) {
  def tmpDir = sh(returnStdout: true, script: 'mktemp -d').trim()
  def listCmd = "yarn --silent cdk list --output '${tmpDir}' --long --json --app 'node ${entrypoint}'"

  Set<String> accountIds
  try {
    def stacks = sh(returnStdout: true, script: listCmd)
    accountIds = readJSON(text: stacks).collect { it.environment.account }
  } catch (e) {
    // We failed above so lets capture the error and extract it
    def listErrors = sh(returnStdout: true, script: "${listCmd} 2>&1 ||:")
    def accountId = (listErrors =~ /(?ms).*Need to perform AWS calls for account (\d+), but no credentials found.*/).with { it.matches() ? it[0][1] : null }

    if (accountId) {
      accountIds = [accountId] as Set
    } else {
      logWarn "Unknown cdk list response encountered: ${listErrors}"
    }
  }

  if (accountIds == null || accountIds.size() == 0) {
    error "No AWS accounts found"
  } else if (accountIds.size() == 1) {
    return AwsAccount.find(accountIds[0]) ?: new AwsAccount(id: accountIds[0])
  } else {
    error "Too many AWS accounts found (${accountIds.join(", ")})"
  }
}
