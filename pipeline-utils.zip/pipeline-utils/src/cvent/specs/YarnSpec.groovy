package cvent.specs

import cvent.aws.AwsUtils

/**
 * This builds and tests the yarn package defined beside the spec file.
 *
 * To be compatible, your package.json should provide the following scripts:
 *   - `lint` Should lint everything (ts, js, cfn, ...)
 *   - `build` Should build everything (ts, cfn, ...)
 *   - `test` Should test everything (ts, js, cfn, ...)
 * The exact balance between lint and test is not defined here.
 *
 * Applications can (and should) use yarn workspaces to manage dependencies
 * between application components. The package.json scripts mentioned above
 * may call out to other language-specific build tools (e.g. maven) in order
 * to complete the script step. There is nothing that enforces the existance
 * of particular build tools
 */
public static build(Map config = [:]) { new YarnSpec()._build(config) }
private _build(Map config = [:]) {
  AwsUtils.withAwsProfiles {
    sh "yarn install"
    sh "yarn lint"
    sh "yarn build"
    sh "yarn test"
  }
}

/**
 * This sets up a CI environment to be tested.
 *
 * To be compatible, your package.json should provide the following scripts:
 *   - `ci:setup` Should perform any relevent setup steps required for CI testing
 */
public static ciSetup(Map config = [:]) { new YarnSpec()._ciSetup(config) }
private _ciSetup(Map config = [:]) {
  AwsUtils.withAwsProfiles {
    sh "yarn ci:setup"
  }
}

/**
 * This performs CI tests.
 *
 * To be compatible, your package.json should provide the following scripts:
 *   - `ci:test` Should perform any relevent steps to execute CI tests
 */
public static ciTest(Map config = [:]) { new YarnSpec()._ciTest(config) }
private _ciTest(Map config = [:]) {
  AwsUtils.withAwsProfiles {
    sh "yarn ci:test"
  }
}

/**
 * This tears down any resources that are only used for CI tests.
 *
 * To be compatible, your package.json should provide the following scripts:
 *   - `ci:teardown` Should perform any relevent steps to execute CI tests
 */
public static ciTeardown(Map config = [:]) { new YarnSpec()._ciTeardown(config) }
private _ciTeardown(Map config = [:]) {
  AwsUtils.withAwsProfiles {
    sh "yarn ci:teardown"
  }
}

/**
 * This publishes any publishable artifacts to the relevant artifact stores
 *
 * To be compatible, your package.json should provide the following scripts:
 *   - `push` Should package and publish any relevant artifacts
 *
 * The following tokens are exposed as environment variables to allow authing
 * to common artifact stores:
 *   - OCTO_API_KEY (API Key for pushing packages to Octopus Deploy)
 *
 * More tokens should be added as we start wanting to publish to more varied
 * artifact stores.
 */
public static publish(Map config = [:]) { new YarnSpec()._publish(config) }
private _publish(Map config = [:]) {
  withCredentials([string(credentialsId: 'octopus-deploy-apikey',
                          variable: 'OCTO_API_KEY')]) {
    sh "yarn push"
  }
}
