package crowdcompass.jenkins;

class ShipDockerService implements Serializable {
  String silo, application, tag, domain, awsRegion, shortenerDomain, overlayNetwork, dockerHostMgmt, dockerHostNode, clickDomain, legacyClickDomain, awsId, vpcId
  Boolean migrationsEnabled

  ShipDockerService(silo, application, tag) {
    this.silo = silo
    this.application = application
    this.tag = tag
  }

  //We can't look this up in the constructor, so we seperate this information out here.
  def lookupConsulData(script) {
    this.awsRegion = script.consul.getEnvironmentData("silo/${this.silo}/config/global/region")

    this.migrationsEnabled = script.consul.getEnvironmentData("infrastructure/${this.awsRegion}/${this.silo}/db_migrations").toBoolean()
    this.overlayNetwork = script.consul.getEnvironmentData("infrastructure/${this.awsRegion}/${this.silo}/overlay_network")
    this.vpcId = script.consul.getEnvironmentData("infrastructure/${this.awsRegion}/${this.silo}/vpc_id")
    this.awsId = script.consul.getEnvironmentData("infrastructure/${this.awsRegion}/${this.silo}/jenkins_aws_credentials")

    this.domain = script.consul.getEnvironmentData("silo/${this.silo}/config/domain")
    this.shortenerDomain = script.consul.getEnvironmentData("silo/${this.silo}/config/domain/shortener")

    this.clickDomain = script.consul.getEnvironmentData("silo/${this.silo}/config/domain/click")
    this.legacyClickDomain = script.consul.getEnvironmentData("silo/${this.silo}/config/domain/legacy_click")

    this.dockerHostMgmt = script.consul.getDockerHost("docker-mgmt", this.silo, this.awsRegion, this.vpcId, this.awsId)
    this.dockerHostNode = script.consul.getDockerHost("docker-node", this.silo, this.awsRegion, this.vpcId, this.awsId)
  }

  // Entry for building a docker service
  def build(script) {
    script.stage("build ${this.application} in ${this.silo}") {
      if (script.ccDocker.imageExists(this.application, this.tag)) {
        println "This image already exists, skipping build."
      } else {
        script.ccDocker.dockerBuild(this.application, this.tag)
      }
    }
  }

  // Entry for migrating a docker service's database
  def migrateDatabase(script) {
    String command = 'bundle exec rake db:migrate'

    if (this.migrationsEnabled) {
      script.stage("database migrations") {
        script.ccDocker.dockerRunScript(
          this.application, this.dockerHostNode,
          this.silo, command,
          this.tag, this.overlayNetwork
        )
      }
    } else {
      println "Migrations have been disabled for this build."
    }
  }

  // Entry for updating a docker service
  def update(script) {
    script.stage ("update ${this.application} in ${this.silo}") {
      script.ccDocker.updateService(
        this.application, this.tag, this.silo, this.domain,
        this.dockerHostMgmt, this.shortenerDomain,
        this.clickDomain, this.legacyClickDomain
      )
    }
  }
}
