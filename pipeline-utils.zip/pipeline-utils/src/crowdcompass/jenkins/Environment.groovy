package crowdcompass.jenkins;

class Environment implements Serializable {
  String name, awsRegion, awsAccountID, ccEnvironment, linkedSilos, ec2Enabled, overlayNetwork, slackChannel, shortenerDomain, clickDomain, legacyClickDomain, output, vpcId, awsId
  GString domain, dockerHostMgmt, dockerHostNode
  Boolean imageDeploy, imageCapture, reportingEnabled, migrationsEnabled

  Environment(name) {
    this.name = name
  }

  //We can't look this up in the constructor, so we seperate this information out here.
  def lookupConsulData(script){
    this.domain = script.consul.getEnvironmentData("silo/${name}/config/domain")
    this.shortenerDomain = script.consul.getEnvironmentData("silo/${name}/config/domain/shortener")
    this.clickDomain = script.consul.getEnvironmentData("silo/${name}/config/domain/click")
    this.legacyClickDomain = script.consul.getEnvironmentData("silo/${name}/config/domain/legacy_click")
    this.awsRegion = script.consul.getEnvironmentData("silo/${name}/config/global/region")
    this.slackChannel = script.consul.getEnvironmentData("silo/${name}/deploy/slack_channel")
    this.awsAccountID = script.consul.getEnvironmentData("infrastructure/${this.awsRegion}/${name}/account_id")
    this.migrationsEnabled = script.consul.getEnvironmentData("infrastructure/${this.awsRegion}/${name}/db_migrations").toBoolean()
    this.overlayNetwork = script.consul.getEnvironmentData("infrastructure/${this.awsRegion}/${name}/overlay_network")
    this.vpcId = script.consul.getEnvironmentData("infrastructure/${this.awsRegion}/${name}/vpc_id")
    this.awsId = script.consul.getEnvironmentData("infrastructure/${this.awsRegion}/${name}/jenkins_aws_credentials")
    this.dockerHostMgmt="${script.consul.getDockerHost("docker-mgmt",this.name,this.awsRegion,this.vpcId,this.awsId)}"
    this.dockerHostNode="${script.consul.getDockerHost("docker-node",this.name,this.awsRegion,this.vpcId,this.awsId)}"
    this.ccEnvironment = this.name
  }

  //Entry for deploying a docker service
  def shipDockerService(script,application,tag,db=false,composeTarget='rails',localizationSupport=false,gitBranch=""){
      error("The function shipDockerService is deprecated. Please update to use shipDockerServicev2 in your Jenkinsfile")
  }
  //Entry for deploying a docker service
  def shipDockerServicev2(script,application,tag,db=false,composeTarget='rails',localizationSupport=false,gitBranch=""){
    if (!script.ccDocker.imageExists(application,tag)) {
      println("Branch: ${gitBranch}")
      if (localizationSupport) {
        script.stage ("clone localization support") {
          script.dir('localizationSupport') {
            script.git url: "ssh://git@stash.crwd.cc:7999/stash/cc/localization_support.git", branch: "${gitBranch}"
          }
        }
      }
      if (script.fileExists('Gemfile')) {
        script.stage ("bundle ${application} in ${this.name}") {
          script.ccDocker.buildScriptv2(application,this.name,"bundle package --all")
        }
      }
      if (localizationSupport) {
        script.stage ("build localization support") {
          script.ccDocker.buildScriptv2(application,this.name,"/usr/local/bin/build_localization.sh",gitBranch,"localizationSupport/Dockerfile")
        }
      }
      script.ccDocker.dockerBuild(application,tag,composeTarget)
    }
    else {
      println "This image already exists, skipping build."
    }

    if (db && this.migrationsEnabled) {
      script.stage ("database migrations") {
        script.ccDocker.dockerRunScriptv2(application,this.dockerHostNode,this.ccEnvironment,'bundle exec rake db:migrate',tag)
      }
    }

    script.stage ("update ${application} in ${this.name}") {
      script.ccDocker.updateService(application,tag,this.ccEnvironment,this.domain,this.dockerHostMgmt,this.shortenerDomain,this.clickDomain,this.legacyClickDomain)
    }
  }
  //Entry for restarting a docker service
  def restartDockerService(script,application){
    script.stage ("restart ${application} in ${this.name}") {
      script.ccDocker.restartService(application,this.ccEnvironment,this.dockerHostMgmt)
    }
  }
  // Scale docker service
  def scaleDockerService(script,application){
    script.stage ("Scale ${application} in ${this.name}") {
      script.ccDocker.scaleContainer(application,tag,this.ccEnvironment,this.domain,this.dockerHostMgmt,this.shortenerDomain)
    }
  }
  // Function to remove the service
  def removeDockerService(script,application,tag){
    script.stage ("Deleting ${application} in ${this.name}") {
      script.ccDocker.deleteContainer(application,tag,this.ccEnvironment,this.domain,this.dockerHostMgmt,this.shortenerDomain)
    }
  }
  // Function for running scripts
  def runDockerScript(script,application,tag,runScript,envVars){
    script.stage ("Running ${runScript} for ${application} in ${this.name}") {
      this.output=script.ccDocker.dockerRunScriptv2(application,this.dockerHostNode,this.ccEnvironment,runScript,tag,this.overlayNetwork,'crowdcompass',envVars)
      return this.output
    }
  }

  //Entry for deploying an ember service
  def shipEmberCloudfront(script,application,gitBranch,tag,localizationSupport=false){
    error("The function shipEmberCloudfront is deprecated. Please update to use shipEmberCloudfrontv2 in your Jenkinsfile")
  }

  //Entry for deploying an ember service, with updated permission funcationality
  def shipEmberCloudfrontv2(script,application,gitBranch,tag,localizationSupport=false){
    if (localizationSupport) {
      script.stage ("build localization support") {
        script.dir('localizationSupport') {
          script.git url: "ssh://git@stash.crwd.cc:7999/stash/cc/localization_support.git", branch: "${gitBranch}"
        }
        script.ccDocker.buildScriptv2(application,this.name,"bundle package --all",gitBranch,"localizationSupport/Dockerfile")
        script.ccDocker.buildScriptv2(application,this.name,"/usr/local/bin/build_localization.sh",gitBranch,"localizationSupport/Dockerfile")
      }
    }
    if (script.fileExists('bower.json')) {
      script.stage ("bower install") {
        script.ccDocker.buildScriptv2(application,this.name,"/usr/local/bin/bower install")
      }
    }
    script.stage ("build yarn") {
      script.ccDocker.buildScriptv2(application,this.name,"/usr/local/bin/yarn")
    }
    script.stage ("deploy ${application} in ${this.name}") {
      script.ccDocker.buildScriptv2(application,this.name,"/usr/local/bin/ember deploy ${this.name} --activate --verbose",gitBranch)
    }
  }

  //retrieves any downstream silos that also need deployed to
  //If there is a value for a specific application it will override the environment value
  def getLinkedSilos(script,application) {
    def overrideLinkedSilos = script.consul.getEnvironmentData("silo/${name}/config/services/${application}/linked_silos")
    if (overrideLinkedSilos!=null) {
      this.linkedSilos = overrideLinkedSilos
    } else this.linkedSilos = script.consul.getEnvironmentData("silo/${name}/linked_silos")

    return this.linkedSilos
  }

  def notify(script,application,tag,branch,user="ccjenkinsman@cvent.com",changelog="",description="") {
    if (reportingEnabled) {
      script.ccNotify.notifyNewRelic(type,this.name,revision,changeLog,description,user)
      script.ccNotify.notifyDataDog(service,this.name,revision,description,user)
      script.ccNotify.notifyRollBar(service,this.name,revision,user)
    } else {
      script.println "This environment does not have reporting enabled so we won't notify the monitoring services"
    }
    script.slackSend channel: "#cc-deploys", color: "good", message: "Deployment of ${application} ${tag} in ${this.name} SUCCESSFULL"
  }
}
