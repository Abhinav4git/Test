@Library('pipeline_utils@master')
//replace with your release_branch if needed

import crowdcompass.jenkins.deploys

mrhelper = new crowdcompass.jenkins.deploys()

docker_registry="docker-registry.crwd.cc"

node('redhat') {
  if (environment == "production") { env_url = "crowdcompass.com" }
  else { env_url = "${environment}.crowdcompass.com" }
  def applications = ['api','attendeedirectory','click','emailforge','eventcenter','eventengagement','frs','hub','hubling','login','publican','publing','questions','transcriber','vip','workling']
    //OEG not included in this list
  for (int i = 0; i < applications.size(); i++) {
    type = applications[i]
    if  ( type == 'api' ) { service = 'api_proxy'; repo = "api_proxy" }
    else if  ( type == 'attendeedirectory' ) { service = 'attendee_directory'; repo = "attendee_directory" }
    else if  ( type == 'emailforge' ) { service = 'emailforge';repo = "email_compositor" }
    else if  ( type == 'eventcenter' ) { service = 'eventcenter'; repo = "event_center" }
    else if  ( type == 'eventengagement' ) { service = 'eventengagement'; repo = "engagement" }
    else if  ( type == 'frs' ) { service = 'frs'; repo = "file_reflector" }
    else if  ( type == 'vip' ) { service = 'vip'; repo = "vip_portal" }
    else { service = "${type}"; repo = "${type}" }

    git url: "ssh://git@stash.cvent.net:7999/cc/${repo}.git", branch: "${release_branch}"
    sh "git rev-parse --short HEAD > .git/commit-id"
    commit_id = readFile('.git/commit-id').trim()
    if (release_version.length() > 0) { tag = release_version }
    else { tag = commit_id }
    mrhelper.buildContainer("${service}","${tag}","${environment}","${release_version}","${docker_registry}","${env_url}")
  }
}
