@Library('pipeline_utils@master')
//replace with your branch if needed

import crowdcompass.jenkins.Environment

pipeline {
  agent none
  parameters {
    choice(description: 'What silo?', name: 'silo', choices:
      [
        'development',
        'qa',
        'staging',
        'hotfix',
        'production',
        'pr50',
        'pr53',
        'pr54',
        'pf51'
      ]
    )
    choice(description: 'What service?', name: 'application', choices:
      [
        'api_proxy',
        'attendee_attachments',
        'attendee_directory','click',
        'emailforge',
        'eventengagement',
        'eventcenter',
        'frs',
        'help',
        'hub',
        'login',
        'publican',
        'questions',
        'textmessenger',
        'transcriber',
        'vip_portal'
      ]
    )
    choice(description: 'What action?', name: 'action', choices: ['restart'])
  }
  options { timestamps() }

  stages {
    stage ('restart') {
      agent {
        label 'redhat'
      }
      steps {
        script {
          cc_env = new crowdcompass.jenkins.Environment(silo)
          cc_env.lookupConsulData(this)
          switch (action) {
             case 'restart': cc_env.restartDockerService(this,params.application); break;
             default: println "Select an action!";
          }
        }
      }
    }
  }
  post {
    success {
      slackSend color: "#2ECC71", message: "SUCCESS: Service ${application} restarted in ${silo}"
    }
    failure {
      slackSend color: "#E74C3C", message: "FAILED: Service ${application} did not restart in ${silo}"
    }
  }
}
