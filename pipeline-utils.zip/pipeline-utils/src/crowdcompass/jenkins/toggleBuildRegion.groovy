pipeline {
    agent {
      label 'master'
    }
    options {
      ansiColor('xterm')
    }
    stages {
      stage('toggling environment') {
        steps {
          script {
          for (slave in hudson.model.Hudson.instance.slaves) {
              println('====================');
              println('Name: ' + slave.name);
              println('getLabelString: ' + slave.getLabelString());
              if (slave.name =~ "^${region}") {
                if (effect == "disabled") { slave.getComputer().setTemporarilyOffline(true,null); }
                else { slave.getComputer().setTemporarilyOffline(false,null); }
                println('Slave ' + slave.name + " ${effect}.");
              }
            }
          }
        }
      }
    }
}
