@Library('pipeline_utils@master') _

def incrementVersion(last_tag, pattern) {
    last_tag = last_tag.minus(pattern)
    parts = last_tag.tokenize(".")
    parts[-1] = (parts[-1].toInteger() + 1).toString()
    return parts.join(".")
}

pipeline {
  agent { label 'redhat' }
  parameters {
    string(description: 'Which repo to target?', name: 'repo')
    string(description: 'What version to set? (omitted will auto-increment)', name: 'version')
    string(description: 'What SHA to target? (will default to HEAD)', name: 'sha')
  }
  options {
    ansiColor('xterm')
  }
  stages {
    stage ('versioning repo') {
      steps {
        script {
          helpers.checkoutStash(repo)
          dir (repo) {
            pattern = "v"
            last_tag = sh(script:"git describe --match ${pattern}*[!-]", returnStdout: true).trim()
            if (env.VERSION?.isEmpty() != false) {
              env.VERSION = incrementVersion(last_tag, pattern)
            }
            tag_name = "${pattern}${env.VERSION}"
            rollback_tag_name = "${tag_name}-rollback"

            sh "git tag -a -m 'Rollback for version ${env.VERSION}' ${rollback_tag_name} ${last_tag}"
            sh "git push origin tag ${rollback_tag_name}"
            sh "git tag -a -m 'Releasing version ${env.VERSION}' ${tag_name} ${env.SHA}"
            sh "git push origin tag ${tag_name}"
          }
        }
      }
      post {
        success {
          script {
            ccNotify.slackMessageSimple('N/A', 'good', "Updating ${repo} version to ${env.VERSION}", "#cc-release-team")
          }
        }
        failure {
          script {
            ccNotify.slackMessageSimple('N/A', 'bad', "Failed to update ${repo} version to ${env.VERSION}", "#cc-release-team")
          }
        }
      }
    }
  }
}
