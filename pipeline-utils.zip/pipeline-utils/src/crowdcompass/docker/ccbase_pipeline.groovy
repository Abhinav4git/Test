def branch = '${BRANCH}'
def commit_id
def docker_registry = 'docker-registry.crwd.cc'
def docker_repo = "crowdcompass/ccbase"

node ('redhat') {
  stage ('checkout') {
    git url: 'ssh://git@stash:7999/cc/infrastructure.git', branch:"${branch}"
    sh "git rev-parse --short HEAD > .git/commit-id"
    commit_id = readFile('.git/commit-id').trim()
    println commit_id
  }

  stage ('docker build') {
     sh "docker system prune --force"
     sh "docker build ccbase --no-cache --tag image_22 --pull -f ccbase/ruby22.df"
     sh "docker tag image_22:latest ${docker_registry}/${docker_repo}:ruby2.2-${commit_id}"

     sh "docker build ccbase --no-cache --tag image_24 --pull -f ccbase/ruby24.df"
     sh "docker tag image_24:latest ${docker_registry}/${docker_repo}:ruby2.4-${commit_id}"

     sh "docker build ccbase --no-cache --tag onbuild_image_22 --pull -f ccbase/onbuild_ruby22.df"
     sh "docker tag onbuild_image_22:latest ${docker_registry}/${docker_repo}:onbuild_ruby2.2-${commit_id}"

     sh "docker build ccbase --no-cache --tag onbuild_image_24 --pull -f ccbase/onbuild_ruby24.df"
     sh "docker tag onbuild_image_24:latest ${docker_registry}/${docker_repo}:onbuild_ruby2.4-${commit_id}"
  }

  stage ('docker push') {
      sh "docker push ${docker_registry}/${docker_repo}:ruby2.2-${commit_id}"
      sh "docker push ${docker_registry}/${docker_repo}:ruby2.4-${commit_id}"
      sh "docker push ${docker_registry}/${docker_repo}:onbuild_ruby2.2-${commit_id}"
      sh "docker push ${docker_registry}/${docker_repo}:onbuild_ruby2.4-${commit_id}"
      if (params.GOLD==true){
           sh "docker tag image_22:latest ${docker_registry}/${docker_repo}:ruby2.2-GOLD"
           sh "docker tag image_24:latest ${docker_registry}/${docker_repo}:ruby2.4-GOLD"
           sh "docker tag onbuild_image_22:latest ${docker_registry}/${docker_repo}:onbuild_ruby2.2-GOLD"
           sh "docker tag onbuild_image_24:latest ${docker_registry}/${docker_repo}:onbuild_ruby2.4-GOLD"
           sh "docker push ${docker_registry}/${docker_repo}:ruby2.2-GOLD"
           sh "docker push ${docker_registry}/${docker_repo}:ruby2.4-GOLD"
           sh "docker push ${docker_registry}/${docker_repo}:onbuild_ruby2.2-GOLD"
           sh "docker push ${docker_registry}/${docker_repo}:onbuild_ruby2.4-GOLD"
       }
  }
}
