package crowdcompass.docker

import groovy.json.JsonSlurperClassic

def lookup_fslayers(url){
  json = sh returnStdout:true, script: "curl -s ${url}"
  mapped_json = new JsonSlurperClassic().parseText(json)
  return mapped_json['fsLayers']
}

def url_health(url,code){
  resp = sh returnStdout:true, script: "curl -I -s -k -o /dev/null -w '%{http_code}' ${url} || exit 0"
  echo "Response: ${resp}"
  if (resp == "${code}"){
    return true
  }
  return false
}

def build_container(docker_registry,docker_repo,commit_id,overwrite,environment,tag,env_url){
  def docker_host = "docker.${env_url}:2376"
  if (!url_health("https://${docker_registry}/v2/${docker_repo}/manifests/${commit_id}",'200') || overwrite == "true"){
    echo "bundling package"
    sh "bundle package --all"
    echo "building"
    sh "DOMAIN=${env_url} ENVIRONMENT=${environment} TAG=${commit_id} docker-compose build --force-rm --pull rails"
    sh "DOMAIN=${env_url} ENVIRONMENT=${environment} docker tag ${docker_registry}/${docker_repo}:${commit_id} ${docker_registry}/${docker_repo}:latest"
    sh "DOMAIN=${env_url} ENVIRONMENT=${environment} docker push ${docker_registry}/${docker_repo}:latest"
    sh "DOMAIN=${env_url} ENVIRONMENT=${environment} docker push ${docker_registry}/${docker_repo}:${commit_id}"
  }
  else {
    println "This image already exists, skip the build."
  }
  if (release_version.length() > 0){
    sh "DOMAIN=${env_url} ENVIRONMENT=${environment} docker pull ${docker_registry}/${docker_repo}:${commit_id}"
    sh "DOMAIN=${env_url} ENVIRONMENT=${environment} docker tag ${docker_registry}/${docker_repo}:${commit_id} ${docker_registry}/${docker_repo}:${release_version}"
    sh "DOMAIN=${env_url} ENVIRONMENT=${environment} docker push ${docker_registry}/${docker_repo}:${release_version}"
  }
}

def test_container(docker_registry,docker_repo,tag,port){
  sh "docker run -i -d --name ${service}_${environment}_${tag} -p ${port}:9292 ${docker_registry}/${docker_repo}:${tag}"
  def count = 1
  def alive = "false"
  while(count<5) {
    if (!url_health("http://localhost:${port}/okcomputer",'200')) {
      count = count + 1
      sleep(5)
      if (count == 5) {
        break
      }
    }
    else {
      alive = "true"
      break
    }
  }
  println "*******************|DOCKER LOGS|***************************"
  sh "docker logs ${service}_${environment}_${tag}"
  println "*******************|DOCKER LOGS|***************************"
  sh "docker kill ${service}_${environment}_${tag}"
  if (alive) {
    return true
  }
  else {
    return false
  }
}

def update_service(docker_registry,docker_repo,tag,environment,service,external_port,internal_port,env_url){
  def docker_host = "docker.${env_url}:2376"

  println "Using tag ${tag}"
  if (db_migrate == "true"){
    if (environment == "production" || environment == "hotfix") {
      consul_cluster = 'us-west-2' }
    else {
      consul_cluster = 'us-west-2-dev'
    }
    docker_target = sh returnStdout:true, script: "dig ${environment}-docker-mgmt.service.${consul_cluster}.discovery.crwd.cc +short | head -1 | tr -d \"\n\""
    def secrets = [
        [$class: 'VaultSecret', path: "secret/${environment}", secretValues: [
            [$class: 'VaultSecretValue', envVar: 'amqp_credentials', vaultKey: 'amqp_credentials'],
        ]]
    ]
    def configuration = [$class: 'VaultConfiguration',
                         vaultUrl: 'http://vault.crwd.cc',
                         vaultCredentialId: 'vault_id']
    wrap([$class: 'VaultBuildWrapper', configuration: configuration, vaultSecrets: secrets]) {
      amqp = "amqp://${amqp_credentials}@${docker_target}:5672"
    }
    sh "DOCKER_HOST=${docker_target}:2376 docker run --rm --name ${service}_${environment}_migrations -e CC_ENVIRONMENT=${environment} -e AMQP_OVERRIDE=${amqp} ${docker_registry}/${docker_repo}:${tag} /usr/local/bin/run_migrations.sh"
  }
  sh "DOMAIN=${env_url} ENVIRONMENT=${environment} TAG=${tag} DOCKER_HOST=${docker_host} docker stack deploy --compose-file docker-compose.yml ${service}"
}

def validate_service(base_url,env_url,url_path,http_code){
  //validate service updated successfully
  def count = 1
  while(count<5) {
    if (!url_health("${base_url}.${env_url}/${url_path}","${http_code}")) {
      count = count + 1
      sleep(15)
    }
    else {
      return true
    }
  }
  if (!url_health("${base_url}.${env_url}/${url_path}","${http_code}")) {
    currentBuild.result = 'FAILURE'
    return false
  }
}
