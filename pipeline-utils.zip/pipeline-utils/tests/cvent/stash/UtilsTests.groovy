package cvent.stash

import groovy.mock.interceptor.StubFor
import groovyx.net.http.ContentType
@Grab(group = 'org.codehaus.groovy.modules.http-builder', module = 'http-builder', version = '0.7.1')
import groovyx.net.http.HTTPBuilder
@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.7.1' )
import groovyx.net.http.HTTPBuilder

class UtilsTests extends GroovyTestCase {

  void setUp() {
    Utils.metaClass.logInfo = {}
  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(Utils, null)
  }

  void setupBuildWithChanges(changedFile) {
    Utils.metaClass.currentBuild = [
      changeSets: [
        [
          [
            affectedFiles: [
              [
                path: "${changedFile}"
              ]
            ]
          ]
        ]
      ]
    ]
  }

  void setupEmptyBuild() {
    Utils.metaClass.currentBuild = []
  }

  void test_ignore_file_exact_match() {
    setupBuildWithChanges('package.json')
    def ignoreFiles = [
      'package.json'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert match
  }

  void test_ignore_file_wildcard_match_1() {
    setupBuildWithChanges('package.json')
    def ignoreFiles = [
      '*.json'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert match
  }

  void test_ignore_file_wildcard_match_2() {
    setupBuildWithChanges('a/b/c')
    def ignoreFiles = [
      'a/*/c'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert match
  }

  void test_ignore_file_wildcard_match_3() {
    setupBuildWithChanges('a/b/c/d')
    def ignoreFiles = [
      'a/**/d'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert match
  }

  void test_ignore_file_wildcard_match_4() {
    setupBuildWithChanges('package.json')
    def ignoreFiles = [
      'pack?ge.json'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert match
  }

  void test_ignore_file_wildcard_match_5() {
    setupBuildWithChanges('a/b')
    def ignoreFiles = [
      '*/b'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert match
  }

  void test_ignore_file_wildcard_match_6() {
    setupBuildWithChanges('a/b')
    def ignoreFiles = [
      'a/*'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert match
  }

  void test_ignore_file_wildcard_match_7() {
    setupBuildWithChanges('a/b/c')
    def ignoreFiles = [
      'a/**'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert match
  }

  void test_ignore_file_wildcard_match_8() {
    setupBuildWithChanges('a/b/c')
    def ignoreFiles = [
      '**/c'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert match
  }

  void test_ignore_file_wildcard_non_match_1() {
    setupBuildWithChanges('a/b')
    def ignoreFiles = [
      'a*b'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert !match
  }

  void test_ignore_file_wildcard_non_match_2() {
    setupBuildWithChanges('pacage.json')
    def ignoreFiles = [
      'pack?ge.json'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert !match
  }

  void test_ignore_file_empty_changeset() {
    setupEmptyBuild()
    def ignoreFiles = [
      'package.json'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert !match
  }

  void test_ignore_file_non_match() {
    setupBuildWithChanges('package.json')
    def ignoreFiles = [
      'test.txt'
    ]
    def match = Utils.changeSetContainsOnlyIgnoredFiles(ignoreFiles)
    assert !match
  }

  void test_that_getStashCloneUrl_called_with_project_and_repo_returns_a_url_starting_with_STASH_BASE_URL_SSH() {

    def url = Utils.getStashCloneUrl('PROJ','my-repo')

    assert url.startsWith(Utils.STASH_BASE_URL_SSH)

  }

  void test_that_getStashCloneUrl_called_with_project_slash_repo_returns_the_same_as_call_with_proj_and_repo() {

    def expectedUrl = Utils.getStashCloneUrl('PROJ', 'my-repo')
    def actualUrl = Utils.getStashCloneUrl('PROJ/my-repo')

    assert actualUrl == expectedUrl

  }

  void test_that_getStashCloneUrl_called_with_ssh_url_returns_the_url() {

    def expectedUrl = 'ssh://my-url'
    def actualUrl = Utils.getStashCloneUrl(expectedUrl)

    assert actualUrl == expectedUrl

  }

  void test_that_getStashCloneUrl_called_with_http_url_returns_the_url() {

    def expectedUrl = 'http://my-url'
    def actualUrl = Utils.getStashCloneUrl(expectedUrl)

    assert actualUrl == expectedUrl

  }

  void test_that_getStashCloneUrl_called_with_https_url_returns_the_url() {

    def expectedUrl = 'https://my-url'
    def actualUrl = Utils.getStashCloneUrl(expectedUrl)

    assert actualUrl == expectedUrl

  }

  void test_that_getProjectSlashRepo_called_with_http_url_returns_the_correct_value() {

    def expected =  'my-proj/my-repo'
    def actual = Utils.getProjectSlashRepo('http://me@stash/scm/my-proj/my-repo.git')

    assert actual == expected

  }

  void test_that_getProjectSlashRepo_called_with_https_url_returns_the_correct_value() {

    def expected =  'my-proj/my-repo'
    def actual = Utils.getProjectSlashRepo('https://me@stash/scm/my-proj/my-repo.git')

    assert actual == expected

  }

  void test_that_getProjectSlashRepo_called_with_ssh_url_returns_the_correct_value() {

    def expected =  'my-proj/my-repo'
    def actual = Utils.getProjectSlashRepo('ssh://git@stash:7999/my-proj/my-repo.git')

    assert actual == expected

  }

  void test_that_getProjectSlashRepo_called_with_invalid_url_returns_null() {

    def expected =  null
    def actual = Utils.getProjectSlashRepo('ftp://me@stash/scm/my-proj/my-repo.git')

    assert actual == expected

  }

  void test_that_getRawFile_correctly_invokes_the_httpClient_when_already_in_a_node_context() {
    def nodeInovked = test_that_getRawFile_correctly_invokes_the_httpClient_in_given_env([ NODE_NAME: 'master' ])
    assert nodeInovked == false
  }

  void test_that_getRawFile_correctly_invokes_the_httpClient_in_a_node_context_if_not_already_in_one() {
    def nodeInovked = test_that_getRawFile_correctly_invokes_the_httpClient_in_given_env([:])
    assert nodeInovked == true
  }

  private def test_that_getRawFile_correctly_invokes_the_httpClient_in_given_env(Map givenEnv) {

    def actualBaseUrl
    def ignoreSSLIssuesWasCalled = false
    def actualHeaders
    def actualGetArgs
    def nodeInvoked = false

    def stub = new StubFor(HTTPBuilder.class)
    stub.demand.ignoreSSLIssues { -> ignoreSSLIssuesWasCalled = true }
    stub.demand.setHeaders { headers -> actualHeaders = headers }
    stub.demand.get { args ->
      actualGetArgs = args
      return [text: 'some content']
    }

    Utils.metaClass.getHttpBuilder = { String baseUrl ->
      actualBaseUrl = baseUrl
      return stub.proxyInstance()
    }

    def envMap = givenEnv
    Utils.metaClass.env = envMap

    Utils.metaClass.withCredentials = { ArrayList args, fn ->

      assert args[0].$class == 'UsernamePasswordMultiBinding'
      assert args[0].credentialsId: Utils.BASIC_AUTH_CREDENTIALS_ID

      envMap[args[0].usernameVariable] = 'stash-user'
      envMap[args[0].passwordVariable] = 'stash-pwd'

      fn.call()

    }

    Utils.metaClass.node = { closure ->
      nodeInvoked = true
      closure()
    }

    def fileContent = Utils.getRawFile('my-proj/my-repo', 'my-branch', 'path/to/file')

    assert actualBaseUrl == Utils.STASH_BASE_URL_HTTPS
    assert ignoreSSLIssuesWasCalled == true
    assert actualHeaders == [ Authorization: 'Basic c3Rhc2gtdXNlcjpzdGFzaC1wd2Q=' ]
    assert actualGetArgs == [
            path: '/projects/my-proj/repos/my-repo/browse/path/to/file',
            query: [at: 'my-branch', raw: null],
            contentType: ContentType.TEXT
    ]

    assert fileContent == 'some content'

    return nodeInvoked
  }

}
