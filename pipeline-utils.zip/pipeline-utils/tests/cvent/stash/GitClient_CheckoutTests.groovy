package cvent.stash

import groovy.util.GroovyTestCase
import org.junit.Test
import cvent.jenkins.SlaveUtils
import cvent.jenkins.OSType

class GitClient_CheckoutTests extends GroovyTestCase {

  def checkoutArgs = [:]
  def retryCount
  def expectedCheckoutArgs
  OSType slaveOs
  def refRepoPath = null

  void setUp() {

    SlaveUtils.metaClass.static.getOsType = { -> return slaveOs }
    SlaveUtils.metaClass.static.getSlaveName = { -> return 'test-slave' }
    ReferenceRepoUtils.metaClass.static.getRepoPath = { String url, String slave -> return refRepoPath }
    GitClient.metaClass.checkout = { Map args -> checkoutArgs = args }
    GitClient.metaClass.retry = { retryCountArg, fn ->
      retryCount = retryCountArg
      fn()
    }
    GitClient.metaClass.getRefRepo = { String url, String os ->
      if( url == 'ssh://git@stash:7999/ref-test/windows.git' && os == "${OSType.WINDOWS}" ) return 'e:\\jenkins\\ref-repo'
      if( url == 'ssh://git@stash:7999/ref-test/linux.git' && os == "${OSType.LINUX}") return '/jenkins/ref-repo'
      return null
    }

    slaveOs = OSType.LINUX

    expectedCheckoutArgs = [
      changelog: false,
      poll: false,
      scm: [
        $class: 'GitSCM',
        branches: [[name: 'master']],
        doGenerateSubmoduleConfigurations: false,
        extensions: [
          [
            $class: 'CloneOption',
            depth: 0,
            noTags: true,
            shallow: true,
            timeout: 20
          ],
          [$class:'CleanCheckout']
        ],
        gitTool: GitClient.LINUX_GIT_TOOL,
        submoduleCfg: [],
        userRemoteConfigs: [[
          credentialsId: Utils.SSH_CREDENTIALS_ID,
          url: 'ssh://stash/my-proj/my-repo.git'
        ]]
      ]
    ]
  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(GitClient, null)
    GroovySystem.metaClassRegistry.setMetaClass(SlaveUtils, null)
    GroovySystem.metaClassRegistry.setMetaClass(ReferenceRepoUtils, null)
  }

  void test_that_checkoutRepo_called_with_a_repo_performs_expected_clone() {

    GitClient.checkoutRepo('ssh://stash/my-proj/my-repo.git')

    assert retryCount == 2
    assert checkoutArgs == expectedCheckoutArgs

  }

  void test_that_checkoutRepo_called_with_option_performs_expected_clone() {

    GitClient.checkoutRepo('PROJ/my-repo',
      poll: true,
      branch: 'my-branch',
      checkoutLocalBranch: true,
      subDir: 'my-subdir',
      shallowClone: false,
      timeout: 30,
      retry: 1,
      modCheckout: { checkout -> checkout.randomValue = 1234 }
    )

    expectedCheckoutArgs.poll = true
    expectedCheckoutArgs.scm.branches[0].name = 'my-branch'
    expectedCheckoutArgs.scm.extensions[0].shallow = false
    expectedCheckoutArgs.scm.extensions[0].timeout = 30
    expectedCheckoutArgs.scm.extensions << [
      $class: 'RelativeTargetDirectory',
      relativeTargetDir: 'my-subdir'
    ]
    expectedCheckoutArgs.scm.extensions << [
      $class: 'LocalBranch',
      localBranch: 'my-branch'
    ]
    expectedCheckoutArgs.randomValue = 1234

    //We'll test this below in a fuzzy manner so we don't need to know the exact url.
    expectedCheckoutArgs.scm.userRemoteConfigs[0].url = checkoutArgs.scm.userRemoteConfigs[0].url

    assert retryCount == 1
    assert checkoutArgs == expectedCheckoutArgs
    assert checkoutArgs.scm.userRemoteConfigs[0].url.endsWith('PROJ/my-repo.git')

  }

  void test_that_checkoutRepo_called_on_a_windows_node_uses_the_windows_git_tool() {

    slaveOs = OSType.WINDOWS
    GitClient.checkoutRepo('my-proj/my-repo')

    assert checkoutArgs.scm.gitTool == GitClient.WINDOWS_GIT_TOOL

  }

  void test_that_checkoutRepo_called_on_a_windows_node_for_repo_with_ref_repo_uses_ref_repo() {

    slaveOs = OSType.WINDOWS
    refRepoPath = 'e:\\jenkins\\ref-repo'
    GitClient.checkoutRepo('ref-test/windows')

    assert checkoutArgs.scm.extensions[0].reference  == refRepoPath

  }

  void test_that_checkoutRepo_called_on_a_linux_node_for_repo_with_ref_repo_uses_ref_repo() {

    refRepoPath = '~/jenkins/ref-repo'
    GitClient.checkoutRepo('ref-test/linux')

    assert checkoutArgs.scm.extensions[0].reference  == refRepoPath
  }

  void test_that_checkoutRepo_called_on_a_windows_node_for_repo_with_linux_ref_repo_only_does_not_set_ref_repo() {

    slaveOs = OSType.WINDOWS
    GitClient.checkoutRepo('ref-test/linux')

    assert checkoutArgs.scm.extensions[0].reference  == null

  }

  void test_that_checkoutRepo_called_on_a_linux_node_for_repo_with_windows_ref_repo_only_does_not_set_ref_repo() {

    GitClient.checkoutRepo('ref-test/windows')

    assert checkoutArgs.scm.extensions[0].reference  == null
  }

  void test_that_checkoutC4_called_without_options_performs_expected_clone() {

    GitClient.checkoutC4()

    expectedCheckoutArgs.scm.branches[0].name = 'prod'
    expectedCheckoutArgs.scm.extensions[0].timeout = 60
    expectedCheckoutArgs.scm.extensions << [
      $class: 'ChangelogToBranch',
      options: [compareRemote: 'origin', compareTarget: 'prod']
    ]

    //We'll test this below in a fuzzy manner so we don't need to know the exact url.
    expectedCheckoutArgs.scm.userRemoteConfigs[0].url = checkoutArgs.scm.userRemoteConfigs[0].url

    assert retryCount == 3
    assert checkoutArgs == expectedCheckoutArgs
    assert checkoutArgs.scm.userRemoteConfigs[0].url.endsWith('cvt/c4.git')

  }

  void test_that_checkoutC4_called_with_options_performs_expected_clone() {

    GitClient.checkoutC4(branch: 'ccid-123', shallowClone: false)

    expectedCheckoutArgs.scm.branches[0].name = 'ccid-123'
    expectedCheckoutArgs.scm.extensions[0].timeout = 60
    expectedCheckoutArgs.scm.extensions[0].shallow = false
    expectedCheckoutArgs.scm.extensions << [
      $class: 'ChangelogToBranch',
      options: [compareRemote: 'origin', compareTarget: 'ccid-123']
    ]

    //We'll test this below in a fuzzy manner so we don't need to know the exact url.
    expectedCheckoutArgs.scm.userRemoteConfigs[0].url = checkoutArgs.scm.userRemoteConfigs[0].url

    assert retryCount == 3
    assert checkoutArgs == expectedCheckoutArgs
    assert checkoutArgs.scm.userRemoteConfigs[0].url.endsWith('cvt/c4.git')

  }

  void test_that_checkoutToSubdir_called_without_options_performs_expected_clone() {

    GitClient.checkoutToSubdir('ssh://stash/my-proj/my-repo.git')

    expectedCheckoutArgs.scm.extensions << [
      $class: 'RelativeTargetDirectory',
      relativeTargetDir: 'my-repo'
    ]

    assert checkoutArgs == expectedCheckoutArgs

  }

  void test_that_checkoutToSubdir_called_with_options_performs_expected_clone() {

    GitClient.checkoutToSubdir('ssh://stash/my-proj/my-repo.git', subDir: 'anotherDir', branch: 'temp')

    expectedCheckoutArgs.scm.extensions << [
      $class: 'RelativeTargetDirectory',
      relativeTargetDir: 'anotherDir'
    ]

    expectedCheckoutArgs.scm.branches[0].name = 'temp'

    assert checkoutArgs == expectedCheckoutArgs

  }
}
