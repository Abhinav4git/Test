package cvent.stash

import groovy.util.GroovyTestCase
import cvent.jenkins.SlaveUtils

class ReferenceRepoUtilsTests extends GroovyTestCase {

  def nodeNames = []
  def batScripts = []
  def shellScripts = []
  def parallelJobs = []

  def testSlaves = [
    [name: 'linux-slave', isUnix: true, repos: ['PROJ/my-repo', 'P2/repo'] ],
    [name: 'win-slave', isUnix: false, repos: ['PROJ/my-repo'] ]
  ]

  def expectedShellScripts = [
    'mkdir -p ~/ref-repos',
    '[ -e ~/ref-repos/my-repo.git ] && git -C ~/ref-repos/my-repo.git remote update || git git -C ~/ref-repos clone --mirror ssh://git@stash:7999/PROJ/my-repo.git',
    '[ -e ~/ref-repos/repo.git ] && git -C ~/ref-repos/repo.git remote update || git git -C ~/ref-repos clone --mirror ssh://git@stash:7999/P2/repo.git'
  ]

  def expectedBatScripts = [
    'IF not exist "E:\\jenkins\\ref-repos" mkdir "E:\\jenkins\\ref-repos"',
    'IF not exist "E:\\jenkins\\ref-repos\\my-repo.git" (git -C E:\\jenkins\\ref-repos clone --mirror ssh://git@stash:7999/PROJ/my-repo.git) ELSE git -C E:\\jenkins\\ref-repos\\my-repo.git remote update'
  ]

  void setUp() {

    ReferenceRepoUtils.metaClass.static.node = { String label, Closure action ->
      nodeNames << label
      action()
    }

    ReferenceRepoUtils.metaClass.static.sh = { String script ->
      shellScripts << script
    }

    ReferenceRepoUtils.metaClass.static.bat = { String script ->
      batScripts << script
    }

    ReferenceRepoUtils.metaClass.static.parallel = { Map jobs ->
      parallelJobs << jobs
      jobs.each { k, v -> v() }
    }

    //just to suppress output during testing.
    ReferenceRepoUtils.metaClass.static.println = { String text -> }

    SlaveUtils.metaClass.static.getSlaveMetadata = { Closure filter ->
      [
        [name: 'xx00-jenlin-001', isUnix: true, isOnline: true ],
        [name: 'xx00-jenddb-001', isUnix: false, isOnline: true ],
        [name: 'xx00-jenwin-001', isUnix: false, isOnline: true ],
        [name: 'xx00-jenwin-002', isUnix: false, isOnline: false ]
      ].findAll(filter)
    }

  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(ReferenceRepoUtils, null)
    GroovySystem.metaClassRegistry.setMetaClass(SlaveUtils, null)
  }

  void test_that_calling_updateRepos_with_no_slaves_does_not_call_parallel() {

    def errorList = ReferenceRepoUtils.updateRepos([])

    assert parallelJobs.size == 0
    assert errorList == []
  }

  void test_that_calling_updateRepos_with_slaves_invokes_the_expected_nodes() {

    def errorList = ReferenceRepoUtils.updateRepos(testSlaves)

    assert nodeNames == testSlaves.collect { s -> s.name }
    assert errorList == []
  }


  void test_that_calling_updateRepos_with_windows_slaves_invokes_the_expected_sh_commands() {

    def errorList = ReferenceRepoUtils.updateRepos(testSlaves.findAll { s -> s.isUnix } )

    assert batScripts.size() == 0
    assert shellScripts == expectedShellScripts
    assert errorList == []
  }

  void test_that_calling_updateRepos_with_windows_slaves_invokes_the_expected_bat_commands() {

    def errorList = ReferenceRepoUtils.updateRepos(testSlaves.findAll { s -> !s.isUnix } )

    assert shellScripts.size() == 0
    assert batScripts == expectedBatScripts
    assert errorList == []
  }

  void test_that_calling_updateRepos_with_linux_and_windows_slaves_invokes_the_expected_sh_and_bat_commands() {

    def errorList = ReferenceRepoUtils.updateRepos(testSlaves)

    assert shellScripts == expectedShellScripts
    assert batScripts == expectedBatScripts
    assert errorList == []
  }

  void test_that_updateRepos_correctly_reports_failures() {

    ReferenceRepoUtils.metaClass.static.sh = { String script ->
      if(script.contains('P2'))throw new Exception('Cannot clone P2.')
    }
    ReferenceRepoUtils.metaClass.static.bat = { String script ->
      if(script.contains('mkdir'))throw new Exception('Cannot create directories.')
    }

    def errorList = ReferenceRepoUtils.updateRepos(testSlaves)

    assert errorList == [
      'Failed to refresh repo P2/repo on slave linux-slave: java.lang.Exception: Cannot clone P2.',
      'Failed to refresh repos on slave win-slave: java.lang.Exception: Cannot create directories.'
    ]
  }

  void test_that_calling_getRepoPath_with_the_c4_repo_and_a_winodows_slave_returns_the_expected_path() {

    def path = ReferenceRepoUtils.getRepoPath('ssh://git@stash:7999/cvt/c4.git', 'DC-JENWIN-001')

    assert path == 'E:\\jenkins\\ref-repos\\c4.git'
  }

  void test_that_calling_getRepoPath_with_the_c4_repo_and_a_db_slave_returns_the_expected_path() {

    def path = ReferenceRepoUtils.getRepoPath('ssh://git@stash:7999/cvt/c4.git', 'dv30-jenddb-008')

    assert path == 'E:\\jenkins\\ref-repos\\c4.git'
  }

  void test_that_calling_getRepoPath_with_the_c4_repo_and_a_linux_slave_returns_null() {

    def path = ReferenceRepoUtils.getRepoPath('ssh://git@stash:7999/cvt/c4.git', 'sv01-jenlin-000')

    assert path == null
  }

  void test_that_calling_getRepoPath_with_repo_other_than_c4_and_a_windows_slave_returns_null() {

    def path = ReferenceRepoUtils.getRepoPath('ssh://git@stash:7999/cvt/v9.git', 'dv30-jenddb-008')

    assert path == null
  }

  void test_that_getSlavesWithRefRepos_without_filter_return_expected_slaves_() {

    def slaves = ReferenceRepoUtils.getSlavesWithRefRepos()

    assert slaves.collect {s -> s.name} == ['xx00-jenddb-001', 'xx00-jenwin-001']
  }

  void test_that_getSlavesWithRefRepos_with_a_filter_return_expected_slaves_() {

    def slaves = ReferenceRepoUtils.getSlavesWithRefRepos { s -> s.name == 'xx00-jenddb-001'}

    assert slaves.collect {s -> s.name} == ['xx00-jenddb-001']
  }
}