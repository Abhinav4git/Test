package cvent.serviceDiscovery

import groovy.mock.interceptor.StubFor

import groovy.util.GroovyTestCase
@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.7.1' )
import groovyx.net.http.HTTPBuilder
import groovyx.net.http.ContentType
import org.junit.Test

class ConsulClientTests extends GroovyTestCase {

  def expectedBaseUrl = "http://ts99-consul-101.core.cvent.org:${ConsulClient.CONSUL_PORT}"
  def actualBaseUrl
  def catalogStub

  void setUp() {

    ConsulClient.ENV_CONFIG.ALPHA = [regionPrefix: 'ts99', serviceUrlSuffix: 'test']

    catalogStub = new StubFor(HTTPBuilder.class)


    ConsulClient.metaClass.getHttpBuilder = { String baseUrl ->
      actualBaseUrl = baseUrl
      return catalogStub.proxyInstance()
    }
  }

  void test_that_getServices_invokes_correct_endpoint_returns_correct_value(){

    def expectedServiceList = ['my-service': ['tag1', 'tag2']]

    def actualHttpGetArgs

    catalogStub.demand.get { args ->
        actualHttpGetArgs = args
        return expectedServiceList
      }

    def actualServiceList = new ConsulClient(ConsulEnv.ALPHA).getServices()

    assert actualBaseUrl == expectedBaseUrl
    assert actualHttpGetArgs == [path: '/v1/catalog/services', contentType : ContentType.JSON]
    assert actualServiceList == expectedServiceList
  }

  void test_that_getService_invokes_correct_endpoint_returns_correct_value(){

    def expectedServiceInstanceList = [
      ['ServiceId': 'service-1', 'Address': '10.0.0.1']
    ]

    def actualHttpGetArgs

    catalogStub.demand.get { args ->
        actualHttpGetArgs = args
        return expectedServiceInstanceList
      }

    def actualServiceInstanceList = new ConsulClient(ConsulEnv.ALPHA).getService('my-service')

    assert actualBaseUrl == expectedBaseUrl
    assert actualHttpGetArgs == [path: '/v1/catalog/service/my-service', contentType : ContentType.JSON]
    assert actualServiceInstanceList == expectedServiceInstanceList
  }

  void test_that_getService_throws_by_default_if_no_services_found(){

    catalogStub.demand.get { args ->
        return []
      }

    def errorMessage = shouldFail(IllegalArgumentException) {
      new ConsulClient(ConsulEnv.ALPHA).getService('non-existant-service')
    }

    assert errorMessage ==~/.*non-existant-service.*/
  }

  void test_that_getService_return_empty_array_when_throwIfNotFound_is_false(){

    def actualHttpGetArgs

    catalogStub.demand.get { args ->
        actualHttpGetArgs = args
        return []
      }

    def actualServiceInstanceList = new ConsulClient(ConsulEnv.ALPHA).getService('my-service', false)

    assert actualBaseUrl == expectedBaseUrl
    assert actualHttpGetArgs == [path: '/v1/catalog/service/my-service', contentType : ContentType.JSON]
    assert actualServiceInstanceList == []
  }

  void test_that_deregisterService_invokes_correct_deregistration_endpoints(){

    def agentStub = new StubFor(HTTPBuilder.class)
    def agentBaseUrls = []

    ConsulClient.metaClass.getHttpBuilder = { String baseUrl ->
      if (baseUrl ==~ /.*\d+\.\d+\.\d+\.\d+.*/) {
        agentBaseUrls.push baseUrl
        return agentStub.proxyInstance()
      } else {
        actualBaseUrl = baseUrl
        return catalogStub.proxyInstance()
      }
    }

    def expectedServiceInstanceList = [
      ['ServiceID': 'service-1-1', 'Address': '10.0.0.1'],
      ['ServiceID': 'service-1-2', 'Address': '10.0.0.2']
    ]

    def actualHttpDeregisterArgs = []

    catalogStub.demand.get { args ->
        return expectedServiceInstanceList
      }
    agentStub.demand.get { args ->
        actualHttpDeregisterArgs.push args
        return
      }

    def actualServiceInstanceList = new ConsulClient(ConsulEnv.ALPHA).deregisterService('my-service')

    assert agentBaseUrls.toSet() == ["http://10.0.0.1:${ConsulClient.CONSUL_PORT}","http://10.0.0.2:${ConsulClient.CONSUL_PORT}"] as Set
    assert actualHttpDeregisterArgs.toSet() == [[path: '/v1/agent/service/deregister/service-1-1'],[path: '/v1/agent/service/deregister/service-1-2']] as Set
  }

  void test_that_deregisterService_throws_by_default_if_no_services_found() {

    catalogStub.demand.get { args ->
        return []
      }

    def errorMessage = shouldFail(IllegalArgumentException) {
      new ConsulClient(ConsulEnv.ALPHA).deregisterService('non-existant-service')
    }

    assert errorMessage ==~/.*non-existant-service.*/
  }

  void test_that_deregisterService_return_empty_array_when_throwIfNotFound_is_false(){

    def actualHttpGetArgs

    catalogStub.demand.get { args ->
        actualHttpGetArgs = args
        return []
      }

    def actualServiceInstanceList = new ConsulClient(ConsulEnv.ALPHA).deregisterService('my-service', false)

    assert actualBaseUrl == expectedBaseUrl
    assert actualHttpGetArgs == [path: '/v1/catalog/service/my-service', contentType : ContentType.JSON]
    assert actualServiceInstanceList == []
  }

  void test_that_getServiceEndpoint_returns_expected_url_for_production(){

    def actualServiceUrl = new ConsulClient(ConsulEnv.PRODUCTION).getServiceEndpoint('my-service', 'PROD')

    assert actualServiceUrl == "http://discovery.core.cvent.org/my-service-PROD"
  }

  void test_that_getServiceEndpoint_returns_expected_url_for_non_production(){

    def actualServiceUrl = new ConsulClient(ConsulEnv.STAGING).getServiceEndpoint('my-service', 'sg20')

    assert actualServiceUrl == "http://discovery-staging.core.cvent.org/my-service-sg20"
  }

}
