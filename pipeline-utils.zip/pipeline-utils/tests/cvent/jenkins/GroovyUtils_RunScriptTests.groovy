package cvent.jenkins

import groovy.util.GroovyTestCase
import org.junit.Test
import cvent.jenkins.SlaveUtils
import cvent.jenkins.OSType


class GroovyUtilsRunScriptTestCase extends GroovyTestCase{

  def TEMP_PATH ='/tmp'
  def GROOVY_PATH ='/groovy'
  def SCRIPT_OUTPUT = 'This is the script output.'

  def writeFileArgs, toolArgs
  def shArgs = []
  def batArgs = []
  OSType slaveOs = OSType.LINUX

  void setUp() {

    SlaveUtils.metaClass.static.getOsType = { -> return slaveOs }

    GroovyUtils.metaClass.pwd = { args -> ( args.tmp  == true ) ? TEMP_PATH : '/workspace' }
    GroovyUtils.metaClass.writeFile = { args -> writeFileArgs = args; return null}
    GroovyUtils.metaClass.tool = { args -> toolArgs = args; return GROOVY_PATH}

    GroovyUtils.metaClass.sh = { args ->
      if(args instanceof String || args instanceof GString) {
        args = [script: args]
      }
      shArgs << args

      if(args.script ==~ /.*\/bin\/groovy .*/) {
        return SCRIPT_OUTPUT
      } else {
        return null
      }
    }

    GroovyUtils.metaClass.bat = { args ->
      if(args instanceof String || args instanceof GString) {
        args = [script: args]
      }
      batArgs << args

      if(args.script ==~ /.*\\bin\\groovy .*/) {
        return SCRIPT_OUTPUT
      } else {
        return null
      }
    }
  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(SlaveUtils, null)
    GroovySystem.metaClassRegistry.setMetaClass(GroovyUtils, null)
  }


  def make_common_assertions(scriptOutput) {

    //Correct content should be writen
    assert writeFileArgs.text == 'echo foo'

    if(slaveOs == OSType.LINUX) {

      //File should be writen to temp location as groovy file
      assert writeFileArgs.file ==~ /^${TEMP_PATH}\/.+\.groovy/

      //The temp file should be cleaned up
      assert shArgs[1] == [script: "rm -f ${writeFileArgs.file}"]

      //bat should not have been invoked
      assert batArgs == []

    } else {

      //File should be writen to temp location as groovy file
      assert writeFileArgs.file ==~ /^${TEMP_PATH}\\.+\.groovy/

      //The temp file should be cleaned up
      assert batArgs[1] == [script: "del /Q/F ${writeFileArgs.file}"]

      //sh should not have been invoked
      assert shArgs == []
    }

    //The result of the sh command that ran the script is always returned.
    assert scriptOutput == SCRIPT_OUTPUT

  }

  void test_that_on_linux_runScript_without_params_invokes_the_expected_script() {

    def result = GroovyUtils.runScript('echo foo')

    //Groovy should be run to invoke the file
    assert shArgs[0] == [
      script: "${GROOVY_PATH}/bin/groovy ${writeFileArgs.file}"
    ]

    make_common_assertions(result)

  }

  void test_that_on_linux_runScript_with_params_invokes_the_expected_script_and_appends_params() {

    def result = GroovyUtils.runScript('echo foo', params: ['one', 2])

    assert shArgs[0] == [
      script: "${GROOVY_PATH}/bin/groovy ${writeFileArgs.file} one 2"
    ]

    make_common_assertions(result)
  }

  void test_that_on_linux_runScript_returns_the_exit_code_when_requested() {

    def result = GroovyUtils.runScript('echo foo', returnStatus: true)

    assert shArgs[0] == [
      returnStatus: true,
      script: "${GROOVY_PATH}/bin/groovy ${writeFileArgs.file}"
    ]

    make_common_assertions(result)
  }

  void test_that_on_linux_runScript_returns_the_script_output_when_requested() {

    def result = GroovyUtils.runScript('echo foo', returnStdout: true)

    assert shArgs[0] == [
      returnStdout: true,
      script: "${GROOVY_PATH}/bin/groovy ${writeFileArgs.file}"
    ]

    make_common_assertions(result)
  }

  void test_that_on_windows_runScript_without_params_invokes_the_expected_script() {

    slaveOs = OSType.WINDOWS

    def result = GroovyUtils.runScript('echo foo')

    //Groovy should be run to invoke the file
    assert batArgs[0] == [
      script: "${GROOVY_PATH}\\bin\\groovy ${writeFileArgs.file}"
    ]

    make_common_assertions(result)

  }

  void test_that_on_windows_runScript_with_params_invokes_the_expected_script_and_appends_params() {

    slaveOs = OSType.WINDOWS

    def result = GroovyUtils.runScript('echo foo', params: ['one', 2])

    assert batArgs[0] == [
      script: "${GROOVY_PATH}\\bin\\groovy ${writeFileArgs.file} one 2"
    ]

    make_common_assertions(result)
  }

  void test_that_on_windows_runScript_returns_the_exit_code_when_requested() {

    slaveOs = OSType.WINDOWS

    def result = GroovyUtils.runScript('echo foo', returnStatus: true)

    assert batArgs[0] == [
      returnStatus: true,
      script: "${GROOVY_PATH}\\bin\\groovy ${writeFileArgs.file}"
    ]

    make_common_assertions(result)
  }

  void test_that_on_windows_runScript_returns_the_script_output_when_requested() {

    slaveOs = OSType.WINDOWS

    def result = GroovyUtils.runScript('echo foo', returnStdout: true)

    assert batArgs[0] == [
      returnStdout: true,
      script: "${GROOVY_PATH}\\bin\\groovy ${writeFileArgs.file}"
    ]

    make_common_assertions(result)
  }
}