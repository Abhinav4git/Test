package cvent.jenkins

import groovy.util.GroovyTestCase
import org.junit.Test
import helpers.Hudson

class BuildUtilsTestCase extends GroovyTestCase{

  def expectedLogOutput = 'This is the expected log output'
  def buildCauses

  def version = '1.0.0'
  def environment = ['VERSION': version]

  void setUp() {
    buildCauses = []
    BuildUtils.metaClass.currentBuild = [ getRawBuild: { -> [
      getCauses: { -> buildCauses },
      log: expectedLogOutput,
      getEnvironment: { -> environment }
    ]}]
  }

  def existingBuild = [ getRawBuild: { -> [
            getCauses: { -> buildCauses },
            log: expectedLogOutput,
            getEnvironment: { -> environment }
    ]}]

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(BuildUtils, null)
  }

  void test_that_getBuildInfo_for_a_upstream_cause_types_returns_the_cause_type_and_cause_info() {

    buildCauses << [
      class: 'class hudson.model.Cause$UpstreamCause',
          getUpstreamProject: { -> 'ParentProject'},
          getUpstreamUrl: { -> '/jobs/ParentProject'},
          getUpstreamBuild: { -> 123 }
    ]

    assert BuildUtils.getBuildInfo() == [
      causes: [[
        type: 'UpstreamCause',
        upstreamProject: 'ParentProject',
        upstreamUrl: '/jobs/ParentProject',
        upstreamBuildNum: 123
      ]],
      log: expectedLogOutput,
      env: environment
    ]

  }

  void test_that_calling_getBuildInfo_with_existing_build_for_a_upstream_cause_types_returns_the_cause_type_and_cause_info() {

    buildCauses << [
      class: 'class hudson.model.Cause$UpstreamCause',
          getUpstreamProject: { -> 'ParentProject'},
          getUpstreamUrl: { -> '/jobs/ParentProject'},
          getUpstreamBuild: { -> 123 }
    ]

    assert BuildUtils.getBuildInfo(existingBuild) == [
      causes: [[
        type: 'UpstreamCause',
        upstreamProject: 'ParentProject',
        upstreamUrl: '/jobs/ParentProject',
        upstreamBuildNum: 123
      ]],
      log: expectedLogOutput,
      env: environment
    ]

  }

  void test_that_callin_getBuildInfo_for_a_user_cause_types_returns_the_user_details_and_cause_type() {

    buildCauses << [
      class: 'class hudson.model.Cause$UserIdCause',
      getUserName: { -> 'MagnificentMe'},
      getUserId: { -> 'MMe'}
    ]

    assert BuildUtils.getBuildInfo() == [
      causes: [[type: 'UserIdCause', userName: 'MagnificentMe', userId: 'MMe']],
      log: expectedLogOutput,
      env: environment
    ]

  }

  void test_that_calling_getBuildInfo_with_existing_build_for_a_user_cause_types_returns_the_user_details_and_cause_type() {

    buildCauses << [
            class: 'class hudson.model.Cause$UserIdCause',
            getUserName: { -> 'MagnificentMe'},
            getUserId: { -> 'MMe'}
    ]

    assert BuildUtils.getBuildInfo(existingBuild) == [
      causes: [[type: 'UserIdCause', userName: 'MagnificentMe', userId: 'MMe']],
      log: expectedLogOutput,
      env: environment
    ]
  }

  void test_that_getBuildInfo_for_other_cause_types_returns_the_class_name() {

    buildCauses << [ class: 'class hudson.model.Cause$RandomCause']

    assert BuildUtils.getBuildInfo() == [
      causes: [[type: 'RandomCause']],
      log: expectedLogOutput,
      env: environment
    ]

  }

  void test_that_calling_getBuildInfo_with_existing_build_for_other_cause_types_returns_the_class_nameting() {

    buildCauses << [ class: 'class hudson.model.Cause$RandomCause']

    assert BuildUtils.getBuildInfo(existingBuild) == [
      causes: [[type: 'RandomCause']],
      log: expectedLogOutput,
      env: environment
    ]

  }

  void test_that_getBuildInfo_returns_environment() {
    assert BuildUtils.getBuildInfo()["env"] == environment
  }

  void test_that_calling_getBuildInfo_with_existing_build_returns_environment() {
    assert BuildUtils.getBuildInfo(existingBuild)["env"] == environment
  }
}
