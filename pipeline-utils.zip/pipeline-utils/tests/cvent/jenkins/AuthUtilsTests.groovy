package cvent.jenkins

import groovy.util.GroovyTestCase
import org.junit.Test
import hudson.model.User

class AuthUtilsTestCase extends GroovyTestCase{

  def buildCauses
  def builderAuthorities

  void setUp() {

    builderAuthorities = [:]
    buildCauses = []

    BuildUtils.metaClass.currentBuild = [ getRawBuild: { -> [
      getCauses: { -> buildCauses },
      log: '',
      getEnvironment: { -> [:] }
    ]}]

    User.metaClass.static.get = { id ->
      [ getAuthorities: { -> builderAuthorities[id] } ]
    }
  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(BuildUtils, null)
    GroovySystem.metaClassRegistry.setMetaClass(User, null)
  }

  void test_that_isJobRunnerInRole_returns_true_when_current_build_is_started_by_user_with_requested_role() {

    def buildUserId = 'the.builder'
    def neededRole = 'needed-role'

    builderAuthorities = [ (buildUserId): [ neededRole ] ]
    buildCauses << [
      class: 'class hudson.model.Cause$UserIdCause',
      getUserName: { -> 'Builder, The'},
      getUserId: { -> buildUserId}
    ]

    assert AuthUtils.isJobRunnerInRole(neededRole)

  }

  void test_that_isJobRunnerInRole_returns_false_when_current_build_is_started_by_user_without_requested_role() {

    def buildUserId = 'the.builder'
    def neededRole = 'needed-role'

    builderAuthorities = [ (buildUserId): [ 'some-other-role' ] ]
    buildCauses << [
      class: 'class hudson.model.Cause$UserIdCause',
      getUserName: { -> 'Builder, The'},
      getUserId: { -> buildUserId}
    ]

    assert !AuthUtils.isJobRunnerInRole(neededRole)

  }


  void test_that_isJobRunnerInRole_returns_false_when_current_build_is_not_user_started() {

    buildCauses << [ class: 'class hudson.model.Cause$RandomCause']

    assert !AuthUtils.isJobRunnerInRole('needed-role')

  }}
