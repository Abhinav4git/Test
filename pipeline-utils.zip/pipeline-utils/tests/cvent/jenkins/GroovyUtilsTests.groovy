package cvent.jenkins

import groovy.util.GroovyTestCase
import org.junit.Test
import cvent.jenkins.SlaveUtils
import cvent.jenkins.OSType


class GroovyUtilsTestCase extends GroovyTestCase{

  def TEMPLATE = 'This is a ${adj} test.'

  def expectedResult = 'This is a good test.'
  def actualResourcePath

  void setUp() {

    GroovyUtils.metaClass.libraryResource = {
      path -> actualResourcePath = path
      return TEMPLATE
    }
  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(GroovyUtils, null)
  }

  void test_that_loadTemplate_loads_and_binds_the_requested_template() {

    def expectedPath = 'test/my-template'

    def actualResult = GroovyUtils.loadTemplate(expectedPath, adj: 'good')

    assert actualResourcePath == expectedPath
    assert actualResult == expectedResult
  }

  void test_that_mergeMaps_merges_multiple_maps_in_correct_order() {
    def map1 = [
        k1: 'v1',
        k2: [
            k3: [
              [k4: 'v4', k5: 'v5']
            ]
        ]
    ]

    def map2 = [
        k1: 'v1_2',
        k2: [
            k3: [
                [k4: 'v4_2', k5: 'v5_2']
            ]
        ]
    ]

    def map3 = [
        k2: [
            k3: [
                [k4: 'v4_3', k5: 'v5_3'],
                [k6: 'v6', k7: 'v7']
            ]
        ]
    ]

    def expected = [
        k1: 'v1_2',
        k2: [
            k3: [
                [k4: 'v4_3', k5: 'v5_3'],
                [k6: 'v6', k7: 'v7']
            ]
        ]
    ]

    def actual = cvent.jenkins.GroovyUtils.mergeMaps(map1, map2, map3)

    assert actual == expected
  }
}