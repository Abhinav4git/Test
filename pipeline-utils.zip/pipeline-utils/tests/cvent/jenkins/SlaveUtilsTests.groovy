package cvent.jenkins

import groovy.util.GroovyTestCase
import org.junit.Test

class SlaveUtilsTestCase extends GroovyTestCase{

  def nodeEnv = [:]

  void setUp() {

    SlaveUtils.metaClass._getEnv = { -> return nodeEnv }
    Hudson.setInstance( [ slaves: [
      [
        getNodeName: { -> 'Node 1' },
        getNodeDescription: { -> 'This is online' },
        computer: [
          isOnline: { -> true },
          isUnix: { -> false },
          getOSDescription: { -> 'Windows' }
        ],
        getRemoteFS: { -> 'c:\\home-dir' },
        getAssignedLabels: { -> ['windows', 'doors'] }
      ],
      [
        getNodeName: { -> 'Node 2' },
        getNodeDescription: { -> 'This is offline' },
        computer: [
          isOnline: { -> false },
          isUnix: { -> true },
          getOSDescription: { -> 'Centos 7.0' }
        ],
        getRemoteFS: { -> '/home/dir' },
        getAssignedLabels: { -> ['linux', 'docker'] }
      ]

    ] ] )
  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(SlaveUtils, null)
  }

  void test_that_getSlaveMetadata_without_filter_returns_all_slaves() {

    assert SlaveUtils.getSlaveMetadata() == [
      [
        name: 'Node 1',
        description: 'This is online',
        os: 'Windows',
        isUnix: false,
        remoteHomeDir: 'c:\\home-dir',
        labels: ['windows', 'doors'],
        isOnline: true
      ],
      [
        name: 'Node 2',
        description: 'This is offline',
        os: null,
        isUnix: true,
        remoteHomeDir: '/home/dir',
        labels: ['linux', 'docker'],
        isOnline: false
      ]
    ]

  }

  void test_that_getSlaveMetadata_with_filter_returns_only_matching_slaves() {

    assert SlaveUtils.getSlaveMetadata( { s -> s.isOnline } ) == [
      [
        name: 'Node 1',
        description: 'This is online',
        os: 'Windows',
        isUnix: false,
        remoteHomeDir: 'c:\\home-dir',
        labels: ['windows', 'doors'],
        isOnline: true
      ],
    ]

  }

  void test_that_getOsType_returns_correct_type_for_windows() {

    nodeEnv.OS = 'Windows_NT'

    assert SlaveUtils.getOsType() == OSType.WINDOWS

  }

  void test_that_getOsType_returns_correct_type_for_non_windows() {

    nodeEnv.OS = 'Centos 6.5'

    assert SlaveUtils.getOsType() == OSType.LINUX

  }

  void test_that_getSlaveName_returns_the_env_node_name_value() {

    nodeEnv.NODE_NAME = 'my-slave'

    assert SlaveUtils.getSlaveName() == 'my-slave'

  }
}