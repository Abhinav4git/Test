package cvent.aws

import groovy.util.GroovyTestCase
import org.junit.Test

class AwsUtilTests extends GroovyTestCase {
  void test_account() {
    def (account) = AwsUtils.parseLocation('cvent-sandbox')
    assert account == 'cvent-sandbox'
  }

  void test_account_region() {
    def (account, environment, region) = AwsUtils.parseLocation('cvent-sandbox@us-east-1')
    assert account == 'cvent-sandbox'
    assert environment == null
    assert region == 'us-east-1'
  }

  void test_account_env_region() {
    def (account, environment, region) = AwsUtils.parseLocation('cvent-development_S431@us-east-1')
    assert account == 'cvent-development'
    assert environment == 'S431'
    assert region == 'us-east-1'
  }

  void test_account_region_az() {
    def (account, _environment, region, availability_zone) = AwsUtils.parseLocation('cvent-production@us-west-2a')
    assert account == 'cvent-production'
    assert region == 'us-west-2'
    assert availability_zone == 'us-west-2a'
  }
}
