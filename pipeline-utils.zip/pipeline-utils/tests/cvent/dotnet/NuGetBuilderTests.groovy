package cvent.dotnet

import groovy.util.GroovyTestCase
import org.junit.Test
import cvent.stash.GitClient
import cvent.jenkins.GroovyUtils
import cvent.windows.Powershell
import cvent.windows.Robocopy

class NuGetBuilderTests extends GroovyTestCase {
  def batArgs = []
  def checkoutArgs = []
  def findFilesArgs = []
  def fileExistsArgs = []
  def echoArgs = []
  def retryArgs = []

  void setUp() {
    GitClient.metaClass.static.checkoutToSubdir = { Map args, String repo, Closure action ->
      checkoutArgs << [repo: repo, args: args]
      action()
    }

    GitClient.metaClass.static.checkoutToSubdir = { Map args, String repo ->
      checkoutArgs << [repo: repo, args: args]
    }

    NuGetBuilder.metaClass.static.findFiles = { Map args ->
      findFilesArgs << args
    }

    NuGetBuilder.metaClass.static.fileExists = { String str ->
      fileExistsArgs << str
    }

    NuGetBuilder.metaClass.static.pwd = { args ->
      ( args?.tmp  == true ) ? TEMP_PATH : '/workspace'
    }

    NuGetBuildWrappers.metaClass.static.pwd = { args ->
      ( args?.tmp  == true ) ? TEMP_PATH : '/workspace'
    }

    NuGetBuilder.metaClass.static.echo = { String str ->
      echoArgs << str
    }

    NuGetBuilder.metaClass.static.retry = { int str, Closure action ->
      action()
    }

    NuGetBuildWrappers.metaClass.static.echo = { String str ->
      echoArgs << str
    }

    Powershell.metaClass.static.bat = { Map args ->
      batArgs << args
    }

    Powershell.metaClass.static.bat = { String script ->
      batArgs << [script: script]
    }

    Robocopy.metaClass.static.bat = { Map args ->
      batArgs << args
      0
    }

    Robocopy.metaClass.static.bat = { String script ->
      batArgs << [script: script]
      0
    }
  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(GitClient, null)
    GroovySystem.metaClassRegistry.setMetaClass(NuGetBuilder, null)
    GroovySystem.metaClassRegistry.setMetaClass(NuGetBuildWrappers, null)
    GroovySystem.metaClassRegistry.setMetaClass(Powershell, null)
    GroovySystem.metaClassRegistry.setMetaClass(Robocopy, null)
  }

  String powershell_command(String expectedCommand) {
    def encodedCommand = expectedCommand.getBytes("UTF-16LE").encodeBase64().toString()
    "@powershell.exe -EncodedCommand ${encodedCommand} -ExecutionPolicy ByPass -NoProfile"
  }

  void test_that_build_and_publish_correctly_builds_and_publishes_solution_with_defaults() {

    NuGetBuilder.buildAndPublish('my-proj/my-service',
                                 path: 'solution.sln',
                                 name: 'test_solution',
                                 build_number: '1')

    assert checkoutArgs[0].subMap(['repo']) == [repo: 'my-proj/my-service']

    [
      "if(Test-Path /workspace\\c4\\target) {rm -r /workspace\\c4\\target -ErrorAction SilentlyContinue > null}",
      "nuget-build/Update-Configs-With-Hogan.ps1",
      "nuget-build/Create-ReleaseNotes.ps1",
      "nuget-build/compileSolution.ps1 -appName test_solution -buildVersion 1 -rootDir /workspace -solutionPath solution.sln -enableOctoPack yes -pushToNuget yes -packageFolder octoPackages/test_solution -doSonarAnalysis no",
      "nuget-build/SolutionAuditAnalysis.ps1 -solutionPath solution.sln -version 1.1.1 -gradeSolution \$true -options -ft",
      "nuget-build/runTests.ps1 -buildOutputPath /workspace/target -testOutputPath /workspace/target/test_solution/test_output",
      "nuget-build/publishPackageFolder.ps1 -packageFolder octoPackages/test_solution -feedName applications",
      "nuget-build/publishPackageFolder.ps1 -packageFolder nugetPackages/test_solution -feedName default",
    ].eachWithIndex { psCommand, idx -> assert batArgs[idx].script == powershell_command(psCommand) }
  }

  void test_that_build_and_publish_correctly_builds_and_publishes_solution_without_solutionAudit_with_defaults() {

    NuGetBuilder.buildAndPublish('my-proj/my-service',
                                 path: 'solution.sln',
                                 name: 'test_solution',
                                 build_number: '1',
                                 disableAudit: true)

    assert checkoutArgs[0].subMap(['repo']) == [repo: 'my-proj/my-service']

    [
      "if(Test-Path /workspace\\c4\\target) {rm -r /workspace\\c4\\target -ErrorAction SilentlyContinue > null}",
      "nuget-build/Update-Configs-With-Hogan.ps1",
      "nuget-build/Create-ReleaseNotes.ps1",
      "nuget-build/compileSolution.ps1 -appName test_solution -buildVersion 1 -rootDir /workspace -solutionPath solution.sln -enableOctoPack yes -pushToNuget yes -packageFolder octoPackages/test_solution -doSonarAnalysis no",
      "nuget-build/runTests.ps1 -buildOutputPath /workspace/target -testOutputPath /workspace/target/test_solution/test_output",
      "nuget-build/publishPackageFolder.ps1 -packageFolder octoPackages/test_solution -feedName applications",
      "nuget-build/publishPackageFolder.ps1 -packageFolder nugetPackages/test_solution -feedName default",
    ].eachWithIndex { psCommand, idx -> assert batArgs[idx].script == powershell_command(psCommand) }
  }

  void test_that_build_and_publish_correctly_builds_and_publishes_solution_with_zipDirectory() {

    NuGetBuilder.buildAndPublish('my-proj/my-service',
                                 path: 'solution.sln',
                                 name: 'test_solution',
                                 build_number: '1',
                                 zipDirectories: [ [ path: 'test_dir' ] ])

    assert checkoutArgs[0].subMap(['repo']) == [repo: 'my-proj/my-service']

    [
      "if(Test-Path /workspace\\c4\\target) {rm -r /workspace\\c4\\target -ErrorAction SilentlyContinue > null}",
      "nuget-build/Update-Configs-With-Hogan.ps1",
      "nuget-build/Create-ReleaseNotes.ps1",
      "nuget-build/zipFolder.ps1 -zipFolder /workspace/test_dir -outputFile test_dir.octo.zip",
      "nuget-build/compileSolution.ps1 -appName test_solution -buildVersion 1 -rootDir /workspace -solutionPath solution.sln -enableOctoPack yes -pushToNuget yes -packageFolder octoPackages/test_solution -doSonarAnalysis no",
      "nuget-build/SolutionAuditAnalysis.ps1 -solutionPath solution.sln -version 1.1.1 -gradeSolution \$true -options -ft",
      "nuget-build/runTests.ps1 -buildOutputPath /workspace/target -testOutputPath /workspace/target/test_solution/test_output",
      "nuget-build/publishPackageFolder.ps1 -packageFolder octoPackages/test_solution -feedName applications",
      "nuget-build/publishPackageFolder.ps1 -packageFolder nugetPackages/test_solution -feedName default",
    ].eachWithIndex { psCommand, idx -> assert batArgs[idx].script == powershell_command(psCommand) }
  }

  void test_that_build_and_publish_correctly_builds_and_publishes_solution_with_precompile() {

    NuGetBuilder.buildAndPublish('my-proj/my-service',
                                 path: 'solution.sln',
                                 name: 'cvent',
                                 build_number: '1',
                                 precompPackages: [
                                    [
                                      path: 'Test.nuspec',
                                      type: PackageType.OCTO
                                    ]
                                 ],
                                 precomp: true)

    assert checkoutArgs[0].subMap(['repo']) == [repo: 'my-proj/my-service']

    [
      "if(Test-Path /workspace\\c4\\target) {rm -r /workspace\\c4\\target -ErrorAction SilentlyContinue > null}",
      "nuget-build/Update-Configs-With-Hogan.ps1",
      "nuget-build/Create-ReleaseNotes.ps1",
      "nuget-build/compileSolution.ps1 -appName cvent -buildVersion 1 -rootDir /workspace -solutionPath solution.sln -enableOctoPack yes -pushToNuget yes -packageFolder octoPackages/cvent -doSonarAnalysis no -precompile ",
    ].eachWithIndex { psCommand, idx -> assert batArgs[idx].script == powershell_command(psCommand) }

    assert batArgs[4].script == "robocopy target/Cvent.Web.Subscribers-precomp target/Cvent.Web.Subscribers/_PublishedWebsites/Cvent.Web.Subscribers /e"

    [
      "Remove-Item 'octoPackages/cvent/Cvent.Web.Subscribers.*'",
      "nuget-build/SolutionAuditAnalysis.ps1 -solutionPath solution.sln -version 1.1.1 -gradeSolution \$true -options -ft",
      "nuget-build/runTests.ps1 -buildOutputPath /workspace/target -testOutputPath /workspace/target/cvent/test_output",
      "nuget-build/postBuildCleanup.ps1",
      "New-Item -ItemType Directory -Force 'octoPackages-precomp/cvent'",
      "nuget-build/createPackage.ps1 -nuspecFile Test.nuspec -outputDirectory octoPackages-precomp/cvent",
      "nuget-build/publishPackageFolder.ps1 -packageFolder octoPackages/cvent -organization precomp -feedName applications",
      "nuget-build/publishPackageFolder.ps1 -packageFolder nugetPackages/cvent -organization precomp -feedName default",
      "nuget-build/publishPackageFolder.ps1 -packageFolder octoPackages-precomp/cvent -organization precomp -feedName applications",
    ].eachWithIndex { psCommand, idx -> assert batArgs[5 + idx].script == powershell_command(psCommand) }
  }

  void test_that_build_and_publish_correctly_builds_and_publishes_nuspec_with_defaults() {

    NuGetBuilder.buildAndPublish('my-proj/my-service',
                                 packages: [
                                    [
                                      path: 'Test.nuspec'
                                    ]
                                 ],
                                 name: 'test_solution',
                                 build_number: '1')

    assert checkoutArgs[0].subMap(['repo']) == [repo: 'my-proj/my-service']

    [
      "if(Test-Path /workspace\\c4\\target) {rm -r /workspace\\c4\\target -ErrorAction SilentlyContinue > null}",
      "nuget-build/Update-Configs-With-Hogan.ps1",
      "nuget-build/Create-ReleaseNotes.ps1",
      "New-Item -ItemType Directory -Force 'nugetPackages/test_solution'",
      "nuget-build/createPackage.ps1 -nuspecFile Test.nuspec -outputDirectory nugetPackages/test_solution",
      "nuget-build/publishPackageFolder.ps1 -packageFolder octoPackages/test_solution -feedName applications",
      "nuget-build/publishPackageFolder.ps1 -packageFolder nugetPackages/test_solution -feedName default"
    ].eachWithIndex { psCommand, idx -> assert batArgs[idx].script == powershell_command(psCommand) }
  }

  void test_that_build_and_publish_correctly_builds_and_publishes_nuspec_with_partial_SQL() {

    NuGetBuilder.buildAndPublish('my-proj/my-service',
                                 packages: [
                                    [
                                      path: 'Test.nuspec'
                                    ]
                                 ],
                                 name: 'test_solution',
                                 build_number: '1',
                                 enableCreatePartialSQL: true)

    assert checkoutArgs[0].subMap(['repo']) == [repo: 'my-proj/my-service']

    [
      "if(Test-Path /workspace\\c4\\target) {rm -r /workspace\\c4\\target -ErrorAction SilentlyContinue > null}",
      "nuget-build/Update-Configs-With-Hogan.ps1",
      "nuget-build/Create-ReleaseNotes.ps1",
      "nuget-build/copySQLFiles.ps1",
      "nuget-build/createLookupFile.ps1",
      "New-Item -ItemType Directory -Force 'nugetPackages/test_solution'",
      "nuget-build/createPackage.ps1 -nuspecFile Test.nuspec -outputDirectory nugetPackages/test_solution",
      "nuget-build/publishPackageFolder.ps1 -packageFolder octoPackages/test_solution -feedName applications",
      "nuget-build/publishPackageFolder.ps1 -packageFolder nugetPackages/test_solution -feedName default"
    ].eachWithIndex { psCommand, idx -> assert batArgs[idx].script == powershell_command(psCommand) }
  }

  void test_that_build_and_publish_correctly_builds_and_publishes_octo_nuspec() {

    NuGetBuilder.buildAndPublish('my-proj/my-service',
                                 packages: [
                                    [
                                      path: 'Test.nuspec',
                                      type: PackageType.OCTO
                                    ]
                                 ],
                                 name: 'test_solution',
                                 build_number: '1')

    assert checkoutArgs[0].subMap(['repo']) == [repo: 'my-proj/my-service']

    [
      "if(Test-Path /workspace\\c4\\target) {rm -r /workspace\\c4\\target -ErrorAction SilentlyContinue > null}",
      "nuget-build/Update-Configs-With-Hogan.ps1",
      "nuget-build/Create-ReleaseNotes.ps1",
      "New-Item -ItemType Directory -Force 'octoPackages/test_solution'",
      "nuget-build/createPackage.ps1 -nuspecFile Test.nuspec -outputDirectory octoPackages/test_solution",
      "nuget-build/publishPackageFolder.ps1 -packageFolder octoPackages/test_solution -feedName applications",
      "nuget-build/publishPackageFolder.ps1 -packageFolder nugetPackages/test_solution -feedName default"
    ].eachWithIndex { psCommand, idx -> assert batArgs[idx].script == powershell_command(psCommand) }
  }

  void test_that_build_and_publish_correctly_builds_and_publishes_solution_with_csproj() {

    NuGetBuilder.buildAndPublish('my-proj/my-service',
                                 path: 'solution.sln',
                                 packages: [
                                    [
                                      path: 'Test/Test.csproj', name: 'Test'
                                    ]
                                 ],
                                 name: 'test_solution',
                                 build_number: '1')

    assert checkoutArgs[0].subMap(['repo']) == [repo: 'my-proj/my-service']

    [
      "if(Test-Path /workspace\\c4\\target) {rm -r /workspace\\c4\\target -ErrorAction SilentlyContinue > null}",
      "nuget-build/Update-Configs-With-Hogan.ps1",
      "nuget-build/Create-ReleaseNotes.ps1",
      "nuget-build/compileSolution.ps1 -appName test_solution -buildVersion 1 -rootDir /workspace -solutionPath solution.sln -enableOctoPack yes -pushToNuget yes -packageFolder octoPackages/test_solution -doSonarAnalysis no",
      "nuget-build/SolutionAuditAnalysis.ps1 -solutionPath solution.sln -version 1.1.1 -gradeSolution \$true -options -ft",
      "nuget-build/runTests.ps1 -buildOutputPath /workspace/target -testOutputPath /workspace/target/test_solution/test_output",
      "New-Item -ItemType Directory -Force 'nugetPackages/test_solution'",
      "nuget-build/updateNuspecVersions.ps1 -buildVersion 1",
      "nuget pack Test/Test.csproj -IncludeReferencedProjects -OutputDirectory nugetPackages/test_solution -Properties \"Configuration=Release;OutDir=/workspace/target/Test\\\"",
      "nuget-build/publishPackageFolder.ps1 -packageFolder octoPackages/test_solution -feedName applications",
      "nuget-build/publishPackageFolder.ps1 -packageFolder nugetPackages/test_solution -feedName default"
    ].eachWithIndex { psCommand, idx -> assert batArgs[idx].script == powershell_command(psCommand) }
  }
}
