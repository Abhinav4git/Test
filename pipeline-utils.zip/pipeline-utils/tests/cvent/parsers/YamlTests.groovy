package cvent.parsers

import groovy.util.GroovyTestCase
import org.junit.Test

//These tests are realy just a smoke tests to ensure that the code-under-test compiles.
//We assume the snakesyaml parse does the right thing. :-)
class YamlTests extends GroovyTestCase {

  void test_that_parse_will_parse_valid_yaml() {

    def result = Yaml.parse("- 1\n- 2\n- 3")

    assert result == [1,2,3]
    assert result instanceof ArrayList

  }

  void test_that_emit_will_emit_valid_yaml() {

    assert Yaml.emit([1,2,3]) == "- 1\n- 2\n- 3\n"

  }

  //Okay not exactly a smoke test here...
  void test_that_emit_will_use_correct_indentation() {

    assert Yaml.emit([level1: [level2: 123]]) == "level1:\n  level2: 123\n"

  }
}
