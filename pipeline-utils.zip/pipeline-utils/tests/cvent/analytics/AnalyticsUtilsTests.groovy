package cvent.analytics

import groovy.util.GroovyTestCase
import org.junit.Test

class AnalyticsUtilsTests extends GroovyTestCase {

  def expectedStart = 1000
  def expectedEnd = 1500

  void setUp() {
    def firstCall = true
    System.metaClass.static.currentTimeMillis = { ->
      if(firstCall){
        firstCall = false;
        return expectedStart
      } else {
        return expectedEnd
      }
    }
  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(System, null)
  }

  void test_that_measureDuration_returns_correct_timings() {
    def results = Utils.measureDuration { -> sleep 10 }

    assert results == [
      startTs: expectedStart,
      endTs: expectedEnd,
      durationMillis: 500,
      success: true,
      result: null
    ]
  }

  void test_that_measureDuration_returns_correct_return_value() {
    def results = Utils.measureDuration { -> return 'results' }

    assert results == [
      startTs: expectedStart,
      endTs: expectedEnd,
      durationMillis: 500,
      success: true,
      result: 'results'
    ]
  }

  void test_that_measureDuration_returns_exception_on_exception() {
    def expectedException = new Exception('testing')
    def results = Utils.measureDuration { -> throw expectedException }

    assert results == [
      startTs: expectedStart,
      endTs: expectedEnd,
      durationMillis: 500,
      success: false,
      exception: expectedException
    ]
  }

  void test_that_startMeasureDuration_returns_a_running_timer() {

    def timer = Utils.startMeasureDuration()

    assert timer == [
      startTs: expectedStart,
      endTs: null,
      durationMillis: null,
      running: true,
      stop: timer.stop
    ]
  }

  void test_that_calling_stop_on_a_running_timer_stops_it_with_correct_timings() {

    def timer = Utils.startMeasureDuration()
    timer.stop()

    assert timer == [
      startTs: expectedStart,
      endTs: expectedEnd,
      durationMillis: 500,
      running: false,
      stop: timer.stop
    ]
  }

  void test_that_calling_stop_on_a_stopped_timer_throws_IllegalStateException() {

    def timer = Utils.startMeasureDuration()
    timer.stop()

    shouldFail(IllegalStateException) { timer.stop() }
  }
}