package cvent.analytics

import groovy.util.GroovyTestCase
import org.junit.Test

import groovy.mock.interceptor.StubFor
@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.7.1' )

import groovyx.net.http.HTTPBuilder;
import groovyx.net.http.ContentType;
import groovyx.net.http.Method;

class AnalyticsClientTests extends GroovyTestCase {

  def actualRequestDelegate = [ response: [:] ]
  def actualRequestMethod
  def actualBaseUrl
  def printedLines = []

  void setUp(){
    def stub = new StubFor(HTTPBuilder.class)
    stub.demand.request { Method method, Closure request ->
        actualRequestMethod = method
        request.delegate = actualRequestDelegate
        request.call()
      }

    AnalyticsClient.metaClass.static.getHttpBuilder = { String baseUrl ->
      actualBaseUrl = baseUrl
      return stub.proxyInstance()
    }

    AnalyticsClient.metaClass.static.println = { String line ->
      printedLines << line
    }

    System.metaClass.static.currentTimeMillis = { ->
      return 9999
    }
  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(AnalyticsClient, null)
    GroovySystem.metaClassRegistry.setMetaClass(System, null)
  }

  void test_that_analytics_with_ts_are_correctly_sent(){

    AnalyticsClient.recordFact([ type: 'test-analytic', ts: 1234 ])

    assert actualBaseUrl == AnalyticsClient.ANALYTICS_ENDPOINT
    assert actualRequestMethod == Method.POST

    assert actualRequestDelegate.requestContentType == ContentType.JSON
    assert actualRequestDelegate.body == '{"type":"test-analytic","ts":1234}'

  }

  void test_that_analytics_without_ts_is_correctly_assigned_one(){

    AnalyticsClient.recordFact([ type: 'test-analytic' ])

    assert actualBaseUrl == AnalyticsClient.ANALYTICS_ENDPOINT
    assert actualRequestMethod == Method.POST

    assert actualRequestDelegate.requestContentType == ContentType.JSON
    assert actualRequestDelegate.body == '{"type":"test-analytic","ts":9999}'

  }

  void test_that_analytics_logs_failures_by_default(){

    AnalyticsClient.recordFact([ type: 'test-analytic' ])
    actualRequestDelegate.response.failure([status:500])

    assert printedLines == ['INFO: Analytics recordFact failed with status: 500 for fact {"type":"test-analytic","ts":9999}.']

  }

  void test_that_analytics_does_not_log_failures_when_told_not_to(){

    AnalyticsClient.recordFact([ type: 'test-analytic' ], false)
    actualRequestDelegate.response.failure([status:500])

    assert printedLines == []

  }

  void test_that_analytics_does_not_throw_even_in_face_of_error_but_logs(){

    AnalyticsClient.metaClass.static.getHttpBuilder = { String baseUrl ->
      throw new Exception('Boom!')
    }

    AnalyticsClient.recordFact([ type: 'test-analytic' ])

    assert printedLines == ['INFO: Analytics recordFact failed with exception: java.lang.Exception: Boom! for fact {"type":"test-analytic","ts":9999}.']
  }

  void test_that_analytics_does_not_throw_even_in_face_of_error_and_does_not_log_if_so_told(){

    AnalyticsClient.metaClass.static.getHttpBuilder = { String baseUrl ->
      throw new Exception('Boom!')
    }

    AnalyticsClient.recordFact([ type: 'test-analytic' ], false)

    assert printedLines == []
  }


}