package cvent.windows

import groovy.util.GroovyTestCase
import org.junit.Test

class PowershellTests extends GroovyTestCase {

  def batArgs = []

  void setUp() {
    Powershell.metaClass.static.bat = { Map args ->
      batArgs << args
    }

    Powershell.metaClass.static.bat = { String script ->
      batArgs << [script: script]
    }
  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(Powershell, null)
  }

  void test_that_runScript_correctly_sets_ExecutionPolicy_to_Bypass() {

    Powershell.runScript "Get-ChildItem"

    assert batArgs[0].script.contains( "-ExecutionPolicy ByPass" )
  }

  void test_that_runScript_correctly_passes_returnStatus_arg() {

    Powershell.runScript "Get-ChildItem", returnStatus: true
    String encodedPsCode = "Get-ChildItem".getBytes("UTF-16LE").encodeBase64().toString()

    assert batArgs[0].returnStatus == true
    assert batArgs[0].script.contains( 'powershell.exe' )
    assert batArgs[0].script.contains( encodedPsCode )

  }

  void test_that_runScript_correctly_passes_returnStdout_arg() {

    Powershell.runScript "Get-ChildItem", returnStdout: true
    String encodedPsCode = "Get-ChildItem".getBytes("UTF-16LE").encodeBase64().toString()

    assert batArgs[0].returnStdout == true
    assert batArgs[0].script.contains( '@powershell.exe' )
    assert batArgs[0].script.contains( encodedPsCode )

  }

  void test_that_runScript_correctly_handles_script_params() {

    Powershell.runScript "./script.ps1", params: [
      string: 'one',
      'spaced-string': 'one two',
      bool: true,
      number: 2,
      env: '$env.var'
    ]
    String encodedPsCode = "./script.ps1 -string one -spaced-string 'one two' -bool:\$true -number 2 -env \$env.var".getBytes("UTF-16LE").encodeBase64().toString()
    assert batArgs[0].script.contains( encodedPsCode )

  }
}
