package cvent.java

import groovy.util.GroovyTestCase
import org.junit.Test

class ServiceManager_getDeployedVersionTests extends GroovyTestCase {

  def nodeRunOn, shellArgs
  def nodeInvoked = false
  def shellOutput = "Login Banner...\n/services/cvent/R123/my-service/1.2.3/my-service-1.2.3.jar\n"

  void setUp() {
    ServiceManager.metaClass.static.node = { label, action ->
      nodeRunOn = label
      nodeInvoked = true
      action()
    }

    ServiceManager.metaClass.static.sh = { Map args ->
      shellArgs = args
      return shellOutput
    }

    ServiceManager.metaClass.env = [ NODE_NAME: 'some-node' ]
  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(ServiceManager, null)
  }

  void test_that_getDeployedVersion_runs_expected_linux_command_using_existing_node_context_when_available() {

    ServiceManager.getDeployedVersion('my-service', 'R123', 'my-host.me.com')

    assert nodeInvoked == false
    assert shellArgs == [
      returnStdout: true,
      script: "ssh ${ServiceManager.SSH_USER}@my-host.me.com \"echo; readlink -f /services/cvent/R123/my-service/my-service.jar || echo 'NOT_FOUND'\""
    ]

  }

  void test_that_getDeployedVersion_runs_expected_linux_command_using_new_node_context_when_needed() {

    ServiceManager.metaClass.env = [:]

    ServiceManager.getDeployedVersion('my-service', 'R123', 'my-host.me.com')

    assert nodeInvoked == true
    assert nodeRunOn == 'linux'
    assert shellArgs == [
      returnStdout: true,
      script: "ssh ${ServiceManager.SSH_USER}@my-host.me.com \"echo; readlink -f /services/cvent/R123/my-service/my-service.jar || echo 'NOT_FOUND'\""
    ]
  }

  void test_that_getDeployedVersion_returns_correct_version() {

    def version = ServiceManager.getDeployedVersion('my-service', 'R123', 'my-host.me.com')

    assert version == '1.2.3'
  }

  void test_that_getDeployedVersion_throws_on_not_found_by_default() {

    shellOutput = "Login Banner...\nNOT_FOUND\n"

    shouldFail(IllegalArgumentException) {
      ServiceManager.getDeployedVersion('unknown-service', 'R123', 'my-host.me.com')
    }

  }

  void test_that_getDeployedVersion_returns_null_on_not_found_when_asked() {

    shellOutput = "Login Banner...\nNOT_FOUND\n"

    def version = ServiceManager.getDeployedVersion('unknown-service', 'R123', 'my-host.me.com', false)

    assert version == null
  }
}