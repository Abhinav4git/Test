package cvent.java

import groovy.util.GroovyTestCase
import org.junit.Test

import groovy.mock.interceptor.StubFor
@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.7.1' )
import groovyx.net.http.HTTPBuilder
import groovyx.net.http.ContentType

class MavenUtils_MetadataTests extends GroovyTestCase {

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(MavenUtils, null)
  }

  void test_that_getArtifactMetadata_invokes_the_correct_endpoint_return_received_xml_for_release_builds() {

    doMetaDataTest  'com.test.my-group', 'test.my-artifact', true, '''<?xml version="1.0" encoding="UTF-8"?>
      <metadata>
        <groupId>com.test.my-group</groupId>
        <artifactId>test.my-artifact</artifactId>
        <versioning>
          <latest>1.1.0</latest>
          <release>1.2.3</release>
          <versions>
            <version>1.1.0</version>
            <version>1.2.3</version>
            <version>1.2.4</version>
          </versions>
          <lastUpdated>20161122153344</lastUpdated>
        </versioning>
      </metadata>''',
      '/nexus/content/repositories/releases/com/test/my-group/test.my-artifact/maven-metadata.xml'
  }

  void test_that_getArtifactMetadata_invokes_the_correct_endpoint_return_received_xml_for_snapshot_builds() {

    doMetaDataTest  'com.test.my-group', 'test.my-artifact', false, '''<?xml version="1.0" encoding="UTF-8"?>
      <metadata>
        <groupId>com.test.my-group</groupId>
        <artifactId>test.my-artifact</artifactId>
        <versioning>
          <latest>1.1.0-SNAPSHOT</latest>
          <release/>
          <versions>
            <version>1.1.0-SNAPSHOT</version>
            <version>1.2.3-SNAPSHOT</version>
            <version>1.2.4-SNAPSHOT</version>
          </versions>
          <lastUpdated>20161122153344</lastUpdated>
        </versioning>
      </metadata>''',
      '/nexus/content/repositories/snapshots/com/test/my-group/test.my-artifact/maven-metadata.xml'
  }

  void doMetaDataTest(groupId, artifactId, release, expectedMetadata, expectedPath) {

      doTest(expectedMetadata, expectedPath, {
        def actualMetadata = MavenUtils.getArtifactMetadata(
          groupId,
          artifactId,
          release
        )

        assert actualMetadata == new XmlSlurper().parseText(expectedMetadata)
      })

  }

  void doTest(expectedMetadata, expectedPath, test) {

    def actualBaseUrl, actualArgs

    def stub = new StubFor(HTTPBuilder.class)
    stub.demand.get { args ->
        actualArgs = args
        return new XmlSlurper().parseText(expectedMetadata)
      }

    MavenUtils.metaClass.static.getHttpBuilder = { String baseUrl ->
      actualBaseUrl = baseUrl
      return stub.proxyInstance()
    }

    test()

    assert actualBaseUrl == MavenUtils.MAVEN_REPO_BASE_URL
    assert actualArgs == [ path: expectedPath, contentType: ContentType.XML ]

  }

  void test_that_getMostRecentVersion_invokes_correct_url_and_returns_expected_result() {

    doTest '''<?xml version="1.0" encoding="UTF-8"?>
      <metadata>
        <groupId>com.test.my-group</groupId>
        <artifactId>test.my-artifact</artifactId>
        <versioning>
          <latest>1.1.0</latest>
          <release>1.2.3</release>
          <versions>
            <version>1.1.0</version>
            <version>1.2.2</version>
            <version>1.2.4</version>
          </versions>
          <lastUpdated>20161122153344</lastUpdated>
        </versioning>
      </metadata>''',
      '/nexus/content/repositories/releases/com/test/my-group/test.my-artifact/maven-metadata.xml',
      {
        def actualVersion = MavenUtils.getMostRecentReleaseVersion('com.test.my-group', 'test.my-artifact')
        assert actualVersion == '1.2.3'
        assert actualVersion instanceof String
      }

  }

  void test_that_getHighestReleaseVersion_invokes_correct_url_and_returns_expected_result() {

    doTest '''<?xml version="1.0" encoding="UTF-8"?>
      <metadata>
        <groupId>com.test.my-group</groupId>
        <artifactId>test.my-artifact</artifactId>
        <versioning>
          <latest>1.1.0</latest>
          <release>1.2.3</release>
          <versions>
            <version>1.1.0</version>
            <version>1.3.0</version>
            <version>1.2.2</version>
          </versions>
          <lastUpdated>20161122153344</lastUpdated>
        </versioning>
      </metadata>''',
      '/nexus/content/repositories/releases/com/test/my-group/test.my-artifact/maven-metadata.xml',
      {
        def actualVersion = MavenUtils.getHighestReleaseVersion('com.test.my-group', 'test.my-artifact')
        assert actualVersion == '1.3.0'
        assert actualVersion instanceof String
      }

  }

}
