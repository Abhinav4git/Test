package cvent.java

import groovy.util.GroovyTestCase
import org.junit.Test
import cvent.stash.GitClient
import cvent.jenkins.GroovyUtils
import cvent.parsers.Yaml

class MavenBuilderTests extends GroovyTestCase {


  def checkoutArgs, withMavenArgs, yamlToParse, actualBuildResults
  def groovyScripts = []
  def shellScripts = []
  def loadedTemplate
  def templateBindings

  def TEMP_PATH ='/tmp'
  def expectedBuildResults = [groupId: 'my-group', artifactId: 'my-artifact']
  def expectedGetInfoScript = 'A groovy script to get build info'
  def expectedSnapshotVerificationScript = 'Must be a snapshot!'

  void setUp() {
    GitClient.metaClass.static.checkoutRepo = { Map args, String repo ->
      checkoutArgs = [repo: repo, args: args]
    }

    GroovyUtils.metaClass.static.loadTemplate = { Map bindings, String resourcePath ->
      if(resourcePath == MavenBuilder.EXTRACT_BUILD_INFO_RESC_PATH) {
        return expectedGetInfoScript
      }
    }

    GroovyUtils.metaClass.static.runScript = { String script ->
      groovyScripts << script
    }

    Yaml.metaClass.static.parse = { String yaml ->
      yamlToParse = [yaml]
      return expectedBuildResults
    }

    MavenBuilder.metaClass.static.withMaven = { Map args, Closure action ->
      withMavenArgs = args
      action()
    }

    MavenBuilder.metaClass.static.sh = { String script ->
      shellScripts << script
    }

    MavenBuilder.metaClass.pwd = { args ->
      ( args.tmp  == true ) ? TEMP_PATH : '/workspace'
    }

    MavenBuilder.metaClass.libraryResource = { resourcePath ->
      if(resourcePath == MavenBuilder.ENSURE_SNAPSHOT_RESC_PATH) {
        return expectedSnapshotVerificationScript
      }
    }

    MavenBuilder.metaClass.readFile = { args -> 'yaml: results'}

  }

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(MavenBuilder, null)
    GroovySystem.metaClassRegistry.setMetaClass(GitClient, null)
    GroovySystem.metaClassRegistry.setMetaClass(GroovyUtils, null)
    GroovySystem.metaClassRegistry.setMetaClass(Yaml, null)
  }

  void common_assertions(String expectedBranch, String expectedMavenInstance){
    //The correct project and branch was checked out
    assert checkoutArgs == [repo: 'my-proj/my-service', args: [branch: expectedBranch]]

    //The correct maven instance was invoked.
    assert withMavenArgs == [ maven: expectedMavenInstance]

    //the maven command containd the correct -dgetBranch value
    assert shellScripts.any { script -> script ==~ /(?s).*mvn.*-DgitBranch=${expectedBranch}.*/ }

    //the exepcted artifact info is returned
    assert actualBuildResults == expectedBuildResults

    //the temp files were cleans up.
    assert shellScripts.any { script -> script ==~ /(?s).*rm -f $TEMP_PATH\/.*/ }

  }

  void snapshot_assertions(String expectedBranch, String expectedMavenInstance){
    common_assertions(expectedBranch, expectedMavenInstance)

    //the maven command containd the correct goals for a snapshot build
    assert shellScripts.any { script -> script ==~ /(?s).*mvn.*clean.*deploy.*-DperformRelease=true.*/ }

    //The pom files were checked for snapshot versions
    assert groovyScripts.any { script -> script == expectedSnapshotVerificationScript}

  }

  void release_assertions(String expectedBranch, String expectedMavenInstance){
    common_assertions(expectedBranch, expectedMavenInstance)

    //the maven command containd the correct goals for a release build
    assert shellScripts.any { script -> script ==~ /(?s).*mvn.*clean.*release:prepare.*release:perform.*/ }

    //The pom files were not checked for snapshot versions
    assert !groovyScripts.any { script -> script == expectedSnapshotVerificationScript}

  }

  void test_that_buildSnapshot_correctly_builds_with_defaults() {

    actualBuildResults = MavenBuilder.buildSnapshot('my-proj/my-service')

    snapshot_assertions(MavenBuilder.DEFAULT_CHECKOUT_BRANCH, MavenBuilder.DEFAULT_MVN_INSTANCE)
  }

  void test_that_buildSnapshot_correctly_builds_with_alternate_maven_install() {

    actualBuildResults = MavenBuilder.buildSnapshot('my-proj/my-service', mavenInstance: 'maven2.0')

    snapshot_assertions(MavenBuilder.DEFAULT_CHECKOUT_BRANCH, 'maven2.0')
  }

  void test_that_buildSnapshot_correctly_builds_with_altenate_branch() {

    actualBuildResults = MavenBuilder.buildSnapshot('my-proj/my-service', branch: 'other')

    snapshot_assertions('other', MavenBuilder.DEFAULT_MVN_INSTANCE)
  }

  void test_that_buildRelease_correctly_builds_with_defaults() {

    actualBuildResults = MavenBuilder.buildRelease('my-proj/my-service')

    release_assertions(MavenBuilder.DEFAULT_CHECKOUT_BRANCH, MavenBuilder.DEFAULT_MVN_INSTANCE)
  }

  void test_that_buildRelease_correctly_builds_with_alternate_maven_install() {

    actualBuildResults = MavenBuilder.buildRelease('my-proj/my-service', mavenInstance: 'maven2.0')

    release_assertions(MavenBuilder.DEFAULT_CHECKOUT_BRANCH, 'maven2.0')

  }

  void test_that_buildRelease_correctly_builds_with_altenate_branch() {

    actualBuildResults = MavenBuilder.buildRelease('my-proj/my-service', branch: 'other')

    release_assertions('other', MavenBuilder.DEFAULT_MVN_INSTANCE)
  }
}