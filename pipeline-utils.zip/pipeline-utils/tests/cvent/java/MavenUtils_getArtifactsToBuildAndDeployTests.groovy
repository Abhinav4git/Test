package cvent.java

import groovy.util.GroovyTestCase
import org.junit.Test
import cvent.stash.Utils

class MavenUtils_getArtifactsToBuildAndDeployTests extends GroovyTestCase {

  void tearDown() {
    GroovySystem.metaClassRegistry.setMetaClass(Utils, null)
  }

  void test_that_getArtifactsToBuildAndDeploy_returns_the_correct_results_when_modules_to_deploy_property_present() {

    doTest '''<?xml version="1.0" encoding="UTF-8"?>
      <project>
          <groupId>my-group</groupId>
          <artifactId>my-artifact</artifactId>
          <version>1.2.3</version>

          <properties>
              <modules.to.deploy>my-service , my-consumer</modules.to.deploy>
              <module.to.deploy>wrong-service</module.to.deploy>
          </properties>
          <build>
              <finalName>wrong-service</finalName>
          </build>
      </project>''', ['my-service', 'my-consumer']

  }

  void test_that_getArtifactsToBuildAndDeploy_returns_the_correct_results_when_module_to_deploy_property_present() {

    doTest '''<?xml version="1.0" encoding="UTF-8"?>
      <project>
          <groupId>my-group</groupId>
          <artifactId>my-artifact</artifactId>
          <version>1.2.3</version>

          <properties>
              <module.to.deploy>my-service</module.to.deploy>
          </properties>
          <build>
              <finalName>wrong-service</finalName>
          </build>
      </project>''', ['my-service']

  }

  void test_that_getArtifactsToBuildAndDeploy_returns_the_correct_results_when_finalName_present() {

    doTest '''<?xml version="1.0" encoding="UTF-8"?>
      <project>
          <groupId>my-group</groupId>
          <artifactId>my-artifact</artifactId>
          <version>1.2.3</version>

          <build>
              <finalName>my-service</finalName>
          </build>
      </project>''', ['my-service']

  }

  void test_that_getArtifactsToBuildAndDeploy_returns_the_correct_results_when_only_artifactId_present() {

    doTest '''<?xml version="1.0" encoding="UTF-8"?>
      <project>
          <groupId>my-group</groupId>
          <artifactId>my-artifact</artifactId>
          <version>1.2.3</version>
      </project>''', ['my-artifact']

  }

  void doTest(xml, expectedArtifactsToDeploy) {

    def actualProjectSlashRepo, actualFilePath
    Utils.metaClass.static.getRawFile = { String projectSlashRepo, String branch = 'master', String filePath ->
      actualProjectSlashRepo = projectSlashRepo
      actualFilePath = filePath
      return xml
    }

    def results = MavenUtils.getArtifactsToBuildAndDeploy("my-proj/my-repo")

    assert actualProjectSlashRepo == 'my-proj/my-repo'
    assert actualFilePath == '/pom.xml'

    assert results == [
      groupId           : 'my-group',
      artifactId        : 'my-artifact',
      version           : '1.2.3',
      artifactsToDeploy : expectedArtifactsToDeploy
    ]

    assert results.groupId instanceof String
    assert results.artifactId instanceof String
    assert results.version instanceof String
    assert results.artifactsToDeploy instanceof ArrayList
    results.artifactsToDeploy.each { assert it instanceof String }
  }


}
