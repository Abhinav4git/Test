def file = new File('pom.xml')
println file.name
def project = new XmlSlurper().parse(file)

println 'GROUP_ID=' + project.groupId
println 'ARTIFACT_ID=' + project.artifactId
println 'VERSION=' + project.version

def artifactsToDeploy = ''
if(project.properties.'modules.to.deploy' != '') {
  println "doing something\\n"
  artifactsToDeploy=project.properties.'modules.to.deploy'
} else if(project.properties.'module.to.deploy' != '') {
  println "choosing artifact name " + project.properties.'module.to.deploy'
  artifactsToDeploy=project.properties.'module.to.deploy'
} else if(project.build.finalName != '') {
  println "choosing artifact name " + project.build.finalName
  artifactsToDeploy=project.build.finalName
} else {
  println "choosing artifact name " + project.artifactId
  artifactsToDeploy=project.artifactId
}

println 'artifactsToDeploy=' + artifactsToDeploy

def results = new File("${outFileYaml}")
results << "groupId: " + project.groupId + "\\n"
results << "version: " + project.version + "\\n"
results << "artifactsToDeploy: " + artifactsToDeploy + "\\n"

//for backward compatibility with old flow
results << "artifactId: " + artifactsToDeploy + "\\n"

//for use in naming the build
results << "parent_artifactId: " + project.artifactId + "\\n"