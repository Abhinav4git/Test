def testFile(fileName){
  def file = new File(fileName)

  def project = new XmlSlurper().parse(file)

  if(project.version !='' && project.version !=null && !(project.version ==~ /.*-SNAPSHOT$/)){
    throw new Exception("This job is for building snapshots but version number ${project.version}, found in $fileName, does not end in '-SNAPSHOT'.")
  }
  return project
}

def topProject = testFile('pom.xml')

topProject.modules.module.each { mod ->
  testFile("./${mod.toString()}/pom.xml")
}
