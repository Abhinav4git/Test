# Jenkins Pipeline Utility Scripts

This repo contains Jenkins pipeline utilities that will be generally useful across all Jenkins instances and code bases.

- To understand the layout of the repo and for general information the purpose and use of pipeline libraries see the [Pipeline Library Docs](https://github.com/jenkinsci/workflow-cps-global-lib-plugin/blob/master/README.md).

- For information on specific utility functions, see the details in the groovy-doc comments in individual files.

## The `test-helpers/` Folder

The `test-helpers` folder contains classes that are meant to represent the classes contained in the Jenkins API, namely those in the `jenkins` and `hudson` name spaces. For example, this allows the `cvent/jenkins/AuthUtils.groovy` class, when loaded into the test harness, to still be able to import the `hudson.model.User`class. Though it remains up to the test cases to stub or mock these classes as their implementations under test-helpers is generally empty.

There are also some special classes in the `test-helpers/globals` folder. These classes are 'globally' present in the Jenkins Groovy run-time. As such they do not need to be imported to be used in CPS groovy. To accomplish this same effect for unit testing (and even allow the pipleline-utils to compile outside Jenkins), an import compilation customizer is used. This is set up in the test environment via the `run-tests.groovy` file in the root of this repo. See it for details.

All other classes in this folder must be `import`ed as usual.

Classes in this folder are made available for import by including them on the groovy classpath as shown in the `Jenkinsfile`.

## Pipelines

- [dropwizardPipeline](doc/dropwizardPipeline.md)
- [javaLibraryPipeline](doc/javaLibraryPipeline.md)
- [nodeLibraryPipeline](doc/nodeLibraryPipeline.md)
- [nxPipeline](https://nx.core.cvent.org/docs/nx_pipeline)
- [prototypeAwsCdkPipeline](doc/prototypeAwsCdkPipeline.md)

## ToDos

- Find a way to import groovy-docs into this read-me?

## Authors:

- kbaltrinic
- jmorley
