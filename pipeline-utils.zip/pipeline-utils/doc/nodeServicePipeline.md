# nodeServicePipeline

The _nodeServicePipeline_ supports building and deploying AWS based services to CI, alpha, and staging regions.

- [Example](#example)
- [Definitions](#definitions)
- [Build Order](#build-order)
- [Slack Notification](#slack-notification)
- [Release Builds](#release-builds)
- [Build Image](#build-image)
- [Postman](#postman)
- [CI](#ci)
- [Alpha/Staging](#alpha-staging)
- [Unit and Integration Tests](#unit-and-integration-tests)
- [Load Tests](#load-tests)
- [Code Coverage](#code-coverage)
- [Checkmarx](#checkmarx)
- [ReadyAPI](#ready-api)
- [Planner Tools UI Test](#planner-tools-ui-test)
- [Cloudformation](#cloudformation)
- [Jenkins](#jenkins)
- [Jenkins Job Build Parameters](#jenkins-job-build-parameters)
- [FAQ](#faq)
- [Best Practices](#best-practices)
- [Help](#help)

### <a name="example">Example</a>

```groovy
#!/usr/bin/env groovy

@Library('pipeline-utils') _

nodeServicePipeline([
  // If a release branch is built then subsequent deploys use the RELEASE version, otherwise deploys use the SNAPSHOT
  release: [
    // Regular expression to determine which branch triggers a release build
    branch: 'master|release/.*'
  ],

  // Slack event notification by branch. The first entry which matches the current branch is used.
  slack : [
    [ branch: 'master|release/.*', channel: 'test-release', events: ['SUCCESS', 'FAILURE'] ],

    // Note this entry must come last since it matches all branches.
    [ branch: '.*', channel: [ 'teamA', 'teamB' ], events: ['START', 'SUCCESS', 'FAILURE'] ]
  ],

  // Optional. Enable to run a Checkmarx scan.
  // https://wiki.cvent.com/display/DEV/Checkmarx+Teams+and+Scan+Preset
  checkmarx: [
    branch: 'master|dev',
    syncMode: true,
    teamValue: '10c6f1f8-2a2d-46fb-b367-6a3195bde7c6',
    presetValue: '100011'
  ],

  // Optional. Run ReadyAPI tests on https://qe-jenkins.core.cvent.org
  readyApi: [
    apiProject: 'falcon-planner'
  ],

  ci: [
    builds: [
      // Deploys branch ci447 to S447. Leaves the service running. By default CI builds are shutdown after running
      // integration tests
      [ branch: 'ci447', environments: 'S447', shutdown: false ],

      // Deploys all branches to ci environment. Note this entry must occur after the ci447 otherwise ci447 branch will
      // deploy to ci instead of S447
      [ branch: '.*', environments: 'ci' ]
    ],
  ],

  // configuration for Cloudformation deployments. Restricts which branches are
  // capable of deploying Cloudformation changes. By default, no cloudformation
  // is executed.
  cloudformation: [
      branch: [ 'master' ]
  ],

  // Alpha/Staging builds
  // PR builds are always ignored in this section
  builds: [
    // Deploys branches matching a regular expression to multiple silos
    [ branch: 'devsilo413', environments: 'S413' ],

    // Additional settings required for ReadyAPI
    [ branch: 'devsilo439', environments: 'S439', readyApi: [ branch: 's439' ]],

    // Deploys "dev" and "develop" branch to "S412"
    [ branch: 'dev|develop', environments: 'S412' ],

    // Deploys "master" and "release/.*' branches to "sg50" and "L2". Combined with the "release" property above this
    // will deploy RELEASE builds to sg50 and L2
    [ branch: 'master|release/.*', environments: [ 'sg50', 'L2' ] ]
  ]
])
```

### <a name="definitions">Definitions</a>

- BRANCH_NAME - The service repository's branch to build and deploy. If building a PR branch, then BRANCH_NAME equals
  the target branch.

### <a name="build-order">Build Order</a>

1. Checkout dependent repositories
1. Build a SNAPSHOT or RELEASE build depending on `release` property's branch regex
   1. In parallel, run checkmarx if it is enabled for the branch
1. Build the service docker image
1. If a branch regex in the `ci` section is found then perform the following steps for each environment found in the branch specification.
   1. Run liquibase migration
   1. Deploy service
   1. In parallel, run integration tests and postman service tests if configured
   1. Shutdown CI deploy if configured (default is true).
1. If a branch regex in the `builds` section is found then perform the following steps for each environment found in the branch specification.
   1. Run liquibase migration
   1. Deploy service
   1. In parallel, run integration tests and postman service tests if configured
1. Notify Slack based on `slack` branch specification

### <a name="slack-notification">Slack Notification</a>

The pipeline determines the notification based on the BRANCH_NAME.

- _branch_ (regex) - A regular expression matched against BRANCH_NAME
- _branch_type_ (SOURCE, TARGET) - Type of branch used for branch matching, defaults to 'TARGET'
- _channel_ (String/Array) - A String or Array containing one or more channels to notify.
  - Use the special `_owner_` channel to notify the PR author, this special channel is only considered in PR builds and
    may not work in all cases as it assumes the first part of email before `@` is the Slack username.
- _events_ (START, SUCCESS, FAILURE) - The events that trigger notification

Slack is notified on the first entry which matches the BRANCH_NAME.

```groovy
slack: [
  [ branch: 'PR-.*', branch_type: 'SOURCE', channel: ['team-pull-requests', '_owner_'], events: ['SUCCESS', 'FAILURE']],
  [ branch: 'master|release/.*', channel: 'test-deploy', events: ['SUCCESS', 'FAILURE'] ],

  // this entry must come last since it matches all branches.
  [ branch: '.*', branch_type: 'TARGET', channel: 'test-deploy', events: ['START', 'SUCCESS', 'FAILURE'] ]
]
```

![Sample Slack Notification](dropwizardPipeline-slack-success.png) ![Sample Slack Notification](dropwizardPipeline-slack-failure.png)

### <a name="release-builds">Release Builds</a>

Determines which branches trigger a RELEASE build. You may need to update "Build strategies" in your Jenkins project
configuration in order to automatically build the RELEASE. Many project configurations only enable _master_ branch.

```groovy
release: [
  // Regular expression to determine which branch triggers a release build
  branch: 'master|release/.*'
]
```

If Jenkins triggers a RELEASE build, then subsequent deploys use the RELEASE artifact.

Pull request builds never trigger a RELEASE.

A build triggered by a maven release commit (a commit containing `[maven-release-plugin]`) will not perform any actions. The
build display name will include `No build: Maven release commit`.

### <a name="build-image">Build Image</a>

Determines which build image to use to build the node service

- `centos7` for node version before 8
- `centos7-node12` for node version 12

```groovy
release: [
  branch: 'master',
  buildImage: 'centos7-node12'
],
snapshot: [
  buildImage: 'centos7' // Default is centos7
]
```

### <a name="postman">Postman</a>

The artifacts containing postman service test scripts. The package.json must contain a property named 'postmanTest' that defines the name for the postman service test and the collections to run.

Example, [postmanTest](https://stash.cvent.net/projects/PT/repos/event-api/browse/package.json#132)

See [Setup Service Testing](https://wiki.cvent.com/display/RD/Testing) for more information on setting up your project to support postman
service testing.

### <a name="ci">CI</a>

Contains the configuration which determines which branch to build and deploy to CI.

- _branch_ (regex) - A regular expression matched against BRANCH_NAME
- _environments_ (String/Array) - A String or Array containing one or more environments to deploy the service
- _shutdown_ (boolean) - True to shutdown the service after running integration tests (Default: true)

The deploy occurs on the first entry which matches BRANCH_NAME.

```groovy
ci: [
  builds: [
    // Deploys branch ci447 to S447 and the service continues to run
    [ branch: 'ci447', environments: 'S447', shutdown: false ],

    // Deploy every branch to the ci environment.
    // This entry must come last otherwise ci447 branch will deploy to ci instead of S447.
    // Stops the service after running integration tests
    [ branch: '.*', environments: 'ci' ]
  ]
]
```

If the pipeline does not contain a `ci` property, then the pipeline will default to:

```groovy
builds: [
  [ branch: '.*', environments: 'ci' ]
]
```

### <a name="alpha-staging">Alpha/Staging</a>

Contains the configuration which determines which branch to build and deploy after running CI.

If the pipeline does not contain `builds`, then no alpha/staging deploy occurs.

- _branch_ (regex) - A regular expression matched against BRANCH_NAME
- _environments_ (String/Array) - A String or Array containing one or more environments to deploy the service

The deploy occurs on the first entry which matches BRANCH_NAME.

```groovy
builds: [
  builds: [
    // Deploys branches matching a regular expression to multiple silos
    [ branch: 'devsilo.*', environments: [ 'S413', 'S447' ] ],

    // Deploys "dev" and "develop" branch to "S412"
    [ branch: 'dev|develop', environments: 'S412' ],

    // Deploys "master" and "release/.*' branches to "sg50"
    // When deploying to staging, you should ensure your release property has the same branch regex
    [ branch: 'master|release/.*', environments: 'sg50' ]
  ]
]
```

### <a name="unit-and-integration-tests">Unit and Integration Tests</a>

Unit and Integration test results are displayed under the same _Test Results_ Jenkins link. Integration tests are
suffixed with the environment.

In the following example `PipelineTestServiceConfigurationTest` is a unit test and `PipelineTestEndpointTestIT(ci)`
is an integration test run in the `ci` environment.

![Test Results](dropwizardPipeline-test-results.png)

Some services run integration tests in CI with custom environments like `ci-S408`. Each build entry supports
an `it_environments` property to specify environments that differ from the deployment environment. If the `it_environments`
property does not exist then integration tests use the deployment environment.

```groovy
// devsilo408 branch will deploy to S408 and integration tests will run using ci-S408 as the environment
ci: [
  [ branch: 'devsilo408', environments: 'S408', it_environments: 'ci-S408' ]
]
```

If you want to run your integration tests sequentially for a branch that specifies multiple
environments then use the configuration parallelTests = false.

```groovy
builds: [
  builds: [
    // Deploys "master" and "release/.*' branches to "sg50"
    // When deploying to staging, you should ensure your release property has the same branch regex
    [ branch: 'master|release/.*', environments: [ 'sg50', 'ld50' ], parallelTests: false ]
  ]
]
```

### <a name="load-tests">Load Tests</a>

Gatling load tests are supported. Load tests will run if your service contains a build-load.sh file and the POM file
contains a "modules.to.load-test" property. If the modules listed either contain an \$environment.test.yaml file or an
environment is listed in the module's environments.txt file then load tests will run (identical mechanism to integration
tests). If you would like load tests to run using a different environment from the one being deployed to, then
"load_environments" can be specified. Example:

```groovy
builds: [
  builds: [
    # Build is deployed to ld50, load tests are executed using L2, hence L2.test.yaml.
    [ branch: 'master|release/.*', environments: 'ld50', load_environments: 'L2' ],
  ]
]
```

The Gatling HTML report showing performance results is published to Jenkins and should be visible under
the icon resembling the Gatling logo when viewing your build. When Gatling assertions fail this will result in your
build failing (that's desirable / by design to enforce performance requirements specified in your tests being met).

For more information see [here](https://wiki.cvent.com/display/RD/Gatling)

### <a name="code-coverage">Code Coverage</a>

Every build runs [Jacoco](https://www.jacoco.org/jacoco/trunk/index.html) to determine code coverage.

By default code coverage results are uploaded to [Sonar](http://sonar.core.cvent.org/) for RELEASE builds. You
can configure both RELEASE and SNAPSHOT Sonar uploads with the following:

```groovy
release: [
  branch: 'master',
  sonar: true
],
snapshot: [
  sonar: false // Default is false
]
```

### <a name="checkmarx">Checkmarx</a>

Checkmarx scans are performed in parallel with the SNAPSHOT/RELEASE builds

```groovy
// By default checkmarx is disabled
// https://wiki.cvent.com/display/DEV/Checkmarx+Teams+and+Scan+Preset
// syncMode - enabled by default but you can opt out by setting it to false.
// With syncMode enabled build waits for Checkmarx scan to finish to obtain/show results in build output.
// When turned off, build only upload source code to checkmarx and doesn't wait for results.
// ** WARNING **
// If an application is already created in Checkmarx and team/preset are added at a
// later point, make those changes for team/preset in Checkmarx application first
//  to match what will be specified in Jenkinsfile. Otherwise a new application
//  with same name but different team/preset will be created in Checkmarx

checkmarx: [
  branch: 'master|dev',
  syncMode: true,
  teamValue: '10c6f1f8-2a2d-46fb-b367-6a3195bde7c6',
  presetValue: '100011'
]
```

### <a name="ready-api">Ready API</a>

Run Ready API tests by calling https://qe-jenkins.core.cvent.org/job/runAPI/

Ready API supports both project level configuration and per branch configuration. Branch configuration parameters
override project parameters. The configuration supports all the parameters of the runAPI Jenkins job.

Parameters:

- _apiProject_ - Ready API project name
- _branch_ - Ready API branch
- _syncMode_ (default: true) - If true wait until the Ready API job completes otherwise asynchronously run the Ready API job

```groovy
// Project configuration
readyApi: [
  apiProject: 'falcon-planner'
]

// Branch configuration
builds: [
  [ branch: 'devsilo439', environments: 'S439', readyApi: [ branch: 's439' ]],
  [ branch: 'master', environments: 'sg50', readyApi: [ branch: 'master', apiProject: 'foobar', syncMode: false ]]
]
```

### <a name="planner-tools-ui-test">Planner Tools UI Test</a>

Run Web UI tests by calling https://mobile-jenkins.core.cvent.org/job/pt-web-ui-automation-ci/

Web UI test supports both project level configuration and per branch configuration. Branch configuration parameters
override project parameters. The configuration supports all the parameters of the pt-web-ui-automation-ci Jenkins job.

Parameters:

- _tests_ (String) - Web UI tests name
- _branch_ - Web UI tests branch
- _environment_ - Environment to run tests
- _thread_count_ - Number of threads to run with (e.g thread_count: '1')
- _syncMode_ (default: true) - If true wait until the Ready API job completes otherwise asynchronously run the Ready API job

```groovy
// Project configuration
plannerTools: [
  tests: '@user-api'
]

// Branch configuration
builds: [
  // Waits for planner tools tests to complete
  [ branch: 'devsilo439', environments: 'S439', plannerTools: [ branch: 'develop' ]],

  // Kicks off planner tools tests asynchronously
  [ branch: 'master', environments: 'sg50', plannerTools: [ branch: 'develop', tests: '@user-api', syncMode: false ]]
]
```

### <a name="cloudformation">Cloudformation</a>

The pipeline also supports deploying cloudformation and lambdas that are included in your project. The cloudformation
is deployed after the service is deployed to ECS. When the scripts run both a cloudformation
[package](https://docs.aws.amazon.com/cli/latest/reference/cloudformation/package.html)
and [deploy](https://docs.aws.amazon.com/cli/latest/reference/cloudformation/deploy/index.html) are executed. A
package is done in case there are lambda functions or artifacts that need to be uploaded to S3 so the cloudformation
can refer to the S3 artifacts.

In order to enable Cloudformation deployments, you must specify which branches should execute deployments.
This is done in order to prevent deployment "thrashing"; where two developers are out of sync and Cloudformation
changes are repeatedly applied and removed. By selecting a central branch or branches, you prevent this.
During builds for other branches, Cloudformation is still validated for correctness and deployability
(via --no-execute-changeset).

Example: [universal-auth example](https://stash.cvent.net/projects/API/repos/universal-auth/browse/cloudformation/pom.xml#42)

### <a name="jenkins">Jenkins</a>

This pipeline takes advantage of the [Bitbucket Branch Source Plugin](https://wiki.cvent.com/display/RD/Jenkinsfiles+and+Bitbucket+Integration).
If your project is not configured with this plugin, please reach out to #tech-jenkinsfile in Slack.

Remove your custom Jenkins jobs and the jobs created by dropkick (eg. foo-service-ci and foo-service-release) after
upgrading to this pipeline.

### <a name="jenkins-job-build-parameters">Jenkins Job Build Parameters</a>

**RELEASE**

Forces the pipeline to build a Maven release artifact. Do not use unless absolutely necessary. Instead use the `release`
property in the Jenkinsfile to standardize a service's release branches.

**HOGAN_CONFIGS_BRANCH**

Hogan configs branch to use during deployments. Useful to test configuration changes.

**VERBOSE_LOGGING**

Enables verbose logging in the deployment scripts.

**DEPLOY_SERVICE_ECS_TAG**

Do not use. This is only recommended when developing changes to the [deploy-service-ecs](https://stash.cvent.net/projects/DEP/repos/deploy-service-ecs/browse)

**HOGAN_BRANCH**

Hogan branch to convert to git SHA for deploy time configuration. The default value for this is "master"

**HOGAN_GIT_SHA**

Hogan git SHA for deploy time configuration. Takes priority over HOGAN_BRANCH

**ENVIRONMENT**

Overrides the alpha/staging deployment environment defined in the Jenkinsfile. Not recommended for use.

**CLOUDFORMATION_DEPLOY**
Overrides the Cloudformation section, running Cloudformation deployments at all points during a build.

This can be useful when you need to deploy changes as part of your pull request, and cannot wait for it to be merged to master.

### <a name="faq">FAQ</a>

#### How do I rebuild the service?

Always use `Rebuild`, do not use `Retry` or `Replay` Jenkins links.

#### How do I build a RELEASE version?

Most of the time the pipeline should take the correct action and build a RELEASE version when the release branch is updated.

However sometimes the build fails in which case you can force a RELEASE version.

1. Select the branch to build in Jenkins
1. Click `Build with Parameters`
1. Check the `RELEASE` checkbox
1. Click `Build'

This works on any branch not only the branches specified as release branches.

#### How do I deploy to a custom environment?

1. Select the branch to build in Jenkins
1. Click `Build with Parameters`
1. Specify the environment in the `ENVIRONMENT` field
1. Click `Build'

This currently does not work on release branches, https://jira.cvent.com/browse/SRE-13277

### <a name="best-practices">Best Practices</a>

#### Remove obsolete build scripts

`build.sh`, `build-release.sh`, `jenkins.sh`, `build-it.sh`, and `build-st.sh` are no longer required.

#### Remove obsolete Jenkins jobs

These are usually named like `foo-service-ci` and `foo-service-release`. The pipeline replaces the functionality in
these jobs.

#### Branches

Use consistent branch names. Name your branches following the pattern `devsiloNNN (devsilo412)` not branches named
after your sprint team name. This makes it easy to correspond branches with deployed environments and easy to
configure Jenkins build strategy (eg. `^devsilo\d+\$).

Deploy all branches to CI. This is the default behavior of the pipeline. Some teams need custom CI behavior, for example,
https://stash.cvent.net/projects/OSLO/repos/event-guestside/browse/Jenkinsfile#21. However even in these cases there's a final
entry for all branches.

Use the top level `builds` property to determine which branch to deploy to which silo.

In the following Jenkinsfile changes to master branch will build a RELEASE. See [Release Builds](#release-builds) for
exceptions.

```groovy
release: [
  branch: 'master'
]
ci: [
  // PRs and branches (determined by build strategy configuration) will deploy to CI
  builds: [
    [ branch: '.*', environments: 'ci' ]
  ]
],
builds: [
  // Consistent silo branch names. Merges to devsiloNNN will deploy SNAPSHOTs to the corresponding silo
  [ branch: 'devsilo408', environments: 'S408' ],
  [ branch: 'devsilo420', environments: 'S420' ],

  // Changes to master branch will build and deploy a RELEASE build to sg50 and L2 environments.
  [ branch: 'master', environments: [ 'sg50', 'L2' ]
]
```

#### Remove merged branches

Once a day Jenkins scans all the project repositories to find any new Jenkinsfiles. Please remove unused branches or
branches that have been merged to master.

The following script will output all branches that were merged to master. Run with "-d" to delete the branches.

```shell script
#!/bin/sh

BRANCH=master

# Branches to ignore
IGNORE='(>|^master.*$|dev|^silo\d+)'

while getopts "b:d" OPTION; do
  case "$OPTION" in
    b)
      BRANCH="$OPTARG"
      ;;
    d)
      DELETE=1
      ;;
    *)
      echo "Incorrect options provided"
      exit 1
      ;;
  esac
done

if [ -n "$DELETE" ]; then
  git co "$BRANCH" > /dev/null && git branch -r --merged |
    grep origin |
    xargs -L1 |
    cut -d"/" -f2- |
    grep -vE "$IGNORE" |
    xargs -n 100 git push origin --delete
else
  git co "$BRANCH" > /dev/null && git branch -r --merged |
    grep origin |
    xargs -L1 |
    cut -d"/" -f2- |
    grep -vE "$IGNORE"
fi
```

### <a name="help">Help</a>

- [#tech-build-and-deploy](https://slack.com/app_redirect?team=TCCMVR5Q8&channel=CHTB4CLSC) for build and deploy issues
- [Jenkinsfile and Bitbucket Integration](https://wiki.cvent.com/display/RD/Jenkinsfiles+and+Bitbucket+Integration)
- [Tech Talk](https://cvent.box.com/s/r879aviq4buznzbv9y0s7uylnjkmd2yi) and [Slides](https://cvent.box.com/s/w689x91kuqawt6f5olnnjxwu6e5nnlzp)
