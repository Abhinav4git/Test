# nodeLibraryPipeline

The _nodeLibraryPipeline_ supports building/publishing a Node library.

- [Usage](#usage)
- [Slack Notification](#slack-notification)
- [Ignore Files](#ignore-files)
- [Release](#release)
- [Build Parameters](#build-parameters)

### <a name="usage">Usage</a>

Jenkinsfile

```groovy
#!/usr/bin/env groovy

@Library('pipeline-utils') _

nodeLibraryPipeline([
    slack_channel: 'test-deploy', // Slack channel(s) for RELEASE build notifications

    // Optional. Files in the change set that match any files and/or directories and/or patterns in this list will NOT
    // trigger automatic snapshot/release builds.
    //
    // Each entry in the array must adhere to a file/directory matching pattern that may optionally include
    // wildcards ('*', '**' or '?').
    //
    // The wildcard character '*' within the pattern matches a sequence of zero or more characters within a single file
    // or directory name in the input string. It does not match a sequence of two or more dir/file names. For instance,
    // 'a*b' matches 'a12345b' and 'ab', but does NOT match 'a/b' or 'a123/b'.
    //
    // The '**' wildcard matches any sequence of zero or more path segments in the input string, including directory names
    // and separators. It matches any part of the directory tree. For instance, 'a/**/b' matches 'a/11/b' and 'a/1/2/3/b'.
    //
    // The wildcard character '?' within the pattern matches exactly one character in the input string, excluding the
    // normalized file separator character ('/').
    //
    // All matching is case-insensitive!
    //
    // See https://confluence.atlassian.com/fisheye/pattern-matching-guide-960155410.html for more details
    //
    // The following files are ignored by default:
    // - .gitignore
    // - CHANGELOG.md
    // - CODEOWNERS
    // - Jenkinsfile
    // - pull_request.md
    // - README.md
    // - renovate.json
    ignoreFiles: [
      'package.json',
      'temp*',
      'example/dir'
    ],

    release: [
        branch: 'master', // Regular expression to determine which branch triggers a RELEASE build
        publish: true // Whether to publish package to registry
    ]
])
```

### <a name="slack-notification">Slack Notification</a>

Only RELEASE builds send a notification to Slack.

```groovy
slack_channel: 'test-deploy'
```

`slack_channel` supports a single channel name or a user (`@userA`), comma separate list of channels
(`channelA,channelB,@userX`), or an array of channels (`['channelA', 'channelB', '@userX']`)

### <a name="ignore-files">Ignore Files</a>

A build triggered by a commit which contains changes only to the default ignore files and/or custom ignore files will not perform any actions. The build display name will include
`No build: Changeset contains only ignored files`

The default ignore files are as follows:

- .gitignore
- CHANGELOG.md
- CODEOWNERS
- Jenkinsfile
- pull_request.md
- README.md
- renovate.json

Ignore file definitions do not affect manually triggered builds.

### <a name="release">Release</a>

A release will bump package version, git tag and push to Stash, and optionally publish to a registry defined in the library.
When a release script is defined in the library's package.json, the pipeline will run it without bumping version.

Release configurations:

- `branch` is a regular expression that determines which branch triggers a RELEASE build. Defaults to `master`.
- `publish` controls whether the package gets published (via `yarn publish`) as part of a release. Defaults to `true`.
  - The primary usage of `publish: false` is when the library has a custom release script that also handles publishing.

A build containing changes to only ignore files will not perform any actions. See [Ignore Files](#ignore-files).

Pull request builds never trigger a RELEASE.

### <a name="build-parameters">Build Parameters</a>

**RELEASE**

Forces the pipeline to build a release. Do not use unless absolutely necessary. Instead use the `release`
property in the Jenkinsfile to standardize a service's release branches.

**RELEASE_TYPE**

When a release is handled by the pipeline (vs. custom release script defined in the library's package.json file),
RELEASE_TYPE value controls how to assign a new version:

- PATCH: increment PATCH version (default)
- MINOR: increment MINOR version
- MAJOR: increment MAJOR version
