# prototypeAwsCdkPipeline

The _prototypeAwsCdkPipeline_ supports building and deploy AWS CDK based applications.

- [Example](#example)
- [Polyglot Applications](#polyglot-apps)

### <a name="example">Example</a>

```groovy
#!/usr/bin/env groovy

@Library('pipeline-utils') _

prototypeAwsCdkPipeline([
  // default application directory is app, you can override this.
  app: [
    dir: 'app'
  ],
])
```

### <a name="polyglot-apps">Polyglot Applications</a>

The pipeline supports building and deploying polyglot applications by using yarn as a task runner.

In order to use this, you need to add a package.json in each of your applications root directory. The pipeline will loop through each directory looking for a package.json and use that to build your application. The package.json should have the following yarn targets :

- build: Use this target to lint and compile your applications.
- test: Use this target to run unit tests.
- release: Use this target to publish the built artifact to a registry.
- dist: Use this target to create a distribution (zip file, jar file, dockerfile, etc) that can be consumed by your infrastructure code.

NOTE: In case you do not want to use a specific target, you still need to define it and do some sort of a noop.
