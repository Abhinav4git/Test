# dropwizardPipeline

The _dropwizardPipeline_ supports building and deploying AWS based services to CI, alpha, and staging regions.

- [Example](#example)
- [Definitions](#definitions)
- [Build Order](#build-order)
- [Slack Notification](#slack-notification)
- [Ignore Files](#ignore-files)
- [Release Builds](#release-builds)
- [Liquibase](#liquibase)
- [Postman](#postman)
- [CI](#ci)
- [Alpha/Staging](#alpha-staging)
- [Unit and Integration Tests](#unit-and-integration-tests)
- [Load Tests](#load-tests)
- [Code Coverage](#code-coverage)
- [Checkmarx](#checkmarx)
- [ReadyAPI](#ready-api)
- [Planner Tools UI Test](#planner-tools-ui-test)
- [Cloudformation](#cloudformation)
- [Node](#node)
- [Jenkins](#jenkins)
- [Jenkins Job Build Parameters](#jenkins-job-build-parameters)
- [FAQ](#faq)
- [Best Practices](#best-practices)
- [Help](#help)

### <a name="example">Example</a>

```groovy
#!/usr/bin/env groovy

@Library('pipeline-utils') _

dropwizardPipeline([
  // Optional. If liquibase is not included it defaults to the values specified in the pom's modules.to.deploy property
  // A few services keep their liquibase migration code in a separate module from the service
  liquibase: [
    artifacts: [ 'falcon-planner-service' ]
  ],

  // Optional. Files in the change set that match any files and/or directories and/or patterns in this list will NOT
  // trigger automatic snapshot/release builds.
  //
  // Each entry in the array must adhere to a file/directory matching pattern that may optionally include
  // wildcards ('*', '**' or '?').
  //
  // The wildcard character '*' within the pattern matches a sequence of zero or more characters within a single file
  // or directory name in the input string. It does not match a sequence of two or more dir/file names. For instance,
  // 'a*b' matches 'a12345b' and 'ab', but does NOT match 'a/b' or 'a123/b'.
  //
  // The '**' wildcard matches any sequence of zero or more path segments in the input string, including directory names
  // and separators. It matches any part of the directory tree. For instance, 'a/**/b' matches 'a/11/b' and 'a/1/2/3/b'.
  //
  // The wildcard character '?' within the pattern matches exactly one character in the input string, excluding the
  // normalized file separator character ('/').
  //
  // All matching is case-insensitive!
  //
  // See https://confluence.atlassian.com/fisheye/pattern-matching-guide-960155410.html for more details
  //
  // The following files are ignored by default:
  // - .gitignore
  // - CHANGELOG.md
  // - CODEOWNERS
  // - Jenkinsfile
  // - pull_request.md
  // - README.md
  // - renovate.json
  // - **/UPGRADE.md
  ignoreFiles: [
    'package.json',
    'temp*',
    'example/dir'
  ],

  // If a release branch is built then subsequent deploys use the RELEASE version, otherwise deploys use the SNAPSHOT
  release: [
    // Regular expression to determine which branch triggers a release build
    branch: 'master|release/.*'
  ],

  // Slack event notification by branch. The first entry which matches the current branch is used.
  slack : [
    [ branch: 'master|release/.*', channel: 'test-release', events: ['SUCCESS', 'FAILURE'] ],

    // Note this entry must come last since it matches all branches.
    [ branch: '.*', channel: [ 'teamA', 'teamB' ], events: ['START', 'SUCCESS', 'FAILURE'] ]
  ],

  // Optional. Enable to run a Checkmarx scan.
  // https://wiki.cvent.com/display/DEV/Checkmarx+Teams+and+Scan+Preset
  checkmarx: [
    branch: 'master|dev',
    syncMode: true,
    teamValue: '10c6f1f8-2a2d-46fb-b367-6a3195bde7c6',
    presetValue: '100011'
  ],

  // Optional. Run ReadyAPI tests on https://qe-jenkins.core.cvent.org
  readyApi: [
    apiProject: 'falcon-planner'
  ],

  ci: [
    builds: [
      // Deploys branch ci447 to S447. Leaves the service running. By default CI builds are shutdown after running
      // integration tests
      [ branch: 'ci447', environments: 'S447', shutdown: false ],

      // Deploys all branches to ci environment. Note this entry must occur after the ci447 otherwise ci447 branch will
      // deploy to ci instead of S447
      [ branch: '.*', environments: 'ci' ]
    ],
  ],

  // configuration for Cloudformation deployments. Restricts which branches are
  // capable of deploying Cloudformation changes. By default, no cloudformation
  // is executed.
  cloudformation: [
      branch: [ 'master' ]
  ],

  // Alpha/Staging builds
  // PR builds are always ignored in this section
  builds: [
    // Deploys branches matching a regular expression to multiple silos
    [ branch: 'devsilo413', environments: 'S413' ],

    // Additional settings required for ReadyAPI
    [ branch: 'devsilo439', environments: 'S439', readyApi: [ branch: 's439' ]],

    // Deploys "dev" and "develop" branch to "S412"
    [ branch: 'dev|develop', environments: 'S412' ],

    // Deploys "master" and "release/.*' branches to "sg50" and "L2". Combined with the "release" property above this
    // will deploy RELEASE builds to sg50 and L2
    [ branch: 'master|release/.*', environments: [ 'sg50', 'L2' ] ]
  ]
])
```

### <a name="definitions">Definitions</a>

- BRANCH_NAME - The service repository's branch to build and deploy. If building a PR branch, then BRANCH_NAME equals
  the target branch.

### <a name="build-order">Build Order</a>

1. Checkout dependent repositories
1. Build a SNAPSHOT or RELEASE build depending on `release` property's branch regex
   1. In parallel, run checkmarx if it is enabled for the branch
1. Build the service docker image
1. If a branch regex in the `ci` section is found then perform the following steps for each environment found in the branch specification.
   1. Run liquibase migration
   1. Deploy service
   1. In parallel, run integration tests and postman service tests if configured
   1. Shutdown CI deploy if configured (default is true).
1. If a branch regex in the `builds` section is found then perform the following steps for each environment found in the branch specification.
   1. Run liquibase migration
   1. Deploy service
   1. In parallel, run integration tests and postman service tests if configured
1. Notify Slack based on `slack` branch specification

### <a name="slack-notification">Slack Notification</a>

The pipeline determines the notification based on the BRANCH_NAME.

- _branch_ (regex) - A regular expression matched against BRANCH_NAME
- _branch_type_ (SOURCE, TARGET) - Type of branch used for branch matching, defaults to 'TARGET'
- _channel_ (String/Array) - A String or Array containing one or more channels to notify.
  - Use the special `_owner_` channel to notify the PR author, this special channel is only considered in PR builds and
    may not work in all cases as it assumes the first part of email before `@` is the Slack username.
- _events_ (START, SUCCESS, FAILURE) - The events that trigger notification

Slack is notified on the first entry which matches the BRANCH_NAME.

```groovy
slack: [
  [ branch: 'PR-.*', branch_type: 'SOURCE', channel: ['team-pull-requests', '_owner_'], events: ['SUCCESS', 'FAILURE']],
  [ branch: 'master|release/.*', channel: 'test-deploy', events: ['SUCCESS', 'FAILURE'] ],

  // this entry must come last since it matches all branches.
  [ branch: '.*', branch_type: 'TARGET', channel: 'test-deploy', events: ['START', 'SUCCESS', 'FAILURE'] ]
]
```

![Sample Slack Notification](dropwizardPipeline-slack-success.png) ![Sample Slack Notification](dropwizardPipeline-slack-failure.png)

### <a name="ignore-files">Ignore Files</a>

A build triggered by a commit which contains changes only to the default ignore files and/or custom ignore files will not perform any actions. The build display name will include
`No build: Changeset contains only ignored files`

**This applies to both SNAPSHOT and RELEASE builds.**

See the [example Jenkinsfile](#example) above for more info on defining custom ignore files.

The default ignore files are as follows:

- .gitignore
- CHANGELOG.md
- CODEOWNERS
- Jenkinsfile
- pull_request.md
- README.md
- renovate.json
- \*\*/UPGRADE.md

Ignore file definitions do not affect manually triggered builds.

### <a name="release-builds">Release Builds</a>

Determines which branches trigger a RELEASE build. You may need to update "Build strategies" in your Jenkins project
configuration in order to automatically build the RELEASE. Many project configurations only enable _master_ branch.

```groovy
release: [
  // Regular expression to determine which branch triggers a release build
  branch: 'master|release/.*'
]
```

If Jenkins triggers a RELEASE build, then subsequent deploys use the RELEASE artifact.

Pull request builds never trigger a RELEASE.

A build containing changes to only ignore files will not perform any actions. See [Ignore Files](#ignore-files).

A build triggered by a maven release commit (a commit containing `[maven-release-plugin]`) will not perform any actions. The
build display name will include `No build: Maven release commit`.

### <a name="liquibase">Liquibase</a>

The artifacts containing liquibase migration files. The `liquibase` property is only required if an artifact other
than your service artifact contains the liquibase migration or you have multiple artifacts with liquibase migrations.
If the `liquibase` property does not exist, the pipeline attempts to run liquibase using your service's artifact.

If `<artifact>/configs/template-liquibase.yaml` exists then the pipeline runs liquibase.

```groovy
liquibase: [
  artifacts: [ 'pipeline-test-migration' ]
]
```

### <a name="postman">Postman</a>

The artifacts containing postman service test scripts. The root pom must contain a property named 'postman.service-test.module' that defines the artifact id for the postman service test.
The postman service test pom should also contain a property 'collections.to.run' that list the postman collection files names.

Example, [postman.service-test.module](https://stash.cvent.net/projects/API/repos/universal-event/browse/pom.xml), [collections.to.run](https://stash.cvent.net/projects/API/repos/universal-event/browse/universal-event-service-test/pom.xml)

See [Setup Service Testing](https://wiki.cvent.com/display/RD/Testing) for more information on setting up your project to support postman
service testing.

### <a name="ci">CI</a>

Contains the configuration which determines which branch to build and deploy to CI.

- _branch_ (regex) - A regular expression matched against BRANCH_NAME
- _environments_ (String/Array) - A String or Array containing one or more environments to deploy the service
- _shutdown_ (boolean) - True to shutdown the service after running integration tests (Default: true)

The deploy occurs on the first entry which matches BRANCH_NAME.

```groovy
ci: [
  builds: [
    // Deploys branch ci447 to S447 and the service continues to run
    [ branch: 'ci447', environments: 'S447', shutdown: false ],

    // Deploy every branch to the ci environment.
    // This entry must come last otherwise ci447 branch will deploy to ci instead of S447.
    // Stops the service after running integration tests
    [ branch: '.*', environments: 'ci' ]
  ]
]
```

If the pipeline does not contain a `ci` property, then the pipeline will default to:

```groovy
builds: [
  [ branch: '.*', environments: 'ci' ]
]
```

### <a name="alpha-staging">Alpha/Staging</a>

Contains the configuration which determines which branch to build and deploy after running CI.

If the pipeline does not contain `builds`, then no alpha/staging deploy occurs.

- _branch_ (regex) - A regular expression matched against BRANCH_NAME
- _environments_ (String/Array) - A String or Array containing one or more environments to deploy the service

The deploy occurs on the first entry which matches BRANCH_NAME.

```groovy
builds: [
  builds: [
    // Deploys branches matching a regular expression to multiple silos
    [ branch: 'devsilo.*', environments: [ 'S413', 'S447' ] ],

    // Deploys "dev" and "develop" branch to "S412"
    [ branch: 'dev|develop', environments: 'S412' ],

    // Deploys "master" and "release/.*' branches to "sg50"
    // When deploying to staging, you should ensure your release property has the same branch regex
    [ branch: 'master|release/.*', environments: 'sg50' ]
  ]
]
```

### <a name="unit-and-integration-tests">Unit and Integration Tests</a>

Unit and Integration test results are displayed under the same _Test Results_ Jenkins link. Integration tests are
suffixed with the environment.

In the following example `PipelineTestServiceConfigurationTest` is a unit test and `PipelineTestEndpointTestIT(ci)`
is an integration test run in the `ci` environment.

![Test Results](dropwizardPipeline-test-results.png)

Some services run integration tests in CI with custom environments like `ci-S408`. Each build entry supports
an `it_environments` property to specify environments that differ from the deployment environment. If the `it_environments`
property does not exist then integration tests use the deployment environment.

```groovy
// devsilo408 branch will deploy to S408 and integration tests will run using ci-S408 as the environment
ci: [
  [ branch: 'devsilo408', environments: 'S408', it_environments: 'ci-S408' ]
]
```

If you want to run your integration tests sequentially for a branch that specifies multiple
environments then use the configuration parallelTests = false.

```groovy
builds: [
  builds: [
    // Deploys "master" and "release/.*' branches to "sg50"
    // When deploying to staging, you should ensure your release property has the same branch regex
    [ branch: 'master|release/.*', environments: [ 'sg50', 'ld50' ], parallelTests: false ]
  ]
]
```

### <a name="load-tests">Load Tests</a>

Gatling load tests are supported. Load tests will run if your service contains a build-load.sh file and the POM file
contains a "modules.to.load-test" property. If the modules listed either contain an \$environment.test.yaml file or an
environment is listed in the module's environments.txt file then load tests will run (identical mechanism to integration
tests). If you would like load tests to run using a different environment from the one being deployed to, then
"load_environments" can be specified. Example:

```groovy
builds: [
  builds: [
    # Build is deployed to ld50, load tests are executed using L2, hence L2.test.yaml.
    [ branch: 'master|release/.*', environments: 'ld50', load_environments: 'L2' ],
  ]
]
```

The Gatling HTML report showing performance results is published to Jenkins and should be visible under
the icon resembling the Gatling logo when viewing your build. When Gatling assertions fail this will result in your
build failing (that's desirable / by design to enforce performance requirements specified in your tests being met).

For more information see [here](https://wiki.cvent.com/display/RD/Gatling)

### <a name="code-coverage">Code Coverage</a>

Every build runs [Jacoco](https://www.jacoco.org/jacoco/trunk/index.html) to determine code coverage.

By default code coverage results are uploaded to [Sonar](http://sonar.core.cvent.org/) for RELEASE builds. You
can configure both RELEASE and SNAPSHOT Sonar uploads with the following:

```groovy
release: [
  branch: 'master',
  sonar: true
],
snapshot: [
  sonar: false // Default is false
]
```

### <a name="checkmarx">Checkmarx</a>

Checkmarx scans are performed in parallel with the SNAPSHOT/RELEASE builds

```groovy
// By default checkmarx is disabled
// https://wiki.cvent.com/display/DEV/Checkmarx+Teams+and+Scan+Preset
// syncMode - enabled by default but you can opt out by setting it to false.
// With syncMode enabled build waits for Checkmarx scan to finish to obtain/show results in build output.
// When turned off, build only upload source code to checkmarx and doesn't wait for results.
// ** WARNING **
// If an application is already created in Checkmarx and team/preset are added at a
// later point, make those changes for team/preset in Checkmarx application first
//  to match what will be specified in Jenkinsfile. Otherwise a new application
//  with same name but different team/preset will be created in Checkmarx

checkmarx: [
  branch: 'master|dev',
  syncMode: true,
  teamValue: '10c6f1f8-2a2d-46fb-b367-6a3195bde7c6',
  presetValue: '100011'
]
```

### <a name="ready-api">Ready API</a>

Run Ready API tests by calling https://qe-jenkins.core.cvent.org/job/runAPI/

Ready API supports both project level configuration and per branch configuration. Branch configuration parameters
override project parameters. The configuration supports all the parameters of the runAPI Jenkins job.

Parameters:

- _apiProject_ - Ready API project name
- _branch_ - Ready API branch
- _syncMode_ (default: true) - If true wait until the Ready API job completes otherwise asynchronously run the Ready API job

```groovy
// Project configuration
readyApi: [
  apiProject: 'falcon-planner'
]

// Branch configuration
builds: [
  [ branch: 'devsilo439', environments: 'S439', readyApi: [ branch: 's439' ]],
  [ branch: 'master', environments: 'sg50', readyApi: [ branch: 'master', apiProject: 'foobar', syncMode: false ]]
]
```

### <a name="planner-tools-ui-test">Planner Tools UI Test</a>

Run Web UI tests by calling https://mobile-jenkins.core.cvent.org/job/pt-web-ui-automation-ci/

Web UI test supports both project level configuration and per branch configuration. Branch configuration parameters
override project parameters. The configuration supports all the parameters of the pt-web-ui-automation-ci Jenkins job.

Parameters:

- _tests_ (String) - Web UI tests name
- _branch_ - Web UI tests branch
- _environment_ - Environment to run tests
- _thread_count_ - Number of threads to run with (e.g thread_count: '1')
- _syncMode_ (default: true) - If true wait until the Ready API job completes otherwise asynchronously run the Ready API job

```groovy
// Project configuration
plannerTools: [
  tests: '@user-api'
]

// Branch configuration
builds: [
  // Waits for planner tools tests to complete
  [ branch: 'devsilo439', environments: 'S439', plannerTools: [ branch: 'develop' ]],

  // Kicks off planner tools tests asynchronously
  [ branch: 'master', environments: 'sg50', plannerTools: [ branch: 'develop', tests: '@user-api', syncMode: false ]]
]
```

### <a name="cloudformation">Cloudformation</a>

The pipeline also supports deploying cloudformation and lambdas that are included in your project. The cloudformation
is deployed after the service is deployed to ECS. When the scripts run both a cloudformation
[package](https://docs.aws.amazon.com/cli/latest/reference/cloudformation/package.html)
and [deploy](https://docs.aws.amazon.com/cli/latest/reference/cloudformation/deploy/index.html) are executed. A
package is done in case there are lambda functions or artifacts that need to be uploaded to S3 so the cloudformation
can refer to the S3 artifacts.

In order to enable Cloudformation deployments, you must specify which branches should execute deployments.
This is done in order to prevent deployment "thrashing"; where two developers are out of sync and Cloudformation
changes are repeatedly applied and removed. By selecting a central branch or branches, you prevent this.
During builds for other branches, Cloudformation is still validated for correctness and deployability
(via --no-execute-changeset).

Example: [universal-auth example](https://stash.cvent.net/projects/API/repos/universal-auth/browse/cloudformation/pom.xml#42)

### <a name="node">Node</a>

The pipeline will run `nvm use` if the service repository contains a `.nvmrc` file.

[dropwizard-jenkins](https://stash.cvent.net/projects/DOC/repos/dropwizard-jenkins/browse/install-node.sh) contains the supported
versions of node. Please open a pull request if your service requires a different version.

### <a name="jenkins">Jenkins</a>

This pipeline takes advantage of the [Bitbucket Branch Source Plugin](https://wiki.cvent.com/display/RD/Jenkinsfiles+and+Bitbucket+Integration).
If your project is not configured with this plugin, please reach out to #tech-jenkinsfile in Slack.

Remove your custom Jenkins jobs and the jobs created by dropkick (eg. foo-service-ci and foo-service-release) after
upgrading to this pipeline.

### <a name="jenkins-job-build-parameters">Jenkins Job Build Parameters</a>

**RELEASE**

Forces the pipeline to build a Maven release artifact. Do not use unless absolutely necessary. Instead use the `release`
property in the Jenkinsfile to standardize a service's release branches.

**HOGAN_CONFIGS_BRANCH**

Hogan configs branch to use during deployments. Useful to test configuration changes.

**VERBOSE_LOGGING**

Enables verbose logging in the deployment scripts.

**DEPLOY_SERVICE_ECS_TAG**

Do not use. This is only recommended when developing changes to the [deploy-service-ecs](https://stash.cvent.net/projects/DEP/repos/deploy-service-ecs/browse)
repository in conjunction with this pipeline.

**HOGAN_BRANCH**

Hogan branch to convert to git SHA for deploy time configuration. The default value for this is "master"

**HOGAN_GIT_SHA**

Hogan git SHA for deploy time configuration. Takes priority over HOGAN_BRANCH

**DEPLOY_AWS_DOCKER_BRANCH**

Do not use. This is only recommended when developing changes to the [deploy-aws-docker](https://stash.cvent.net/projects/DEP/repos/deploy-aws-docker/browse)
repository in conjunction with this pipeline.

**ENVIRONMENT**

Overrides the alpha/staging deployment environment defined in the Jenkinsfile. Not recommended for use.

See [Add deploy environment as parameter to dropwizard pipeline](adr/0003-add-deploy-environment-as-parameter-to-dropwizard-pipeline.md)

**CLOUDFORMATION_DEPLOY**
Overrides the Cloudformation section, running Cloudformation deployments at all points during a build.

This can be useful when you need to deploy changes as part of your pull request, and cannot wait for it to be merged to master.

### <a name="faq">FAQ</a>

#### Why do integration tests fail to resolve dependencies?

```
15:06:44 [ERROR] Failed to execute goal on project survey-data-loader-integration-test:
Could not resolve dependencies for project com.cvent.survey-data-loader:survey-data-loader-integration-test:jar:1.1.13-SNAPSHOT:
Could not find artifact com.cvent.survey-data-loader:survey-data-loader-java-client:jar:1.1.13-SNAPSHOT in nexus (http://nexus.core.cvent.org:8081/nexus/content/groups/public) -> [Help 1]
```

Service pom.xml files contain a `run-it` profile used to execute integration tests. In order to ensure the tests are run
properly you must add any dependent child modules to the `run-it` profile. In most cases, adding the
`service-api` and the `service-java-client` to the `run-it` profile _modules_ tag in your root pom.xml file will solve
problem.

As of 2019-02-19 dropkick ensures these modules are included in the run-it profile.

#### Why doesn't Jenkins automatically build my branch?

The organization/bitbucket project's configuration within Jenkins ultimately determines which branches to automatically build.
Ensure the configuration contains an entry for each branch mentioned in your Jenkinsfile.

![Jenkins Build Strategies](dropwizardPipeline-build-strategies.png)

#### Unable to find module

The pipeline expects each service module to live in its own directory, not the root.

```
# Incorrect directory structure
pom.xml
src/main/java/

# Correct directory structure
pom.xml
my-awesome-service/pom.xml
my-awesome-service/src/main/java
```

#### Cannot stat jar file: No such file or directory

Example `cp: cannot stat '/home/jenkins/workspace/_Network_nso-service_maintenance/nso-service-web/target/nso-service-web-1.6.19-SNAPSHOT.jar': No such file or directory`

Possible solutions:

- Ensure your pom.xml does not specify `finalName`
  ```xml
  <build>
    <!-- Remove this property!!! -->
    <finalName>my-awesome-service</finalName>
  </build>
  ```
- Ensure every pom.xml in your project contains the same version. The pipeline determines the version of the service
  from the root pom.xml file. This error will occur if the root and service pom.xml files have different versions.

#### "no main manifest attribute" when running liquibase migration

Ensure your `run-it` maven profile does not contain your consumer and service modules. This error occurs because the
integration tests end up building a non-shaded service jar file. When liquibase attempts to run it fails because the
service jar is missing its dependencies and a correct MANIFEST.MF file.

Example PR with a fix, https://stash.cvent.net/projects/CSN/repos/venue-cluster/pull-requests/191/overview

#### How do I rebuild the service?

Always use `Rebuild`, do not use `Retry` or `Replay` Jenkins links.

#### How do I build a RELEASE version?

Most of the time the pipeline should take the correct action and build a RELEASE version when the release branch is updated.

However sometimes the build fails in which case you can force a RELEASE version.

1. Select the branch to build in Jenkins
1. Click `Build with Parameters`
1. Check the `RELEASE` checkbox
1. Click `Build'

This works on any branch not only the branches specified as release branches.

#### How do I deploy to a custom environment?

1. Select the branch to build in Jenkins
1. Click `Build with Parameters`
1. Specify the environment in the `ENVIRONMENT` field
1. Click `Build'

This currently does not work on release branches, https://jira.cvent.com/browse/SRE-13277

### <a name="best-practices">Best Practices</a>

#### Remove obsolete build scripts

`build.sh`, `build-release.sh`, `jenkins.sh`, `build-it.sh`, and `build-st.sh` are no longer required.

#### Remove obsolete Jenkins jobs

These are usually named like `foo-service-ci` and `foo-service-release`. The pipeline replaces the functionality in
these jobs.

#### Code Coverage

The pipeline uses [jacoco](https://www.jacoco.org/jacoco/trunk/index.html) for code coverage.

- Remove all references to `clover` in your pom.xml files. Also remove any profiles named `coverage`.
- If you're on Dropwizard 1.3, then update to the latest [mono-java](https://stash.cvent.net/projects/COM/repos/mono-java/browse)
- If you're on Dropwizard 0.7, then update to maven-parent 4.2.2 for java8 or 5.0.6 for java11.

If you're currently on maven-parent 3.x and are unable to upgrade, copy https://stash.cvent.net/projects/DPR/repos/maven-parent/browse/pom.xml#34-37
and https://stash.cvent.net/projects/DPR/repos/maven-parent/browse/pom.xml#61-112 into your root pom.xml. This will enable jacoco
code coverage.

To update jacoco code coverage limits specify the following properties in your root pom.xml file.

```xml
<properties>
  <!-- default values inherited from maven-parent -->
  <jacoco.lineCoverage>0.60</jacoco.lineCoverage>
  <jacoco.branchCoverage>0.40</jacoco.branchCoverage>
  <jacoco.instructionCoverage>0.80</jacoco.instructionCoverage>
</properties>
```

#### Branches

Use consistent branch names. Name your branches following the pattern `devsiloNNN (devsilo412)` not branches named
after your sprint team name. This makes it easy to correspond branches with deployed environments and easy to
configure Jenkins build strategy (eg. `^devsilo\d+\$).

Deploy all branches to CI. This is the default behavior of the pipeline. Some teams need custom CI behavior, for example,
https://stash.cvent.net/projects/OSLO/repos/event-guestside/browse/Jenkinsfile#21. However even in these cases there's a final
entry for all branches.

Use the top level `builds` property to determine which branch to deploy to which silo.

In the following Jenkinsfile changes to master branch will build a RELEASE. See [Release Builds](#release-builds) for
exceptions.

```groovy
release: [
  branch: 'master'
]
ci: [
  // PRs and branches (determined by build strategy configuration) will deploy to CI
  builds: [
    [ branch: '.*', environments: 'ci' ]
  ]
],
builds: [
  // Consistent silo branch names. Merges to devsiloNNN will deploy SNAPSHOTs to the corresponding silo
  [ branch: 'devsilo408', environments: 'S408' ],
  [ branch: 'devsilo420', environments: 'S420' ],

  // Changes to master branch will build and deploy a RELEASE build to sg50 and L2 environments.
  [ branch: 'master', environments: [ 'sg50', 'L2' ]
]
```

#### Remove merged branches

Once a day Jenkins scans all the project repositories to find any new Jenkinsfiles. Please remove unused branches or
branches that have been merged to master.

The following script will output all branches that were merged to master. Run with "-d" to delete the branches.

```shell script
#!/bin/sh

BRANCH=master

# Branches to ignore
IGNORE='(>|^master.*$|dev|^silo\d+)'

while getopts "b:d" OPTION; do
  case "$OPTION" in
    b)
      BRANCH="$OPTARG"
      ;;
    d)
      DELETE=1
      ;;
    *)
      echo "Incorrect options provided"
      exit 1
      ;;
  esac
done

if [ -n "$DELETE" ]; then
  git co "$BRANCH" > /dev/null && git branch -r --merged |
    grep origin |
    xargs -L1 |
    cut -d"/" -f2- |
    grep -vE "$IGNORE" |
    xargs -n 100 git push origin --delete
else
  git co "$BRANCH" > /dev/null && git branch -r --merged |
    grep origin |
    xargs -L1 |
    cut -d"/" -f2- |
    grep -vE "$IGNORE"
fi
```

### <a name="help">Help</a>

- [#tech-build-and-deploy](https://slack.com/app_redirect?team=TCCMVR5Q8&channel=CHTB4CLSC) for build and deploy issues
- [#tech-dropwizard](https://slack.com/app_redirect?team=TCCMVR5Q8&channel=CH4RQKXQU) for dropwizard help
- [#tech-dropwiz-pipeline](https://slack.com/app_redirect?team=TCCMVR5Q8&channel=CKK80JC0P) for pipeline issues
- [Jenkinsfile and Bitbucket Integration](https://wiki.cvent.com/display/RD/Jenkinsfiles+and+Bitbucket+Integration)
- [Tech Talk](https://cvent.box.com/s/r879aviq4buznzbv9y0s7uylnjkmd2yi) and [Slides](https://cvent.box.com/s/w689x91kuqawt6f5olnnjxwu6e5nnlzp)
