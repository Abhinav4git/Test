# 2. Create dropwizard pipeline which builds everything inline

Date: 2019-03-16

## Status

Accepted

## Context

Our Jenkins jobs currently call many other jobs in order to build and deploy a dropwizard service. This has
a number of disadvantages.

- Downstream jobs have a different lifecycle from the parent job
- Test results are scattered across multiple jobs
- Time is wasted waiting for an executor to run downstream jobs
- The same repositories are checked out many times across jobs (eg. hogan-configs)
- Possible deadlock in available executors depending on when downstream jobs run

## Decision

Create a new pipeline which runs everything from the same Jenkins script. This removes the necessity to call
downstream jobs.

## Consequences

Running everything from the same script will produce faster builds, better job lifecycle management,
a centralized location for all unit test and integration test results, and remove the need for
repositories to contain custom scripts (eg. build-release.sh, jenkins.sh)
