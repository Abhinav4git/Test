# 3. Add deploy environment as parameter to dropwizard pipeline

Date: 2019-06-28

## Status

Accepted

## Context

Dropwizard pipeline uses a fixed set of rules within a Jenkinsfile to determine the environment when deploying a branch.
This is the recommended approach for teams to follow. It maintains consistency and documentation on each service's
branch and deployment strategy.

However, in some cases teams need to deploy branches not based on a fixed set of rules but dynamically.

- A developer wants to run some test code that hits OSS or CrowdCompass.
- A branch integrates with Amex APIs but the prod silo does not have the required setup.
- A developer wants to test a template.yaml change with a corresponding hogan configuration.
- Another team may need a temporary deployment of the service to their silo to test an integration.

## Decision

Add an `ENVIRONMENT` build parameter to the dropwizard pipeline. If `ENVIRONMENT` is non-empty, the pipeline will honor
the `ci` deployments, however, it will ignore the alpha/staging deployments and instead deploy to the specified `ENVIRONMENT`.

The pipeline will fail if the `ENVIRONMENT` build parameter contains a production environment.

## Consequences

Teams may end up relying on the `ENVIRONMENT` build parameter as a crutch instead of taking the time to determine a
consistent branch and deploy strategy.

It is highly recommended that teams setup different branches specified in their Jenkinsfile to handle all their deployments.
For example, create `devsiloNNN` or `release/v\d+` branches with deployment rules.

```groovy
builds: [
  [ branch: 'devsilo413', environments: 'S413' ],
  [ branch: 'release/v\d+', environments: 'S521' ],
  [ branch: 'master', environments: 'sg50' ]
]
```
