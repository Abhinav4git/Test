# javaLibraryPipeline

The _javaLibraryPipeline_ supports building Java libraries using Maven.

- [Example](#example)
- [Definitions](#definitions)
- [Build Order](#build-order)
- [Slack Notification](#slack-notification)
- [Ignore Files](#ignore-files)
- [Release Builds](#release-builds)
- [Unit and Integration Tests](#unit-and-integration-tests)
- [Code Coverage](#code-coverage)
- [Checkmarx](#checkmarx)
- [Jenkins](#jenkins)
- [Jenkins Job Build Parameters](#jenkins-job-build-parameters)

### <a name="example">Example</a>

```groovy
#!/usr/bin/env groovy

@Library('pipeline-utils') _

javaLibraryPipeline([
  // Optional. Files in the change set that match any files and/or directories and/or patterns in this list will NOT
  // trigger automatic snapshot/release builds.
  //
  // Each entry in the array must adhere to a file/directory matching pattern that may optionally include
  // wildcards ('*', '**' or '?').
  //
  // The wildcard character '*' within the pattern matches a sequence of zero or more characters within a single file
  // or directory name in the input string. It does not match a sequence of two or more dir/file names. For instance,
  // 'a*b' matches 'a12345b' and 'ab', but does NOT match 'a/b' or 'a123/b'.
  //
  // The '**' wildcard matches any sequence of zero or more path segments in the input string, including directory names
  // and separators. It matches any part of the directory tree. For instance, 'a/**/b' matches 'a/11/b' and 'a/1/2/3/b'.
  //
  // The wildcard character '?' within the pattern matches exactly one character in the input string, excluding the
  // normalized file separator character ('/').
  //
  // All matching is case-insensitive!
  //
  // See https://confluence.atlassian.com/fisheye/pattern-matching-guide-960155410.html for more details
  //
  // The following files are ignored by default:
  // - .gitignore
  // - CHANGELOG.md
  // - CODEOWNERS
  // - Jenkinsfile
  // - pull_request.md
  // - README.md
  // - renovate.json
  ignoreFiles: [
    'package.json',
    'temp*',
    'example/dir'
  ],

  // If a release branch is built then subsequent deploys use the RELEASE version, otherwise deploys use the SNAPSHOT
  release: [
    // Regular expression to determine which branch triggers a release build
    branches: 'master|release/.*'
  ],

  slack_channel: 'test-deploy',

  // Optional. Enable to run a Checkmarx scan.
  // https://wiki.cvent.com/display/DEV/Checkmarx+Teams+and+Scan+Preset
  checkmarx: [
    branch: 'master|dev',
    syncMode: true,
    teamValue: '10c6f1f8-2a2d-46fb-b367-6a3195bde7c6',
    presetValue: '100011'
  ],

  // Use jacoco instead of the default clover
  coverage: 'jacoco'
])
```

### <a name="definitions">Definitions</a>

- BRANCH_NAME - The service repository's branch to build and deploy. If building a PR branch, then BRANCH_NAME equals
  the target branch.

### <a name="build-order">Build Order</a>

1. Checkout dependent repositories
1. Build a SNAPSHOT or RELEASE build depending on `release` property's branch regex
   1. In parallel, run checkmarx if it is enabled for the branch
1. If a RELEASE build upload code coverage results to sonar
1. Notify Slack based on `slack` branch specification

### <a name="slack-notification">Slack Notification</a>

Only RELEASE builds send a notification to Slack.

```groovy
slack_channel: 'test-deploy'
```

### <a name="ignore-files">Ignore Files</a>

A build triggered by a commit which contains changes only to the default ignore files and/or custom ignore files will not perform any actions. The build display name will include
`No build: Changeset contains only ignored files`

**This applies to both SNAPSHOT and RELEASE builds.**

See the [example Jenkinsfile](#example) above for more info on defining custom ignore files.

The default ignore files are as follows:

- .gitignore
- CHANGELOG.md
- CODEOWNERS
- Jenkinsfile
- pull_request.md
- README.md
- renovate.json
- \*\*/UPGRADE.md

Ignore file definitions do not affect manually triggered builds.

### <a name="release-builds">Release Builds</a>

Determines which branches trigger a RELEASE build. You may need to update "Build strategies" in your Jenkins project
configuration in order to automatically build the RELEASE. Many project configurations only enable _master_ branch.

```groovy
release: [
  // Regular expression to determine which branch triggers a release build
  branches: [ 'master|release/.*' ]
]
```

If Jenkins triggers a RELEASE build, then subsequent deploys use the RELEASE artifact.

Pull request builds never trigger a RELEASE.

A build containing changes to only ignore files will not perform any actions. See [Ignore Files](#ignore-files).

A build triggered by a maven release commit (a commit containing `[maven-release-plugin]`) will not perform any actions. The
build display name will include `No build: Maven release commit`.

### <a name="unit-tests">Unit Tests</a>

Unit test results are displayed under the same _Test Results_ Jenkins link.

### <a name="code-coverage">Code Coverage</a>

By default code coverage is performed using Clover. However, jacoco is available too.

```groovy
coverage: 'jacoco'
```

By default code coverage results are uploaded to [Sonar](http://sonar.core.cvent.org/) for RELEASE builds. You
can configure both RELEASE and SNAPSHOT Sonar uploads with the following:

```groovy
release: [
  branch: 'master',
  sonar: true
],
snapshot: [
  sonar: false // Default is false
]
```

### <a name="checkmarx">Checkmarx</a>

Checkmarx scans are performed in parallel with the SNAPSHOT/RELEASE builds

```groovy
// By default checkmarx is disabled
// https://wiki.cvent.com/display/DEV/Checkmarx+Teams+and+Scan+Preset
// syncMode - enabled by default but you can opt out by setting it to false.
// With syncMode enabled build waits for Checkmarx scan to finish to obtain/show results in build output.
// When turned off, build only upload source code to checkmarx and doesn't wait for results.
// ** WARNING **
// If an application is already created in Checkmarx and team/preset are added at a
// later point, make those changes for team/preset in Checkmarx application first
//  to match what will be specified in Jenkinsfile. Otherwise a new application
//  with same name but different team/preset will be created in Checkmarx

checkmarx: [
  branch: 'master|dev',
  syncMode: true,
  teamValue: '10c6f1f8-2a2d-46fb-b367-6a3195bde7c6',
  presetValue: '100011'
]
```

### <a name="jenkins">Jenkins</a>

This pipeline takes advantage of the [Bitbucket Branch Source Plugin](https://wiki.cvent.com/display/RD/Jenkinsfiles+and+Bitbucket+Integration).
If your project is not configured with this plugin, please reach out to #tech-jenkinsfile in Slack.

Remove your custom Jenkins jobs and the jobs created by dropkick (eg. foo-library-ci and foo-library-release) after
upgrading to this pipeline.

### <a name="jenkins-job-build-parameters">Jenkins Job Build Parameters</a>

**RELEASE**

Forces the pipeline to build a Maven release artifact. Do not use unless absolutely necessary. Instead use the `release`
property in the Jenkinsfile to standardize a service's release branches.
